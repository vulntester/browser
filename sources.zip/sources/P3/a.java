package P3;

import V3.b;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public final int f7326a;

    /* renamed from: b  reason: collision with root package name */
    public final int f7327b;

    public a(int i10, int i11) {
        this.f7326a = i10;
        this.f7327b = i11;
    }

    public abstract void a(b bVar);
}
