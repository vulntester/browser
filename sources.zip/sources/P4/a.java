package P4;

import A4.f;
import A4.o;
import U4.b;
import U4.c;
import U4.i;
import U4.j;
import U4.k;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Bitmap;
import android.os.Build;
import android.view.View;
import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1337o;
import java.util.LinkedHashMap;
import ya.C5007D;
import z4.C3562e;
import z4.m;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final m f7328a;

    /* renamed from: b  reason: collision with root package name */
    public final i f7329b;

    public a(m mVar, U4.a aVar) {
        i iVar;
        this.f7328a = mVar;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 26) {
            boolean z10 = j.f10479a;
        } else if (!j.f10479a) {
            if (i10 == 26 || i10 == 27) {
                iVar = new o(12);
            } else {
                iVar = new k(true);
            }
            this.f7329b = iVar;
        }
        iVar = new k(false);
        this.f7329b = iVar;
    }

    public static C1333k a(f fVar) {
        Context context;
        f fVar2 = fVar.f7340c;
        if (fVar2 instanceof R4.a) {
            context = ((R4.a) fVar2).getView().getContext();
        } else {
            context = fVar.f7338a;
        }
        while (!(context instanceof C1337o)) {
            if (!(context instanceof ContextWrapper)) {
                return null;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return ((C1337o) context).W();
    }

    public static boolean b(f fVar, Bitmap.Config config) {
        if (!b.a(config)) {
            return true;
        }
        if (!((Boolean) z4.f.a(fVar, h.f7411f)).booleanValue()) {
            return false;
        }
        f fVar2 = fVar.f7340c;
        if (!(fVar2 instanceof R4.a)) {
            return true;
        }
        View view = ((R4.a) fVar2).getView();
        if (!view.isAttachedToWindow() || view.isHardwareAccelerated()) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0059  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x005b  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0090  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00a5  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final P4.m c(P4.f r12, Q4.h r13) {
        /*
            r11 = this;
            P4.m r0 = new P4.m
            z4.e$b<android.graphics.Bitmap$Config> r1 = P4.h.f7407b
            java.lang.Object r2 = z4.f.a(r12, r1)
            android.graphics.Bitmap$Config r2 = (android.graphics.Bitmap.Config) r2
            z4.e$b<java.lang.Boolean> r3 = P4.h.f7412g
            java.lang.Object r4 = z4.f.a(r12, r3)
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            boolean r4 = r4.booleanValue()
            z4.e$b<java.util.List<S4.a>> r5 = P4.g.f7402a
            java.lang.Object r6 = z4.f.a(r12, r5)
            java.util.List r6 = (java.util.List) r6
            boolean r6 = r6.isEmpty()
            r7 = 0
            r8 = 1
            if (r6 != 0) goto L_0x0037
            android.graphics.Bitmap$Config[] r6 = U4.t.f10494a
            java.lang.Object r9 = z4.f.a(r12, r1)
            android.graphics.Bitmap$Config r9 = (android.graphics.Bitmap.Config) r9
            boolean r6 = ya.m.B(r9, r6)
            if (r6 == 0) goto L_0x0035
            goto L_0x0037
        L_0x0035:
            r6 = r7
            goto L_0x0038
        L_0x0037:
            r6 = r8
        L_0x0038:
            java.lang.Object r9 = z4.f.a(r12, r1)
            android.graphics.Bitmap$Config r9 = (android.graphics.Bitmap.Config) r9
            boolean r9 = U4.b.a(r9)
            if (r9 == 0) goto L_0x005b
            java.lang.Object r9 = z4.f.a(r12, r1)
            android.graphics.Bitmap$Config r9 = (android.graphics.Bitmap.Config) r9
            boolean r9 = b(r12, r9)
            if (r9 == 0) goto L_0x0059
            U4.i r9 = r11.f7329b
            boolean r9 = r9.a(r13)
            if (r9 == 0) goto L_0x0059
            goto L_0x005b
        L_0x0059:
            r9 = r7
            goto L_0x005c
        L_0x005b:
            r9 = r8
        L_0x005c:
            if (r6 == 0) goto L_0x0061
            if (r9 == 0) goto L_0x0061
            goto L_0x0063
        L_0x0061:
            android.graphics.Bitmap$Config r2 = android.graphics.Bitmap.Config.ARGB_8888
        L_0x0063:
            if (r4 == 0) goto L_0x0076
            java.lang.Object r4 = z4.f.a(r12, r5)
            java.util.List r4 = (java.util.List) r4
            boolean r4 = r4.isEmpty()
            if (r4 == 0) goto L_0x0076
            android.graphics.Bitmap$Config r4 = android.graphics.Bitmap.Config.ALPHA_8
            if (r2 == r4) goto L_0x0076
            r7 = r8
        L_0x0076:
            P4.f$b r4 = r12.f7358u
            z4.e r4 = r4.f7391n
            java.util.Map<z4.e$b<?>, java.lang.Object> r4 = r4.f31818a
            z4.e r5 = r12.f7356s
            java.util.Map<z4.e$b<?>, java.lang.Object> r5 = r5.f31818a
            java.util.LinkedHashMap r4 = ya.C5007D.z(r4, r5)
            java.util.LinkedHashMap r4 = ya.C5007D.F(r4)
            java.lang.Object r5 = z4.f.a(r12, r1)
            android.graphics.Bitmap$Config r5 = (android.graphics.Bitmap.Config) r5
            if (r2 == r5) goto L_0x0099
            if (r2 == 0) goto L_0x0096
            r4.put(r1, r2)
            goto L_0x0099
        L_0x0096:
            r4.remove(r1)
        L_0x0099:
            java.lang.Object r1 = z4.f.a(r12, r3)
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            if (r7 == r1) goto L_0x00ac
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r7)
            r4.put(r3, r1)
        L_0x00ac:
            z4.e r10 = new z4.e
            java.util.Map r1 = U4.c.b(r4)
            r10.<init>(r1)
            P4.c r8 = r12.f7348k
            P4.c r9 = r12.f7349l
            android.content.Context r1 = r12.f7338a
            Q4.f r3 = r12.f7354q
            Q4.c r4 = r12.f7355r
            java.lang.String r5 = r12.f7342e
            Uc.n r6 = r12.f7343f
            P4.c r7 = r12.f7347j
            r2 = r13
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: P4.a.c(P4.f, Q4.h):P4.m");
    }

    public final m d(m mVar) {
        C3562e eVar;
        boolean z10;
        C3562e eVar2 = mVar.f7425j;
        C3562e.b bVar = h.f7407b;
        if (!b.a((Bitmap.Config) z4.f.b(mVar, bVar)) || this.f7329b.b()) {
            eVar = eVar2;
            z10 = false;
        } else {
            eVar2.getClass();
            LinkedHashMap F10 = C5007D.F(eVar2.f31818a);
            Bitmap.Config config = Bitmap.Config.ARGB_8888;
            if (config != null) {
                F10.put(bVar, config);
            } else {
                F10.remove(bVar);
            }
            C3562e eVar3 = new C3562e(c.b(F10));
            z10 = true;
            eVar = eVar3;
        }
        if (!z10) {
            return mVar;
        }
        return new m(mVar.f7416a, mVar.f7417b, mVar.f7418c, mVar.f7419d, mVar.f7420e, mVar.f7421f, mVar.f7422g, mVar.f7423h, mVar.f7424i, eVar);
    }
}
