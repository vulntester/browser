package P4;

import ic.C4516m0;
import kotlin.jvm.internal.l;
import xa.C4959D;
import z4.p;

public final class b implements n {

    /* renamed from: f  reason: collision with root package name */
    public final C4516m0 f7330f;

    public /* synthetic */ b(C4516m0 m0Var) {
        this.f7330f = m0Var;
    }

    public final /* synthetic */ void b() {
    }

    public final /* synthetic */ void c() {
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        if (!l.a(this.f7330f, ((b) obj).f7330f)) {
            return false;
        }
        return true;
    }

    public final Object g(p pVar) {
        return C4959D.f44058a;
    }

    public final int hashCode() {
        return this.f7330f.hashCode();
    }

    public final /* synthetic */ void start() {
    }

    public final String toString() {
        return "BaseRequestDelegate(job=" + this.f7330f + ')';
    }
}
