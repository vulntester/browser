package P4;

import A1.a;

public enum c {
    ENABLED(true, true);
    

    /* renamed from: f  reason: collision with root package name */
    public final boolean f7333f;

    /* renamed from: i  reason: collision with root package name */
    public final boolean f7334i;

    static {
        c[] cVarArr;
        a.r(cVarArr);
    }

    /* access modifiers changed from: public */
    c(boolean z10, boolean z11) {
        this.f7333f = z10;
        this.f7334i = z11;
    }
}
