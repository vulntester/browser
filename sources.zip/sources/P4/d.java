package P4;

import ic.J;

public interface d {
    J<i> getJob();
}
