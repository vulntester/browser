package P4;

import kotlin.jvm.internal.l;
import z4.g;

public final class e implements i {

    /* renamed from: a  reason: collision with root package name */
    public final g f7335a;

    /* renamed from: b  reason: collision with root package name */
    public final f f7336b;

    /* renamed from: c  reason: collision with root package name */
    public final Throwable f7337c;

    public e(g gVar, f fVar, Throwable th) {
        this.f7335a = gVar;
        this.f7336b = fVar;
        this.f7337c = th;
    }

    public final g a() {
        return this.f7335a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof e)) {
            return false;
        }
        e eVar = (e) obj;
        if (l.a(this.f7335a, eVar.f7335a) && l.a(this.f7336b, eVar.f7336b) && l.a(this.f7337c, eVar.f7337c)) {
            return true;
        }
        return false;
    }

    public final f getRequest() {
        return this.f7336b;
    }

    public final int hashCode() {
        int i10;
        g gVar = this.f7335a;
        if (gVar == null) {
            i10 = 0;
        } else {
            i10 = gVar.hashCode();
        }
        int hashCode = this.f7336b.hashCode();
        return this.f7337c.hashCode() + ((hashCode + (i10 * 31)) * 31);
    }

    public final String toString() {
        return "ErrorResult(image=" + this.f7335a + ", request=" + this.f7336b + ", throwable=" + this.f7337c + ')';
    }
}
