package P4;

import Ba.h;
import Na.l;
import Q4.i;
import U4.s;
import Uc.C4168n;
import android.content.Context;
import java.util.Map;
import kotlin.jvm.internal.H;
import x.i0;
import ya.C5007D;
import ya.v;
import z4.C3562e;
import z4.g;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final Context f7338a;

    /* renamed from: b  reason: collision with root package name */
    public final Object f7339b;

    /* renamed from: c  reason: collision with root package name */
    public final A4.f f7340c;

    /* renamed from: d  reason: collision with root package name */
    public final Map<String, String> f7341d;

    /* renamed from: e  reason: collision with root package name */
    public final String f7342e;

    /* renamed from: f  reason: collision with root package name */
    public final C4168n f7343f;

    /* renamed from: g  reason: collision with root package name */
    public final h f7344g;

    /* renamed from: h  reason: collision with root package name */
    public final h f7345h;

    /* renamed from: i  reason: collision with root package name */
    public final h f7346i;

    /* renamed from: j  reason: collision with root package name */
    public final c f7347j;

    /* renamed from: k  reason: collision with root package name */
    public final c f7348k;

    /* renamed from: l  reason: collision with root package name */
    public final c f7349l;

    /* renamed from: m  reason: collision with root package name */
    public final l<f, g> f7350m;

    /* renamed from: n  reason: collision with root package name */
    public final l<f, g> f7351n;

    /* renamed from: o  reason: collision with root package name */
    public final l<f, g> f7352o;

    /* renamed from: p  reason: collision with root package name */
    public final i f7353p;

    /* renamed from: q  reason: collision with root package name */
    public final Q4.f f7354q;

    /* renamed from: r  reason: collision with root package name */
    public final Q4.c f7355r;

    /* renamed from: s  reason: collision with root package name */
    public final C3562e f7356s;

    /* renamed from: t  reason: collision with root package name */
    public final c f7357t;

    /* renamed from: u  reason: collision with root package name */
    public final b f7358u;

    public static final class b {

        /* renamed from: o  reason: collision with root package name */
        public static final b f7377o = new b(0);

        /* renamed from: a  reason: collision with root package name */
        public final C4168n f7378a;

        /* renamed from: b  reason: collision with root package name */
        public final h f7379b;

        /* renamed from: c  reason: collision with root package name */
        public final h f7380c;

        /* renamed from: d  reason: collision with root package name */
        public final h f7381d;

        /* renamed from: e  reason: collision with root package name */
        public final c f7382e;

        /* renamed from: f  reason: collision with root package name */
        public final c f7383f;

        /* renamed from: g  reason: collision with root package name */
        public final c f7384g;

        /* renamed from: h  reason: collision with root package name */
        public final l<f, g> f7385h;

        /* renamed from: i  reason: collision with root package name */
        public final l<f, g> f7386i;

        /* renamed from: j  reason: collision with root package name */
        public final l<f, g> f7387j;

        /* renamed from: k  reason: collision with root package name */
        public final i f7388k;

        /* renamed from: l  reason: collision with root package name */
        public final Q4.f f7389l;

        /* renamed from: m  reason: collision with root package name */
        public final Q4.c f7390m;

        /* renamed from: n  reason: collision with root package name */
        public final C3562e f7391n;

        public b() {
            this(0);
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            if (kotlin.jvm.internal.l.a(this.f7378a, bVar.f7378a) && kotlin.jvm.internal.l.a(this.f7379b, bVar.f7379b) && kotlin.jvm.internal.l.a(this.f7380c, bVar.f7380c) && kotlin.jvm.internal.l.a(this.f7381d, bVar.f7381d) && this.f7382e == bVar.f7382e && this.f7383f == bVar.f7383f && this.f7384g == bVar.f7384g && kotlin.jvm.internal.l.a(this.f7385h, bVar.f7385h) && kotlin.jvm.internal.l.a(this.f7386i, bVar.f7386i) && kotlin.jvm.internal.l.a(this.f7387j, bVar.f7387j) && kotlin.jvm.internal.l.a(this.f7388k, bVar.f7388k) && this.f7389l == bVar.f7389l && this.f7390m == bVar.f7390m && kotlin.jvm.internal.l.a(this.f7391n, bVar.f7391n)) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            int hashCode = this.f7379b.hashCode();
            int hashCode2 = this.f7380c.hashCode();
            int hashCode3 = this.f7381d.hashCode();
            int hashCode4 = this.f7382e.hashCode();
            int hashCode5 = this.f7383f.hashCode();
            int hashCode6 = this.f7384g.hashCode();
            int hashCode7 = this.f7385h.hashCode();
            int hashCode8 = this.f7386i.hashCode();
            int hashCode9 = this.f7387j.hashCode();
            int hashCode10 = this.f7388k.hashCode();
            int hashCode11 = this.f7389l.hashCode();
            int hashCode12 = this.f7390m.hashCode();
            return this.f7391n.f31818a.hashCode() + ((hashCode12 + ((hashCode11 + ((hashCode10 + ((hashCode9 + ((hashCode8 + ((hashCode7 + ((hashCode6 + ((hashCode5 + ((hashCode4 + ((hashCode3 + ((hashCode2 + ((hashCode + (this.f7378a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31);
        }

        public final String toString() {
            return "Defaults(fileSystem=" + this.f7378a + ", interceptorCoroutineContext=" + this.f7379b + ", fetcherCoroutineContext=" + this.f7380c + ", decoderCoroutineContext=" + this.f7381d + ", memoryCachePolicy=" + this.f7382e + ", diskCachePolicy=" + this.f7383f + ", networkCachePolicy=" + this.f7384g + ", placeholderFactory=" + this.f7385h + ", errorFactory=" + this.f7386i + ", fallbackFactory=" + this.f7387j + ", sizeResolver=" + this.f7388k + ", scale=" + this.f7389l + ", precision=" + this.f7390m + ", extras=" + this.f7391n + ')';
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public b(int r16) {
            /*
                r15 = this;
                Uc.x r1 = Uc.C4168n.f38341f
                Ba.i r2 = Ba.i.f33491f
                ic.U r0 = ic.U.f41134a
                pc.b r3 = pc.b.f43037f
                P4.c r5 = P4.c.ENABLED
                U4.s$a r8 = U4.s.a.f10493f
                Q4.d r11 = Q4.i.f7760g
                Q4.f r12 = Q4.f.f7750i
                Q4.c r13 = Q4.c.f7744f
                z4.e r14 = z4.C3562e.f31817b
                r4 = r3
                r6 = r5
                r7 = r5
                r9 = r8
                r10 = r8
                r0 = r15
                r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: P4.f.b.<init>(int):void");
        }

        public b(C4168n nVar, h hVar, h hVar2, h hVar3, c cVar, c cVar2, c cVar3, l<? super f, ? extends g> lVar, l<? super f, ? extends g> lVar2, l<? super f, ? extends g> lVar3, i iVar, Q4.f fVar, Q4.c cVar4, C3562e eVar) {
            this.f7378a = nVar;
            this.f7379b = hVar;
            this.f7380c = hVar2;
            this.f7381d = hVar3;
            this.f7382e = cVar;
            this.f7383f = cVar2;
            this.f7384g = cVar3;
            this.f7385h = lVar;
            this.f7386i = lVar2;
            this.f7387j = lVar3;
            this.f7388k = iVar;
            this.f7389l = fVar;
            this.f7390m = cVar4;
            this.f7391n = eVar;
        }
    }

    public static final class c {

        /* renamed from: a  reason: collision with root package name */
        public final Ba.i f7392a;

        /* renamed from: b  reason: collision with root package name */
        public final Ba.i f7393b;

        /* renamed from: c  reason: collision with root package name */
        public final Ba.i f7394c;

        /* renamed from: d  reason: collision with root package name */
        public final c f7395d;

        /* renamed from: e  reason: collision with root package name */
        public final s.a f7396e;

        /* renamed from: f  reason: collision with root package name */
        public final s.a f7397f;

        /* renamed from: g  reason: collision with root package name */
        public final l<f, g> f7398g;

        /* renamed from: h  reason: collision with root package name */
        public final i f7399h;

        /* renamed from: i  reason: collision with root package name */
        public final Q4.f f7400i;

        /* renamed from: j  reason: collision with root package name */
        public final Q4.c f7401j;

        public c(Ba.i iVar, Ba.i iVar2, Ba.i iVar3, c cVar, s.a aVar, s.a aVar2, l lVar, i iVar4, Q4.f fVar, Q4.c cVar2) {
            this.f7392a = iVar;
            this.f7393b = iVar2;
            this.f7394c = iVar3;
            this.f7395d = cVar;
            this.f7396e = aVar;
            this.f7397f = aVar2;
            this.f7398g = lVar;
            this.f7399h = iVar4;
            this.f7400i = fVar;
            this.f7401j = cVar2;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            cVar.getClass();
            if (kotlin.jvm.internal.l.a(this.f7392a, cVar.f7392a) && kotlin.jvm.internal.l.a(this.f7393b, cVar.f7393b) && kotlin.jvm.internal.l.a(this.f7394c, cVar.f7394c) && this.f7395d == cVar.f7395d && kotlin.jvm.internal.l.a(this.f7396e, cVar.f7396e) && kotlin.jvm.internal.l.a(this.f7397f, cVar.f7397f) && kotlin.jvm.internal.l.a(this.f7398g, cVar.f7398g) && kotlin.jvm.internal.l.a(this.f7399h, cVar.f7399h) && this.f7400i == cVar.f7400i && this.f7401j == cVar.f7401j) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            int i10;
            int i11;
            int i12;
            int i13;
            int i14;
            int i15;
            int i16 = 0;
            c cVar = this.f7395d;
            if (cVar == null) {
                i10 = 0;
            } else {
                i10 = cVar.hashCode();
            }
            int i17 = i10 * 961;
            s.a aVar = this.f7396e;
            if (aVar == null) {
                i11 = 0;
            } else {
                i11 = aVar.hashCode();
            }
            int i18 = (i17 + i11) * 31;
            s.a aVar2 = this.f7397f;
            if (aVar2 == null) {
                i12 = 0;
            } else {
                i12 = aVar2.hashCode();
            }
            int i19 = (i18 + i12) * 31;
            l<f, g> lVar = this.f7398g;
            if (lVar == null) {
                i13 = 0;
            } else {
                i13 = lVar.hashCode();
            }
            int i20 = (i19 + i13) * 31;
            i iVar = this.f7399h;
            if (iVar == null) {
                i14 = 0;
            } else {
                i14 = iVar.hashCode();
            }
            int i21 = (i20 + i14) * 31;
            Q4.f fVar = this.f7400i;
            if (fVar == null) {
                i15 = 0;
            } else {
                i15 = fVar.hashCode();
            }
            int i22 = (i21 + i15) * 31;
            Q4.c cVar2 = this.f7401j;
            if (cVar2 != null) {
                i16 = cVar2.hashCode();
            }
            return i22 + i16;
        }

        public final String toString() {
            return "Defined(fileSystem=null, interceptorCoroutineContext=" + this.f7392a + ", fetcherCoroutineContext=" + this.f7393b + ", decoderCoroutineContext=" + this.f7394c + ", memoryCachePolicy=null, diskCachePolicy=" + this.f7395d + ", networkCachePolicy=null, placeholderFactory=" + this.f7396e + ", errorFactory=" + this.f7397f + ", fallbackFactory=" + this.f7398g + ", sizeResolver=" + this.f7399h + ", scale=" + this.f7400i + ", precision=" + this.f7401j + ')';
        }
    }

    public f() {
        throw null;
    }

    public f(Context context, Object obj, A4.f fVar, Map map, String str, C4168n nVar, h hVar, h hVar2, h hVar3, c cVar, c cVar2, c cVar3, l lVar, l lVar2, l lVar3, i iVar, Q4.f fVar2, Q4.c cVar4, C3562e eVar, c cVar5, b bVar) {
        this.f7338a = context;
        this.f7339b = obj;
        this.f7340c = fVar;
        this.f7341d = map;
        this.f7342e = str;
        this.f7343f = nVar;
        this.f7344g = hVar;
        this.f7345h = hVar2;
        this.f7346i = hVar3;
        this.f7347j = cVar;
        this.f7348k = cVar2;
        this.f7349l = cVar3;
        this.f7350m = lVar;
        this.f7351n = lVar2;
        this.f7352o = lVar3;
        this.f7353p = iVar;
        this.f7354q = fVar2;
        this.f7355r = cVar4;
        this.f7356s = eVar;
        this.f7357t = cVar5;
        this.f7358u = bVar;
    }

    public static a a(f fVar) {
        Context context = fVar.f7338a;
        fVar.getClass();
        return new a(fVar, context);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        if (kotlin.jvm.internal.l.a(this.f7338a, fVar.f7338a) && kotlin.jvm.internal.l.a(this.f7339b, fVar.f7339b) && kotlin.jvm.internal.l.a(this.f7340c, fVar.f7340c) && kotlin.jvm.internal.l.a(this.f7341d, fVar.f7341d) && kotlin.jvm.internal.l.a(this.f7342e, fVar.f7342e) && kotlin.jvm.internal.l.a(this.f7343f, fVar.f7343f) && kotlin.jvm.internal.l.a(this.f7344g, fVar.f7344g) && kotlin.jvm.internal.l.a(this.f7345h, fVar.f7345h) && kotlin.jvm.internal.l.a(this.f7346i, fVar.f7346i) && this.f7347j == fVar.f7347j && this.f7348k == fVar.f7348k && this.f7349l == fVar.f7349l && kotlin.jvm.internal.l.a(this.f7350m, fVar.f7350m) && kotlin.jvm.internal.l.a(this.f7351n, fVar.f7351n) && kotlin.jvm.internal.l.a(this.f7352o, fVar.f7352o) && kotlin.jvm.internal.l.a(this.f7353p, fVar.f7353p) && this.f7354q == fVar.f7354q && this.f7355r == fVar.f7355r && kotlin.jvm.internal.l.a(this.f7356s, fVar.f7356s) && kotlin.jvm.internal.l.a(this.f7357t, fVar.f7357t) && kotlin.jvm.internal.l.a(this.f7358u, fVar.f7358u)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i10;
        int hashCode = (this.f7339b.hashCode() + (this.f7338a.hashCode() * 31)) * 31;
        int i11 = 0;
        A4.f fVar = this.f7340c;
        if (fVar == null) {
            i10 = 0;
        } else {
            i10 = fVar.hashCode();
        }
        int hashCode2 = (this.f7341d.hashCode() + ((hashCode + i10) * 29791)) * 31;
        String str = this.f7342e;
        if (str != null) {
            i11 = str.hashCode();
        }
        int hashCode3 = this.f7343f.hashCode();
        int hashCode4 = this.f7344g.hashCode();
        int hashCode5 = this.f7345h.hashCode();
        int hashCode6 = this.f7346i.hashCode();
        int hashCode7 = this.f7347j.hashCode();
        int hashCode8 = this.f7348k.hashCode();
        int hashCode9 = this.f7349l.hashCode();
        int hashCode10 = this.f7350m.hashCode();
        int hashCode11 = this.f7351n.hashCode();
        int hashCode12 = this.f7352o.hashCode();
        int hashCode13 = this.f7353p.hashCode();
        int hashCode14 = this.f7354q.hashCode();
        int hashCode15 = this.f7355r.hashCode();
        int hashCode16 = this.f7356s.f31818a.hashCode();
        return this.f7358u.hashCode() + ((this.f7357t.hashCode() + ((hashCode16 + ((hashCode15 + ((hashCode14 + ((hashCode13 + ((hashCode12 + ((hashCode11 + ((hashCode10 + ((hashCode9 + ((hashCode8 + ((hashCode7 + ((hashCode6 + ((hashCode5 + ((hashCode4 + ((hashCode3 + ((hashCode2 + i11) * 31)) * 29791)) * 31)) * 31)) * 31)) * 31)) * 31)) * 961)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "ImageRequest(context=" + this.f7338a + ", data=" + this.f7339b + ", target=" + this.f7340c + ", listener=null, memoryCacheKey=null, memoryCacheKeyExtras=" + this.f7341d + ", diskCacheKey=" + this.f7342e + ", fileSystem=" + this.f7343f + ", fetcherFactory=null, decoderFactory=null, interceptorCoroutineContext=" + this.f7344g + ", fetcherCoroutineContext=" + this.f7345h + ", decoderCoroutineContext=" + this.f7346i + ", memoryCachePolicy=" + this.f7347j + ", diskCachePolicy=" + this.f7348k + ", networkCachePolicy=" + this.f7349l + ", placeholderMemoryCacheKey=null, placeholderFactory=" + this.f7350m + ", errorFactory=" + this.f7351n + ", fallbackFactory=" + this.f7352o + ", sizeResolver=" + this.f7353p + ", scale=" + this.f7354q + ", precision=" + this.f7355r + ", extras=" + this.f7356s + ", defined=" + this.f7357t + ", defaults=" + this.f7358u + ')';
    }

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final Context f7359a;

        /* renamed from: b  reason: collision with root package name */
        public b f7360b;

        /* renamed from: c  reason: collision with root package name */
        public Object f7361c;

        /* renamed from: d  reason: collision with root package name */
        public A4.f f7362d;

        /* renamed from: e  reason: collision with root package name */
        public boolean f7363e;

        /* renamed from: f  reason: collision with root package name */
        public Map f7364f;

        /* renamed from: g  reason: collision with root package name */
        public String f7365g;

        /* renamed from: h  reason: collision with root package name */
        public Ba.i f7366h;

        /* renamed from: i  reason: collision with root package name */
        public Ba.i f7367i;

        /* renamed from: j  reason: collision with root package name */
        public Ba.i f7368j;

        /* renamed from: k  reason: collision with root package name */
        public c f7369k;

        /* renamed from: l  reason: collision with root package name */
        public final s.a f7370l;

        /* renamed from: m  reason: collision with root package name */
        public final s.a f7371m;

        /* renamed from: n  reason: collision with root package name */
        public l<? super f, ? extends g> f7372n;

        /* renamed from: o  reason: collision with root package name */
        public i f7373o;

        /* renamed from: p  reason: collision with root package name */
        public Q4.f f7374p;

        /* renamed from: q  reason: collision with root package name */
        public Q4.c f7375q;

        /* renamed from: r  reason: collision with root package name */
        public Object f7376r;

        public a(Context context) {
            this.f7359a = context;
            this.f7360b = b.f7377o;
            this.f7361c = null;
            this.f7362d = null;
            this.f7364f = v.f44686f;
            this.f7365g = null;
            this.f7366h = null;
            this.f7367i = null;
            this.f7368j = null;
            this.f7369k = null;
            s.a aVar = s.a.f10493f;
            this.f7370l = aVar;
            this.f7371m = aVar;
            this.f7372n = aVar;
            this.f7373o = null;
            this.f7374p = null;
            this.f7375q = null;
            this.f7376r = C3562e.f31817b;
        }

        public final f a() {
            C3562e eVar;
            Object obj = this.f7361c;
            if (obj == null) {
                obj = k.f7415a;
            }
            Object obj2 = obj;
            A4.f fVar = this.f7362d;
            Map map = this.f7364f;
            if (kotlin.jvm.internal.l.a(map, Boolean.valueOf(this.f7363e))) {
                kotlin.jvm.internal.l.d(map, "null cannot be cast to non-null type kotlin.collections.MutableMap<*, *>");
                map = U4.c.b(H.b(map));
            } else if (!i0.g(map)) {
                throw new AssertionError();
            }
            Map map2 = map;
            kotlin.jvm.internal.l.d(map2, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
            String str = this.f7365g;
            b bVar = this.f7360b;
            C4168n nVar = bVar.f7378a;
            c cVar = bVar.f7382e;
            c cVar2 = this.f7369k;
            if (cVar2 == null) {
                cVar2 = bVar.f7383f;
            }
            c cVar3 = cVar2;
            c cVar4 = bVar.f7384g;
            h hVar = this.f7366h;
            if (hVar == null) {
                hVar = bVar.f7379b;
            }
            h hVar2 = hVar;
            h hVar3 = this.f7367i;
            if (hVar3 == null) {
                hVar3 = bVar.f7380c;
            }
            h hVar4 = hVar3;
            h hVar5 = this.f7368j;
            if (hVar5 == null) {
                hVar5 = bVar.f7381d;
            }
            h hVar6 = hVar5;
            l lVar = this.f7370l;
            if (lVar == null) {
                lVar = bVar.f7385h;
            }
            l lVar2 = lVar;
            l lVar3 = this.f7371m;
            if (lVar3 == null) {
                lVar3 = bVar.f7386i;
            }
            l lVar4 = lVar3;
            l lVar5 = this.f7372n;
            if (lVar5 == null) {
                lVar5 = bVar.f7387j;
            }
            l lVar6 = lVar5;
            i iVar = this.f7373o;
            if (iVar == null) {
                iVar = bVar.f7388k;
            }
            i iVar2 = iVar;
            Q4.f fVar2 = this.f7374p;
            if (fVar2 == null) {
                fVar2 = bVar.f7389l;
            }
            Q4.f fVar3 = fVar2;
            Q4.c cVar5 = this.f7375q;
            if (cVar5 == null) {
                cVar5 = bVar.f7390m;
            }
            Q4.c cVar6 = cVar5;
            Object obj3 = this.f7376r;
            if (obj3 instanceof C3562e.a) {
                C3562e.a aVar = (C3562e.a) obj3;
                aVar.getClass();
                eVar = new C3562e(U4.c.b(aVar.f31819a));
            } else if (obj3 instanceof C3562e) {
                eVar = (C3562e) obj3;
            } else {
                throw new AssertionError();
            }
            C3562e eVar2 = eVar;
            Ba.i iVar3 = this.f7366h;
            Ba.i iVar4 = this.f7367i;
            Ba.i iVar5 = this.f7368j;
            l<? super f, ? extends g> lVar7 = this.f7372n;
            Ba.i iVar6 = iVar4;
            Ba.i iVar7 = iVar5;
            return new f(this.f7359a, obj2, fVar, map2, str, nVar, hVar2, hVar4, hVar6, cVar, cVar3, cVar4, lVar2, lVar4, lVar6, iVar2, fVar3, cVar6, eVar2, new c(iVar3, iVar6, iVar7, this.f7369k, this.f7370l, this.f7371m, lVar7, this.f7373o, this.f7374p, this.f7375q), this.f7360b);
        }

        public final C3562e.a b() {
            Object obj = this.f7376r;
            if (obj instanceof C3562e.a) {
                return (C3562e.a) obj;
            }
            if (obj instanceof C3562e) {
                C3562e eVar = (C3562e) obj;
                eVar.getClass();
                C3562e.a aVar = new C3562e.a(eVar);
                this.f7376r = aVar;
                return aVar;
            }
            throw new AssertionError();
        }

        public final Map<String, String> c() {
            Map map = this.f7364f;
            if (!kotlin.jvm.internal.l.a(map, Boolean.valueOf(this.f7363e))) {
                if (i0.g(map)) {
                    map = C5007D.F(map);
                    this.f7364f = map;
                    this.f7363e = true;
                } else {
                    throw new AssertionError();
                }
            }
            kotlin.jvm.internal.l.d(map, "null cannot be cast to non-null type kotlin.collections.MutableMap<kotlin.String, kotlin.String>");
            return H.b(map);
        }

        public a(f fVar, Context context) {
            this.f7359a = context;
            this.f7360b = fVar.f7358u;
            this.f7361c = fVar.f7339b;
            this.f7362d = fVar.f7340c;
            this.f7364f = fVar.f7341d;
            this.f7365g = fVar.f7342e;
            c cVar = fVar.f7357t;
            cVar.getClass();
            this.f7366h = cVar.f7392a;
            this.f7367i = cVar.f7393b;
            this.f7368j = cVar.f7394c;
            this.f7369k = cVar.f7395d;
            this.f7370l = cVar.f7396e;
            this.f7371m = cVar.f7397f;
            this.f7372n = cVar.f7398g;
            this.f7373o = cVar.f7399h;
            this.f7374p = cVar.f7400i;
            this.f7375q = cVar.f7401j;
            this.f7376r = fVar.f7356s;
        }
    }
}
