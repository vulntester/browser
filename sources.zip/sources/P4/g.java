package P4;

import P4.f;
import Q4.a;
import Q4.b;
import Q4.h;
import S4.a;
import T4.b;
import T4.d;
import java.util.List;
import ya.u;
import z4.C3562e;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public static final C3562e.b<List<a>> f7402a = new C3562e.b<>(u.f44685f);

    /* renamed from: b  reason: collision with root package name */
    public static final C3562e.b<h> f7403b;

    /* renamed from: c  reason: collision with root package name */
    public static final C3562e.b<Boolean> f7404c = new C3562e.b<>(Boolean.FALSE);

    /* renamed from: d  reason: collision with root package name */
    public static final C3562e.b<Boolean> f7405d = new C3562e.b<>(Boolean.TRUE);

    static {
        b.a(4096);
        a.C0077a aVar = new a.C0077a(4096);
        b.a(4096);
        f7403b = new C3562e.b<>(new h(aVar, new a.C0077a(4096)));
    }

    public static final void a(f.a aVar) {
        C3562e.b<d.a> bVar = h.f7406a;
        b.a aVar2 = new b.a(200);
        C3562e.a b10 = aVar.b();
        b10.f31819a.put(h.f7406a, aVar2);
    }
}
