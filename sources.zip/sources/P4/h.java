package P4;

import C4.C0540b;
import P4.f;
import T4.d;
import U4.t;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import androidx.lifecycle.C1333k;
import z4.C3562e;

public final class h {

    /* renamed from: a  reason: collision with root package name */
    public static final C3562e.b<d.a> f7406a = new C3562e.b<>(d.a.f10117a);

    /* renamed from: b  reason: collision with root package name */
    public static final C3562e.b<Bitmap.Config> f7407b = new C3562e.b<>(t.f10495b);

    /* renamed from: c  reason: collision with root package name */
    public static final C3562e.b<ColorSpace> f7408c = new C3562e.b<>(null);

    /* renamed from: d  reason: collision with root package name */
    public static final C3562e.b<Boolean> f7409d;

    /* renamed from: e  reason: collision with root package name */
    public static final C3562e.b<C1333k> f7410e = new C3562e.b<>(null);

    /* renamed from: f  reason: collision with root package name */
    public static final C3562e.b<Boolean> f7411f;

    /* renamed from: g  reason: collision with root package name */
    public static final C3562e.b<Boolean> f7412g = new C3562e.b<>(Boolean.FALSE);

    static {
        Boolean bool = Boolean.TRUE;
        f7409d = new C3562e.b<>(bool);
        f7411f = new C3562e.b<>(bool);
    }

    public static final void a(f.a aVar) {
        C3562e.a b10 = aVar.b();
        b10.f31819a.put(f7411f, Boolean.TRUE);
    }

    public static final Bitmap.Config b(m mVar) {
        return (Bitmap.Config) z4.f.b(mVar, f7407b);
    }

    public static final ColorSpace c(m mVar) {
        return C0540b.b(z4.f.b(mVar, f7408c));
    }
}
