package P4;

import z4.g;

public interface i {
    g a();

    f getRequest();
}
