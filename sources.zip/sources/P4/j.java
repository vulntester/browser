package P4;

import Ca.a;
import U4.n;
import androidx.lifecycle.C1326d;
import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1337o;
import ic.C4516m0;
import java.util.concurrent.CancellationException;
import xa.C4959D;
import z4.p;

public final class j implements n, C1326d {

    /* renamed from: f  reason: collision with root package name */
    public final C1333k f7413f;

    /* renamed from: i  reason: collision with root package name */
    public final C4516m0 f7414i;

    public j(C1333k kVar, C4516m0 m0Var) {
        this.f7413f = kVar;
        this.f7414i = m0Var;
    }

    public final void b() {
        this.f7413f.c(this);
    }

    public final /* synthetic */ void c() {
    }

    public final /* synthetic */ void d(C1337o oVar) {
    }

    public final /* synthetic */ void e(C1337o oVar) {
    }

    public final Object g(p pVar) {
        Object a10 = n.a(this.f7413f, pVar);
        if (a10 == a.f33640f) {
            return a10;
        }
        return C4959D.f44058a;
    }

    public final /* synthetic */ void j(C1337o oVar) {
    }

    public final /* synthetic */ void o(C1337o oVar) {
    }

    public final void p(C1337o oVar) {
        this.f7414i.e((CancellationException) null);
    }

    public final /* synthetic */ void s(C1337o oVar) {
    }

    public final void start() {
        this.f7413f.a(this);
    }
}
