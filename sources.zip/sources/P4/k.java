package P4;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    public static final k f7415a = new Object();

    public final boolean equals(Object obj) {
        if (this != obj && !(obj instanceof k)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return 2113961193;
    }

    public final String toString() {
        return "NullRequestData";
    }
}
