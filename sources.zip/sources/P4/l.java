package P4;

public final class l extends RuntimeException {
}
