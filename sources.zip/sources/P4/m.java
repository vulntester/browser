package P4;

import Q4.c;
import Q4.f;
import Q4.h;
import Uc.C4168n;
import android.content.Context;
import kotlin.jvm.internal.l;
import z4.C3562e;

public final class m {

    /* renamed from: a  reason: collision with root package name */
    public final Context f7416a;

    /* renamed from: b  reason: collision with root package name */
    public final h f7417b;

    /* renamed from: c  reason: collision with root package name */
    public final f f7418c;

    /* renamed from: d  reason: collision with root package name */
    public final c f7419d;

    /* renamed from: e  reason: collision with root package name */
    public final String f7420e;

    /* renamed from: f  reason: collision with root package name */
    public final C4168n f7421f;

    /* renamed from: g  reason: collision with root package name */
    public final c f7422g;

    /* renamed from: h  reason: collision with root package name */
    public final c f7423h;

    /* renamed from: i  reason: collision with root package name */
    public final c f7424i;

    /* renamed from: j  reason: collision with root package name */
    public final C3562e f7425j;

    public m(Context context, h hVar, f fVar, c cVar, String str, C4168n nVar, c cVar2, c cVar3, c cVar4, C3562e eVar) {
        this.f7416a = context;
        this.f7417b = hVar;
        this.f7418c = fVar;
        this.f7419d = cVar;
        this.f7420e = str;
        this.f7421f = nVar;
        this.f7422g = cVar2;
        this.f7423h = cVar3;
        this.f7424i = cVar4;
        this.f7425j = eVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        if (l.a(this.f7416a, mVar.f7416a) && l.a(this.f7417b, mVar.f7417b) && this.f7418c == mVar.f7418c && this.f7419d == mVar.f7419d && l.a(this.f7420e, mVar.f7420e) && l.a(this.f7421f, mVar.f7421f) && this.f7422g == mVar.f7422g && this.f7423h == mVar.f7423h && this.f7424i == mVar.f7424i && l.a(this.f7425j, mVar.f7425j)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i10;
        int hashCode = this.f7417b.hashCode();
        int hashCode2 = this.f7418c.hashCode();
        int hashCode3 = (this.f7419d.hashCode() + ((hashCode2 + ((hashCode + (this.f7416a.hashCode() * 31)) * 31)) * 31)) * 31;
        String str = this.f7420e;
        if (str == null) {
            i10 = 0;
        } else {
            i10 = str.hashCode();
        }
        int hashCode4 = this.f7421f.hashCode();
        int hashCode5 = this.f7422g.hashCode();
        int hashCode6 = this.f7423h.hashCode();
        int hashCode7 = this.f7424i.hashCode();
        return this.f7425j.f31818a.hashCode() + ((hashCode7 + ((hashCode6 + ((hashCode5 + ((hashCode4 + ((hashCode3 + i10) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "Options(context=" + this.f7416a + ", size=" + this.f7417b + ", scale=" + this.f7418c + ", precision=" + this.f7419d + ", diskCacheKey=" + this.f7420e + ", fileSystem=" + this.f7421f + ", memoryCachePolicy=" + this.f7422g + ", diskCachePolicy=" + this.f7423h + ", networkCachePolicy=" + this.f7424i + ", extras=" + this.f7425j + ')';
    }
}
