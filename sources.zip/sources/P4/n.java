package P4;

import z4.p;

public interface n {
    void b();

    void c();

    Object g(p pVar);

    void start();
}
