package P4;

import C4.C0545g;
import K4.c;
import M.k;
import kotlin.jvm.internal.l;
import z4.g;

public final class o implements i {

    /* renamed from: a  reason: collision with root package name */
    public final g f7426a;

    /* renamed from: b  reason: collision with root package name */
    public final f f7427b;

    /* renamed from: c  reason: collision with root package name */
    public final C0545g f7428c;

    /* renamed from: d  reason: collision with root package name */
    public final c.b f7429d;

    /* renamed from: e  reason: collision with root package name */
    public final String f7430e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f7431f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f7432g;

    public o(g gVar, f fVar, C0545g gVar2, c.b bVar, String str, boolean z10, boolean z11) {
        this.f7426a = gVar;
        this.f7427b = fVar;
        this.f7428c = gVar2;
        this.f7429d = bVar;
        this.f7430e = str;
        this.f7431f = z10;
        this.f7432g = z11;
    }

    public final g a() {
        return this.f7426a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof o)) {
            return false;
        }
        o oVar = (o) obj;
        if (l.a(this.f7426a, oVar.f7426a) && l.a(this.f7427b, oVar.f7427b) && this.f7428c == oVar.f7428c && l.a(this.f7429d, oVar.f7429d) && l.a(this.f7430e, oVar.f7430e) && this.f7431f == oVar.f7431f && this.f7432g == oVar.f7432g) {
            return true;
        }
        return false;
    }

    public final f getRequest() {
        return this.f7427b;
    }

    public final int hashCode() {
        int i10;
        int i11;
        int hashCode = (this.f7428c.hashCode() + ((this.f7427b.hashCode() + (this.f7426a.hashCode() * 31)) * 31)) * 31;
        int i12 = 0;
        c.b bVar = this.f7429d;
        if (bVar == null) {
            i10 = 0;
        } else {
            i10 = bVar.hashCode();
        }
        int i13 = (hashCode + i10) * 31;
        String str = this.f7430e;
        if (str != null) {
            i12 = str.hashCode();
        }
        int i14 = (i13 + i12) * 31;
        int i15 = 1237;
        if (this.f7431f) {
            i11 = 1231;
        } else {
            i11 = 1237;
        }
        int i16 = (i14 + i11) * 31;
        if (this.f7432g) {
            i15 = 1231;
        }
        return i16 + i15;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("SuccessResult(image=");
        sb2.append(this.f7426a);
        sb2.append(", request=");
        sb2.append(this.f7427b);
        sb2.append(", dataSource=");
        sb2.append(this.f7428c);
        sb2.append(", memoryCacheKey=");
        sb2.append(this.f7429d);
        sb2.append(", diskCacheKey=");
        sb2.append(this.f7430e);
        sb2.append(", isSampled=");
        sb2.append(this.f7431f);
        sb2.append(", isPlaceholderCached=");
        return k.n(sb2, this.f7432g, ')');
    }
}
