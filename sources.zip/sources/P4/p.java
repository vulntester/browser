package P4;

import android.view.View;
import ic.J;
import ic.K;

public final class p implements d {

    /* renamed from: f  reason: collision with root package name */
    public final View f7433f;

    /* renamed from: i  reason: collision with root package name */
    public volatile K f7434i;

    public p(View view, K k10) {
        this.f7433f = view;
        this.f7434i = k10;
    }

    public final J<i> getJob() {
        return this.f7434i;
    }
}
