package P4;

import Ba.e;
import R4.a;
import U4.n;
import androidx.lifecycle.C1326d;
import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1336n;
import androidx.lifecycle.C1337o;
import ic.A0;
import ic.C4502f0;
import ic.C4516m0;
import ic.G;
import ic.U;
import java.util.concurrent.CancellationException;
import xa.C4959D;
import z4.m;
import z4.p;

public final class q implements n, C1326d {

    /* renamed from: E  reason: collision with root package name */
    public final C1333k f7435E;

    /* renamed from: F  reason: collision with root package name */
    public final C4516m0 f7436F;

    /* renamed from: f  reason: collision with root package name */
    public final m f7437f;

    /* renamed from: i  reason: collision with root package name */
    public final f f7438i;

    /* renamed from: z  reason: collision with root package name */
    public final a<?> f7439z;

    public q(m mVar, f fVar, a aVar, C1333k kVar, C4516m0 m0Var) {
        this.f7437f = mVar;
        this.f7438i = fVar;
        this.f7439z = aVar;
        this.f7435E = kVar;
        this.f7436F = m0Var;
    }

    public final void a() {
        this.f7436F.e((CancellationException) null);
        a<?> aVar = this.f7439z;
        boolean z10 = aVar instanceof C1336n;
        C1333k kVar = this.f7435E;
        if (z10 && kVar != null) {
            kVar.c((C1336n) aVar);
        }
        if (kVar != null) {
            kVar.c(this);
        }
    }

    public final /* synthetic */ void b() {
    }

    public final void c() {
        a aVar = this.f7439z;
        if (!aVar.getView().isAttachedToWindow()) {
            s a10 = t.a(aVar.getView());
            q qVar = a10.f7441E;
            if (qVar != null) {
                qVar.a();
            }
            a10.f7441E = this;
            throw new CancellationException("'ViewTarget.view' must be attached to a window.");
        }
    }

    public final /* synthetic */ void d(C1337o oVar) {
    }

    public final /* synthetic */ void e(C1337o oVar) {
    }

    public final Object g(p pVar) {
        C1333k kVar = this.f7435E;
        if (kVar == null) {
            return C4959D.f44058a;
        }
        Object a10 = n.a(kVar, pVar);
        if (a10 == Ca.a.f33640f) {
            return a10;
        }
        return C4959D.f44058a;
    }

    public final /* synthetic */ void j(C1337o oVar) {
    }

    public final /* synthetic */ void o(C1337o oVar) {
    }

    public final void p(C1337o oVar) {
        s a10 = t.a(this.f7439z.getView());
        synchronized (a10) {
            A0 a02 = a10.f7445z;
            if (a02 != null) {
                a02.e((CancellationException) null);
            }
            C4502f0 f0Var = C4502f0.f41169f;
            U u7 = U.f41134a;
            a10.f7445z = G.y(f0Var, nc.p.f42446a.C0(), new r(a10, (e<? super r>) null), 2);
            a10.f7444i = null;
        }
    }

    public final /* synthetic */ void s(C1337o oVar) {
    }

    /* JADX WARNING: type inference failed for: r1v0, types: [R4.a, R4.a<?>] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void start() {
        /*
            r3 = this;
            androidx.lifecycle.k r0 = r3.f7435E
            if (r0 == 0) goto L_0x0007
            r0.a(r3)
        L_0x0007:
            R4.a<?> r1 = r3.f7439z
            boolean r2 = r1 instanceof androidx.lifecycle.C1336n
            if (r2 == 0) goto L_0x0018
            if (r0 == 0) goto L_0x0018
            r2 = r1
            androidx.lifecycle.n r2 = (androidx.lifecycle.C1336n) r2
            r0.c(r2)
            r0.a(r2)
        L_0x0018:
            android.view.View r0 = r1.getView()
            P4.s r0 = P4.t.a(r0)
            P4.q r1 = r0.f7441E
            if (r1 == 0) goto L_0x0027
            r1.a()
        L_0x0027:
            r0.f7441E = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: P4.q.start():void");
    }
}
