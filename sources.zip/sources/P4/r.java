package P4;

import Ca.a;
import Da.e;
import Da.i;
import Na.p;
import ic.C4487C;
import xa.C4959D;
import xa.C4976p;

@e(c = "coil3.request.ViewTargetRequestManager$dispose$1", f = "ViewTargetRequestManager.kt", l = {}, m = "invokeSuspend")
public final class r extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ s f7440f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public r(s sVar, Ba.e<? super r> eVar) {
        super(2, eVar);
        this.f7440f = sVar;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new r(this.f7440f, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((r) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.f33640f;
        C4976p.b(obj);
        s sVar = this.f7440f;
        q qVar = sVar.f7441E;
        if (qVar != null) {
            qVar.a();
        }
        sVar.f7441E = null;
        return C4959D.f44058a;
    }
}
