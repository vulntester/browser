package P4;

import Ba.e;
import android.view.View;
import ic.A0;
import ic.G;
import ic.U;
import jc.C4577e;
import nc.p;
import z4.m;
import z4.n;

public final class s implements View.OnAttachStateChangeListener {

    /* renamed from: E  reason: collision with root package name */
    public q f7441E;

    /* renamed from: F  reason: collision with root package name */
    public boolean f7442F;

    /* renamed from: f  reason: collision with root package name */
    public final View f7443f;

    /* renamed from: i  reason: collision with root package name */
    public p f7444i;

    /* renamed from: z  reason: collision with root package name */
    public A0 f7445z;

    public s(View view) {
        this.f7443f = view;
    }

    public final void onViewAttachedToWindow(View view) {
        q qVar = this.f7441E;
        if (qVar != null) {
            this.f7442F = true;
            m mVar = qVar.f7437f;
            U u7 = U.f41134a;
            C4577e C02 = p.f42446a.C0();
            f fVar = qVar.f7438i;
            z4.s.a(fVar, G.d(mVar.f31832b, C02, new n((e) null, fVar, mVar), 2));
        }
    }

    public final void onViewDetachedFromWindow(View view) {
        q qVar = this.f7441E;
        if (qVar != null) {
            qVar.a();
        }
    }
}
