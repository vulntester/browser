package P4;

public final class t {
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v2, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: P4.s} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final P4.s a(android.view.View r4) {
        /*
            r0 = 2131427495(0x7f0b00a7, float:1.8476608E38)
            java.lang.Object r1 = r4.getTag(r0)
            boolean r2 = r1 instanceof P4.s
            r3 = 0
            if (r2 == 0) goto L_0x000f
            P4.s r1 = (P4.s) r1
            goto L_0x0010
        L_0x000f:
            r1 = r3
        L_0x0010:
            if (r1 != 0) goto L_0x0033
            monitor-enter(r4)
            java.lang.Object r1 = r4.getTag(r0)     // Catch:{ all -> 0x001f }
            boolean r2 = r1 instanceof P4.s     // Catch:{ all -> 0x001f }
            if (r2 == 0) goto L_0x0021
            r3 = r1
            P4.s r3 = (P4.s) r3     // Catch:{ all -> 0x001f }
            goto L_0x0021
        L_0x001f:
            r0 = move-exception
            goto L_0x0031
        L_0x0021:
            if (r3 == 0) goto L_0x0024
            goto L_0x002f
        L_0x0024:
            P4.s r3 = new P4.s     // Catch:{ all -> 0x001f }
            r3.<init>(r4)     // Catch:{ all -> 0x001f }
            r4.addOnAttachStateChangeListener(r3)     // Catch:{ all -> 0x001f }
            r4.setTag(r0, r3)     // Catch:{ all -> 0x001f }
        L_0x002f:
            monitor-exit(r4)
            return r3
        L_0x0031:
            monitor-exit(r4)
            throw r0
        L_0x0033:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: P4.t.a(android.view.View):P4.s");
    }
}
