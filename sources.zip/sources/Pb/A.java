package Pb;

import Na.a;
import Rb.v;
import Sb.c;
import xb.m;

public final class A implements a {

    /* renamed from: f  reason: collision with root package name */
    public final H f37436f;

    /* renamed from: i  reason: collision with root package name */
    public final m f37437i;

    /* renamed from: z  reason: collision with root package name */
    public final v f37438z;

    public A(H h10, m mVar, v vVar) {
        this.f37436f = h10;
        this.f37437i = mVar;
        this.f37438z = vVar;
    }

    public final Object invoke() {
        H h10 = this.f37436f;
        c cVar = h10.f37460a.f37543a.f37522a;
        G g6 = new G(h10, this.f37437i, this.f37438z);
        cVar.getClass();
        return new c.f(cVar, g6);
    }
}
