package Pb;

import Db.h;
import Na.a;
import java.util.List;
import ya.s;
import ya.u;

public final class B implements a {

    /* renamed from: f  reason: collision with root package name */
    public final H f37439f;

    /* renamed from: i  reason: collision with root package name */
    public final h.c f37440i;

    /* renamed from: z  reason: collision with root package name */
    public final C4113c f37441z;

    public B(H h10, h.c cVar, C4113c cVar2) {
        this.f37439f = h10;
        this.f37440i = cVar;
        this.f37441z = cVar2;
    }

    public final Object invoke() {
        List list;
        H h10 = this.f37439f;
        K a10 = h10.a(h10.f37460a.f37545c);
        if (a10 != null) {
            list = s.w0(h10.f37460a.f37543a.f37526e.d(a10, this.f37440i, this.f37441z));
        } else {
            list = null;
        }
        if (list == null) {
            return u.f44685f;
        }
        return list;
    }
}
