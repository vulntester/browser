package Pb;

import Na.a;
import java.util.List;
import xb.m;
import ya.s;
import ya.u;

public final class C implements a {

    /* renamed from: f  reason: collision with root package name */
    public final H f37442f;

    /* renamed from: i  reason: collision with root package name */
    public final boolean f37443i;

    /* renamed from: z  reason: collision with root package name */
    public final m f37444z;

    public C(H h10, boolean z10, m mVar) {
        this.f37442f = h10;
        this.f37443i = z10;
        this.f37444z = mVar;
    }

    public final Object invoke() {
        List<T> list;
        H h10 = this.f37442f;
        K a10 = h10.a(h10.f37460a.f37545c);
        if (a10 != null) {
            boolean z10 = this.f37443i;
            m mVar = this.f37444z;
            C4125o oVar = h10.f37460a;
            if (z10) {
                list = s.w0(oVar.f37543a.f37526e.i(a10, mVar));
            } else {
                list = s.w0(oVar.f37543a.f37526e.h(a10, mVar));
            }
        } else {
            list = null;
        }
        if (list == null) {
            return u.f44685f;
        }
        return list;
    }
}
