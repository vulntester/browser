package Pb;

import Db.h;
import Pb.K;
import Qb.a;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;
import xb.C4987a;
import xb.c;
import xb.f;
import xb.m;
import xb.p;
import xb.r;
import xb.t;
import ya.n;
import ya.u;
import zb.C5035c;

/* renamed from: Pb.a  reason: case insensitive filesystem */
public abstract class C4111a<A> implements C4117g<A> {

    /* renamed from: a  reason: collision with root package name */
    public final a f37495a;

    public C4111a(a aVar) {
        l.f(aVar, "protocol");
        this.f37495a = aVar;
    }

    public final ArrayList a(p pVar, C5035c cVar) {
        l.f(pVar, "proto");
        l.f(cVar, "nameResolver");
        Iterable<C4987a> iterable = (List) pVar.k(this.f37495a.f37396k);
        if (iterable == null) {
            iterable = u.f44685f;
        }
        ArrayList arrayList = new ArrayList(n.v(10, iterable));
        for (C4987a l10 : iterable) {
            arrayList.add(((C4115e) this).l(l10, cVar));
        }
        return arrayList;
    }

    public final List<A> b(K k10, f fVar) {
        l.f(k10, "container");
        Iterable<C4987a> iterable = (List) fVar.k(this.f37495a.f37393h);
        if (iterable == null) {
            iterable = u.f44685f;
        }
        ArrayList arrayList = new ArrayList(n.v(10, iterable));
        for (C4987a l10 : iterable) {
            arrayList.add(((C4115e) this).l(l10, k10.f37466a));
        }
        return arrayList;
    }

    public final List d(K k10, h.c cVar, C4113c cVar2) {
        Iterable<C4987a> iterable;
        l.f(cVar, "proto");
        boolean z10 = cVar instanceof c;
        a aVar = this.f37495a;
        if (z10) {
            iterable = (List) ((c) cVar).k(aVar.f37387b);
        } else if (cVar instanceof xb.h) {
            iterable = (List) ((xb.h) cVar).k(aVar.f37389d);
        } else if (cVar instanceof m) {
            int ordinal = cVar2.ordinal();
            if (ordinal == 1) {
                iterable = (List) ((m) cVar).k(aVar.f37390e);
            } else if (ordinal == 2) {
                iterable = (List) ((m) cVar).k(aVar.f37391f);
            } else if (ordinal == 3) {
                iterable = (List) ((m) cVar).k(aVar.f37392g);
            } else {
                throw new IllegalStateException("Unsupported callable kind with property proto");
            }
        } else {
            throw new IllegalStateException(("Unknown message: " + cVar).toString());
        }
        if (iterable == null) {
            iterable = u.f44685f;
        }
        ArrayList arrayList = new ArrayList(n.v(10, iterable));
        for (C4987a l10 : iterable) {
            arrayList.add(((C4115e) this).l(l10, k10.f37466a));
        }
        return arrayList;
    }

    public final List e(K k10, h.c cVar, C4113c cVar2, int i10, t tVar) {
        l.f(cVar, "callableProto");
        Iterable<C4987a> iterable = (List) tVar.k(this.f37495a.f37395j);
        if (iterable == null) {
            iterable = u.f44685f;
        }
        ArrayList arrayList = new ArrayList(n.v(10, iterable));
        for (C4987a l10 : iterable) {
            arrayList.add(((C4115e) this).l(l10, k10.f37466a));
        }
        return arrayList;
    }

    public final List g(K k10, h.c cVar, C4113c cVar2) {
        l.f(cVar, "proto");
        boolean z10 = cVar instanceof xb.h;
        a aVar = this.f37495a;
        if (z10) {
            aVar.getClass();
        } else if (cVar instanceof m) {
            int ordinal = cVar2.ordinal();
            if (ordinal == 1 || ordinal == 2 || ordinal == 3) {
                aVar.getClass();
            } else {
                throw new IllegalStateException(("Unsupported callable kind with property proto for receiver annotations: " + cVar2).toString());
            }
        } else {
            throw new IllegalStateException(("Unknown message: " + cVar).toString());
        }
        u<C4987a> uVar = u.f44685f;
        ArrayList arrayList = new ArrayList(n.v(10, uVar));
        for (C4987a l10 : uVar) {
            arrayList.add(((C4115e) this).l(l10, k10.f37466a));
        }
        return arrayList;
    }

    public final List<A> h(K k10, m mVar) {
        l.f(mVar, "proto");
        this.f37495a.getClass();
        u<C4987a> uVar = u.f44685f;
        ArrayList arrayList = new ArrayList(n.v(10, uVar));
        for (C4987a l10 : uVar) {
            arrayList.add(((C4115e) this).l(l10, k10.f37466a));
        }
        return arrayList;
    }

    public final List<A> i(K k10, m mVar) {
        l.f(mVar, "proto");
        this.f37495a.getClass();
        u<C4987a> uVar = u.f44685f;
        ArrayList arrayList = new ArrayList(n.v(10, uVar));
        for (C4987a l10 : uVar) {
            arrayList.add(((C4115e) this).l(l10, k10.f37466a));
        }
        return arrayList;
    }

    public final ArrayList j(r rVar, C5035c cVar) {
        l.f(rVar, "proto");
        l.f(cVar, "nameResolver");
        Iterable<C4987a> iterable = (List) rVar.k(this.f37495a.f37397l);
        if (iterable == null) {
            iterable = u.f44685f;
        }
        ArrayList arrayList = new ArrayList(n.v(10, iterable));
        for (C4987a l10 : iterable) {
            arrayList.add(((C4115e) this).l(l10, cVar));
        }
        return arrayList;
    }

    public final ArrayList k(K.a aVar) {
        l.f(aVar, "container");
        Iterable<C4987a> iterable = (List) aVar.f37469d.k(this.f37495a.f37388c);
        if (iterable == null) {
            iterable = u.f44685f;
        }
        ArrayList arrayList = new ArrayList(n.v(10, iterable));
        for (C4987a l10 : iterable) {
            arrayList.add(((C4115e) this).l(l10, aVar.f37466a));
        }
        return arrayList;
    }
}
