package Pb;

import Cb.f;
import Eb.q;
import Qb.a;
import Qb.d;
import Sb.c;
import Sb.h;
import ab.o;
import db.C4295I;
import db.C4299M;
import gb.C4432B;
import ib.e;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.l;
import m4.F;
import xa.C4961a;
import ya.n;
import ya.w;

/* renamed from: Pb.b  reason: case insensitive filesystem */
public abstract class C4112b implements C4299M {

    /* renamed from: a  reason: collision with root package name */
    public final c f37496a;

    /* renamed from: b  reason: collision with root package name */
    public final e f37497b;

    /* renamed from: c  reason: collision with root package name */
    public final C4432B f37498c;

    /* renamed from: d  reason: collision with root package name */
    public C4123m f37499d;

    /* renamed from: e  reason: collision with root package name */
    public final h<Cb.c, C4295I> f37500e;

    public C4112b(c cVar, e eVar, C4432B b10) {
        this.f37496a = cVar;
        this.f37497b = eVar;
        this.f37498c = b10;
        this.f37500e = cVar.f(new q(this, 1));
    }

    @C4961a
    public final List<C4295I> a(Cb.c cVar) {
        l.f(cVar, "fqName");
        return n.y(this.f37500e.invoke(cVar));
    }

    public final boolean b(Cb.c cVar) {
        Object obj;
        InputStream inputStream;
        l.f(cVar, "fqName");
        h<Cb.c, C4295I> hVar = this.f37500e;
        Object obj2 = ((c.j) hVar).f37899i.get(cVar);
        if (obj2 == null || obj2 == c.l.f37903i) {
            cb.n nVar = (cb.n) this;
            e eVar = nVar.f37497b;
            if (!cVar.h(o.f39172k)) {
                inputStream = null;
            } else {
                a.f37618m.getClass();
                String a10 = a.a(cVar);
                eVar.f41095b.getClass();
                inputStream = Qb.e.a(a10);
            }
            if (inputStream != null) {
                obj = d.a.a(cVar, nVar.f37496a, nVar.f37498c, inputStream);
            } else {
                obj = null;
            }
        } else {
            obj = hVar.invoke(cVar);
        }
        if (obj == null) {
            return true;
        }
        return false;
    }

    public final void c(Cb.c cVar, ArrayList arrayList) {
        l.f(cVar, "fqName");
        F.f(arrayList, this.f37500e.invoke(cVar));
    }

    public final Collection<Cb.c> r(Cb.c cVar, Na.l<? super f, Boolean> lVar) {
        l.f(cVar, "fqName");
        return w.f44687f;
    }
}
