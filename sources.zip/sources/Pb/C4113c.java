package Pb;

/* renamed from: Pb.c  reason: case insensitive filesystem */
public enum C4113c {
    ;

    /* access modifiers changed from: public */
    C4113c() {
        throw null;
    }
}
