package Pb;

import Tb.C4154z;
import xb.m;

/* renamed from: Pb.d  reason: case insensitive filesystem */
public interface C4114d<A, C> extends C4117g<A> {
    C c(K k10, m mVar, C4154z zVar);

    C f(K k10, m mVar, C4154z zVar);
}
