package Pb;

import Hb.g;
import Qb.a;
import Tb.C4154z;
import db.C4291E;
import db.C4294H;
import eb.C4373b;
import eb.C4374c;
import kotlin.jvm.internal.l;
import xb.C4987a;
import xb.m;
import zb.C5035c;
import zb.C5037e;

/* renamed from: Pb.e  reason: case insensitive filesystem */
public final class C4115e extends C4111a<C4373b> implements C4114d<C4373b, g<?>> {

    /* renamed from: b  reason: collision with root package name */
    public final C4116f f37506b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C4115e(C4291E e10, C4294H h10, a aVar) {
        super(aVar);
        l.f(e10, "module");
        l.f(aVar, "protocol");
        this.f37506b = new C4116f(e10, h10);
    }

    public final Object c(K k10, m mVar, C4154z zVar) {
        l.f(mVar, "proto");
        C4987a.b.c cVar = (C4987a.b.c) C5037e.a(mVar, this.f37495a.f37394i);
        if (cVar == null) {
            return null;
        }
        return this.f37506b.c(zVar, cVar, k10.f37466a);
    }

    public final Object f(K k10, m mVar, C4154z zVar) {
        l.f(mVar, "proto");
        return null;
    }

    public final C4374c l(C4987a aVar, C5035c cVar) {
        l.f(aVar, "proto");
        l.f(cVar, "nameResolver");
        return this.f37506b.a(aVar, cVar);
    }
}
