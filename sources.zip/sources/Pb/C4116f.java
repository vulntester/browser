package Pb;

import Cb.f;
import Fb.i;
import Hb.A;
import Hb.B;
import Hb.C;
import Hb.C4000b;
import Hb.C4002d;
import Hb.D;
import Hb.g;
import Hb.j;
import Hb.l;
import Hb.m;
import Hb.u;
import Hb.x;
import Hb.z;
import Ta.e;
import Tb.C4154z;
import Tb.H;
import ab.k;
import ab.o;
import db.C4291E;
import db.C4294H;
import db.C4309X;
import db.C4314d;
import db.C4315e;
import db.C4316f;
import db.C4318h;
import db.C4332v;
import db.h0;
import eb.C4374c;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.l;
import xa.C4973m;
import xb.C4987a;
import ya.C5004A;
import ya.C5006C;
import ya.C5007D;
import ya.n;
import ya.s;
import ya.v;
import zb.C5034b;
import zb.C5035c;

/* renamed from: Pb.f  reason: case insensitive filesystem */
public final class C4116f {

    /* renamed from: a  reason: collision with root package name */
    public final C4291E f37507a;

    /* renamed from: b  reason: collision with root package name */
    public final C4294H f37508b;

    /* renamed from: Pb.f$a */
    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f37509a;

        static {
            int[] iArr = new int[C4987a.b.c.C0461c.values().length];
            try {
                iArr[0] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[1] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[2] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[3] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[4] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[5] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[6] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[7] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[8] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                iArr[9] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                iArr[10] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                iArr[11] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                iArr[12] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            f37509a = iArr;
        }
    }

    public C4116f(C4291E e10, C4294H h10) {
        l.f(e10, "module");
        l.f(h10, "notFoundClasses");
        this.f37507a = e10;
        this.f37508b = h10;
    }

    public final C4374c a(C4987a aVar, C5035c cVar) {
        l.f(aVar, "proto");
        l.f(cVar, "nameResolver");
        C4315e c10 = C4332v.c(this.f37507a, I.a(cVar, aVar.f44090z), this.f37508b);
        Map map = v.f44686f;
        if (aVar.f44085E.size() != 0 && !Vb.l.f(c10)) {
            int i10 = i.f35017a;
            if (i.n(c10, C4316f.f40379F)) {
                Collection<C4314d> j10 = c10.j();
                l.e(j10, "getConstructors(...)");
                C4314d dVar = (C4314d) s.n0(j10);
                if (dVar != null) {
                    List<h0> g6 = dVar.g();
                    l.e(g6, "getValueParameters(...)");
                    int t10 = C5006C.t(n.v(10, g6));
                    if (t10 < 16) {
                        t10 = 16;
                    }
                    LinkedHashMap linkedHashMap = new LinkedHashMap(t10);
                    for (T next : g6) {
                        linkedHashMap.put(((h0) next).getName(), next);
                    }
                    List<C4987a.b> list = aVar.f44085E;
                    l.e(list, "getArgumentList(...)");
                    ArrayList arrayList = new ArrayList();
                    for (C4987a.b bVar : list) {
                        l.c(bVar);
                        h0 h0Var = (h0) linkedHashMap.get(I.b(cVar, bVar.f44098z));
                        g<?> gVar = null;
                        if (h0Var != null) {
                            f b10 = I.b(cVar, bVar.f44098z);
                            C4154z type = h0Var.getType();
                            l.e(type, "getType(...)");
                            C4987a.b.c cVar2 = bVar.f44093E;
                            l.e(cVar2, "getValue(...)");
                            g<?> c11 = c(type, cVar2, cVar);
                            if (b(c11, type, cVar2)) {
                                gVar = c11;
                            }
                            if (gVar == null) {
                                String str = "Unexpected argument value: actual type " + cVar2.f44118z + " != expected type " + type;
                                l.f(str, "message");
                                gVar = new l.a(str);
                            }
                            gVar = new C4973m<>(b10, gVar);
                        }
                        if (gVar != null) {
                            arrayList.add(gVar);
                        }
                    }
                    map = C5007D.D(arrayList);
                }
            }
        }
        return new C4374c(c10.q(), map, C4309X.f40365y);
    }

    public final boolean b(g<?> gVar, C4154z zVar, C4987a.b.c cVar) {
        int i10;
        C4315e eVar;
        C4987a.b.c.C0461c cVar2 = cVar.f44118z;
        if (cVar2 == null) {
            i10 = -1;
        } else {
            i10 = a.f37509a[cVar2.ordinal()];
        }
        if (i10 != 10) {
            C4291E e10 = this.f37507a;
            if (i10 != 13) {
                return kotlin.jvm.internal.l.a(gVar.a(e10), zVar);
            }
            if (gVar instanceof C4000b) {
                C4000b bVar = (C4000b) gVar;
                if (((List) bVar.f35521a).size() == cVar.f44111L.size()) {
                    C4154z f10 = e10.l().f(zVar);
                    Collection collection = (Collection) bVar.f35521a;
                    kotlin.jvm.internal.l.f(collection, "<this>");
                    e eVar2 = new e(0, collection.size() - 1, 1);
                    if (!(eVar2 instanceof Collection) || !((Collection) eVar2).isEmpty()) {
                        Iterator it = eVar2.iterator();
                        while (((Ta.f) it).f38037z) {
                            int a10 = ((C5004A) it).a();
                            C4987a.b.c cVar3 = cVar.f44111L.get(a10);
                            kotlin.jvm.internal.l.e(cVar3, "getArrayElement(...)");
                            if (!b((g) ((List) bVar.f35521a).get(a10), f10, cVar3)) {
                            }
                        }
                    }
                    return true;
                }
            }
            throw new IllegalStateException(("Deserialized ArrayValue should have the same number of elements as the original array value: " + gVar).toString());
        }
        C4318h n10 = zVar.z0().n();
        if (n10 instanceof C4315e) {
            eVar = (C4315e) n10;
        } else {
            eVar = null;
        }
        if (eVar != null) {
            f fVar = k.f39134e;
            if (k.b(eVar, o.a.f39195Q)) {
                return true;
            }
        }
        return true;
        return false;
    }

    public final g<?> c(C4154z zVar, C4987a.b.c cVar, C5035c cVar2) {
        int i10;
        boolean z10;
        kotlin.jvm.internal.l.f(cVar, "value");
        kotlin.jvm.internal.l.f(cVar2, "nameResolver");
        boolean booleanValue = C5034b.f44778N.c(cVar.f44113N).booleanValue();
        C4987a.b.c.C0461c cVar3 = cVar.f44118z;
        if (cVar3 == null) {
            i10 = -1;
        } else {
            i10 = a.f37509a[cVar3.ordinal()];
        }
        switch (i10) {
            case 1:
                byte b10 = (byte) ((int) cVar.f44104E);
                if (booleanValue) {
                    return new A(b10);
                }
                return new C4002d(b10);
            case 2:
                return new g<>(Character.valueOf((char) ((int) cVar.f44104E)));
            case 3:
                short s10 = (short) ((int) cVar.f44104E);
                if (booleanValue) {
                    return new D(s10);
                }
                return new x(s10);
            case 4:
                int i11 = (int) cVar.f44104E;
                if (booleanValue) {
                    return new B(i11);
                }
                return new Hb.n(i11);
            case 5:
                long j10 = cVar.f44104E;
                if (booleanValue) {
                    return new C(j10);
                }
                return new Hb.v(j10);
            case 6:
                return new m(cVar.f44105F);
            case 7:
                return new j(cVar.f44106G);
            case 8:
                if (cVar.f44104E != 0) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                return new g<>(Boolean.valueOf(z10));
            case 9:
                return new g<>(cVar2.b(cVar.f44107H));
            case 10:
                return new u(I.a(cVar2, cVar.f44108I), cVar.f44112M);
            case 11:
                return new Hb.k(I.a(cVar2, cVar.f44108I), I.b(cVar2, cVar.f44109J));
            case 12:
                C4987a aVar = cVar.f44110K;
                kotlin.jvm.internal.l.e(aVar, "getAnnotation(...)");
                return new g<>(a(aVar, cVar2));
            case 13:
                List<C4987a.b.c> list = cVar.f44111L;
                kotlin.jvm.internal.l.e(list, "getArrayElementList(...)");
                ArrayList arrayList = new ArrayList(n.v(10, list));
                for (C4987a.b.c cVar4 : list) {
                    H e10 = this.f37507a.l().e();
                    kotlin.jvm.internal.l.c(cVar4);
                    arrayList.add(c(e10, cVar4, cVar2));
                }
                return new z(arrayList, zVar);
            default:
                throw new IllegalStateException(("Unsupported annotation argument type: " + cVar.f44118z + " (expected " + zVar + ')').toString());
        }
    }
}
