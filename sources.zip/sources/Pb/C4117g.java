package Pb;

import Db.h;
import Pb.K;
import java.util.ArrayList;
import java.util.List;
import xb.f;
import xb.m;
import xb.p;
import xb.r;
import xb.t;
import zb.C5035c;

/* renamed from: Pb.g  reason: case insensitive filesystem */
public interface C4117g<A> {
    ArrayList a(p pVar, C5035c cVar);

    List<A> b(K k10, f fVar);

    List d(K k10, h.c cVar, C4113c cVar2);

    List e(K k10, h.c cVar, C4113c cVar2, int i10, t tVar);

    List g(K k10, h.c cVar, C4113c cVar2);

    List<A> h(K k10, m mVar);

    List<A> i(K k10, m mVar);

    ArrayList j(r rVar, C5035c cVar);

    ArrayList k(K.a aVar);
}
