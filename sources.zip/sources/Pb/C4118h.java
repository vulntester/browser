package Pb;

import db.C4309X;
import kotlin.jvm.internal.l;
import xb.C4988b;
import zb.C5033a;
import zb.C5035c;

/* renamed from: Pb.h  reason: case insensitive filesystem */
public final class C4118h {

    /* renamed from: a  reason: collision with root package name */
    public final C5035c f37510a;

    /* renamed from: b  reason: collision with root package name */
    public final C4988b f37511b;

    /* renamed from: c  reason: collision with root package name */
    public final C5033a f37512c;

    /* renamed from: d  reason: collision with root package name */
    public final C4309X f37513d;

    public C4118h(C5035c cVar, C4988b bVar, C5033a aVar, C4309X x10) {
        l.f(cVar, "nameResolver");
        l.f(bVar, "classProto");
        l.f(x10, "sourceElement");
        this.f37510a = cVar;
        this.f37511b = bVar;
        this.f37512c = aVar;
        this.f37513d = x10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C4118h)) {
            return false;
        }
        C4118h hVar = (C4118h) obj;
        if (l.a(this.f37510a, hVar.f37510a) && l.a(this.f37511b, hVar.f37511b) && l.a(this.f37512c, hVar.f37512c) && l.a(this.f37513d, hVar.f37513d)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int hashCode = this.f37511b.hashCode();
        int hashCode2 = this.f37512c.hashCode();
        return this.f37513d.hashCode() + ((hashCode2 + ((hashCode + (this.f37510a.hashCode() * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "ClassData(nameResolver=" + this.f37510a + ", classProto=" + this.f37511b + ", metadataVersion=" + this.f37512c + ", sourceElement=" + this.f37513d + ')';
    }
}
