package Pb;

import Cb.b;

/* renamed from: Pb.i  reason: case insensitive filesystem */
public interface C4119i {
    C4118h a(b bVar);
}
