package Pb;

import Na.l;

/* renamed from: Pb.j  reason: case insensitive filesystem */
public final class C4120j implements l {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f37514f;

    /* renamed from: i  reason: collision with root package name */
    public final Object f37515i;

    public /* synthetic */ C4120j(Object obj, int i10) {
        this.f37514f = i10;
        this.f37515i = obj;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: Tb.z} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v5, resolved type: Tb.y} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v5, resolved type: Tb.z} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v6, resolved type: Tb.y} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: Tb.y} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v6, resolved type: Tb.z} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v20, resolved type: Tb.y} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v7, resolved type: Tb.z} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v8, resolved type: Tb.z} */
    /* JADX WARNING: type inference failed for: r14v10, types: [java.util.Map, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r3v17, types: [xa.h, java.lang.Object] */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invoke(java.lang.Object r14) {
        /*
            r13 = this;
            java.lang.String r0 = "kotlinTypeRefiner"
            r1 = 0
            java.lang.Object r2 = r13.f37515i
            int r3 = r13.f37514f
            switch(r3) {
                case 0: goto L_0x017f;
                case 1: goto L_0x0128;
                case 2: goto L_0x006d;
                case 3: goto L_0x0033;
                default: goto L_0x000a;
            }
        L_0x000a:
            vb.s r14 = (vb.s) r14
            java.lang.String r0 = "kotlinClass"
            kotlin.jvm.internal.l.f(r14, r0)
            vb.d r2 = (vb.C4917d) r2
            r2.getClass()
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            java.util.HashMap r1 = new java.util.HashMap
            r1.<init>()
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            vb.c r4 = new vb.c
            r4.<init>(r2, r0, r14, r1)
            r14.c(r4)
            vb.h r14 = new vb.h
            r14.<init>(r0, r1, r3)
            return r14
        L_0x0033:
            tb.x r14 = (tb.C4864x) r14
            java.lang.String r0 = "typeParameter"
            kotlin.jvm.internal.l.f(r14, r0)
            pb.f r2 = (pb.C4780f) r2
            java.util.LinkedHashMap r0 = r2.f43008d
            java.lang.Object r0 = r0.get(r14)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 == 0) goto L_0x006c
            int r0 = r0.intValue()
            qb.A r1 = new qb.A
            pb.e r3 = r2.f43005a
            java.lang.String r4 = "<this>"
            kotlin.jvm.internal.l.f(r3, r4)
            pb.e r4 = new pb.e
            pb.a r5 = r3.f43000a
            java.lang.Object r3 = r3.f43002c
            r4.<init>(r5, r2, r3)
            db.l r3 = r2.f43006b
            eb.f r5 = r3.getAnnotations()
            pb.e r4 = C.N.l(r4, r5)
            int r2 = r2.f43007c
            int r2 = r2 + r0
            r1.<init>(r4, r14, r2, r3)
        L_0x006c:
            return r1
        L_0x006d:
            r3 = r14
            Cb.c r3 = (Cb.c) r3
            kotlin.jvm.internal.l.c(r3)
            Z5.a r2 = (Z5.a) r2
            java.lang.Object r14 = r2.f12211i
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Set r14 = r14.entrySet()
            java.util.Iterator r14 = r14.iterator()
        L_0x0084:
            boolean r2 = r14.hasNext()
            if (r2 == 0) goto L_0x00bf
            java.lang.Object r2 = r14.next()
            java.util.Map$Entry r2 = (java.util.Map.Entry) r2
            java.lang.Object r4 = r2.getKey()
            Cb.c r4 = (Cb.c) r4
            boolean r5 = r3.equals(r4)
            if (r5 != 0) goto L_0x00b3
            java.lang.String r5 = "packageName"
            kotlin.jvm.internal.l.f(r4, r5)
            boolean r5 = r3.d()
            if (r5 == 0) goto L_0x00a9
            r5 = r1
            goto L_0x00ad
        L_0x00a9:
            Cb.c r5 = r3.e()
        L_0x00ad:
            boolean r4 = kotlin.jvm.internal.l.a(r5, r4)
            if (r4 == 0) goto L_0x0084
        L_0x00b3:
            java.lang.Object r4 = r2.getKey()
            java.lang.Object r2 = r2.getValue()
            r0.put(r4, r2)
            goto L_0x0084
        L_0x00bf:
            boolean r14 = r0.isEmpty()
            if (r14 != 0) goto L_0x00c6
            goto L_0x00c7
        L_0x00c6:
            r0 = r1
        L_0x00c7:
            if (r0 != 0) goto L_0x00ca
            goto L_0x0127
        L_0x00ca:
            java.util.Set r14 = r0.entrySet()
            java.lang.Iterable r14 = (java.lang.Iterable) r14
            java.util.Iterator r4 = r14.iterator()
            boolean r14 = r4.hasNext()
            if (r14 != 0) goto L_0x00dc
            r14 = r1
            goto L_0x011f
        L_0x00dc:
            java.lang.Object r14 = r4.next()
            boolean r0 = r4.hasNext()
            if (r0 != 0) goto L_0x00e7
            goto L_0x011f
        L_0x00e7:
            r0 = r14
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            java.lang.Object r0 = r0.getKey()
            Cb.c r0 = (Cb.c) r0
            Cb.c r0 = Cb.e.a(r0, r3)
            java.lang.String r0 = r0.b()
            int r0 = r0.length()
        L_0x00fc:
            java.lang.Object r2 = r4.next()
            r5 = r2
            java.util.Map$Entry r5 = (java.util.Map.Entry) r5
            java.lang.Object r5 = r5.getKey()
            Cb.c r5 = (Cb.c) r5
            Cb.c r5 = Cb.e.a(r5, r3)
            java.lang.String r5 = r5.b()
            int r5 = r5.length()
            if (r0 <= r5) goto L_0x0119
            r14 = r2
            r0 = r5
        L_0x0119:
            boolean r2 = r4.hasNext()
            if (r2 != 0) goto L_0x00fc
        L_0x011f:
            java.util.Map$Entry r14 = (java.util.Map.Entry) r14
            if (r14 == 0) goto L_0x0127
            java.lang.Object r1 = r14.getValue()
        L_0x0127:
            return r1
        L_0x0128:
            Ub.f r14 = (Ub.f) r14
            kotlin.jvm.internal.l.f(r14, r0)
            Tb.y r2 = (Tb.C4153y) r2
            r2.getClass()
            kotlin.jvm.internal.l.f(r14, r0)
            java.util.LinkedHashSet<Tb.z> r0 = r2.f38152b
            java.util.ArrayList r3 = new java.util.ArrayList
            r4 = 10
            int r4 = ya.n.v(r4, r0)
            r3.<init>(r4)
            java.util.Iterator r0 = r0.iterator()
            r4 = 0
        L_0x0147:
            boolean r5 = r0.hasNext()
            if (r5 == 0) goto L_0x015c
            java.lang.Object r4 = r0.next()
            Tb.z r4 = (Tb.C4154z) r4
            Tb.z r4 = r4.K0(r14)
            r3.add(r4)
            r4 = 1
            goto L_0x0147
        L_0x015c:
            if (r4 != 0) goto L_0x015f
            goto L_0x0176
        L_0x015f:
            Tb.z r0 = r2.f38151a
            if (r0 == 0) goto L_0x0167
            Tb.z r1 = r0.K0(r14)
        L_0x0167:
            Tb.y r14 = new Tb.y
            r14.<init>(r3)
            Tb.y r0 = new Tb.y
            java.util.LinkedHashSet<Tb.z> r14 = r14.f38152b
            r0.<init>(r14)
            r0.f38151a = r1
            r1 = r0
        L_0x0176:
            if (r1 != 0) goto L_0x0179
            goto L_0x017a
        L_0x0179:
            r2 = r1
        L_0x017a:
            Tb.H r14 = r2.c()
            return r14
        L_0x017f:
            Pb.k$a r14 = (Pb.C4121k.a) r14
            java.lang.String r0 = "key"
            kotlin.jvm.internal.l.f(r14, r0)
            Pb.k r2 = (Pb.C4121k) r2
            r2.getClass()
            Pb.m r0 = r2.f37517a
            java.lang.Iterable<fb.b> r3 = r0.f37532k
            java.util.Iterator r3 = r3.iterator()
        L_0x0193:
            boolean r4 = r3.hasNext()
            Cb.b r5 = r14.f37519a
            if (r4 == 0) goto L_0x01aa
            java.lang.Object r4 = r3.next()
            fb.b r4 = (fb.C4408b) r4
            db.e r4 = r4.a(r5)
            if (r4 == 0) goto L_0x0193
            r1 = r4
            goto L_0x0264
        L_0x01aa:
            java.util.Set<Cb.b> r3 = Pb.C4121k.f37516c
            boolean r3 = r3.contains(r5)
            if (r3 == 0) goto L_0x01b4
            goto L_0x0264
        L_0x01b4:
            Pb.h r14 = r14.f37520b
            if (r14 != 0) goto L_0x01c2
            Pb.i r14 = r0.f37525d
            Pb.h r14 = r14.a(r5)
            if (r14 != 0) goto L_0x01c2
            goto L_0x0264
        L_0x01c2:
            Cb.b r3 = r5.e()
            zb.a r10 = r14.f37512c
            zb.c r8 = r14.f37510a
            xb.b r4 = r14.f37511b
            if (r3 == 0) goto L_0x01f6
            db.e r0 = r2.a(r3, r1)
            boolean r2 = r0 instanceof Rb.i
            if (r2 == 0) goto L_0x01d9
            Rb.i r0 = (Rb.i) r0
            goto L_0x01da
        L_0x01d9:
            r0 = r1
        L_0x01da:
            if (r0 != 0) goto L_0x01de
            goto L_0x0264
        L_0x01de:
            Cb.f r2 = r5.f()
            Rb.i$a r3 = r0.X()
            java.util.Set r3 = r3.m()
            boolean r2 = r3.contains(r2)
            if (r2 != 0) goto L_0x01f2
            goto L_0x0264
        L_0x01f2:
            Pb.o r0 = r0.f37718M
        L_0x01f4:
            r7 = r0
            goto L_0x025a
        L_0x01f6:
            Cb.c r3 = r5.f33655a
            db.M r0 = r0.f37527f
            java.util.ArrayList r0 = z0.C3542c.E(r0, r3)
            java.util.Iterator r0 = r0.iterator()
        L_0x0202:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L_0x022f
            java.lang.Object r3 = r0.next()
            r6 = r3
            db.I r6 = (db.C4295I) r6
            boolean r7 = r6 instanceof Pb.C4127q
            if (r7 == 0) goto L_0x0230
            Pb.q r6 = (Pb.C4127q) r6
            Cb.f r7 = r5.f()
            r6.getClass()
            Pb.s r6 = (Pb.C4128s) r6
            Mb.k r6 = r6.n()
            Rb.q r6 = (Rb.q) r6
            java.util.Set r6 = r6.m()
            boolean r6 = r6.contains(r7)
            if (r6 == 0) goto L_0x0202
            goto L_0x0230
        L_0x022f:
            r3 = r1
        L_0x0230:
            r7 = r3
            db.I r7 = (db.C4295I) r7
            if (r7 != 0) goto L_0x0236
            goto L_0x0264
        L_0x0236:
            zb.g r9 = new zb.g
            xb.s r0 = r4.f44177f0
            java.lang.String r1 = "getTypeTable(...)"
            kotlin.jvm.internal.l.e(r0, r1)
            r9.<init>(r0)
            zb.h r0 = zb.C5040h.f44811b
            xb.v r0 = r4.f44179h0
            java.lang.String r1 = "getVersionRequirementTable(...)"
            kotlin.jvm.internal.l.e(r0, r1)
            zb.h r0 = zb.C5040h.a.a(r0)
            r12 = 0
            Pb.m r6 = r2.f37517a
            r11 = r10
            r10 = r0
            Pb.o r0 = r6.a(r7, r8, r9, r10, r11, r12)
            r10 = r11
            goto L_0x01f4
        L_0x025a:
            Rb.i r6 = new Rb.i
            db.X r11 = r14.f37513d
            r9 = r8
            r8 = r4
            r6.<init>(r7, r8, r9, r10, r11)
            r1 = r6
        L_0x0264:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: Pb.C4120j.invoke(java.lang.Object):java.lang.Object");
    }
}
