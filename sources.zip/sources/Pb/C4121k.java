package Pb;

import Cb.b;
import Cb.c;
import H0.C0708z;
import Sb.h;
import ab.o;
import db.C4315e;
import f7.J;
import java.util.Set;
import kotlin.jvm.internal.l;

/* renamed from: Pb.k  reason: case insensitive filesystem */
public final class C4121k {

    /* renamed from: c  reason: collision with root package name */
    public static final Set<b> f37516c;

    /* renamed from: a  reason: collision with root package name */
    public final C4123m f37517a;

    /* renamed from: b  reason: collision with root package name */
    public final h f37518b;

    /* renamed from: Pb.k$a */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final b f37519a;

        /* renamed from: b  reason: collision with root package name */
        public final C4118h f37520b;

        public a(b bVar, C4118h hVar) {
            l.f(bVar, "classId");
            this.f37519a = bVar;
            this.f37520b = hVar;
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof a)) {
                return false;
            }
            if (l.a(this.f37519a, ((a) obj).f37519a)) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return this.f37519a.hashCode();
        }
    }

    static {
        c g6 = o.a.f39209c.g();
        l.e(g6, "toSafe(...)");
        c e10 = g6.e();
        f37516c = J.B(new b(e10, C0708z.i(e10, "parent(...)", g6, "shortName(...)")));
    }

    public C4121k(C4123m mVar) {
        l.f(mVar, "components");
        this.f37517a = mVar;
        this.f37518b = mVar.f37522a.f(new C4120j(this, 0));
    }

    public final C4315e a(b bVar, C4118h hVar) {
        l.f(bVar, "classId");
        return (C4315e) this.f37518b.invoke(new a(bVar, hVar));
    }
}
