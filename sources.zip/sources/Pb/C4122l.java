package Pb;

/* renamed from: Pb.l  reason: case insensitive filesystem */
public final class C4122l {

    /* renamed from: a  reason: collision with root package name */
    public static final a f37521a = new Object();

    /* renamed from: Pb.l$a */
    public static final class a {
    }
}
