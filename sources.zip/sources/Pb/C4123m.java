package Pb;

import Db.f;
import Hb.g;
import Pb.C4122l;
import Sb.c;
import Tb.V;
import Ub.k;
import db.C4291E;
import db.C4294H;
import db.C4295I;
import db.C4299M;
import db.C4315e;
import eb.C4373b;
import fb.C4407a;
import fb.C4408b;
import fb.C4409c;
import java.util.List;
import java.util.Set;
import kotlin.jvm.internal.l;
import lb.b;
import vb.n;
import ya.u;
import zb.C5033a;
import zb.C5035c;
import zb.C5039g;
import zb.C5040h;

/* renamed from: Pb.m  reason: case insensitive filesystem */
public final class C4123m {

    /* renamed from: a  reason: collision with root package name */
    public final c f37522a;

    /* renamed from: b  reason: collision with root package name */
    public final C4291E f37523b;

    /* renamed from: c  reason: collision with root package name */
    public final C4124n f37524c;

    /* renamed from: d  reason: collision with root package name */
    public final C4119i f37525d;

    /* renamed from: e  reason: collision with root package name */
    public final C4114d<C4373b, g<?>> f37526e;

    /* renamed from: f  reason: collision with root package name */
    public final C4299M f37527f;

    /* renamed from: g  reason: collision with root package name */
    public final y f37528g;

    /* renamed from: h  reason: collision with root package name */
    public final u f37529h;

    /* renamed from: i  reason: collision with root package name */
    public final b f37530i;

    /* renamed from: j  reason: collision with root package name */
    public final v f37531j;

    /* renamed from: k  reason: collision with root package name */
    public final Iterable<C4408b> f37532k;

    /* renamed from: l  reason: collision with root package name */
    public final C4294H f37533l;

    /* renamed from: m  reason: collision with root package name */
    public final C4122l.a f37534m;

    /* renamed from: n  reason: collision with root package name */
    public final C4407a f37535n;

    /* renamed from: o  reason: collision with root package name */
    public final C4409c f37536o;

    /* renamed from: p  reason: collision with root package name */
    public final f f37537p;

    /* renamed from: q  reason: collision with root package name */
    public final k f37538q;

    /* renamed from: r  reason: collision with root package name */
    public final List<V> f37539r;

    /* renamed from: s  reason: collision with root package name */
    public final C4129t f37540s;

    /* renamed from: t  reason: collision with root package name */
    public final C4121k f37541t;

    public C4123m(c cVar, C4291E e10, C4119i iVar, C4114d dVar, C4299M m10, u uVar, v vVar, Iterable iterable, C4294H h10, C4407a aVar, C4409c cVar2, f fVar, k kVar, Z7.b bVar, List list, C4129t tVar) {
        Iterable iterable2 = iterable;
        C4407a aVar2 = aVar;
        C4409c cVar3 = cVar2;
        f fVar2 = fVar;
        k kVar2 = kVar;
        C4129t tVar2 = tVar;
        C4124n nVar = C4124n.f37542a;
        y yVar = y.f37570a;
        b bVar2 = b.f41763a;
        C4122l.a aVar3 = C4122l.f37521a;
        l.f(e10, "moduleDescriptor");
        l.f(iterable2, "fictitiousClassDescriptorFactories");
        l.f(aVar2, "additionalClassPartsProvider");
        l.f(cVar3, "platformDependentDeclarationFilter");
        l.f(fVar2, "extensionRegistryLite");
        l.f(kVar2, "kotlinTypeChecker");
        l.f(tVar2, "enumEntriesDeserializationSupport");
        this.f37522a = cVar;
        this.f37523b = e10;
        this.f37524c = nVar;
        this.f37525d = iVar;
        this.f37526e = dVar;
        this.f37527f = m10;
        this.f37528g = yVar;
        this.f37529h = uVar;
        this.f37530i = bVar2;
        this.f37531j = vVar;
        this.f37532k = iterable2;
        this.f37533l = h10;
        this.f37534m = aVar3;
        this.f37535n = aVar2;
        this.f37536o = cVar3;
        this.f37537p = fVar2;
        this.f37538q = kVar2;
        this.f37539r = list;
        this.f37540s = tVar2;
        this.f37541t = new C4121k(this);
    }

    public final C4125o a(C4295I i10, C5035c cVar, C5039g gVar, C5040h hVar, C5033a aVar, n nVar) {
        l.f(i10, "descriptor");
        l.f(cVar, "nameResolver");
        C5033a aVar2 = aVar;
        l.f(aVar2, "metadataVersion");
        return new C4125o(this, cVar, i10, gVar, hVar, aVar2, nVar, (S) null, u.f44685f);
    }

    public final C4315e b(Cb.b bVar) {
        l.f(bVar, "classId");
        Set<Cb.b> set = C4121k.f37516c;
        return this.f37541t.a(bVar, (C4118h) null);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C4123m(Sb.c r18, db.C4291E r19, Pb.C4126p r20, Pb.C4115e r21, db.C4299M r22, java.lang.Iterable r23, db.C4294H r24, fb.C4407a r25, fb.C4409c r26, Db.f r27, Ub.l r28, Z7.b r29, int r30) {
        /*
            r17 = this;
            Pb.u$a r6 = Pb.u.f37561a
            Pb.v$a r7 = Pb.v.a.f37562a
            Pb.x r0 = Pb.x.f37569a
            r1 = 65536(0x10000, float:9.18355E-41)
            r1 = r30 & r1
            if (r1 == 0) goto L_0x0015
            Ub.k$a r1 = Ub.k.f38234b
            r1.getClass()
            Ub.l r1 = Ub.k.a.f38236b
            r13 = r1
            goto L_0x0017
        L_0x0015:
            r13 = r28
        L_0x0017:
            Tb.l r1 = Tb.C4141l.f38122a
            java.util.List r15 = f7.M.s(r1)
            r1 = 524288(0x80000, float:7.34684E-40)
            r1 = r30 & r1
            if (r1 == 0) goto L_0x0025
            Pb.t$a r0 = Pb.C4129t.a.f37560a
        L_0x0025:
            r1 = r18
            r2 = r19
            r3 = r20
            r4 = r21
            r5 = r22
            r8 = r23
            r9 = r24
            r10 = r25
            r11 = r26
            r12 = r27
            r14 = r29
            r16 = r0
            r0 = r17
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: Pb.C4123m.<init>(Sb.c, db.E, Pb.p, Pb.e, db.M, java.lang.Iterable, db.H, fb.a, fb.c, Db.f, Ub.l, Z7.b, int):void");
    }
}
