package Pb;

/* renamed from: Pb.n  reason: case insensitive filesystem */
public final class C4124n {

    /* renamed from: a  reason: collision with root package name */
    public static final C4124n f37542a = new Object();
}
