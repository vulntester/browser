package Pb;

import db.C4321k;
import java.util.List;
import kotlin.jvm.internal.l;
import vb.n;
import xb.r;
import zb.C5033a;
import zb.C5035c;
import zb.C5039g;
import zb.C5040h;

/* renamed from: Pb.o  reason: case insensitive filesystem */
public final class C4125o {

    /* renamed from: a  reason: collision with root package name */
    public final C4123m f37543a;

    /* renamed from: b  reason: collision with root package name */
    public final C5035c f37544b;

    /* renamed from: c  reason: collision with root package name */
    public final C4321k f37545c;

    /* renamed from: d  reason: collision with root package name */
    public final C5039g f37546d;

    /* renamed from: e  reason: collision with root package name */
    public final C5040h f37547e;

    /* renamed from: f  reason: collision with root package name */
    public final C5033a f37548f;

    /* renamed from: g  reason: collision with root package name */
    public final n f37549g;

    /* renamed from: h  reason: collision with root package name */
    public final S f37550h;

    /* renamed from: i  reason: collision with root package name */
    public final H f37551i;

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0069, code lost:
        if (r3 == null) goto L_0x0071;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C4125o(Pb.C4123m r2, zb.C5035c r3, db.C4321k r4, zb.C5039g r5, zb.C5040h r6, zb.C5033a r7, vb.n r8, Pb.S r9, java.util.List r10) {
        /*
            r1 = this;
            java.lang.String r0 = "components"
            kotlin.jvm.internal.l.f(r2, r0)
            java.lang.String r0 = "nameResolver"
            kotlin.jvm.internal.l.f(r3, r0)
            java.lang.String r0 = "containingDeclaration"
            kotlin.jvm.internal.l.f(r4, r0)
            java.lang.String r0 = "versionRequirementTable"
            kotlin.jvm.internal.l.f(r6, r0)
            java.lang.String r0 = "metadataVersion"
            kotlin.jvm.internal.l.f(r7, r0)
            java.lang.String r0 = "typeParameters"
            kotlin.jvm.internal.l.f(r10, r0)
            r1.<init>()
            r1.f37543a = r2
            r1.f37544b = r3
            r1.f37545c = r4
            r1.f37546d = r5
            r1.f37547e = r6
            r1.f37548f = r7
            r1.f37549g = r8
            Pb.S r2 = new Pb.S
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r5 = "Deserializer for \""
            r3.<init>(r5)
            Cb.f r4 = r4.getName()
            r3.append(r4)
            r4 = 34
            r3.append(r4)
            java.lang.String r6 = r3.toString()
            if (r8 == 0) goto L_0x0071
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "Class '"
            r3.<init>(r4)
            Cb.b r4 = r8.a()
            Cb.c r4 = r4.a()
            java.lang.String r4 = r4.b()
            r3.append(r4)
            r4 = 39
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            if (r3 != 0) goto L_0x006c
            goto L_0x0071
        L_0x006c:
            r7 = r3
            r4 = r9
            r5 = r10
            r3 = r1
            goto L_0x0074
        L_0x0071:
            java.lang.String r3 = "[container not found]"
            goto L_0x006c
        L_0x0074:
            r2.<init>(r3, r4, r5, r6, r7)
            r3.f37550h = r2
            Pb.H r2 = new Pb.H
            r2.<init>(r1)
            r3.f37551i = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: Pb.C4125o.<init>(Pb.m, zb.c, db.k, zb.g, zb.h, zb.a, vb.n, Pb.S, java.util.List):void");
    }

    public final C4125o a(C4321k kVar, List<r> list, C5035c cVar, C5039g gVar, C5040h hVar, C5033a aVar) {
        C5033a aVar2 = aVar;
        l.f(list, "typeParameterProtos");
        l.f(cVar, "nameResolver");
        l.f(hVar, "versionRequirementTable");
        l.f(aVar2, "metadataVersion");
        int i10 = aVar2.f44761b;
        if ((i10 != 1 || aVar2.f44762c < 4) && i10 <= 1) {
            hVar = this.f37547e;
        }
        return new C4125o(this.f37543a, cVar, kVar, gVar, hVar, aVar2, this.f37549g, this.f37550h, list);
    }
}
