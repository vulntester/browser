package Pb;

import Cb.c;
import Mb.s;
import Rb.u;
import db.C4291E;
import xb.k;
import xb.l;
import xb.n;
import xb.o;
import yb.C5022a;
import zb.C5036d;

/* renamed from: Pb.s  reason: case insensitive filesystem */
public abstract class C4128s extends C4127q {

    /* renamed from: I  reason: collision with root package name */
    public final C5022a f37555I;

    /* renamed from: J  reason: collision with root package name */
    public final C5036d f37556J;

    /* renamed from: K  reason: collision with root package name */
    public final J f37557K;

    /* renamed from: L  reason: collision with root package name */
    public l f37558L;

    /* renamed from: M  reason: collision with root package name */
    public u f37559M;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C4128s(c cVar, Sb.c cVar2, C4291E e10, l lVar, C5022a aVar) {
        super(e10, cVar);
        kotlin.jvm.internal.l.f(cVar, "fqName");
        kotlin.jvm.internal.l.f(e10, "module");
        kotlin.jvm.internal.l.f(cVar, "fqName");
        kotlin.jvm.internal.l.f(e10, "module");
        this.f37555I = aVar;
        o oVar = lVar.f44356E;
        kotlin.jvm.internal.l.e(oVar, "getStrings(...)");
        n nVar = lVar.f44357F;
        kotlin.jvm.internal.l.e(nVar, "getQualifiedNames(...)");
        C5036d dVar = new C5036d(oVar, nVar);
        this.f37556J = dVar;
        this.f37557K = new J(lVar, dVar, aVar, new r(this, 0));
        this.f37558L = lVar;
    }

    public final J Q0() {
        return this.f37557K;
    }

    public final void R0(C4123m mVar) {
        kotlin.jvm.internal.l.f(mVar, "components");
        l lVar = this.f37558L;
        if (lVar != null) {
            this.f37558L = null;
            k kVar = lVar.f44358G;
            kotlin.jvm.internal.l.e(kVar, "getPackage(...)");
            this.f37559M = new u(this, kVar, this.f37556J, this.f37555I, (vb.n) null, mVar, "scope of " + this, new s(this, 1));
            return;
        }
        throw new IllegalStateException("Repeated call to DeserializedPackageFragmentImpl::initialize");
    }

    public final Mb.k n() {
        u uVar = this.f37559M;
        if (uVar != null) {
            return uVar;
        }
        kotlin.jvm.internal.l.m("_memberScope");
        throw null;
    }
}
