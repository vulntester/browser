package Pb;

/* renamed from: Pb.t  reason: case insensitive filesystem */
public interface C4129t {

    /* renamed from: Pb.t$a */
    public static final class a implements C4129t {

        /* renamed from: a  reason: collision with root package name */
        public static final a f37560a = new Object();

        public final Boolean a() {
            return null;
        }
    }

    Boolean a();
}
