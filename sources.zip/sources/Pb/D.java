package Pb;

import Db.h;
import Na.a;
import java.util.List;
import ya.u;

public final class D implements a {

    /* renamed from: f  reason: collision with root package name */
    public final H f37445f;

    /* renamed from: i  reason: collision with root package name */
    public final h.c f37446i;

    /* renamed from: z  reason: collision with root package name */
    public final C4113c f37447z;

    public D(H h10, h.c cVar, C4113c cVar2) {
        this.f37445f = h10;
        this.f37446i = cVar;
        this.f37447z = cVar2;
    }

    public final Object invoke() {
        List list;
        H h10 = this.f37445f;
        K a10 = h10.a(h10.f37460a.f37545c);
        if (a10 != null) {
            list = h10.f37460a.f37543a.f37526e.g(a10, this.f37446i, this.f37447z);
        } else {
            list = null;
        }
        if (list == null) {
            return u.f44685f;
        }
        return list;
    }
}
