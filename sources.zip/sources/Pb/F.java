package Pb;

import Hb.g;
import Na.a;
import Rb.v;
import Tb.C4154z;
import eb.C4373b;
import kotlin.jvm.internal.l;
import xb.m;

public final class F implements a {

    /* renamed from: f  reason: collision with root package name */
    public final H f37454f;

    /* renamed from: i  reason: collision with root package name */
    public final m f37455i;

    /* renamed from: z  reason: collision with root package name */
    public final v f37456z;

    public F(H h10, m mVar, v vVar) {
        this.f37454f = h10;
        this.f37455i = mVar;
        this.f37456z = vVar;
    }

    public final Object invoke() {
        H h10 = this.f37454f;
        K a10 = h10.a(h10.f37460a.f37545c);
        l.c(a10);
        C4114d<C4373b, g<?>> dVar = h10.f37460a.f37543a.f37526e;
        C4154z returnType = this.f37456z.getReturnType();
        l.e(returnType, "getReturnType(...)");
        return dVar.c(a10, this.f37455i, returnType);
    }
}
