package Pb;

import Hb.g;
import Na.a;
import Rb.v;
import Tb.C4154z;
import eb.C4373b;
import kotlin.jvm.internal.l;
import xb.m;

public final class G implements a {

    /* renamed from: f  reason: collision with root package name */
    public final H f37457f;

    /* renamed from: i  reason: collision with root package name */
    public final m f37458i;

    /* renamed from: z  reason: collision with root package name */
    public final v f37459z;

    public G(H h10, m mVar, v vVar) {
        this.f37457f = h10;
        this.f37458i = mVar;
        this.f37459z = vVar;
    }

    public final Object invoke() {
        H h10 = this.f37457f;
        K a10 = h10.a(h10.f37460a.f37545c);
        l.c(a10);
        C4114d<C4373b, g<?>> dVar = h10.f37460a.f37543a.f37526e;
        C4154z returnType = this.f37459z.getReturnType();
        l.e(returnType, "getReturnType(...)");
        return dVar.f(a10, this.f37458i, returnType);
    }
}
