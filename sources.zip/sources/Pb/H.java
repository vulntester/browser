package Pb;

import Cb.c;
import Cb.f;
import Db.h;
import Jb.d;
import Pb.K;
import Rb.a;
import Rb.i;
import Rb.z;
import Tb.C4154z;
import db.C4295I;
import db.C4306U;
import db.C4308W;
import db.C4309X;
import db.C4311a;
import db.C4312b;
import db.C4315e;
import db.C4320j;
import db.C4321k;
import db.c0;
import db.h0;
import eb.C4377f;
import gb.J;
import gb.P;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;
import xb.j;
import xb.m;
import xb.p;
import xb.r;
import xb.t;
import xb.w;
import ya.n;
import ya.s;
import ya.u;
import ya.v;
import zb.C5034b;
import zb.C5035c;
import zb.C5038f;
import zb.C5039g;
import zb.C5040h;

public final class H {

    /* renamed from: a  reason: collision with root package name */
    public final C4125o f37460a;

    /* renamed from: b  reason: collision with root package name */
    public final C4116f f37461b;

    public H(C4125o oVar) {
        l.f(oVar, "c");
        this.f37460a = oVar;
        C4123m mVar = oVar.f37543a;
        this.f37461b = new C4116f(mVar.f37523b, mVar.f37533l);
    }

    public final K a(C4321k kVar) {
        if (kVar instanceof C4295I) {
            c c10 = ((C4295I) kVar).c();
            C4125o oVar = this.f37460a;
            return new K.b(c10, oVar.f37544b, oVar.f37546d, oVar.f37549g);
        } else if (kVar instanceof i) {
            return ((i) kVar).f37729X;
        } else {
            return null;
        }
    }

    public final C4377f b(h.c cVar, int i10, C4113c cVar2) {
        if (!C5034b.f44781c.c(i10).booleanValue()) {
            return C4377f.a.f40620a;
        }
        return new z(this.f37460a.f37543a.f37522a, new B(this, cVar, cVar2));
    }

    public final C4377f c(m mVar, boolean z10) {
        if (!C5034b.f44781c.c(mVar.f44371E).booleanValue()) {
            return C4377f.a.f40620a;
        }
        return new z(this.f37460a.f37543a.f37522a, new C(this, z10, mVar));
    }

    public final Rb.c d(xb.c cVar, boolean z10) {
        xb.c cVar2 = cVar;
        C4125o oVar = this.f37460a;
        C4321k kVar = oVar.f37545c;
        l.d(kVar, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor");
        C4315e eVar = (C4315e) kVar;
        int i10 = cVar2.f44218E;
        C4113c cVar3 = C4113c.f37503f;
        boolean z11 = z10;
        Rb.c cVar4 = new Rb.c(eVar, (C4320j) null, b(cVar, i10, cVar3), z11, C4312b.a.f40370f, cVar2, oVar.f37544b, oVar.f37546d, oVar.f37547e, oVar.f37549g, (C4309X) null);
        C4125o b10 = oVar.a(cVar4, u.f44685f, oVar.f37544b, oVar.f37546d, oVar.f37547e, oVar.f37548f);
        List<t> list = cVar2.f44219F;
        l.e(list, "getValueParameterList(...)");
        cVar4.c1(b10.f37551i.g(list, cVar, cVar3), M.a((w) C5034b.f44782d.c(cVar2.f44218E)));
        cVar4.Z0(eVar.q());
        cVar4.f40924T = eVar.H();
        cVar4.f40929Y = !C5034b.f44793o.c(cVar2.f44218E).booleanValue();
        return cVar4;
    }

    public final Rb.w e(xb.h hVar) {
        int i10;
        C4377f fVar;
        C5040h hVar2;
        J j10;
        C4315e eVar;
        C4306U u7;
        C4154z g6;
        xb.h hVar3 = hVar;
        l.f(hVar3, "proto");
        if ((hVar3.f44317z & 1) == 1) {
            i10 = hVar3.f44299E;
        } else {
            int i11 = hVar3.f44300F;
            i10 = ((i11 >> 8) << 6) + (i11 & 63);
        }
        int i12 = i10;
        C4113c cVar = C4113c.f37503f;
        C4377f b10 = b(hVar3, i12, cVar);
        int i13 = hVar3.f44317z;
        int i14 = i13 & 32;
        C4377f.a.C0393a aVar = C4377f.a.f40620a;
        C4125o oVar = this.f37460a;
        if (i14 == 32 || (i13 & 64) == 64) {
            fVar = new a(oVar.f37543a.f37522a, new D(this, hVar3, cVar));
        } else {
            fVar = aVar;
        }
        c g10 = d.g(oVar.f37545c);
        int i15 = hVar3.f44301G;
        C5035c cVar2 = oVar.f37544b;
        if (g10.c(I.b(cVar2, i15)).equals(N.f37479a)) {
            hVar2 = C5040h.f44811b;
        } else {
            hVar2 = oVar.f37547e;
        }
        C5040h hVar4 = hVar2;
        f b11 = I.b(cVar2, hVar3.f44301G);
        C4312b.a b12 = M.b((xb.i) C5034b.f44794p.c(i12));
        C5039g gVar = oVar.f37546d;
        C4125o oVar2 = oVar;
        int i16 = i12;
        C4377f.a.C0393a aVar2 = aVar;
        C4377f fVar2 = fVar;
        Rb.w wVar = new Rb.w(oVar.f37545c, (C4308W) null, b10, b11, b12, hVar3, oVar.f37544b, gVar, hVar4, oVar.f37549g, (C4309X) null);
        List<r> list = hVar3.f44304J;
        l.e(list, "getTypeParameterList(...)");
        C4125o b13 = oVar2.a(wVar, list, oVar2.f37544b, oVar2.f37546d, oVar2.f37547e, oVar2.f37548f);
        p b14 = C5038f.b(hVar3, gVar);
        S s10 = b13.f37550h;
        if (b14 == null || (g6 = s10.g(b14)) == null) {
            j10 = null;
        } else {
            j10 = Fb.h.h(wVar, g6, fVar2);
        }
        C4321k kVar = oVar2.f37545c;
        if (kVar instanceof C4315e) {
            eVar = (C4315e) kVar;
        } else {
            eVar = null;
        }
        if (eVar != null) {
            u7 = eVar.J0();
        } else {
            u7 = null;
        }
        ArrayList arrayList = hVar3.f44307M;
        if (arrayList.isEmpty()) {
            arrayList = null;
        }
        if (arrayList == null) {
            List<Integer> list2 = hVar3.f44308N;
            l.e(list2, "getContextReceiverTypeIdList(...)");
            ArrayList arrayList2 = new ArrayList(n.v(10, list2));
            for (Integer num : list2) {
                l.c(num);
                arrayList2.add(gVar.a(num.intValue()));
            }
            arrayList = arrayList2;
        }
        ArrayList arrayList3 = new ArrayList();
        int i17 = 0;
        for (T next : arrayList) {
            int i18 = i17 + 1;
            if (i17 >= 0) {
                J b15 = Fb.h.b(wVar, s10.g((p) next), (f) null, aVar2, i17);
                if (b15 != null) {
                    arrayList3.add(b15);
                }
                i17 = i18;
            } else {
                n.C();
                throw null;
            }
        }
        List<c0> b16 = s10.b();
        List<t> list3 = hVar3.f44310P;
        l.e(list3, "getValueParameterList(...)");
        int i19 = i16;
        Rb.w wVar2 = wVar;
        wVar2.e1(j10, u7, arrayList3, b16, b13.f37551i.g(list3, hVar3, cVar), s10.g(C5038f.c(hVar3, gVar)), L.a((j) C5034b.f44783e.c(i19)), M.a((w) C5034b.f44782d.c(i19)), v.f44686f);
        Rb.w wVar3 = wVar2;
        wVar3.f40919O = C5034b.f44795q.c(i19).booleanValue();
        wVar3.f40920P = C5034b.f44796r.c(i19).booleanValue();
        wVar3.f40921Q = C5034b.f44799u.c(i19).booleanValue();
        wVar3.f40922R = C5034b.f44797s.c(i19).booleanValue();
        wVar3.f40923S = C5034b.f44798t.c(i19).booleanValue();
        wVar3.f40928X = C5034b.f44800v.c(i19).booleanValue();
        wVar3.f40924T = C5034b.f44801w.c(i19).booleanValue();
        wVar3.f40929Y = !C5034b.f44802x.c(i19).booleanValue();
        oVar2.f37543a.f37534m.getClass();
        return wVar3;
    }

    /* JADX WARNING: Removed duplicated region for block: B:104:0x03a8  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x011f  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0122  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0125  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x012b  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0136  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0138  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x013b  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x013e  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0154  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x015a  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0164  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0169  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x019d  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x01b4  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x01fd  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Rb.v f(xb.m r28) {
        /*
            r27 = this;
            r0 = r27
            r15 = r28
            java.lang.String r1 = "proto"
            kotlin.jvm.internal.l.f(r15, r1)
            int r1 = r15.f44389z
            r2 = 1
            r1 = r1 & r2
            r20 = 6
            if (r1 != r2) goto L_0x0014
            int r1 = r15.f44371E
            goto L_0x001d
        L_0x0014:
            int r1 = r15.f44372F
            r3 = r1 & 63
            int r1 = r1 >> 8
            int r1 = r1 << 6
            int r1 = r1 + r3
        L_0x001d:
            Rb.v r4 = new Rb.v
            Pb.o r3 = r0.f37460a
            r5 = r2
            db.k r2 = r3.f37545c
            Pb.c r6 = Pb.C4113c.f37504i
            eb.f r6 = r0.b(r15, r1, r6)
            zb.b$b r7 = zb.C5034b.f44783e
            java.lang.Object r7 = r7.c(r1)
            xb.j r7 = (xb.j) r7
            db.C r7 = Pb.L.a(r7)
            zb.b$b r8 = zb.C5034b.f44782d
            java.lang.Object r8 = r8.c(r1)
            xb.w r8 = (xb.w) r8
            db.p r8 = Pb.M.a(r8)
            zb.b$a r9 = zb.C5034b.f44803y
            java.lang.Boolean r9 = r9.c(r1)
            boolean r9 = r9.booleanValue()
            int r10 = r15.f44373G
            zb.c r11 = r3.f37544b
            Cb.f r10 = Pb.I.b(r11, r10)
            zb.b$b r11 = zb.C5034b.f44794p
            java.lang.Object r11 = r11.c(r1)
            xb.i r11 = (xb.i) r11
            db.b$a r11 = Pb.M.b(r11)
            zb.b$a r12 = zb.C5034b.f44767C
            java.lang.Boolean r12 = r12.c(r1)
            boolean r12 = r12.booleanValue()
            zb.b$a r13 = zb.C5034b.f44766B
            java.lang.Boolean r13 = r13.c(r1)
            boolean r13 = r13.booleanValue()
            zb.b$a r14 = zb.C5034b.f44769E
            java.lang.Boolean r14 = r14.c(r1)
            boolean r14 = r14.booleanValue()
            zb.b$a r5 = zb.C5034b.f44770F
            java.lang.Boolean r5 = r5.c(r1)
            boolean r5 = r5.booleanValue()
            r17 = r2
            zb.b$a r2 = zb.C5034b.f44771G
            java.lang.Boolean r2 = r2.c(r1)
            boolean r2 = r2.booleanValue()
            r18 = r1
            zb.g r1 = r3.f37546d
            r19 = 0
            r21 = r1
            zb.c r1 = r3.f37544b
            r22 = r1
            zb.h r1 = r3.f37547e
            r23 = r1
            vb.n r1 = r3.f37549g
            r0 = r13
            r13 = r5
            r5 = r7
            r7 = r9
            r9 = r11
            r11 = r0
            r0 = r3
            r3 = r19
            r16 = r22
            r19 = r1
            r1 = r4
            r4 = r6
            r6 = r8
            r8 = r10
            r10 = r12
            r12 = r14
            r14 = r2
            r2 = r17
            r17 = r21
            r21 = r18
            r18 = r23
            r1.<init>(r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19)
            r4 = r1
            r1 = r17
            java.util.List<xb.r> r2 = r15.f44376J
            java.lang.String r3 = "getTypeParameterList(...)"
            kotlin.jvm.internal.l.e(r2, r3)
            Pb.o r2 = r0.a(r4, r2, r0.f37544b, r0.f37546d, r0.f37547e, r0.f37548f)
            zb.b$a r3 = zb.C5034b.f44804z
            r14 = r21
            java.lang.Boolean r3 = r3.c(r14)
            boolean r9 = r3.booleanValue()
            eb.f$a$a r3 = eb.C4377f.a.f40620a
            Pb.c r10 = Pb.C4113c.f37505z
            r5 = 64
            r6 = 32
            if (r9 == 0) goto L_0x0104
            int r7 = r15.f44389z
            r8 = r7 & 32
            if (r8 != r6) goto L_0x00f0
            goto L_0x00f3
        L_0x00f0:
            r7 = r7 & r5
            if (r7 != r5) goto L_0x0104
        L_0x00f3:
            Rb.a r7 = new Rb.a
            Pb.m r8 = r0.f37543a
            Sb.c r8 = r8.f37522a
            Pb.D r11 = new Pb.D
            r12 = r27
            r11.<init>(r12, r15, r10)
            r7.<init>(r8, r11)
            goto L_0x0107
        L_0x0104:
            r12 = r27
            r7 = r3
        L_0x0107:
            xb.p r8 = zb.C5038f.d(r15, r1)
            Pb.S r11 = r2.f37550h
            Tb.z r8 = r11.g(r8)
            java.util.List r13 = r11.b()
            r16 = r5
            db.k r5 = r0.f37545c
            boolean r6 = r5 instanceof db.C4315e
            r18 = r0
            if (r6 == 0) goto L_0x0122
            db.e r5 = (db.C4315e) r5
            goto L_0x0123
        L_0x0122:
            r5 = 0
        L_0x0123:
            if (r5 == 0) goto L_0x012b
            db.U r5 = r5.J0()
            r6 = r5
            goto L_0x012c
        L_0x012b:
            r6 = 0
        L_0x012c:
            int r5 = r15.f44389z
            r0 = r5 & 32
            r21 = r2
            r2 = 32
            if (r0 != r2) goto L_0x0138
            r2 = 1
            goto L_0x0139
        L_0x0138:
            r2 = 0
        L_0x0139:
            if (r2 == 0) goto L_0x013e
            xb.p r0 = r15.f44377K
            goto L_0x014c
        L_0x013e:
            r0 = r5 & 64
            r2 = r16
            if (r0 != r2) goto L_0x014b
            int r0 = r15.f44378L
            xb.p r0 = r1.a(r0)
            goto L_0x014c
        L_0x014b:
            r0 = 0
        L_0x014c:
            if (r0 == 0) goto L_0x015a
            Tb.z r0 = r11.g(r0)
            if (r0 == 0) goto L_0x015a
            gb.J r0 = Fb.h.h(r4, r0, r7)
            r7 = r0
            goto L_0x015b
        L_0x015a:
            r7 = 0
        L_0x015b:
            java.util.List<xb.p> r0 = r15.f44379M
            boolean r2 = r0.isEmpty()
            if (r2 != 0) goto L_0x0164
            goto L_0x0165
        L_0x0164:
            r0 = 0
        L_0x0165:
            r2 = 10
            if (r0 != 0) goto L_0x019d
            java.util.List<java.lang.Integer> r0 = r15.f44380N
            java.lang.String r5 = "getContextReceiverTypeIdList(...)"
            kotlin.jvm.internal.l.e(r0, r5)
            java.util.ArrayList r5 = new java.util.ArrayList
            r16 = r6
            int r6 = ya.n.v(r2, r0)
            r5.<init>(r6)
            java.util.Iterator r0 = r0.iterator()
        L_0x017f:
            boolean r6 = r0.hasNext()
            if (r6 == 0) goto L_0x019a
            java.lang.Object r6 = r0.next()
            java.lang.Integer r6 = (java.lang.Integer) r6
            kotlin.jvm.internal.l.c(r6)
            int r6 = r6.intValue()
            xb.p r6 = r1.a(r6)
            r5.add(r6)
            goto L_0x017f
        L_0x019a:
            r0 = r5
        L_0x019b:
            r1 = r8
            goto L_0x01a0
        L_0x019d:
            r16 = r6
            goto L_0x019b
        L_0x01a0:
            java.util.ArrayList r8 = new java.util.ArrayList
            int r5 = ya.n.v(r2, r0)
            r8.<init>(r5)
            java.util.Iterator r0 = r0.iterator()
            r5 = 0
        L_0x01ae:
            boolean r6 = r0.hasNext()
            if (r6 == 0) goto L_0x01d6
            java.lang.Object r6 = r0.next()
            int r17 = r5 + 1
            if (r5 < 0) goto L_0x01d1
            xb.p r6 = (xb.p) r6
            Tb.z r6 = r11.g(r6)
            r23 = r2
            r2 = 0
            gb.J r5 = Fb.h.b(r4, r6, r2, r3, r5)
            r8.add(r5)
            r5 = r17
            r2 = r23
            goto L_0x01ae
        L_0x01d1:
            r2 = 0
            ya.n.C()
            throw r2
        L_0x01d6:
            r23 = r2
            r3 = r4
            r5 = r13
            r6 = r16
            r4 = r1
            r3.W0(r4, r5, r6, r7, r8)
            r4 = r3
            zb.b$a r0 = zb.C5034b.f44781c
            java.lang.Boolean r1 = r0.c(r14)
            boolean r1 = r1.booleanValue()
            zb.b$b r2 = zb.C5034b.f44782d
            java.lang.Object r3 = r2.c(r14)
            xb.w r3 = (xb.w) r3
            zb.b$b r5 = zb.C5034b.f44783e
            java.lang.Object r6 = r5.c(r14)
            xb.j r6 = (xb.j) r6
            if (r3 == 0) goto L_0x03a8
            if (r6 == 0) goto L_0x039f
            if (r1 == 0) goto L_0x0207
            int r0 = r0.f44806a
            r1 = 1
            int r0 = r1 << r0
            goto L_0x0209
        L_0x0207:
            r1 = 1
            r0 = 0
        L_0x0209:
            int r6 = r6.a()
            int r7 = r5.f44806a
            int r6 = r6 << r7
            r0 = r0 | r6
            int r3 = r3.a()
            int r6 = r2.f44806a
            int r3 = r3 << r6
            r0 = r0 | r3
            zb.b$a r3 = zb.C5034b.f44775K
            r3.getClass()
            zb.b$a r6 = zb.C5034b.f44776L
            r6.getClass()
            zb.b$a r7 = zb.C5034b.f44777M
            r7.getClass()
            db.X$a r13 = db.C4309X.f40365y
            if (r9 == 0) goto L_0x02aa
            int r8 = r15.f44389z
            r9 = 256(0x100, float:3.59E-43)
            r8 = r8 & r9
            if (r8 != r9) goto L_0x0236
            int r8 = r15.f44383Q
            goto L_0x0237
        L_0x0236:
            r8 = r0
        L_0x0237:
            java.lang.Boolean r9 = r3.c(r8)
            boolean r9 = r9.booleanValue()
            java.lang.Boolean r11 = r6.c(r8)
            boolean r11 = r11.booleanValue()
            java.lang.Boolean r16 = r7.c(r8)
            boolean r16 = r16.booleanValue()
            eb.f r10 = r12.b(r15, r8, r10)
            if (r9 == 0) goto L_0x0292
            r17 = r3
            gb.H r3 = new gb.H
            java.lang.Object r23 = r5.c(r8)
            xb.j r23 = (xb.j) r23
            db.C r23 = Pb.L.a(r23)
            java.lang.Object r8 = r2.c(r8)
            xb.w r8 = (xb.w) r8
            db.p r8 = Pb.M.a(r8)
            r9 = r9 ^ r1
            r24 = r7
            r7 = r8
            r8 = r9
            r9 = r11
            db.b$a r11 = r4.e()
            r12 = 0
            r25 = r16
            r16 = r0
            r0 = r6
            r6 = r23
            r23 = r5
            r5 = r10
            r10 = r25
            r25 = r17
            r17 = r2
            r2 = r25
            r25 = r1
            r1 = r24
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            goto L_0x02a2
        L_0x0292:
            r16 = r0
            r25 = r1
            r17 = r2
            r2 = r3
            r23 = r5
            r0 = r6
            r1 = r7
            r5 = r10
            gb.H r3 = Fb.h.c(r4, r5)
        L_0x02a2:
            Tb.z r5 = r4.getReturnType()
            r3.T0(r5)
            goto L_0x02b6
        L_0x02aa:
            r16 = r0
            r25 = r1
            r17 = r2
            r2 = r3
            r23 = r5
            r0 = r6
            r1 = r7
            r3 = 0
        L_0x02b6:
            zb.b$a r5 = zb.C5034b.f44765A
            java.lang.Boolean r5 = r5.c(r14)
            boolean r5 = r5.booleanValue()
            if (r5 == 0) goto L_0x034c
            int r5 = r15.f44389z
            r6 = 512(0x200, float:7.175E-43)
            r5 = r5 & r6
            if (r5 != r6) goto L_0x02cc
            int r5 = r15.f44384R
            goto L_0x02ce
        L_0x02cc:
            r5 = r16
        L_0x02ce:
            java.lang.Boolean r2 = r2.c(r5)
            boolean r2 = r2.booleanValue()
            java.lang.Boolean r0 = r0.c(r5)
            boolean r9 = r0.booleanValue()
            java.lang.Boolean r0 = r1.c(r5)
            boolean r10 = r0.booleanValue()
            Pb.c r0 = Pb.C4113c.f37501E
            r1 = r27
            eb.f r6 = r1.b(r15, r5, r0)
            if (r2 == 0) goto L_0x0342
            r7 = r3
            gb.I r3 = new gb.I
            r8 = r23
            java.lang.Object r8 = r8.c(r5)
            xb.j r8 = (xb.j) r8
            db.C r8 = Pb.L.a(r8)
            r11 = r17
            java.lang.Object r5 = r11.c(r5)
            xb.w r5 = (xb.w) r5
            db.p r5 = Pb.M.a(r5)
            r2 = r2 ^ 1
            db.b$a r11 = r4.e()
            r12 = 0
            r26 = r8
            r8 = r2
            r2 = r7
            r7 = r5
            r5 = r6
            r6 = r26
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            ya.u r5 = ya.u.f44685f
            r6 = r21
            Pb.o r5 = r6.a(r3, r5, r6.f37544b, r6.f37546d, r6.f37547e, r6.f37548f)
            xb.t r6 = r15.f44382P
            java.util.List r6 = f7.M.s(r6)
            Pb.H r5 = r5.f37551i
            java.util.List r0 = r5.g(r6, r15, r0)
            java.lang.Object r0 = ya.s.m0(r0)
            db.h0 r0 = (db.h0) r0
            if (r0 == 0) goto L_0x033d
            r3.f40835O = r0
            r0 = 0
            goto L_0x0351
        L_0x033d:
            gb.I.K0(r20)
            r0 = 0
            throw r0
        L_0x0342:
            r2 = r3
            r5 = r6
            r0 = 0
            gb.I r19 = Fb.h.d(r4, r5)
            r3 = r19
            goto L_0x0351
        L_0x034c:
            r1 = r27
            r2 = r3
            r0 = 0
            r3 = r0
        L_0x0351:
            zb.b$a r5 = zb.C5034b.f44768D
            java.lang.Boolean r5 = r5.c(r14)
            boolean r5 = r5.booleanValue()
            if (r5 == 0) goto L_0x0365
            Pb.z r5 = new Pb.z
            r5.<init>(r1, r15, r4)
            r4.Q0(r0, r5)
        L_0x0365:
            r0 = r18
            db.k r0 = r0.f37545c
            boolean r5 = r0 instanceof db.C4315e
            if (r5 == 0) goto L_0x0370
            db.e r0 = (db.C4315e) r0
            goto L_0x0371
        L_0x0370:
            r0 = 0
        L_0x0371:
            if (r0 == 0) goto L_0x0378
            db.f r0 = r0.e()
            goto L_0x0379
        L_0x0378:
            r0 = 0
        L_0x0379:
            db.f r5 = db.C4316f.f40379F
            if (r0 != r5) goto L_0x0386
            Pb.A r0 = new Pb.A
            r0.<init>(r1, r15, r4)
            r5 = 0
            r4.Q0(r5, r0)
        L_0x0386:
            gb.u r0 = new gb.u
            r5 = 0
            eb.f r5 = r1.c(r15, r5)
            r0.<init>(r5, r4)
            gb.u r5 = new gb.u
            r6 = r25
            eb.f r6 = r1.c(r15, r6)
            r5.<init>(r6, r4)
            r4.U0(r2, r3, r0, r5)
            return r4
        L_0x039f:
            r1 = r12
            r0 = 11
            zb.C5034b.a(r0)
            r19 = 0
            throw r19
        L_0x03a8:
            r1 = r12
            r19 = 0
            zb.C5034b.a(r23)
            throw r19
        */
        throw new UnsupportedOperationException("Method not decompiled: Pb.H.f(xb.m):Rb.v");
    }

    public final List g(List list, h.c cVar, C4113c cVar2) {
        int i10;
        C4377f fVar;
        p pVar;
        H h10 = this;
        C4125o oVar = h10.f37460a;
        C4321k kVar = oVar.f37545c;
        l.d(kVar, "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.CallableDescriptor");
        C4311a aVar = (C4311a) kVar;
        C4321k d10 = aVar.d();
        l.e(d10, "getContainingDeclaration(...)");
        K a10 = h10.a(d10);
        List list2 = list;
        ArrayList arrayList = new ArrayList(n.v(10, list2));
        int i11 = 0;
        for (Object next : list2) {
            int i12 = i11 + 1;
            C4154z zVar = null;
            if (i11 >= 0) {
                t tVar = (t) next;
                if ((tVar.f44565z & 1) == 1) {
                    i10 = tVar.f44556E;
                } else {
                    i10 = 0;
                }
                if (a10 == null || !C5034b.f44781c.c(i10).booleanValue()) {
                    fVar = C4377f.a.f40620a;
                } else {
                    fVar = new z(oVar.f37543a.f37522a, new E(h10, a10, cVar, cVar2, i11, tVar));
                }
                f b10 = I.b(oVar.f37544b, tVar.f44557F);
                C5039g gVar = oVar.f37546d;
                p e10 = C5038f.e(tVar, gVar);
                S s10 = oVar.f37550h;
                C4154z g6 = s10.g(e10);
                boolean booleanValue = C5034b.f44772H.c(i10).booleanValue();
                boolean booleanValue2 = C5034b.f44773I.c(i10).booleanValue();
                boolean booleanValue3 = C5034b.f44774J.c(i10).booleanValue();
                int i13 = tVar.f44565z;
                if ((i13 & 16) == 16) {
                    pVar = tVar.f44560I;
                } else if ((i13 & 32) == 32) {
                    pVar = gVar.a(tVar.f44561J);
                } else {
                    pVar = null;
                }
                if (pVar != null) {
                    zVar = s10.g(pVar);
                }
                ArrayList arrayList2 = arrayList;
                arrayList2.add(new P(aVar, (h0) null, i11, fVar, b10, g6, booleanValue, booleanValue2, booleanValue3, zVar, C4309X.f40365y));
                h10 = this;
                arrayList = arrayList2;
                i11 = i12;
            } else {
                n.C();
                throw null;
            }
        }
        return s.w0(arrayList);
    }
}
