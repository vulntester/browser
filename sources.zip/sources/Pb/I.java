package Pb;

import Cb.b;
import Cb.f;
import kotlin.jvm.internal.l;
import zb.C5035c;

public final class I {
    public static final b a(C5035c cVar, int i10) {
        l.f(cVar, "<this>");
        return b.a.a(cVar.a(i10), cVar.c(i10));
    }

    public static final f b(C5035c cVar, int i10) {
        l.f(cVar, "<this>");
        return f.f(cVar.b(i10));
    }
}
