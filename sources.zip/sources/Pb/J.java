package Pb;

import Cb.b;
import android.util.SparseArray;
import com.google.android.gms.internal.pal.I7;
import db.C4309X;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.jvm.internal.l;
import t.C3104a;
import t.C3125v;
import xb.C4988b;
import ya.C5006C;
import ya.n;
import yb.C5022a;
import zb.C5036d;

public final class J implements C4119i {

    /* renamed from: E  reason: collision with root package name */
    public Object f37462E;

    /* renamed from: f  reason: collision with root package name */
    public final Object f37463f;

    /* renamed from: i  reason: collision with root package name */
    public Object f37464i;

    /* renamed from: z  reason: collision with root package name */
    public Object f37465z;

    public /* synthetic */ J(Class cls) {
        this.f37464i = new ConcurrentHashMap();
        this.f37463f = cls;
        this.f37462E = I7.f18154b;
    }

    public C4118h a(b bVar) {
        l.f(bVar, "classId");
        C4988b bVar2 = (C4988b) ((LinkedHashMap) this.f37462E).get(bVar);
        if (bVar2 == null) {
            return null;
        }
        ((r) this.f37465z).invoke(bVar);
        return new C4118h((C5036d) this.f37463f, bVar2, (C5022a) this.f37464i, C4309X.f40365y);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:?, code lost:
        r2 = new com.google.android.gms.internal.pal.C1731d2(2);
        r3 = com.google.android.gms.internal.pal.C1758f7.f18507a[androidx.datastore.preferences.protobuf.C1311s.a(r6.f18855d)];
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x0136, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x013f, code lost:
        throw new java.lang.RuntimeException("Creating a LegacyProtoKey failed", r0);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0066 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(java.lang.Object r14, com.google.android.gms.internal.pal.C1804j9 r15, boolean r16) {
        /*
            r13 = this;
            java.lang.Object r0 = r13.f37464i
            j$.util.concurrent.ConcurrentHashMap r0 = (j$.util.concurrent.ConcurrentHashMap) r0
            if (r0 == 0) goto L_0x0150
            int r0 = r15.y()
            r1 = 3
            if (r0 != r1) goto L_0x0148
            java.lang.Object r0 = r13.f37464i
            j$.util.concurrent.ConcurrentHashMap r0 = (j$.util.concurrent.ConcurrentHashMap) r0
            int r2 = r15.r()
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            int r3 = r15.z()
            r4 = 0
            r5 = 5
            if (r3 != r5) goto L_0x0023
            r11 = r4
            goto L_0x0024
        L_0x0023:
            r11 = r2
        L_0x0024:
            com.google.android.gms.internal.pal.k7 r2 = com.google.android.gms.internal.pal.C1813k7.f18728b
            com.google.android.gms.internal.pal.c9 r3 = r15.s()
            java.lang.String r7 = r3.w()
            com.google.android.gms.internal.pal.c9 r3 = r15.s()
            com.google.android.gms.internal.pal.F r8 = r3.v()
            com.google.android.gms.internal.pal.c9 r3 = r15.s()
            int r9 = r3.s()
            int r10 = r15.z()
            if (r10 != r5) goto L_0x004f
            if (r11 != 0) goto L_0x0047
            goto L_0x0051
        L_0x0047:
            java.security.GeneralSecurityException r14 = new java.security.GeneralSecurityException
            java.lang.String r15 = "Keys with output prefix type raw should not have an id requirement."
            r14.<init>(r15)
            throw r14
        L_0x004f:
            if (r11 == 0) goto L_0x0140
        L_0x0051:
            com.google.android.gms.internal.pal.r7 r6 = new com.google.android.gms.internal.pal.r7
            r6.<init>(r7, r8, r9, r10, r11)
            r2.getClass()
            java.util.concurrent.atomic.AtomicReference r2 = r2.f18729a     // Catch:{ GeneralSecurityException -> 0x0066 }
            java.lang.Object r2 = r2.get()     // Catch:{ GeneralSecurityException -> 0x0066 }
            com.google.android.gms.internal.pal.w7 r2 = (com.google.android.gms.internal.pal.C1944w7) r2     // Catch:{ GeneralSecurityException -> 0x0066 }
            com.google.android.gms.internal.pal.d2 r2 = r2.a(r6)     // Catch:{ GeneralSecurityException -> 0x0066 }
            goto L_0x0076
        L_0x0066:
            com.google.android.gms.internal.pal.g7 r2 = new com.google.android.gms.internal.pal.g7     // Catch:{ GeneralSecurityException -> 0x0136 }
            r3 = 2
            r2.<init>(r3)     // Catch:{ GeneralSecurityException -> 0x0136 }
            int[] r3 = com.google.android.gms.internal.pal.C1758f7.f18507a     // Catch:{ GeneralSecurityException -> 0x0136 }
            int r6 = r6.f18855d     // Catch:{ GeneralSecurityException -> 0x0136 }
            int r6 = androidx.datastore.preferences.protobuf.C1311s.a(r6)     // Catch:{ GeneralSecurityException -> 0x0136 }
            r3 = r3[r6]     // Catch:{ GeneralSecurityException -> 0x0136 }
        L_0x0076:
            boolean r3 = r2 instanceof com.google.android.gms.internal.pal.C1769g7
            if (r3 == 0) goto L_0x008d
            com.google.android.gms.internal.pal.E5 r2 = new com.google.android.gms.internal.pal.E5
            com.google.android.gms.internal.pal.c9 r3 = r15.s()
            java.lang.String r3 = r3.w()
            int r6 = r15.z()
            r2.<init>(r3, r6)
        L_0x008b:
            r12 = r2
            goto L_0x0092
        L_0x008d:
            com.google.android.gms.internal.pal.B5 r2 = r2.a()
            goto L_0x008b
        L_0x0092:
            com.google.android.gms.internal.pal.C5 r6 = new com.google.android.gms.internal.pal.C5
            int r2 = r15.z()
            int r2 = r2 + -2
            r3 = 1
            if (r2 == r3) goto L_0x00c8
            r3 = 2
            if (r2 == r3) goto L_0x00b2
            if (r2 == r1) goto L_0x00ae
            r1 = 4
            if (r2 != r1) goto L_0x00a6
            goto L_0x00b2
        L_0x00a6:
            java.security.GeneralSecurityException r14 = new java.security.GeneralSecurityException
            java.lang.String r15 = "unknown output prefix type"
            r14.<init>(r15)
            throw r14
        L_0x00ae:
            byte[] r1 = com.google.android.gms.internal.pal.C1778h5.f18517a
        L_0x00b0:
            r8 = r1
            goto L_0x00dd
        L_0x00b2:
            java.nio.ByteBuffer r1 = java.nio.ByteBuffer.allocate(r5)
            r2 = 0
            java.nio.ByteBuffer r1 = r1.put(r2)
            int r2 = r15.r()
            java.nio.ByteBuffer r1 = r1.putInt(r2)
            byte[] r1 = r1.array()
            goto L_0x00b0
        L_0x00c8:
            java.nio.ByteBuffer r1 = java.nio.ByteBuffer.allocate(r5)
            java.nio.ByteBuffer r1 = r1.put(r3)
            int r2 = r15.r()
            java.nio.ByteBuffer r1 = r1.putInt(r2)
            byte[] r1 = r1.array()
            goto L_0x00b0
        L_0x00dd:
            int r9 = r15.y()
            int r10 = r15.z()
            int r11 = r15.r()
            r7 = r14
            r6.<init>(r7, r8, r9, r10, r11, r12)
            java.util.ArrayList r14 = new java.util.ArrayList
            r14.<init>()
            r14.add(r6)
            com.google.android.gms.internal.pal.D5 r15 = new com.google.android.gms.internal.pal.D5
            byte[] r1 = r6.f18037b
            if (r1 != 0) goto L_0x00fc
            goto L_0x0101
        L_0x00fc:
            int r2 = r1.length
            byte[] r4 = java.util.Arrays.copyOf(r1, r2)
        L_0x0101:
            r15.<init>(r4)
            java.util.List r14 = java.util.Collections.unmodifiableList(r14)
            java.lang.Object r14 = r0.put(r15, r14)
            java.util.List r14 = (java.util.List) r14
            if (r14 == 0) goto L_0x0122
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r1.addAll(r14)
            r1.add(r6)
            java.util.List r14 = java.util.Collections.unmodifiableList(r1)
            r0.put(r15, r14)
        L_0x0122:
            if (r16 == 0) goto L_0x0135
            java.lang.Object r14 = r13.f37465z
            com.google.android.gms.internal.pal.C5 r14 = (com.google.android.gms.internal.pal.C5) r14
            if (r14 != 0) goto L_0x012d
            r13.f37465z = r6
            goto L_0x0135
        L_0x012d:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r15 = "you cannot set two primary primitives"
            r14.<init>(r15)
            throw r14
        L_0x0135:
            return
        L_0x0136:
            r0 = move-exception
            r14 = r0
            N0.d r15 = new N0.d
            java.lang.String r0 = "Creating a LegacyProtoKey failed"
            r15.<init>(r0, r14)
            throw r15
        L_0x0140:
            java.security.GeneralSecurityException r14 = new java.security.GeneralSecurityException
            java.lang.String r15 = "Keys with output prefix type different from raw should have an id requirement."
            r14.<init>(r15)
            throw r14
        L_0x0148:
            java.security.GeneralSecurityException r14 = new java.security.GeneralSecurityException
            java.lang.String r15 = "only ENABLED key is allowed"
            r14.<init>(r15)
            throw r14
        L_0x0150:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r15 = "addPrimitive cannot be called after build"
            r14.<init>(r15)
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: Pb.J.b(java.lang.Object, com.google.android.gms.internal.pal.j9, boolean):void");
    }

    public J() {
        this.f37463f = new C3104a();
        this.f37464i = new SparseArray();
        this.f37465z = new C3125v();
        this.f37462E = new C3104a();
    }

    public J(xb.l lVar, C5036d dVar, C5022a aVar, r rVar) {
        this.f37463f = dVar;
        this.f37464i = aVar;
        this.f37465z = rVar;
        List<C4988b> list = lVar.f44359H;
        l.e(list, "getClass_List(...)");
        int t10 = C5006C.t(n.v(10, list));
        LinkedHashMap linkedHashMap = new LinkedHashMap(t10 < 16 ? 16 : t10);
        for (T next : list) {
            linkedHashMap.put(I.a((C5036d) this.f37463f, ((C4988b) next).f44152F), next);
        }
        this.f37462E = linkedHashMap;
    }
}
