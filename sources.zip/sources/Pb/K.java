package Pb;

import Cb.c;
import db.C4309X;
import kotlin.jvm.internal.l;
import vb.n;
import xb.C4988b;
import zb.C5034b;
import zb.C5035c;
import zb.C5039g;

public abstract class K {

    /* renamed from: a  reason: collision with root package name */
    public final C5035c f37466a;

    /* renamed from: b  reason: collision with root package name */
    public final C5039g f37467b;

    /* renamed from: c  reason: collision with root package name */
    public final C4309X f37468c;

    public static final class a extends K {

        /* renamed from: d  reason: collision with root package name */
        public final C4988b f37469d;

        /* renamed from: e  reason: collision with root package name */
        public final a f37470e;

        /* renamed from: f  reason: collision with root package name */
        public final Cb.b f37471f;

        /* renamed from: g  reason: collision with root package name */
        public final C4988b.c f37472g;

        /* renamed from: h  reason: collision with root package name */
        public final boolean f37473h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(C4988b bVar, C5035c cVar, C5039g gVar, C4309X x10, a aVar) {
            super(cVar, gVar, x10);
            l.f(bVar, "classProto");
            l.f(cVar, "nameResolver");
            this.f37469d = bVar;
            this.f37470e = aVar;
            this.f37471f = I.a(cVar, bVar.f44152F);
            C4988b.c cVar2 = (C4988b.c) C5034b.f44784f.c(bVar.f44151E);
            this.f37472g = cVar2 == null ? C4988b.c.CLASS : cVar2;
            this.f37473h = C5034b.f44785g.c(bVar.f44151E).booleanValue();
            C5034b.f44786h.getClass();
        }

        public final c a() {
            return this.f37471f.a();
        }
    }

    public static final class b extends K {

        /* renamed from: d  reason: collision with root package name */
        public final c f37474d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(c cVar, C5035c cVar2, C5039g gVar, n nVar) {
            super(cVar2, gVar, nVar);
            l.f(cVar, "fqName");
            l.f(cVar2, "nameResolver");
            this.f37474d = cVar;
        }

        public final c a() {
            return this.f37474d;
        }
    }

    public K(C5035c cVar, C5039g gVar, C4309X x10) {
        this.f37466a = cVar;
        this.f37467b = gVar;
        this.f37468c = x10;
    }

    public abstract c a();

    public final String toString() {
        return getClass().getSimpleName() + ": " + a();
    }
}
