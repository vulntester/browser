package Pb;

import db.C4289C;
import xb.j;

public final class L {

    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f37475a;

        /* renamed from: b  reason: collision with root package name */
        public static final /* synthetic */ int[] f37476b;

        /* JADX WARNING: Can't wrap try/catch for region: R(76:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|(2:33|34)|35|(2:37|38)|39|41|42|43|45|46|47|48|49|50|51|52|53|54|(2:55|56)|57|(2:59|60)|61|63|64|65|66|67|68|69|70|71|72|(2:73|74)|75|77|78|79|80|(2:81|82)|83|85|86|87|88|89|90|(2:91|92)|93|95|96|97|98|(3:99|100|102)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(78:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|54|(2:55|56)|57|(2:59|60)|61|63|64|65|66|67|68|69|70|71|72|(2:73|74)|75|77|78|79|80|(2:81|82)|83|85|86|87|88|89|90|(2:91|92)|93|95|96|97|98|(3:99|100|102)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(79:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|54|(2:55|56)|57|(2:59|60)|61|63|64|65|66|67|68|69|70|71|72|73|74|75|77|78|79|80|(2:81|82)|83|85|86|87|88|89|90|(2:91|92)|93|95|96|97|98|(3:99|100|102)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(81:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|54|(2:55|56)|57|(2:59|60)|61|63|64|65|66|67|68|69|70|71|72|73|74|75|77|78|79|80|(2:81|82)|83|85|86|87|88|89|90|(2:91|92)|93|95|96|97|98|99|100|102) */
        /* JADX WARNING: Can't wrap try/catch for region: R(86:0|(2:1|2)|3|(2:5|6)|7|9|10|11|13|14|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|59|60|61|63|64|65|66|67|68|69|70|71|72|73|74|75|77|78|79|80|(2:81|82)|83|85|86|87|88|89|90|91|92|93|95|96|97|98|99|100|102) */
        /* JADX WARNING: Can't wrap try/catch for region: R(87:0|(2:1|2)|3|5|6|7|9|10|11|13|14|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|59|60|61|63|64|65|66|67|68|69|70|71|72|73|74|75|77|78|79|80|(2:81|82)|83|85|86|87|88|89|90|91|92|93|95|96|97|98|99|100|102) */
        /* JADX WARNING: Can't wrap try/catch for region: R(88:0|1|2|3|5|6|7|9|10|11|13|14|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|54|55|56|57|59|60|61|63|64|65|66|67|68|69|70|71|72|73|74|75|77|78|79|80|(2:81|82)|83|85|86|87|88|89|90|91|92|93|95|96|97|98|99|100|102) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x001f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x0023 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0027 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x0034 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x0036 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:33:0x0038 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:47:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:49:0x004b */
        /* JADX WARNING: Missing exception handler attribute for start block: B:51:0x004d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:53:0x004f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:55:0x0051 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:65:0x0061 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:67:0x0065 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:69:0x0069 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:71:0x006d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:73:0x0071 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:79:0x007e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:81:0x0080 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:87:0x008b */
        /* JADX WARNING: Missing exception handler attribute for start block: B:89:0x008d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:91:0x008f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:97:0x009a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:99:0x009e */
        static {
            /*
                xb.j[] r0 = xb.j.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r1 = 0
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x000b }
            L_0x000b:
                r3 = 2
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x000e }
            L_0x000e:
                r4 = 3
                r0[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0011 }
            L_0x0011:
                r5 = 4
                r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                f37475a = r0
                db.C[] r0 = db.C4289C.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                db.C$a r6 = db.C4289C.f40339f     // Catch:{ NoSuchFieldError -> 0x0023 }
                r0[r3] = r3     // Catch:{ NoSuchFieldError -> 0x0023 }
            L_0x0023:
                db.C$a r6 = db.C4289C.f40339f     // Catch:{ NoSuchFieldError -> 0x0027 }
                r0[r4] = r4     // Catch:{ NoSuchFieldError -> 0x0027 }
            L_0x0027:
                db.C$a r6 = db.C4289C.f40339f     // Catch:{ NoSuchFieldError -> 0x002b }
                r0[r2] = r5     // Catch:{ NoSuchFieldError -> 0x002b }
            L_0x002b:
                xb.w[] r0 = xb.w.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0034 }
            L_0x0034:
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0036 }
            L_0x0036:
                r0[r5] = r4     // Catch:{ NoSuchFieldError -> 0x0038 }
            L_0x0038:
                r0[r3] = r5     // Catch:{ NoSuchFieldError -> 0x003a }
            L_0x003a:
                r6 = 5
                r0[r4] = r6     // Catch:{ NoSuchFieldError -> 0x003d }
            L_0x003d:
                r7 = 6
                r0[r6] = r7     // Catch:{ NoSuchFieldError -> 0x0040 }
            L_0x0040:
                xb.b$c[] r0 = xb.C4988b.c.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x004b }
            L_0x004b:
                r0[r3] = r4     // Catch:{ NoSuchFieldError -> 0x004d }
            L_0x004d:
                r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x004f }
            L_0x004f:
                r0[r5] = r6     // Catch:{ NoSuchFieldError -> 0x0051 }
            L_0x0051:
                r0[r6] = r7     // Catch:{ NoSuchFieldError -> 0x0053 }
            L_0x0053:
                r8 = 7
                r0[r7] = r8     // Catch:{ NoSuchFieldError -> 0x0056 }
            L_0x0056:
                f37476b = r0
                db.f[] r0 = db.C4316f.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0061 }
            L_0x0061:
                db.f r8 = db.C4316f.f40382f     // Catch:{ NoSuchFieldError -> 0x0065 }
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0065 }
            L_0x0065:
                db.f r8 = db.C4316f.f40382f     // Catch:{ NoSuchFieldError -> 0x0069 }
                r0[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0069 }
            L_0x0069:
                db.f r8 = db.C4316f.f40382f     // Catch:{ NoSuchFieldError -> 0x006d }
                r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x006d }
            L_0x006d:
                db.f r8 = db.C4316f.f40382f     // Catch:{ NoSuchFieldError -> 0x0071 }
                r0[r5] = r6     // Catch:{ NoSuchFieldError -> 0x0071 }
            L_0x0071:
                db.f r8 = db.C4316f.f40382f     // Catch:{ NoSuchFieldError -> 0x0075 }
                r0[r6] = r7     // Catch:{ NoSuchFieldError -> 0x0075 }
            L_0x0075:
                xb.r$c[] r0 = xb.r.c.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x007e }
            L_0x007e:
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0080 }
            L_0x0080:
                r0[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0082 }
            L_0x0082:
                xb.p$b$c[] r0 = xb.p.b.c.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x008b }
            L_0x008b:
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x008d }
            L_0x008d:
                r0[r3] = r4     // Catch:{ NoSuchFieldError -> 0x008f }
            L_0x008f:
                r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0091 }
            L_0x0091:
                Tb.o0[] r0 = Tb.o0.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r2] = r2     // Catch:{ NoSuchFieldError -> 0x009a }
            L_0x009a:
                Tb.o0 r2 = Tb.o0.INVARIANT     // Catch:{ NoSuchFieldError -> 0x009e }
                r0[r3] = r3     // Catch:{ NoSuchFieldError -> 0x009e }
            L_0x009e:
                Tb.o0 r2 = Tb.o0.INVARIANT     // Catch:{ NoSuchFieldError -> 0x00a2 }
                r0[r1] = r4     // Catch:{ NoSuchFieldError -> 0x00a2 }
            L_0x00a2:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: Pb.L.a.<clinit>():void");
        }
    }

    public static C4289C a(j jVar) {
        int i10;
        if (jVar == null) {
            i10 = -1;
        } else {
            i10 = a.f37475a[jVar.ordinal()];
        }
        if (i10 == 1) {
            return C4289C.f40340i;
        }
        if (i10 == 2) {
            return C4289C.f40336E;
        }
        if (i10 == 3) {
            return C4289C.f40337F;
        }
        if (i10 != 4) {
            return C4289C.f40340i;
        }
        return C4289C.f40341z;
    }
}
