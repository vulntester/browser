package Pb;

import db.C4312b;
import db.C4326p;
import db.C4328r;
import kotlin.jvm.internal.l;
import xb.i;
import xb.w;

public final class M {

    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f37477a;

        /* renamed from: b  reason: collision with root package name */
        public static final /* synthetic */ int[] f37478b;

        /* JADX WARNING: Can't wrap try/catch for region: R(30:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|17|18|19|20|21|22|(2:23|24)|25|27|28|29|30|31|32|(2:33|34)|35|(2:37|38)|39|(2:41|42)|43|45) */
        /* JADX WARNING: Can't wrap try/catch for region: R(31:0|(2:1|2)|3|(2:5|6)|7|9|10|11|(2:13|14)|15|17|18|19|20|21|22|(2:23|24)|25|27|28|29|30|31|32|(2:33|34)|35|(2:37|38)|39|(2:41|42)|43|45) */
        /* JADX WARNING: Can't wrap try/catch for region: R(38:0|1|2|3|5|6|7|9|10|11|13|14|15|17|18|19|20|21|22|23|24|25|27|28|29|30|31|32|33|34|35|37|38|39|41|42|43|45) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x001f */
        /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x0021 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0023 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x002e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x0030 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:33:0x0032 */
        static {
            /*
                xb.i[] r0 = xb.i.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r1 = 0
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x000b }
            L_0x000b:
                r3 = 2
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x000e }
            L_0x000e:
                r4 = 3
                r0[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0011 }
            L_0x0011:
                r5 = 4
                r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0014 }
            L_0x0014:
                f37477a = r0
                db.b$a[] r0 = db.C4312b.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001f }
            L_0x001f:
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0021 }
            L_0x0021:
                r0[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0023 }
            L_0x0023:
                r0[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0025 }
            L_0x0025:
                xb.w[] r0 = xb.w.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x002e }
            L_0x002e:
                r0[r2] = r3     // Catch:{ NoSuchFieldError -> 0x0030 }
            L_0x0030:
                r0[r5] = r4     // Catch:{ NoSuchFieldError -> 0x0032 }
            L_0x0032:
                r0[r3] = r5     // Catch:{ NoSuchFieldError -> 0x0034 }
            L_0x0034:
                r1 = 5
                r0[r4] = r1     // Catch:{ NoSuchFieldError -> 0x0037 }
            L_0x0037:
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x003a }
            L_0x003a:
                f37478b = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: Pb.M.a.<clinit>():void");
        }
    }

    public static final C4326p a(w wVar) {
        int i10;
        if (wVar == null) {
            i10 = -1;
        } else {
            i10 = a.f37478b[wVar.ordinal()];
        }
        switch (i10) {
            case 1:
                C4328r.g gVar = C4328r.f40399d;
                l.e(gVar, "INTERNAL");
                return gVar;
            case 2:
                C4328r.d dVar = C4328r.f40396a;
                l.e(dVar, "PRIVATE");
                return dVar;
            case 3:
                C4328r.e eVar = C4328r.f40397b;
                l.e(eVar, "PRIVATE_TO_THIS");
                return eVar;
            case 4:
                C4328r.f fVar = C4328r.f40398c;
                l.e(fVar, "PROTECTED");
                return fVar;
            case 5:
                C4328r.h hVar = C4328r.f40400e;
                l.e(hVar, "PUBLIC");
                return hVar;
            case 6:
                C4328r.i iVar = C4328r.f40401f;
                l.e(iVar, "LOCAL");
                return iVar;
            default:
                C4328r.d dVar2 = C4328r.f40396a;
                l.e(dVar2, "PRIVATE");
                return dVar2;
        }
    }

    public static final C4312b.a b(i iVar) {
        int i10;
        if (iVar == null) {
            i10 = -1;
        } else {
            i10 = a.f37477a[iVar.ordinal()];
        }
        C4312b.a aVar = C4312b.a.f40370f;
        if (i10 != 1) {
            if (i10 == 2) {
                return C4312b.a.f40371i;
            }
            if (i10 == 3) {
                return C4312b.a.f40372z;
            }
            if (i10 == 4) {
                return C4312b.a.f40368E;
            }
        }
        return aVar;
    }
}
