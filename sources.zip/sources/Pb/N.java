package Pb;

import Cb.a;
import Cb.c;
import Cb.f;
import ab.o;

public final class N {

    /* renamed from: a  reason: collision with root package name */
    public static final c f37479a = new c("kotlin.suspend");

    static {
        new a(o.f39173l, f.g("suspend"));
    }
}
