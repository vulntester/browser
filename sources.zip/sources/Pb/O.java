package Pb;

import B0.C0491s;
import Cb.b;
import Cb.f;
import Na.l;
import Rb.q;
import Rb.r;
import Rb.w;
import Tb.C4135f;
import Tb.C4154z;
import Tb.n0;
import db.C4318h;
import db.C4332v;
import db.a0;
import db.c0;
import ec.C4398n;
import ec.C4400p;
import f7.M;
import gb.C4440e;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import m4.F;
import xa.C4959D;
import xb.h;
import ya.s;
import ya.u;

public final class O implements l {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f37480f;

    /* renamed from: i  reason: collision with root package name */
    public final Object f37481i;

    public /* synthetic */ O(Object obj, int i10) {
        this.f37480f = i10;
        this.f37481i = obj;
    }

    public final Object invoke(Object obj) {
        Collection<h> collection;
        Collection<C4154z> collection2;
        boolean z10;
        switch (this.f37480f) {
            case 0:
                int intValue = ((Number) obj).intValue();
                C4125o oVar = ((S) this.f37481i).f37486a;
                b a10 = I.a(oVar.f37544b, intValue);
                boolean z11 = a10.f33657c;
                C4123m mVar = oVar.f37543a;
                if (z11) {
                    return mVar.b(a10);
                }
                return C4332v.b(mVar.f37523b, a10);
            case 1:
                f fVar = (f) obj;
                kotlin.jvm.internal.l.f(fVar, "it");
                q.b bVar = (q.b) this.f37481i;
                LinkedHashMap linkedHashMap = bVar.f37754a;
                h.a aVar = h.f44298W;
                kotlin.jvm.internal.l.e(aVar, "PARSER");
                byte[] bArr = (byte[]) linkedHashMap.get(fVar);
                q qVar = bVar.f37762i;
                if (bArr != null) {
                    collection = C4400p.K(C4398n.C(new q.b.a(aVar, new ByteArrayInputStream(bArr), qVar)));
                } else {
                    collection = u.f44685f;
                }
                ArrayList arrayList = new ArrayList(collection.size());
                for (h hVar : collection) {
                    H h10 = qVar.f37749b.f37551i;
                    kotlin.jvm.internal.l.c(hVar);
                    w e10 = h10.e(hVar);
                    if (!qVar.r(e10)) {
                        e10 = null;
                    }
                    if (e10 != null) {
                        arrayList.add(e10);
                    }
                }
                qVar.j(fVar, arrayList);
                return F.h(arrayList);
            case 2:
                C4135f.a aVar2 = (C4135f.a) obj;
                kotlin.jvm.internal.l.f(aVar2, "supertypes");
                C4135f fVar2 = (C4135f) this.f37481i;
                a0 g6 = fVar2.g();
                r rVar = new r(fVar2, 3);
                r rVar2 = new r(fVar2, 1);
                Collection<C4154z> collection3 = aVar2.f38102a;
                g6.a(fVar2, collection3, rVar, rVar2);
                List list = null;
                if (collection3.isEmpty()) {
                    C4154z e11 = fVar2.e();
                    if (e11 != null) {
                        collection2 = M.s(e11);
                    } else {
                        collection2 = null;
                    }
                    if (collection2 == null) {
                        collection2 = u.f44685f;
                    }
                    collection3 = collection2;
                }
                if (collection3 instanceof List) {
                    list = (List) collection3;
                }
                if (list == null) {
                    list = s.w0(collection3);
                }
                List<C4154z> i10 = fVar2.i(list);
                kotlin.jvm.internal.l.f(i10, "<set-?>");
                aVar2.f38103b = i10;
                return C4959D.f44058a;
            default:
                n0 n0Var = (n0) obj;
                kotlin.jvm.internal.l.c(n0Var);
                if (!C0491s.q(n0Var)) {
                    C4318h n10 = n0Var.z0().n();
                    if ((n10 instanceof c0) && !kotlin.jvm.internal.l.a(((c0) n10).d(), (C4440e) this.f37481i)) {
                        z10 = true;
                        return Boolean.valueOf(z10);
                    }
                }
                z10 = false;
                return Boolean.valueOf(z10);
        }
    }
}
