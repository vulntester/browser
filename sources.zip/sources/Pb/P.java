package Pb;

import Na.a;
import Xa.C4187t;
import db.c0;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;
import xb.p;
import ya.n;

public final class P implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f37482f;

    /* renamed from: i  reason: collision with root package name */
    public final Object f37483i;

    /* renamed from: z  reason: collision with root package name */
    public final Object f37484z;

    public /* synthetic */ P(int i10, Object obj, Object obj2) {
        this.f37482f = i10;
        this.f37483i = obj;
        this.f37484z = obj2;
    }

    public final Object invoke() {
        switch (this.f37482f) {
            case 0:
                C4125o oVar = ((S) this.f37483i).f37486a;
                return oVar.f37543a.f37526e.a((p) this.f37484z, oVar.f37544b);
            default:
                List<c0> s10 = ((C4187t.a) this.f37483i).a().s();
                l.e(s10, "getDeclaredTypeParameters(...)");
                ArrayList arrayList = new ArrayList(n.v(10, s10));
                for (c0 c0Var : s10) {
                    l.c(c0Var);
                    arrayList.add(new Xa.P((C4187t) this.f37484z, c0Var));
                }
                return arrayList;
        }
    }
}
