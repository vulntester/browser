package Pb;

import Na.l;
import xb.p;

public final class Q implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final Q f37485f = new Object();

    public final Object invoke(Object obj) {
        p pVar = (p) obj;
        kotlin.jvm.internal.l.f(pVar, "it");
        return Integer.valueOf(pVar.f44441E.size());
    }
}
