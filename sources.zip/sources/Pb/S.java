package Pb;

import A.o;
import Cb.b;
import Rb.y;
import Sb.h;
import Tb.C4154z;
import Tb.H;
import Tb.V;
import Tb.W;
import Tb.Y;
import Tb.c0;
import Ua.f;
import ab.k;
import db.C4315e;
import db.C4321k;
import eb.C4377f;
import ec.C4398n;
import ec.C4400p;
import ec.C4402r;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.E;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.w;
import xb.p;
import xb.r;
import ya.n;
import ya.s;
import ya.u;
import ya.v;
import zb.C5038f;
import zb.C5039g;

public final class S {

    /* renamed from: a  reason: collision with root package name */
    public final C4125o f37486a;

    /* renamed from: b  reason: collision with root package name */
    public final S f37487b;

    /* renamed from: c  reason: collision with root package name */
    public final String f37488c;

    /* renamed from: d  reason: collision with root package name */
    public final String f37489d;

    /* renamed from: e  reason: collision with root package name */
    public final h f37490e;

    /* renamed from: f  reason: collision with root package name */
    public final h f37491f;

    /* renamed from: g  reason: collision with root package name */
    public final Object f37492g;

    public /* synthetic */ class a extends w {

        /* renamed from: f  reason: collision with root package name */
        public static final a f37493f = new w();

        public final Object get(Object obj) {
            return ((b) obj).e();
        }

        public final String getName() {
            return "outerClassId";
        }

        public final f getOwner() {
            return E.f41744a.b(b.class);
        }

        public final String getSignature() {
            return "getOuterClassId()Lorg/jetbrains/kotlin/name/ClassId;";
        }
    }

    public S(C4125o oVar, S s10, List<r> list, String str, String str2) {
        Map map;
        l.f(oVar, "c");
        l.f(list, "typeParameterProtos");
        l.f(str, "debugName");
        this.f37486a = oVar;
        this.f37487b = s10;
        this.f37488c = str;
        this.f37489d = str2;
        C4123m mVar = oVar.f37543a;
        this.f37490e = mVar.f37522a.f(new O(this, 0));
        this.f37491f = mVar.f37522a.f(new r(this, 1));
        if (list.isEmpty()) {
            map = v.f44686f;
        } else {
            map = new LinkedHashMap();
            int i10 = 0;
            for (r next : list) {
                map.put(Integer.valueOf(next.f44520E), new y(this.f37486a, next, i10));
                i10++;
            }
        }
        this.f37492g = map;
    }

    public static H a(H h10, C4154z zVar) {
        k A10 = o.A(h10);
        C4377f annotations = h10.getAnnotations();
        C4154z f10 = ab.h.f(h10);
        List<C4154z> d10 = ab.h.d(h10);
        List<c0> Q10 = s.Q(ab.h.g(h10));
        ArrayList arrayList = new ArrayList(n.v(10, Q10));
        for (c0 type : Q10) {
            arrayList.add(type.getType());
        }
        return ab.h.b(A10, annotations, f10, d10, arrayList, zVar, true).M0(h10.E0());
    }

    public static final ArrayList e(p pVar, S s10) {
        Iterable iterable;
        List<p.b> list = pVar.f44441E;
        l.e(list, "getArgumentList(...)");
        p a10 = C5038f.a(pVar, s10.f37486a.f37546d);
        if (a10 != null) {
            iterable = e(a10, s10);
        } else {
            iterable = null;
        }
        if (iterable == null) {
            iterable = u.f44685f;
        }
        return s.i0(list, iterable);
    }

    public static W f(List list, C4377f fVar, Y y10, C4321k kVar) {
        ArrayList arrayList = new ArrayList(n.v(10, list));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(((V) it.next()).a(fVar));
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            ya.r.F(arrayList2, (Iterable) it2.next());
        }
        W.f38074i.getClass();
        return W.a.l(arrayList2);
    }

    public static final C4315e h(S s10, p pVar, int i10) {
        b a10 = I.a(s10.f37486a.f37544b, i10);
        C4402r I10 = C4400p.I(C4398n.D(new Fb.r(s10, 1), pVar), Q.f37485f);
        ArrayList arrayList = new ArrayList();
        for (T invoke : I10.f40715a) {
            arrayList.add(I10.f40716b.invoke(invoke));
        }
        int E10 = C4400p.E(C4398n.D(a.f37493f, a10));
        while (arrayList.size() < E10) {
            arrayList.add(0);
        }
        return s10.f37486a.f37543a.f37533l.a(a10, arrayList);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.util.Map, java.lang.Object] */
    public final List<db.c0> b() {
        return s.w0(this.f37492g.values());
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.util.Map, java.lang.Object] */
    public final db.c0 c(int i10) {
        db.c0 c0Var = (db.c0) this.f37492g.get(Integer.valueOf(i10));
        if (c0Var != null) {
            return c0Var;
        }
        S s10 = this.f37487b;
        if (s10 != null) {
            return s10.c(i10);
        }
        return null;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v18, resolved type: Tb.e0} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v23, resolved type: Tb.e0} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v24, resolved type: Tb.e0} */
    /* JADX WARNING: type inference failed for: r19v0, types: [Tb.S, java.lang.Object] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:153:0x03ad  */
    /* JADX WARNING: Removed duplicated region for block: B:154:0x03ba  */
    /* JADX WARNING: Removed duplicated region for block: B:164:0x0400  */
    /* JADX WARNING: Removed duplicated region for block: B:165:0x0403  */
    /* JADX WARNING: Removed duplicated region for block: B:169:0x0410  */
    /* JADX WARNING: Removed duplicated region for block: B:171:0x041a A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0116  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x012f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Tb.H d(xb.p r26, boolean r27) {
        /*
            r25 = this;
            r0 = r25
            r1 = r26
            java.lang.String r5 = "getParameters(...)"
            r6 = 10
            r7 = 64
            r8 = 32
            r10 = 1
            r11 = 0
            r12 = 16
            java.lang.String r13 = "proto"
            kotlin.jvm.internal.l.f(r1, r13)
            int r13 = r1.f44458z
            r14 = r13 & 16
            if (r14 != r12) goto L_0x001d
            r14 = r10
            goto L_0x001e
        L_0x001d:
            r14 = r11
        L_0x001e:
            r15 = 128(0x80, float:1.794E-43)
            Pb.o r2 = r0.f37486a
            if (r14 == 0) goto L_0x0038
            int r13 = r1.f44446J
            zb.c r14 = r2.f37544b
            Cb.b r13 = Pb.I.a(r14, r13)
            boolean r13 = r13.f33657c
            if (r13 == 0) goto L_0x004e
            Pb.m r13 = r2.f37543a
            Pb.y r13 = r13.f37528g
            r13.getClass()
            goto L_0x004e
        L_0x0038:
            r13 = r13 & r15
            if (r13 != r15) goto L_0x004e
            int r13 = r1.f44449M
            zb.c r14 = r2.f37544b
            Cb.b r13 = Pb.I.a(r14, r13)
            boolean r13 = r13.f33657c
            if (r13 == 0) goto L_0x004e
            Pb.m r13 = r2.f37543a
            Pb.y r13 = r13.f37528g
            r13.getClass()
        L_0x004e:
            int r13 = r1.f44458z
            r14 = r13 & 16
            if (r14 != r12) goto L_0x0056
            r12 = r10
            goto L_0x0057
        L_0x0056:
            r12 = r11
        L_0x0057:
            java.lang.String r14 = "getTypeConstructor(...)"
            if (r12 == 0) goto L_0x0073
            int r7 = r1.f44446J
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)
            Sb.h r8 = r0.f37490e
            java.lang.Object r7 = r8.invoke(r7)
            db.h r7 = (db.C4318h) r7
            if (r7 != 0) goto L_0x00fa
            int r7 = r1.f44446J
            db.e r7 = h(r0, r1, r7)
            goto L_0x00fa
        L_0x0073:
            r12 = r13 & 32
            if (r12 != r8) goto L_0x0095
            int r7 = r1.f44447K
            db.c0 r7 = r0.c(r7)
            if (r7 != 0) goto L_0x00fa
            Vb.l r7 = Vb.l.f38476a
            Vb.k r7 = Vb.k.CANNOT_LOAD_DESERIALIZE_TYPE_PARAMETER
            int r8 = r1.f44447K
            java.lang.String r8 = java.lang.String.valueOf(r8)
            java.lang.String r12 = r0.f37489d
            java.lang.String[] r8 = new java.lang.String[]{r8, r12}
            Vb.j r7 = Vb.l.d(r7, r8)
            goto L_0x010c
        L_0x0095:
            r8 = r13 & 64
            if (r8 != r7) goto L_0x00e0
            zb.c r7 = r2.f37544b
            int r8 = r1.f44448L
            java.lang.String r7 = r7.b(r8)
            java.util.List r8 = r0.b()
            java.util.Iterator r8 = r8.iterator()
        L_0x00a9:
            boolean r12 = r8.hasNext()
            if (r12 == 0) goto L_0x00c5
            java.lang.Object r12 = r8.next()
            r13 = r12
            db.c0 r13 = (db.c0) r13
            Cb.f r13 = r13.getName()
            java.lang.String r13 = r13.d()
            boolean r13 = kotlin.jvm.internal.l.a(r13, r7)
            if (r13 == 0) goto L_0x00a9
            goto L_0x00c6
        L_0x00c5:
            r12 = 0
        L_0x00c6:
            r8 = r12
            db.c0 r8 = (db.c0) r8
            if (r8 != 0) goto L_0x00de
            Vb.l r8 = Vb.l.f38476a
            Vb.k r8 = Vb.k.CANNOT_LOAD_DESERIALIZE_TYPE_PARAMETER_BY_NAME
            db.k r12 = r2.f37545c
            java.lang.String r12 = r12.toString()
            java.lang.String[] r7 = new java.lang.String[]{r7, r12}
            Vb.j r7 = Vb.l.d(r8, r7)
            goto L_0x010c
        L_0x00de:
            r7 = r8
            goto L_0x00fa
        L_0x00e0:
            r7 = r13 & 128(0x80, float:1.794E-43)
            if (r7 != r15) goto L_0x0102
            int r7 = r1.f44449M
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)
            Sb.h r8 = r0.f37491f
            java.lang.Object r7 = r8.invoke(r7)
            db.h r7 = (db.C4318h) r7
            if (r7 != 0) goto L_0x00fa
            int r7 = r1.f44449M
            db.e r7 = h(r0, r1, r7)
        L_0x00fa:
            Tb.Y r7 = r7.h()
            kotlin.jvm.internal.l.e(r7, r14)
            goto L_0x010c
        L_0x0102:
            Vb.l r7 = Vb.l.f38476a
            Vb.k r7 = Vb.k.UNKNOWN_TYPE
            java.lang.String[] r8 = new java.lang.String[r11]
            Vb.j r7 = Vb.l.d(r7, r8)
        L_0x010c:
            db.h r8 = r7.n()
            boolean r8 = Vb.l.f(r8)
            if (r8 == 0) goto L_0x012f
            Vb.l r1 = Vb.l.f38476a
            Vb.k r1 = Vb.k.TYPE_FOR_ERROR_TYPE_CONSTRUCTOR
            java.lang.String r2 = r7.toString()
            java.lang.String[] r2 = new java.lang.String[]{r2}
            ya.u r3 = ya.u.f44685f
            java.lang.Object[] r2 = java.util.Arrays.copyOf(r2, r10)
            java.lang.String[] r2 = (java.lang.String[]) r2
            Vb.i r1 = Vb.l.e(r1, r3, r7, r2)
            return r1
        L_0x012f:
            Rb.a r8 = new Rb.a
            Pb.m r12 = r2.f37543a
            Sb.c r12 = r12.f37522a
            Pb.P r13 = new Pb.P
            r13.<init>(r11, r0, r1)
            r8.<init>(r12, r13)
            Pb.m r12 = r2.f37543a
            java.util.List<Tb.V> r13 = r12.f37539r
            db.k r15 = r2.f37545c
            Tb.W r13 = f(r13, r8, r7, r15)
            java.util.ArrayList r11 = e(r1, r0)
            r16 = 0
            java.util.ArrayList r9 = new java.util.ArrayList
            r17 = 4
            int r3 = ya.n.v(r6, r11)
            r9.<init>(r3)
            java.util.Iterator r3 = r11.iterator()
            r11 = 0
        L_0x015d:
            boolean r18 = r3.hasNext()
            zb.g r6 = r2.f37546d
            if (r18 == 0) goto L_0x0227
            java.lang.Object r18 = r3.next()
            int r19 = r11 + 1
            if (r11 < 0) goto L_0x0223
            r4 = r18
            xb.p$b r4 = (xb.p.b) r4
            java.util.List r10 = r7.getParameters()
            kotlin.jvm.internal.l.e(r10, r5)
            java.lang.Object r10 = ya.s.W(r11, r10)
            db.c0 r10 = (db.c0) r10
            xb.p$b$c r11 = r4.f44467z
            r21 = r2
            xb.p$b$c r2 = xb.p.b.c.STAR
            if (r11 != r2) goto L_0x01a0
            if (r10 != 0) goto L_0x019a
            Tb.M r2 = new Tb.M
            db.E r4 = r12.f37523b
            ab.k r4 = r4.l()
            r2.<init>(r4)
        L_0x0193:
            r20 = r3
            r10 = r17
            r11 = 2
            goto L_0x0213
        L_0x019a:
            Tb.N r2 = new Tb.N
            r2.<init>(r10)
            goto L_0x0193
        L_0x01a0:
            java.lang.String r2 = "getProjection(...)"
            kotlin.jvm.internal.l.e(r11, r2)
            int r2 = r11.ordinal()
            if (r2 == 0) goto L_0x01d4
            r10 = 1
            if (r2 == r10) goto L_0x01d1
            r10 = 2
            if (r2 == r10) goto L_0x01ce
            r1 = 3
            if (r2 == r1) goto L_0x01ba
            xa.k r1 = new xa.k
            r1.<init>()
            throw r1
        L_0x01ba:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Only IN, OUT and INV are supported. Actual argument: "
            r2.<init>(r3)
            r2.append(r11)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x01ce:
            Tb.o0 r2 = Tb.o0.INVARIANT
            goto L_0x01d6
        L_0x01d1:
            Tb.o0 r2 = Tb.o0.OUT_VARIANCE
            goto L_0x01d6
        L_0x01d4:
            Tb.o0 r2 = Tb.o0.IN_VARIANCE
        L_0x01d6:
            int r10 = r4.f44466i
            r20 = r3
            r11 = 2
            r3 = r10 & 2
            if (r3 != r11) goto L_0x01e4
            xb.p r3 = r4.f44461E
            r10 = r17
            goto L_0x01f3
        L_0x01e4:
            r3 = r10 & 4
            r10 = r17
            if (r3 != r10) goto L_0x01f1
            int r3 = r4.f44462F
            xb.p r3 = r6.a(r3)
            goto L_0x01f3
        L_0x01f1:
            r3 = r16
        L_0x01f3:
            if (r3 != 0) goto L_0x0209
            Tb.e0 r2 = new Tb.e0
            Vb.k r3 = Vb.k.NO_RECORDED_TYPE
            java.lang.String r4 = r4.toString()
            java.lang.String[] r4 = new java.lang.String[]{r4}
            Vb.i r3 = Vb.l.c(r3, r4)
            r2.<init>(r3)
            goto L_0x0213
        L_0x0209:
            Tb.e0 r4 = new Tb.e0
            Tb.z r3 = r0.g(r3)
            r4.<init>(r3, r2)
            r2 = r4
        L_0x0213:
            r9.add(r2)
            r17 = r10
            r11 = r19
            r3 = r20
            r2 = r21
            r6 = 10
            r10 = 1
            goto L_0x015d
        L_0x0223:
            ya.n.C()
            throw r16
        L_0x0227:
            java.util.List r2 = ya.s.w0(r9)
            db.h r3 = r7.n()
            if (r27 == 0) goto L_0x02d3
            boolean r4 = r3 instanceof db.b0
            if (r4 == 0) goto L_0x02d3
            db.b0 r3 = (db.b0) r3
            java.lang.String r4 = "<this>"
            kotlin.jvm.internal.l.f(r3, r4)
            java.lang.String r4 = "arguments"
            kotlin.jvm.internal.l.f(r2, r4)
            Tb.S r19 = new Tb.S
            r19.<init>()
            Tb.Y r4 = r3.h()
            java.util.List r4 = r4.getParameters()
            kotlin.jvm.internal.l.e(r4, r5)
            java.util.ArrayList r5 = new java.util.ArrayList
            r9 = 10
            int r9 = ya.n.v(r9, r4)
            r5.<init>(r9)
            java.util.Iterator r4 = r4.iterator()
        L_0x0260:
            boolean r9 = r4.hasNext()
            if (r9 == 0) goto L_0x0274
            java.lang.Object r9 = r4.next()
            db.c0 r9 = (db.c0) r9
            db.c0 r9 = r9.a()
            r5.add(r9)
            goto L_0x0260
        L_0x0274:
            java.util.ArrayList r4 = ya.s.C0(r5, r2)
            java.util.Map r4 = ya.C5007D.D(r4)
            Tb.T r5 = new Tb.T
            r9 = r16
            r5.<init>(r9, r3, r2, r4)
            Tb.W$a r2 = Tb.W.f38074i
            r2.getClass()
            Tb.W r2 = Tb.W.f38075z
            java.lang.String r3 = "attributes"
            kotlin.jvm.internal.l.f(r2, r3)
            r22 = 0
            r23 = 0
            r24 = 1
            r21 = r2
            r20 = r5
            Tb.H r2 = r19.c(r20, r21, r22, r23, r24)
            java.util.List<Tb.V> r3 = r12.f37539r
            eb.f r4 = r2.getAnnotations()
            java.util.ArrayList r4 = ya.s.g0(r8, r4)
            boolean r5 = r4.isEmpty()
            if (r5 == 0) goto L_0x02b0
            eb.f$a$a r4 = eb.C4377f.a.f40620a
            goto L_0x02b6
        L_0x02b0:
            eb.g r5 = new eb.g
            r5.<init>(r4)
            r4 = r5
        L_0x02b6:
            Tb.W r3 = f(r3, r4, r7, r15)
            boolean r4 = Tb.l0.e(r2)
            if (r4 != 0) goto L_0x02c7
            boolean r4 = r1.f44442F
            if (r4 == 0) goto L_0x02c5
            goto L_0x02c7
        L_0x02c5:
            r10 = 0
            goto L_0x02c8
        L_0x02c7:
            r10 = 1
        L_0x02c8:
            Tb.H r2 = r2.M0(r10)
            Tb.H r2 = r2.O0(r3)
        L_0x02d0:
            r9 = 0
            goto L_0x03f8
        L_0x02d3:
            zb.b$a r3 = zb.C5034b.f44779a
            int r4 = r1.f44454R
            java.lang.Boolean r3 = r3.c(r4)
            boolean r3 = r3.booleanValue()
            if (r3 == 0) goto L_0x03bd
            boolean r3 = r1.f44442F
            java.util.List r4 = r7.getParameters()
            int r4 = r4.size()
            int r5 = r2.size()
            int r4 = r4 - r5
            if (r4 == 0) goto L_0x0317
            r10 = 1
            if (r4 == r10) goto L_0x02f8
        L_0x02f5:
            r9 = 0
            goto L_0x03ab
        L_0x02f8:
            int r4 = r2.size()
            int r4 = r4 - r10
            if (r4 < 0) goto L_0x02f5
            ab.k r5 = r7.l()
            db.e r4 = r5.u(r4)
            Tb.Y r4 = r4.h()
            kotlin.jvm.internal.l.e(r4, r14)
            r9 = 0
            Tb.H r16 = Tb.C.c(r13, r4, r2, r3, r9)
            r9 = r16
            goto L_0x03ab
        L_0x0317:
            r9 = 0
            Tb.H r3 = Tb.C.c(r13, r7, r2, r3, r9)
            Tb.Y r4 = r3.z0()
            db.h r4 = r4.n()
            if (r4 == 0) goto L_0x032b
            bb.f r9 = ab.h.e(r4)
            goto L_0x032c
        L_0x032b:
            r9 = 0
        L_0x032c:
            bb.f$a r4 = bb.C4232f.a.f39367c
            boolean r4 = kotlin.jvm.internal.l.a(r9, r4)
            if (r4 != 0) goto L_0x0335
            goto L_0x02f5
        L_0x0335:
            java.util.List r4 = ab.h.g(r3)
            java.lang.Object r4 = ya.s.d0(r4)
            Tb.c0 r4 = (Tb.c0) r4
            if (r4 == 0) goto L_0x02f5
            Tb.z r4 = r4.getType()
            if (r4 != 0) goto L_0x0348
            goto L_0x02f5
        L_0x0348:
            Tb.Y r5 = r4.z0()
            db.h r5 = r5.n()
            if (r5 == 0) goto L_0x0357
            Cb.c r9 = Jb.d.g(r5)
            goto L_0x0358
        L_0x0357:
            r9 = 0
        L_0x0358:
            java.util.List r5 = r4.X()
            int r5 = r5.size()
            r10 = 1
            if (r5 != r10) goto L_0x03aa
            Cb.c r5 = ab.o.f39168g
            boolean r5 = kotlin.jvm.internal.l.a(r9, r5)
            if (r5 != 0) goto L_0x0374
            Cb.c r5 = Pb.T.f37494a
            boolean r5 = kotlin.jvm.internal.l.a(r9, r5)
            if (r5 != 0) goto L_0x0374
            goto L_0x03aa
        L_0x0374:
            java.util.List r4 = r4.X()
            java.lang.Object r4 = ya.s.m0(r4)
            Tb.c0 r4 = (Tb.c0) r4
            Tb.z r4 = r4.getType()
            java.lang.String r5 = "getType(...)"
            kotlin.jvm.internal.l.e(r4, r5)
            boolean r5 = r15 instanceof db.C4311a
            if (r5 == 0) goto L_0x038f
            r9 = r15
            db.a r9 = (db.C4311a) r9
            goto L_0x0390
        L_0x038f:
            r9 = 0
        L_0x0390:
            if (r9 == 0) goto L_0x0397
            Cb.c r9 = Jb.d.c(r9)
            goto L_0x0398
        L_0x0397:
            r9 = 0
        L_0x0398:
            Cb.c r5 = Pb.N.f37479a
            boolean r5 = kotlin.jvm.internal.l.a(r9, r5)
            if (r5 == 0) goto L_0x03a5
            Tb.H r9 = a(r3, r4)
            goto L_0x03ab
        L_0x03a5:
            Tb.H r9 = a(r3, r4)
            goto L_0x03ab
        L_0x03aa:
            r9 = r3
        L_0x03ab:
            if (r9 != 0) goto L_0x03ba
            Vb.l r3 = Vb.l.f38476a
            Vb.k r3 = Vb.k.INCONSISTENT_SUSPEND_FUNCTION
            r4 = 0
            java.lang.String[] r5 = new java.lang.String[r4]
            Vb.i r2 = Vb.l.e(r3, r2, r7, r5)
            goto L_0x02d0
        L_0x03ba:
            r2 = r9
            goto L_0x02d0
        L_0x03bd:
            boolean r3 = r1.f44442F
            r9 = 0
            Tb.H r2 = Tb.C.c(r13, r7, r2, r3, r9)
            zb.b$a r3 = zb.C5034b.f44780b
            int r4 = r1.f44454R
            java.lang.Boolean r3 = r3.c(r4)
            boolean r3 = r3.booleanValue()
            if (r3 == 0) goto L_0x03f8
            r10 = 1
            Tb.m r3 = Tb.C4142m.a.a(r2, r10)
            if (r3 == 0) goto L_0x03db
            r2 = r3
            goto L_0x03f8
        L_0x03db:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "null DefinitelyNotNullType for '"
            r3.<init>(r4)
            r3.append(r2)
            r2 = 39
            r3.append(r2)
            java.lang.String r2 = r3.toString()
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x03f8:
            int r3 = r1.f44458z
            r4 = 1024(0x400, float:1.435E-42)
            r5 = r3 & 1024(0x400, float:1.435E-42)
            if (r5 != r4) goto L_0x0403
            xb.p r9 = r1.f44452P
            goto L_0x040e
        L_0x0403:
            r4 = 2048(0x800, float:2.87E-42)
            r3 = r3 & r4
            if (r3 != r4) goto L_0x040e
            int r1 = r1.f44453Q
            xb.p r9 = r6.a(r1)
        L_0x040e:
            if (r9 == 0) goto L_0x041a
            r4 = 0
            Tb.H r1 = r0.d(r9, r4)
            Tb.H r1 = Tb.L.c(r2, r1)
            return r1
        L_0x041a:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: Pb.S.d(xb.p, boolean):Tb.H");
    }

    public final C4154z g(p pVar) {
        boolean z10;
        p pVar2;
        l.f(pVar, "proto");
        if ((pVar.f44458z & 2) == 2) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (!z10) {
            return d(pVar, true);
        }
        C4125o oVar = this.f37486a;
        String b10 = oVar.f37544b.b(pVar.f44443G);
        H d10 = d(pVar, true);
        C5039g gVar = oVar.f37546d;
        int i10 = pVar.f44458z;
        if ((i10 & 4) == 4) {
            pVar2 = pVar.f44444H;
        } else if ((i10 & 8) == 8) {
            pVar2 = gVar.a(pVar.f44445I);
        } else {
            pVar2 = null;
        }
        l.c(pVar2);
        return oVar.f37543a.f37531j.a(pVar, b10, d10, d(pVar2, true));
    }

    public final String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(this.f37488c);
        S s10 = this.f37487b;
        if (s10 == null) {
            str = "";
        } else {
            str = ". Child of " + s10.f37488c;
        }
        sb2.append(str);
        return sb2.toString();
    }
}
