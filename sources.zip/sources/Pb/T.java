package Pb;

import Cb.c;

public final class T {

    /* renamed from: a  reason: collision with root package name */
    public static final c f37494a = new c("kotlin.coroutines.experimental.Continuation");
}
