package Pb;

import Na.l;

public final class r implements l {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f37553f;

    /* renamed from: i  reason: collision with root package name */
    public final Object f37554i;

    public /* synthetic */ r(Object obj, int i10) {
        this.f37553f = i10;
        this.f37554i = obj;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v9, resolved type: Tb.Y} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v6, resolved type: Tb.f} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invoke(java.lang.Object r12) {
        /*
            r11 = this;
            java.lang.String r0 = "it"
            r1 = 0
            java.lang.Object r2 = r11.f37554i
            int r3 = r11.f37553f
            switch(r3) {
                case 0: goto L_0x01a2;
                case 1: goto L_0x0178;
                case 2: goto L_0x0119;
                case 3: goto L_0x00e4;
                case 4: goto L_0x0012;
                default: goto L_0x000a;
            }
        L_0x000a:
            Ub.f r12 = (Ub.f) r12
            Rb.x r2 = (Rb.x) r2
            r12.t0(r2)
            return r1
        L_0x0012:
            Tb.b0$a r12 = (Tb.b0.a) r12
            db.c0 r0 = r12.f38095a
            Tb.b0 r2 = (Tb.b0) r2
            r2.getClass()
            rb.a r3 = r12.f38096b
            java.util.Set r12 = r3.b()
            if (r12 == 0) goto L_0x0033
            db.c0 r1 = r0.a()
            boolean r1 = r12.contains(r1)
            if (r1 == 0) goto L_0x0033
            Tb.n0 r12 = r2.a(r3)
            goto L_0x00e3
        L_0x0033:
            Tb.H r1 = r0.q()
            java.lang.String r4 = "getDefaultType(...)"
            kotlin.jvm.internal.l.e(r1, r4)
            java.util.LinkedHashSet r4 = new java.util.LinkedHashSet
            r4.<init>()
            A.o.v(r1, r1, r4, r12)
            r1 = 10
            int r1 = ya.n.v(r1, r4)
            int r1 = ya.C5006C.t(r1)
            r5 = 16
            if (r1 >= r5) goto L_0x0053
            r1 = r5
        L_0x0053:
            java.util.LinkedHashMap r9 = new java.util.LinkedHashMap
            r9.<init>(r1)
            java.util.Iterator r1 = r4.iterator()
        L_0x005c:
            boolean r4 = r1.hasNext()
            if (r4 == 0) goto L_0x00a9
            java.lang.Object r4 = r1.next()
            r10 = r4
            db.c0 r10 = (db.c0) r10
            if (r12 == 0) goto L_0x0077
            boolean r4 = r12.contains(r10)
            if (r4 != 0) goto L_0x0072
            goto L_0x0077
        L_0x0072:
            Tb.d0 r4 = Tb.l0.k(r10, r3)
            goto L_0x00a1
        L_0x0077:
            r3.getClass()
            java.lang.String r4 = "typeParameter"
            kotlin.jvm.internal.l.f(r0, r4)
            java.util.Set<db.c0> r4 = r3.f43367f
            if (r4 == 0) goto L_0x0089
            java.util.LinkedHashSet r4 = ya.C5010G.I(r4, r0)
        L_0x0087:
            r6 = r4
            goto L_0x008e
        L_0x0089:
            java.util.Set r4 = f7.J.B(r0)
            goto L_0x0087
        L_0x008e:
            r5 = 0
            r8 = 47
            r4 = 0
            r7 = 0
            rb.a r4 = rb.C4808a.a(r3, r4, r5, r6, r7, r8)
            Tb.z r4 = r2.b(r10, r4)
            lc.o r5 = r2.f38092a
            Tb.c0 r4 = r5.g(r10, r3, r2, r4)
        L_0x00a1:
            Tb.Y r5 = r10.h()
            r9.put(r5, r4)
            goto L_0x005c
        L_0x00a9:
            Tb.a0$a r12 = Tb.a0.f38091b
            Tb.Z r12 = new Tb.Z
            r12.<init>(r9)
            Tb.j0 r12 = Tb.j0.e(r12)
            java.util.List r0 = r0.getUpperBounds()
            java.lang.String r1 = "getUpperBounds(...)"
            kotlin.jvm.internal.l.e(r0, r1)
            za.g r12 = r2.c(r12, r0, r3)
            za.c<E, ?> r0 = r12.f44759f
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L_0x00df
            za.c<E, ?> r0 = r12.f44759f
            int r0 = r0.f44740J
            r1 = 1
            if (r0 != r1) goto L_0x00d7
            java.lang.Object r12 = ya.s.l0(r12)
            Tb.z r12 = (Tb.C4154z) r12
            goto L_0x00e3
        L_0x00d7:
            java.lang.IllegalArgumentException r12 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Should only be one computed upper bound if no need to intersect all bounds"
            r12.<init>(r0)
            throw r12
        L_0x00df:
            Tb.n0 r12 = r2.a(r3)
        L_0x00e3:
            return r12
        L_0x00e4:
            Tb.Y r12 = (Tb.Y) r12
            kotlin.jvm.internal.l.f(r12, r0)
            Tb.f r2 = (Tb.C4135f) r2
            r2.getClass()
            boolean r0 = r12 instanceof Tb.C4135f
            if (r0 == 0) goto L_0x00f5
            r1 = r12
            Tb.f r1 = (Tb.C4135f) r1
        L_0x00f5:
            if (r1 == 0) goto L_0x010d
            Sb.i<Tb.f$a> r12 = r1.f38101b
            java.lang.Object r12 = r12.invoke()
            Tb.f$a r12 = (Tb.C4135f.a) r12
            java.util.Collection<Tb.z> r12 = r12.f38102a
            r0 = 0
            java.util.Collection r0 = r1.f(r0)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.ArrayList r12 = ya.s.i0(r12, r0)
            goto L_0x0116
        L_0x010d:
            java.util.Collection r12 = r12.m()
            java.lang.String r0 = "getSupertypes(...)"
            kotlin.jvm.internal.l.e(r12, r0)
        L_0x0116:
            java.lang.Iterable r12 = (java.lang.Iterable) r12
            return r12
        L_0x0119:
            Cb.f r12 = (Cb.f) r12
            kotlin.jvm.internal.l.f(r12, r0)
            Rb.q$b r2 = (Rb.q.b) r2
            java.util.LinkedHashMap r0 = r2.f37755b
            xb.m$a r1 = xb.m.f44370W
            java.lang.String r3 = "PARSER"
            kotlin.jvm.internal.l.e(r1, r3)
            java.lang.Object r0 = r0.get(r12)
            byte[] r0 = (byte[]) r0
            Rb.q r2 = r2.f37762i
            if (r0 == 0) goto L_0x0146
            java.io.ByteArrayInputStream r3 = new java.io.ByteArrayInputStream
            r3.<init>(r0)
            Rb.q$b$a r0 = new Rb.q$b$a
            r0.<init>(r1, r3, r2)
            ec.h r0 = ec.C4398n.C(r0)
            java.util.List r0 = ec.C4400p.K(r0)
            goto L_0x0148
        L_0x0146:
            ya.u r0 = ya.u.f44685f
        L_0x0148:
            java.util.ArrayList r1 = new java.util.ArrayList
            int r3 = r0.size()
            r1.<init>(r3)
            java.util.Iterator r0 = r0.iterator()
        L_0x0155:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L_0x0170
            java.lang.Object r3 = r0.next()
            xb.m r3 = (xb.m) r3
            Pb.o r4 = r2.f37749b
            Pb.H r4 = r4.f37551i
            kotlin.jvm.internal.l.c(r3)
            Rb.v r3 = r4.f(r3)
            r1.add(r3)
            goto L_0x0155
        L_0x0170:
            r2.k(r12, r1)
            java.util.List r12 = m4.F.h(r1)
            return r12
        L_0x0178:
            java.lang.Number r12 = (java.lang.Number) r12
            int r12 = r12.intValue()
            Pb.S r2 = (Pb.S) r2
            Pb.o r0 = r2.f37486a
            zb.c r2 = r0.f37544b
            Cb.b r12 = Pb.I.a(r2, r12)
            boolean r2 = r12.f33657c
            if (r2 == 0) goto L_0x018d
            goto L_0x01a1
        L_0x018d:
            Pb.m r0 = r0.f37543a
            db.E r0 = r0.f37523b
            java.lang.String r2 = "<this>"
            kotlin.jvm.internal.l.f(r0, r2)
            db.h r12 = db.C4332v.b(r0, r12)
            boolean r0 = r12 instanceof db.b0
            if (r0 == 0) goto L_0x01a1
            r1 = r12
            db.b0 r1 = (db.b0) r1
        L_0x01a1:
            return r1
        L_0x01a2:
            Cb.b r12 = (Cb.b) r12
            kotlin.jvm.internal.l.f(r12, r0)
            Pb.s r2 = (Pb.C4128s) r2
            r2.getClass()
            db.X$a r12 = db.C4309X.f40365y
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: Pb.r.invoke(java.lang.Object):java.lang.Object");
    }
}
