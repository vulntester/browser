package Pb;

import db.C4312b;
import db.C4315e;
import java.util.ArrayList;

public interface u {

    /* renamed from: a  reason: collision with root package name */
    public static final a f37561a = new Object();

    public static class a implements u {
        public static /* synthetic */ void c(int i10) {
            Object[] objArr = new Object[3];
            if (i10 != 1) {
                objArr[0] = "descriptor";
            } else {
                objArr[0] = "unresolvedSuperClasses";
            }
            objArr[1] = "kotlin/reflect/jvm/internal/impl/serialization/deserialization/ErrorReporter$1";
            if (i10 != 2) {
                objArr[2] = "reportIncompleteHierarchy";
            } else {
                objArr[2] = "reportCannotInferVisibility";
            }
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", objArr));
        }

        public final void a(C4315e eVar, ArrayList arrayList) {
            if (eVar == null) {
                c(0);
                throw null;
            }
        }

        public final void b(C4312b bVar) {
            if (bVar == null) {
                c(2);
                throw null;
            }
        }
    }

    void a(C4315e eVar, ArrayList arrayList);

    void b(C4312b bVar);
}
