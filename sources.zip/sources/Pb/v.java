package Pb;

import Tb.C4154z;
import Tb.H;
import kotlin.jvm.internal.l;
import xb.p;

public interface v {

    public static final class a implements v {

        /* renamed from: a  reason: collision with root package name */
        public static final a f37562a = new Object();

        public final C4154z a(p pVar, String str, H h10, H h11) {
            l.f(pVar, "proto");
            l.f(str, "flexibleId");
            l.f(h10, "lowerBound");
            l.f(h11, "upperBound");
            throw new IllegalArgumentException("This method should not be used.");
        }
    }

    C4154z a(p pVar, String str, H h10, H h11);
}
