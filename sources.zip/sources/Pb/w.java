package Pb;

import Bb.e;
import Cb.b;
import M.k;
import kotlin.jvm.internal.l;

public final class w<T> {

    /* renamed from: a  reason: collision with root package name */
    public final e f37563a;

    /* renamed from: b  reason: collision with root package name */
    public final e f37564b;

    /* renamed from: c  reason: collision with root package name */
    public final e f37565c;

    /* renamed from: d  reason: collision with root package name */
    public final e f37566d;

    /* renamed from: e  reason: collision with root package name */
    public final String f37567e;

    /* renamed from: f  reason: collision with root package name */
    public final b f37568f;

    public w(e eVar, e eVar2, e eVar3, e eVar4, String str, b bVar) {
        l.f(str, "filePath");
        l.f(bVar, "classId");
        this.f37563a = eVar;
        this.f37564b = eVar2;
        this.f37565c = eVar3;
        this.f37566d = eVar4;
        this.f37567e = str;
        this.f37568f = bVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof w)) {
            return false;
        }
        w wVar = (w) obj;
        if (this.f37563a.equals(wVar.f37563a) && l.a(this.f37564b, wVar.f37564b) && l.a(this.f37565c, wVar.f37565c) && this.f37566d.equals(wVar.f37566d) && l.a(this.f37567e, wVar.f37567e) && l.a(this.f37568f, wVar.f37568f)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i10;
        int hashCode = this.f37563a.hashCode() * 31;
        int i11 = 0;
        e eVar = this.f37564b;
        if (eVar == null) {
            i10 = 0;
        } else {
            i10 = eVar.hashCode();
        }
        int i12 = (hashCode + i10) * 31;
        e eVar2 = this.f37565c;
        if (eVar2 != null) {
            i11 = eVar2.hashCode();
        }
        return this.f37568f.hashCode() + k.k((this.f37566d.hashCode() + ((i12 + i11) * 31)) * 31, 31, this.f37567e);
    }

    public final String toString() {
        return "IncompatibleVersionErrorData(actualVersion=" + this.f37563a + ", compilerVersion=" + this.f37564b + ", languageVersion=" + this.f37565c + ", expectedVersion=" + this.f37566d + ", filePath=" + this.f37567e + ", classId=" + this.f37568f + ')';
    }
}
