package Pb;

public final class x implements C4129t {

    /* renamed from: a  reason: collision with root package name */
    public static final x f37569a = new Object();

    public final Boolean a() {
        return Boolean.TRUE;
    }
}
