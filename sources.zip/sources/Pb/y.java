package Pb;

public final class y {

    /* renamed from: a  reason: collision with root package name */
    public static final y f37570a = new Object();
}
