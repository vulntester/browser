package Pb;

import Na.a;
import Rb.v;
import Sb.c;
import xb.m;

public final class z implements a {

    /* renamed from: f  reason: collision with root package name */
    public final H f37571f;

    /* renamed from: i  reason: collision with root package name */
    public final m f37572i;

    /* renamed from: z  reason: collision with root package name */
    public final v f37573z;

    public z(H h10, m mVar, v vVar) {
        this.f37571f = h10;
        this.f37572i = mVar;
        this.f37573z = vVar;
    }

    public final Object invoke() {
        H h10 = this.f37571f;
        c cVar = h10.f37460a.f37543a.f37522a;
        F f10 = new F(h10, this.f37572i, this.f37573z);
        cVar.getClass();
        return new c.f(cVar, f10);
    }
}
