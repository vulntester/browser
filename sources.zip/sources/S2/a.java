package S2;

import R2.C;
import R2.C1012h;
import R2.C1013i;
import R2.C1015k;
import R2.H;
import R2.n;
import R2.p;
import R2.z;
import S7.C1150x;
import S7.O;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import l2.v;
import o2.C2756B;
import o2.o;

public final class a implements n {

    /* renamed from: q  reason: collision with root package name */
    public static final int[] f9663q = {13, 14, 16, 18, 20, 21, 27, 32, 6, 7, 6, 6, 1, 1, 1, 1};

    /* renamed from: r  reason: collision with root package name */
    public static final int[] f9664r = {18, 24, 33, 37, 41, 47, 51, 59, 61, 6, 1, 1, 1, 1, 1, 1};

    /* renamed from: s  reason: collision with root package name */
    public static final byte[] f9665s;

    /* renamed from: t  reason: collision with root package name */
    public static final byte[] f9666t;

    /* renamed from: a  reason: collision with root package name */
    public final byte[] f9667a = new byte[1];

    /* renamed from: b  reason: collision with root package name */
    public final C1015k f9668b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f9669c;

    /* renamed from: d  reason: collision with root package name */
    public long f9670d;

    /* renamed from: e  reason: collision with root package name */
    public int f9671e;

    /* renamed from: f  reason: collision with root package name */
    public int f9672f;

    /* renamed from: g  reason: collision with root package name */
    public int f9673g = -1;

    /* renamed from: h  reason: collision with root package name */
    public int f9674h;

    /* renamed from: i  reason: collision with root package name */
    public long f9675i;

    /* renamed from: j  reason: collision with root package name */
    public p f9676j;

    /* renamed from: k  reason: collision with root package name */
    public H f9677k;

    /* renamed from: l  reason: collision with root package name */
    public H f9678l;

    /* renamed from: m  reason: collision with root package name */
    public C f9679m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f9680n;

    /* renamed from: o  reason: collision with root package name */
    public long f9681o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f9682p;

    static {
        int i10 = C2756B.f25811a;
        Charset charset = StandardCharsets.UTF_8;
        f9665s = "#!AMR\n".getBytes(charset);
        f9666t = "#!AMR-WB\n".getBytes(charset);
    }

    public a() {
        C1015k kVar = new C1015k();
        this.f9668b = kVar;
        this.f9678l = kVar;
    }

    public final void a(long j10, long j11) {
        long j12;
        this.f9670d = 0;
        this.f9671e = 0;
        this.f9672f = 0;
        this.f9681o = j11;
        C c10 = this.f9679m;
        if (c10 instanceof z) {
            z zVar = (z) c10;
            o oVar = zVar.f8234b;
            if (oVar.f25867a == 0) {
                j12 = -9223372036854775807L;
            } else {
                j12 = oVar.c(C2756B.c(zVar.f8233a, j10));
            }
            this.f9675i = j12;
            if (Math.abs(this.f9681o - j12) >= 20000) {
                this.f9680n = true;
                this.f9678l = this.f9668b;
            }
        } else if (j10 == 0 || !(c10 instanceof C1012h)) {
            this.f9675i = 0;
        } else {
            C1012h hVar = (C1012h) c10;
            this.f9675i = (Math.max(0, j10 - hVar.f8161b) * 8000000) / ((long) hVar.f8164e);
        }
    }

    public final int b(C1013i iVar) {
        String str;
        boolean z10;
        iVar.f8169G = 0;
        byte[] bArr = this.f9667a;
        iVar.l(bArr, 0, 1, false);
        byte b10 = bArr[0];
        if ((b10 & 131) <= 0) {
            int i10 = (b10 >> 3) & 15;
            if (i10 < 0 || i10 > 15 || ((!(z10 = this.f9669c) || (i10 >= 10 && i10 <= 13)) && (z10 || (i10 >= 12 && i10 <= 14)))) {
                StringBuilder sb2 = new StringBuilder("Illegal AMR ");
                if (this.f9669c) {
                    str = "WB";
                } else {
                    str = "NB";
                }
                sb2.append(str);
                sb2.append(" frame type ");
                sb2.append(i10);
                throw v.a((RuntimeException) null, sb2.toString());
            } else if (z10) {
                return f9664r[i10];
            } else {
                return f9663q[i10];
            }
        } else {
            throw v.a((RuntimeException) null, "Invalid padding bits for frame header " + b10);
        }
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f9676j = pVar;
        H k10 = pVar.k(0, 1);
        this.f9677k = k10;
        this.f9678l = k10;
        pVar.b();
    }

    public final boolean e(C1013i iVar) {
        iVar.f8169G = 0;
        byte[] bArr = f9665s;
        byte[] bArr2 = new byte[bArr.length];
        iVar.l(bArr2, 0, bArr.length, false);
        if (Arrays.equals(bArr2, bArr)) {
            this.f9669c = false;
            iVar.s(bArr.length);
            return true;
        }
        iVar.f8169G = 0;
        byte[] bArr3 = f9666t;
        byte[] bArr4 = new byte[bArr3.length];
        iVar.l(bArr4, 0, bArr3.length, false);
        if (!Arrays.equals(bArr4, bArr3)) {
            return false;
        }
        this.f9669c = true;
        iVar.s(bArr3.length);
        return true;
    }

    public final boolean g(R2.o oVar) {
        return e((C1013i) oVar);
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    /* JADX WARNING: Removed duplicated region for block: B:54:0x00ff  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0128  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x013b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int i(R2.o r25, R2.B r26) {
        /*
            r24 = this;
            r0 = r24
            r1 = r25
            r2 = 0
            R2.H r4 = r0.f9677k
            f7.M.n(r4)
            int r4 = o2.C2756B.f25811a
            r4 = r1
            R2.i r4 = (R2.C1013i) r4
            long r4 = r4.f8167E
            int r4 = (r4 > r2 ? 1 : (r4 == r2 ? 0 : -1))
            if (r4 != 0) goto L_0x0028
            r4 = r1
            R2.i r4 = (R2.C1013i) r4
            boolean r4 = r0.e(r4)
            if (r4 == 0) goto L_0x0020
            goto L_0x0028
        L_0x0020:
            java.lang.String r1 = "Could not find AMR header."
            r2 = 0
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x0028:
            boolean r4 = r0.f9682p
            r5 = 1
            if (r4 != 0) goto L_0x006f
            r0.f9682p = r5
            boolean r4 = r0.f9669c
            java.lang.String r6 = "audio/amr-wb"
            if (r4 == 0) goto L_0x0037
            r7 = r6
            goto L_0x0039
        L_0x0037:
            java.lang.String r7 = "audio/amr"
        L_0x0039:
            if (r4 == 0) goto L_0x003c
            goto L_0x003e
        L_0x003c:
            java.lang.String r6 = "audio/3gpp"
        L_0x003e:
            if (r4 == 0) goto L_0x0043
            r8 = 16000(0x3e80, float:2.2421E-41)
            goto L_0x0045
        L_0x0043:
            r8 = 8000(0x1f40, float:1.121E-41)
        L_0x0045:
            if (r4 == 0) goto L_0x004e
            int[] r4 = f9664r
            r9 = 8
            r4 = r4[r9]
            goto L_0x0053
        L_0x004e:
            int[] r4 = f9663q
            r9 = 7
            r4 = r4[r9]
        L_0x0053:
            R2.H r9 = r0.f9677k
            l2.n$a r10 = new l2.n$a
            r10.<init>()
            java.lang.String r7 = l2.u.p(r7)
            r10.f24327l = r7
            java.lang.String r6 = l2.u.p(r6)
            r10.f24328m = r6
            r10.f24329n = r4
            r10.f24306C = r5
            r10.f24307D = r8
            D2.E.r(r10, r9)
        L_0x006f:
            int r4 = r0.f9672f
            r6 = 20000(0x4e20, double:9.8813E-320)
            r8 = 0
            r9 = -1
            if (r4 != 0) goto L_0x00f0
            r4 = r1
            R2.i r4 = (R2.C1013i) r4     // Catch:{ EOFException -> 0x00f2 }
            int r4 = r0.b(r4)     // Catch:{ EOFException -> 0x00f2 }
            r0.f9671e = r4     // Catch:{ EOFException -> 0x00f2 }
            r0.f9672f = r4
            int r10 = r0.f9673g
            if (r10 != r9) goto L_0x008d
            r10 = r1
            R2.i r10 = (R2.C1013i) r10
            long r10 = r10.f8167E
            r0.f9673g = r4
        L_0x008d:
            int r10 = r0.f9673g
            if (r10 != r4) goto L_0x0096
            int r10 = r0.f9674h
            int r10 = r10 + r5
            r0.f9674h = r10
        L_0x0096:
            R2.C r10 = r0.f9679m
            boolean r11 = r10 instanceof R2.z
            if (r11 == 0) goto L_0x00f0
            R2.z r10 = (R2.z) r10
            long r11 = r0.f9675i
            long r13 = r0.f9670d
            long r11 = r11 + r13
            long r11 = r11 + r6
            r13 = r1
            R2.i r13 = (R2.C1013i) r13
            long r13 = r13.f8167E
            r15 = r6
            long r6 = (long) r4
            long r13 = r13 + r6
            o2.o r4 = r10.f8234b
            int r6 = r4.f25867a
            if (r6 != 0) goto L_0x00b3
            goto L_0x00c2
        L_0x00b3:
            int r6 = r6 - r5
            long r6 = r4.c(r6)
            long r6 = r11 - r6
            r17 = 100000(0x186a0, double:4.94066E-319)
            int r4 = (r6 > r17 ? 1 : (r6 == r17 ? 0 : -1))
            if (r4 >= 0) goto L_0x00c2
            goto L_0x00da
        L_0x00c2:
            o2.o r4 = r10.f8234b
            int r6 = r4.f25867a
            o2.o r7 = r10.f8233a
            if (r6 != 0) goto L_0x00d4
            int r6 = (r11 > r2 ? 1 : (r11 == r2 ? 0 : -1))
            if (r6 <= 0) goto L_0x00d4
            r7.a(r2)
            r4.a(r2)
        L_0x00d4:
            r7.a(r13)
            r4.a(r11)
        L_0x00da:
            boolean r2 = r0.f9680n
            if (r2 == 0) goto L_0x00f4
            long r2 = r0.f9681o
            long r2 = r2 - r11
            long r2 = java.lang.Math.abs(r2)
            int r2 = (r2 > r15 ? 1 : (r2 == r15 ? 0 : -1))
            if (r2 >= 0) goto L_0x00f4
            r0.f9680n = r8
            R2.H r2 = r0.f9677k
            r0.f9678l = r2
            goto L_0x00f4
        L_0x00f0:
            r15 = r6
            goto L_0x00f4
        L_0x00f2:
            r8 = r9
            goto L_0x0123
        L_0x00f4:
            R2.H r2 = r0.f9678l
            int r3 = r0.f9672f
            int r1 = r2.c(r1, r3, r5)
            if (r1 != r9) goto L_0x00ff
            goto L_0x00f2
        L_0x00ff:
            int r2 = r0.f9672f
            int r2 = r2 - r1
            r0.f9672f = r2
            if (r2 <= 0) goto L_0x0107
            goto L_0x0123
        L_0x0107:
            R2.H r1 = r0.f9678l
            long r2 = r0.f9675i
            long r4 = r0.f9670d
            long r18 = r2 + r4
            int r2 = r0.f9671e
            r20 = 1
            r22 = 0
            r23 = 0
            r17 = r1
            r21 = r2
            r17.b(r18, r20, r21, r22, r23)
            long r1 = r0.f9670d
            long r1 = r1 + r15
            r0.f9670d = r1
        L_0x0123:
            R2.C r1 = r0.f9679m
            if (r1 == 0) goto L_0x0128
            goto L_0x0139
        L_0x0128:
            R2.C$b r1 = new R2.C$b
            r2 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r1.<init>(r2)
            r0.f9679m = r1
            R2.p r2 = r0.f9676j
            r2.a(r1)
        L_0x0139:
            if (r8 != r9) goto L_0x0155
            R2.C r1 = r0.f9679m
            boolean r2 = r1 instanceof R2.z
            if (r2 == 0) goto L_0x0155
            long r2 = r0.f9675i
            long r4 = r0.f9670d
            long r2 = r2 + r4
            r4 = r1
            R2.z r4 = (R2.z) r4
            r4.f8235c = r2
            R2.p r2 = r0.f9676j
            r2.a(r1)
            R2.H r1 = r0.f9677k
            r1.getClass()
        L_0x0155:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: S2.a.i(R2.o, R2.B):int");
    }

    public final void release() {
    }
}
