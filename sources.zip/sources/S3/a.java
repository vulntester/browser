package S3;

import R3.c;
import V.C1201y0;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final C1201y0<c> f9683a;

    /* JADX WARNING: type inference failed for: r1v3, types: [V.v] */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            r0 = 0
            java.lang.Class<R3.c> r1 = R3.c.class
            java.lang.ClassLoader r1 = r1.getClassLoader()     // Catch:{ all -> 0x0031 }
            kotlin.jvm.internal.l.c(r1)     // Catch:{ all -> 0x0031 }
            java.lang.String r2 = "androidx.compose.ui.platform.AndroidCompositionLocals_androidKt"
            java.lang.String r3 = "getLocalSavedStateRegistryOwner"
            java.lang.Class r1 = r1.loadClass(r2)     // Catch:{ all -> 0x0031 }
            r2 = 0
            java.lang.Class[] r4 = new java.lang.Class[r2]     // Catch:{ all -> 0x0031 }
            java.lang.reflect.Method r1 = r1.getMethod(r3, r4)     // Catch:{ all -> 0x0031 }
            java.lang.annotation.Annotation[] r3 = r1.getAnnotations()     // Catch:{ all -> 0x0031 }
            java.lang.String r4 = "getAnnotations(...)"
            kotlin.jvm.internal.l.e(r3, r4)     // Catch:{ all -> 0x0031 }
            int r4 = r3.length     // Catch:{ all -> 0x0031 }
            r5 = r2
        L_0x0024:
            if (r5 >= r4) goto L_0x0033
            r6 = r3[r5]     // Catch:{ all -> 0x0031 }
            boolean r6 = r6 instanceof xa.C4961a     // Catch:{ all -> 0x0031 }
            if (r6 == 0) goto L_0x002e
        L_0x002c:
            r1 = r0
            goto L_0x0044
        L_0x002e:
            int r5 = r5 + 1
            goto L_0x0024
        L_0x0031:
            r1 = move-exception
            goto L_0x0040
        L_0x0033:
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ all -> 0x0031 }
            java.lang.Object r1 = r1.invoke(r0, r2)     // Catch:{ all -> 0x0031 }
            boolean r2 = r1 instanceof V.C1201y0     // Catch:{ all -> 0x0031 }
            if (r2 == 0) goto L_0x002c
            V.y0 r1 = (V.C1201y0) r1     // Catch:{ all -> 0x0031 }
            goto L_0x0044
        L_0x0040:
            xa.o$a r1 = xa.C4976p.a(r1)
        L_0x0044:
            boolean r2 = r1 instanceof xa.C4975o.a
            if (r2 == 0) goto L_0x0049
            goto L_0x004a
        L_0x0049:
            r0 = r1
        L_0x004a:
            V.y0 r0 = (V.C1201y0) r0
            if (r0 != 0) goto L_0x005a
            B9.h r0 = new B9.h
            r1 = 2
            r0.<init>(r1)
            V.j1 r1 = new V.j1
            r1.<init>(r0)
            r0 = r1
        L_0x005a:
            f9683a = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: S3.a.<clinit>():void");
    }
}
