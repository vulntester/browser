package S5;

import Fc.C3986l;
import Fc.m;
import Fc.t;
import android.webkit.CookieManager;
import fc.C4427q;
import io.netty.handler.codec.rtsp.RtspHeaders;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import kotlin.jvm.internal.l;
import ya.u;

public final class a implements m {

    /* renamed from: f  reason: collision with root package name */
    public final CookieManager f9684f;

    public a() {
        CookieManager instance = CookieManager.getInstance();
        l.e(instance, "getInstance(...)");
        this.f9684f = instance;
    }

    public final List<C3986l> a(t tVar) {
        l.f(tVar, RtspHeaders.Values.URL);
        String cookie = this.f9684f.getCookie(tVar.f35231i);
        if (cookie == null) {
            return u.f44685f;
        }
        List<String> o02 = C4427q.o0(cookie, new String[]{";"}, 0, 6);
        ArrayList arrayList = new ArrayList();
        for (String C02 : o02) {
            Pattern pattern = C3986l.f35192j;
            C3986l b10 = C3986l.a.b(tVar, C4427q.C0(C02).toString());
            if (b10 != null) {
                arrayList.add(b10);
            }
        }
        return arrayList;
    }

    public final void c(t tVar, List<C3986l> list) {
        l.f(tVar, RtspHeaders.Values.URL);
        for (C3986l lVar : list) {
            String lVar2 = lVar.toString();
            this.f9684f.setCookie(tVar.f35231i, lVar2);
        }
        CookieManager.getInstance().flush();
    }
}
