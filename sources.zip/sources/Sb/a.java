package Sb;

public interface a<K, V> {
}
