package Sb;

public final class b implements k {

    /* renamed from: f  reason: collision with root package name */
    public static final b f37885f = new Object();

    public final void lock() {
    }

    public final void unlock() {
    }
}
