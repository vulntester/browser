package Sb;

import Fc.C3984j;
import Mb.o;
import Pb.O;
import Q6.C0996q;
import cc.C4254g;
import fc.C4427q;
import j$.util.concurrent.ConcurrentHashMap;
import java.util.Arrays;
import java.util.List;
import x.i0;

public class c implements l {

    /* renamed from: d  reason: collision with root package name */
    public static final String f37886d = C4427q.A0(c.class.getCanonicalName(), ".", "");

    /* renamed from: e  reason: collision with root package name */
    public static final a f37887e = new c("NO_LOCKS", b.f37885f);

    /* renamed from: a  reason: collision with root package name */
    public final k f37888a;

    /* renamed from: b  reason: collision with root package name */
    public final d.a f37889b;

    /* renamed from: c  reason: collision with root package name */
    public final String f37890c;

    public static class a extends c {
        public final m g(Object obj, String str) {
            return new m(null, true);
        }
    }

    public static class b<K, V> extends C0359c<K, V> implements a<K, V> {
        public static /* synthetic */ void a(int i10) {
            String str;
            int i11;
            Throwable th;
            if (i10 != 3) {
                str = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
            } else {
                str = "@NotNull method %s.%s must not return null";
            }
            if (i10 != 3) {
                i11 = 3;
            } else {
                i11 = 2;
            }
            Object[] objArr = new Object[i11];
            if (i10 == 1) {
                objArr[0] = "map";
            } else if (i10 == 2) {
                objArr[0] = "computation";
            } else if (i10 != 3) {
                objArr[0] = "storageManager";
            } else {
                objArr[0] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$CacheWithNotNullValuesBasedOnMemoizedFunction";
            }
            if (i10 != 3) {
                objArr[1] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$CacheWithNotNullValuesBasedOnMemoizedFunction";
            } else {
                objArr[1] = "computeIfAbsent";
            }
            if (i10 == 2) {
                objArr[2] = "computeIfAbsent";
            } else if (i10 != 3) {
                objArr[2] = "<init>";
            }
            String format = String.format(str, objArr);
            if (i10 != 3) {
                th = new IllegalArgumentException(format);
            } else {
                th = new IllegalStateException(format);
            }
            throw th;
        }
    }

    /* renamed from: Sb.c$c  reason: collision with other inner class name */
    public static class C0359c<K, V> extends j<e<K, V>, V> {
    }

    public interface d {

        /* renamed from: a  reason: collision with root package name */
        public static final a f37891a = new Object();

        public static class a implements d {
        }
    }

    public static class e<K, V> {

        /* renamed from: a  reason: collision with root package name */
        public final Cb.c f37892a;

        /* renamed from: b  reason: collision with root package name */
        public final Na.a<? extends V> f37893b;

        public e(Cb.c cVar, Na.a aVar) {
            this.f37892a = cVar;
            this.f37893b = aVar;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || e.class != obj.getClass() || !this.f37892a.equals(((e) obj).f37892a)) {
                return false;
            }
            return true;
        }

        public final int hashCode() {
            return this.f37892a.hashCode();
        }
    }

    public static abstract class g<T> extends f<T> {

        /* renamed from: E  reason: collision with root package name */
        public volatile C0996q f37897E;

        /* JADX WARNING: type inference failed for: r0v0, types: [java.lang.Object, Q6.q] */
        public final void b(T t10) {
            ? obj = new Object();
            obj.f7922f = t10;
            obj.f7923i = Thread.currentThread();
            this.f37897E = obj;
            try {
                e eVar = (e) this;
                if (t10 != null) {
                    eVar.f37907F.invoke(t10);
                } else {
                    e.a(2);
                    throw null;
                }
            } finally {
                this.f37897E = null;
            }
        }

        public T invoke() {
            C0996q qVar = this.f37897E;
            if (qVar == null || ((Thread) qVar.f7923i) != Thread.currentThread()) {
                return super.invoke();
            }
            if (((Thread) qVar.f7923i) == Thread.currentThread()) {
                return qVar.f7922f;
            }
            throw new IllegalStateException("No value in this thread (hasValue should be checked before)");
        }
    }

    public static class h<T> extends f<T> implements i<T> {
        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public h(c cVar, Na.a<? extends T> aVar) {
            super(cVar, aVar);
            if (cVar != null) {
            } else {
                a(0);
                throw null;
            }
        }

        public static /* synthetic */ void a(int i10) {
            String str;
            int i11;
            Throwable th;
            if (i10 != 2) {
                str = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
            } else {
                str = "@NotNull method %s.%s must not return null";
            }
            if (i10 != 2) {
                i11 = 3;
            } else {
                i11 = 2;
            }
            Object[] objArr = new Object[i11];
            if (i10 == 1) {
                objArr[0] = "computable";
            } else if (i10 != 2) {
                objArr[0] = "storageManager";
            } else {
                objArr[0] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$LockBasedNotNullLazyValue";
            }
            if (i10 != 2) {
                objArr[1] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$LockBasedNotNullLazyValue";
            } else {
                objArr[1] = "invoke";
            }
            if (i10 != 2) {
                objArr[2] = "<init>";
            }
            String format = String.format(str, objArr);
            if (i10 != 2) {
                th = new IllegalArgumentException(format);
            } else {
                th = new IllegalStateException(format);
            }
            throw th;
        }

        public final T invoke() {
            T invoke = super.invoke();
            if (invoke != null) {
                return invoke;
            }
            a(2);
            throw null;
        }
    }

    public static abstract class i<T> extends g<T> implements i<T> {
        public static /* synthetic */ void a(int i10) {
            String str;
            int i11;
            Throwable th;
            if (i10 != 2) {
                str = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
            } else {
                str = "@NotNull method %s.%s must not return null";
            }
            if (i10 != 2) {
                i11 = 3;
            } else {
                i11 = 2;
            }
            Object[] objArr = new Object[i11];
            if (i10 == 1) {
                objArr[0] = "computable";
            } else if (i10 != 2) {
                objArr[0] = "storageManager";
            } else {
                objArr[0] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$LockBasedNotNullLazyValueWithPostCompute";
            }
            if (i10 != 2) {
                objArr[1] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$LockBasedNotNullLazyValueWithPostCompute";
            } else {
                objArr[1] = "invoke";
            }
            if (i10 != 2) {
                objArr[2] = "<init>";
            }
            String format = String.format(str, objArr);
            if (i10 != 2) {
                th = new IllegalArgumentException(format);
            } else {
                th = new IllegalStateException(format);
            }
            throw th;
        }

        public final T invoke() {
            T invoke = super.invoke();
            if (invoke != null) {
                return invoke;
            }
            a(2);
            throw null;
        }
    }

    public static class j<K, V> implements h<K, V> {

        /* renamed from: f  reason: collision with root package name */
        public final c f37898f;

        /* renamed from: i  reason: collision with root package name */
        public final ConcurrentHashMap f37899i;

        /* renamed from: z  reason: collision with root package name */
        public final Na.l<? super K, ? extends V> f37900z;

        public j(c cVar, ConcurrentHashMap concurrentHashMap, Na.l lVar) {
            if (cVar != null) {
                this.f37898f = cVar;
                this.f37899i = concurrentHashMap;
                this.f37900z = lVar;
                return;
            }
            a(0);
            throw null;
        }

        public static /* synthetic */ void a(int i10) {
            String str;
            int i11;
            Throwable th;
            if (i10 == 3 || i10 == 4) {
                str = "@NotNull method %s.%s must not return null";
            } else {
                str = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
            }
            if (i10 == 3 || i10 == 4) {
                i11 = 2;
            } else {
                i11 = 3;
            }
            Object[] objArr = new Object[i11];
            if (i10 == 1) {
                objArr[0] = "map";
            } else if (i10 == 2) {
                objArr[0] = "compute";
            } else if (i10 == 3 || i10 == 4) {
                objArr[0] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$MapBasedMemoizedFunction";
            } else {
                objArr[0] = "storageManager";
            }
            if (i10 == 3) {
                objArr[1] = "recursionDetected";
            } else if (i10 != 4) {
                objArr[1] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$MapBasedMemoizedFunction";
            } else {
                objArr[1] = "raceCondition";
            }
            if (!(i10 == 3 || i10 == 4)) {
                objArr[2] = "<init>";
            }
            String format = String.format(str, objArr);
            if (i10 == 3 || i10 == 4) {
                th = new IllegalStateException(format);
            } else {
                th = new IllegalArgumentException(format);
            }
            throw th;
        }

        public final AssertionError b(K k10, Object obj) {
            AssertionError assertionError = new AssertionError("Inconsistent key detected. " + l.f37903i + " is expected, was: " + obj + ", most probably race condition detected on input " + k10 + " under " + this.f37898f);
            c.h(assertionError);
            return assertionError;
        }

        public final AssertionError c(K k10, Object obj) {
            AssertionError assertionError = new AssertionError("Race condition detected on input " + k10 + ". Old value is " + obj + " under " + this.f37898f);
            c.h(assertionError);
            return assertionError;
        }

        public final AssertionError d(K k10, Throwable th) {
            AssertionError assertionError = new AssertionError("Unable to remove " + k10 + " under " + this.f37898f, th);
            c.h(assertionError);
            return assertionError;
        }

        public V invoke(K k10) {
            ConcurrentHashMap concurrentHashMap = this.f37899i;
            V v10 = concurrentHashMap.get(k10);
            V v11 = l.f37903i;
            V v12 = C4254g.f39482a;
            V v13 = null;
            if (v10 == null || v10 == v11) {
                c cVar = this.f37898f;
                k kVar = cVar.f37888a;
                k kVar2 = cVar.f37888a;
                kVar.lock();
                try {
                    V v14 = concurrentHashMap.get(k10);
                    V v15 = l.f37904z;
                    if (v14 == v11) {
                        m g6 = cVar.g(k10, "");
                        if (g6 == null) {
                            a(3);
                            throw null;
                        } else if (!g6.f37906b) {
                            Object obj = g6.f37905a;
                            kVar2.unlock();
                            return obj;
                        } else {
                            v14 = v15;
                        }
                    }
                    if (v14 == v15) {
                        m g10 = cVar.g(k10, "");
                        if (g10 == null) {
                            a(3);
                            throw null;
                        } else if (!g10.f37906b) {
                            Object obj2 = g10.f37905a;
                            kVar2.unlock();
                            return obj2;
                        }
                    }
                    if (v14 != null) {
                        C4254g.a(v14);
                        if (v14 != v12) {
                            v13 = v14;
                        }
                        kVar2.unlock();
                        return v13;
                    }
                    concurrentHashMap.put(k10, v11);
                    V invoke = this.f37900z.invoke(k10);
                    if (invoke != null) {
                        v12 = invoke;
                    }
                    V put = concurrentHashMap.put(k10, v12);
                    if (put == v11) {
                        kVar2.unlock();
                        return invoke;
                    }
                    throw c(k10, put);
                } catch (Throwable th) {
                    throw d(k10, th);
                }
            } else {
                C4254g.a(v10);
                if (v10 == v12) {
                    return null;
                }
                return v10;
            }
        }
    }

    public static class k<K, V> extends j<K, V> implements g<K, V> {
        public final V invoke(K k10) {
            V invoke = super.invoke(k10);
            if (invoke != null) {
                return invoke;
            }
            throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", new Object[]{"kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$MapBasedMemoizedFunctionToNotNull", "invoke"}));
        }
    }

    public enum l {
        ;

        /* access modifiers changed from: public */
        l() {
            throw null;
        }
    }

    public static class m<T> {

        /* renamed from: a  reason: collision with root package name */
        public final T f37905a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f37906b;

        public m(T t10, boolean z10) {
            this.f37905a = t10;
            this.f37906b = z10;
        }

        public final String toString() {
            if (this.f37906b) {
                return "FALL_THROUGH";
            }
            return String.valueOf(this.f37905a);
        }
    }

    public c() {
        throw null;
    }

    public c(String str) {
        this(str, new C3984j(0));
    }

    public static void h(AssertionError assertionError) {
        StackTraceElement[] stackTrace = assertionError.getStackTrace();
        int length = stackTrace.length;
        int i10 = 0;
        while (true) {
            if (i10 >= length) {
                i10 = -1;
                break;
            } else if (!stackTrace[i10].getClassName().startsWith(f37886d)) {
                break;
            } else {
                i10++;
            }
        }
        List subList = Arrays.asList(stackTrace).subList(i10, length);
        assertionError.setStackTrace((StackTraceElement[]) subList.toArray(new StackTraceElement[subList.size()]));
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [Sb.c$h, Sb.c$f] */
    public final h a(Na.a aVar) {
        return new f(this, aVar);
    }

    public final e b(o oVar, O o10) {
        return new e(this, oVar, o10);
    }

    public final f c(Na.a aVar) {
        return new f(this, aVar);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [Sb.c$j, Sb.c$b] */
    /* JADX WARNING: type inference failed for: r2v1, types: [Na.l, java.lang.Object] */
    public final b d() {
        return new j(this, new ConcurrentHashMap(3, 1.0f, 2), new Object());
    }

    /* JADX WARNING: type inference failed for: r1v1, types: [Sb.c$k, Sb.c$j] */
    public final k e(Na.l lVar) {
        return new j(this, new ConcurrentHashMap(3, 1.0f, 2), lVar);
    }

    public final j f(Na.l lVar) {
        return new j(this, new ConcurrentHashMap(3, 1.0f, 2), lVar);
    }

    public m g(Object obj, String str) {
        String str2;
        StringBuilder sb2 = new StringBuilder("Recursion detected ");
        sb2.append(str);
        if (obj == null) {
            str2 = "";
        } else {
            str2 = "on input: " + obj;
        }
        sb2.append(str2);
        sb2.append(" under ");
        sb2.append(this);
        AssertionError assertionError = new AssertionError(sb2.toString());
        h(assertionError);
        throw assertionError;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(getClass().getSimpleName());
        sb2.append("@");
        sb2.append(Integer.toHexString(hashCode()));
        sb2.append(" (");
        return i0.c(sb2, this.f37890c, ")");
    }

    public c(String str, k kVar) {
        d.a aVar = d.f37891a;
        this.f37888a = kVar;
        this.f37889b = aVar;
        this.f37890c = str;
    }

    public static class f<T> implements j<T> {

        /* renamed from: f  reason: collision with root package name */
        public final c f37894f;

        /* renamed from: i  reason: collision with root package name */
        public final Na.a<? extends T> f37895i;

        /* renamed from: z  reason: collision with root package name */
        public volatile Object f37896z;

        public f(c cVar, Na.a<? extends T> aVar) {
            if (cVar != null) {
                this.f37896z = l.f37902f;
                this.f37894f = cVar;
                this.f37895i = aVar;
                return;
            }
            a(0);
            throw null;
        }

        public static /* synthetic */ void a(int i10) {
            String str;
            int i11;
            Throwable th;
            if (i10 == 2 || i10 == 3) {
                str = "@NotNull method %s.%s must not return null";
            } else {
                str = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
            }
            if (i10 == 2 || i10 == 3) {
                i11 = 2;
            } else {
                i11 = 3;
            }
            Object[] objArr = new Object[i11];
            if (i10 == 1) {
                objArr[0] = "computable";
            } else if (i10 == 2 || i10 == 3) {
                objArr[0] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$LockBasedLazyValue";
            } else {
                objArr[0] = "storageManager";
            }
            if (i10 == 2) {
                objArr[1] = "recursionDetected";
            } else if (i10 != 3) {
                objArr[1] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$LockBasedLazyValue";
            } else {
                objArr[1] = "renderDebugInformation";
            }
            if (!(i10 == 2 || i10 == 3)) {
                objArr[2] = "<init>";
            }
            String format = String.format(str, objArr);
            if (i10 == 2 || i10 == 3) {
                th = new IllegalStateException(format);
            } else {
                th = new IllegalArgumentException(format);
            }
            throw th;
        }

        public m<T> c(boolean z10) {
            m<T> g6 = this.f37894f.g((Object) null, "in a lazy value");
            if (g6 != null) {
                return g6;
            }
            a(2);
            throw null;
        }

        public T invoke() {
            T t10;
            T t11 = this.f37896z;
            if (!(t11 instanceof l)) {
                C4254g.a(t11);
                return t11;
            }
            this.f37894f.f37888a.lock();
            try {
                T t12 = this.f37896z;
                if (!(t12 instanceof l)) {
                    C4254g.a(t12);
                } else {
                    t10 = l.f37903i;
                    T t13 = l.f37904z;
                    if (t12 == t10) {
                        this.f37896z = t13;
                        m c10 = c(true);
                        if (!c10.f37906b) {
                            t12 = c10.f37905a;
                        }
                    }
                    if (t12 == t13) {
                        m c11 = c(false);
                        if (!c11.f37906b) {
                            t12 = c11.f37905a;
                        }
                    }
                    this.f37896z = t10;
                    t12 = this.f37895i.invoke();
                    b(t12);
                    this.f37896z = t12;
                }
                this.f37894f.f37888a.unlock();
                return t12;
            } catch (Throwable th) {
                this.f37894f.f37888a.unlock();
                throw th;
            }
        }

        public void b(T t10) {
        }
    }
}
