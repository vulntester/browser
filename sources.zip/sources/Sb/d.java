package Sb;

import Sb.c;
import ya.u;

public final class d extends c.h<Object> {
    public final c.m<Object> c(boolean z10) {
        return new c.m<>(u.f44685f, false);
    }
}
