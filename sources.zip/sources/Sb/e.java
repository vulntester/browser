package Sb;

import Mb.o;
import Pb.O;
import Sb.c;
import Tb.C4135f;
import Vb.l;
import f7.M;

public final class e extends c.i<Object> {

    /* renamed from: F  reason: collision with root package name */
    public final /* synthetic */ O f37907F;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public e(c cVar, o oVar, O o10) {
        super(cVar, oVar);
        this.f37907F = o10;
        if (cVar != null) {
            this.f37897E = null;
            return;
        }
        c.i.a(0);
        throw null;
    }

    public static /* synthetic */ void a(int i10) {
        String str;
        int i11;
        Throwable th;
        if (i10 != 2) {
            str = "@NotNull method %s.%s must not return null";
        } else {
            str = "Argument for @NotNull parameter '%s' of %s.%s must not be null";
        }
        if (i10 != 2) {
            i11 = 2;
        } else {
            i11 = 3;
        }
        Object[] objArr = new Object[i11];
        if (i10 != 2) {
            objArr[0] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$5";
        } else {
            objArr[0] = "value";
        }
        if (i10 != 2) {
            objArr[1] = "recursionDetected";
        } else {
            objArr[1] = "kotlin/reflect/jvm/internal/impl/storage/LockBasedStorageManager$5";
        }
        if (i10 == 2) {
            objArr[2] = "doPostCompute";
        }
        String format = String.format(str, objArr);
        if (i10 != 2) {
            th = new IllegalStateException(format);
        } else {
            th = new IllegalArgumentException(format);
        }
        throw th;
    }

    public final c.m<Object> c(boolean z10) {
        return new c.m<>(new C4135f.a(M.s(l.f38479d)), false);
    }
}
