package Sb;

import Na.l;
import Sb.c;

public final class f implements l<c.e<Object, Object>, Object> {
    public final Object invoke(Object obj) {
        return ((c.e) obj).f37893b.invoke();
    }
}
