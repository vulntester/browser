package Sb;

import Na.l;

public interface g<P, R> extends l<P, R> {
}
