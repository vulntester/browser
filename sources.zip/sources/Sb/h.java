package Sb;

import Na.l;

public interface h<P, R> extends l<P, R> {
}
