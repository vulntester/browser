package Sb;

import Na.a;

public interface i<T> extends a<T> {
}
