package Sb;

import Na.a;

public interface j<T> extends a<T> {
}
