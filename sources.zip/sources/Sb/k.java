package Sb;

public interface k {
    void lock();

    void unlock();
}
