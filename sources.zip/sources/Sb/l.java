package Sb;

import Mb.o;
import Na.a;
import Pb.O;
import Sb.c;

public interface l {
    c.h a(a aVar);

    e b(o oVar, O o10);

    c.f c(a aVar);
}
