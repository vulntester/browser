package Sc;

import Uc.C4161g;
import Uc.C4165k;
import java.io.Closeable;
import java.util.zip.Deflater;

public final class a implements Closeable {

    /* renamed from: E  reason: collision with root package name */
    public final C4165k f37908E;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f37909f;

    /* renamed from: i  reason: collision with root package name */
    public final C4161g f37910i;

    /* renamed from: z  reason: collision with root package name */
    public final Deflater f37911z;

    public a(boolean z10) {
        this.f37909f = z10;
        C4161g gVar = new C4161g();
        this.f37910i = gVar;
        Deflater deflater = new Deflater(-1, true);
        this.f37911z = deflater;
        this.f37908E = new C4165k(A1.a.k(gVar), deflater);
    }

    public final void close() {
        this.f37908E.close();
    }
}
