package Sc;

import Uc.C4164j;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final C4164j f37912a = C4164j.a.b("000000ffff");

    static {
        C4164j jVar = C4164j.f38316E;
    }
}
