package Sc;

import A1.a;
import Uc.C4161g;
import Uc.u;
import java.io.Closeable;
import java.util.zip.Inflater;

public final class c implements Closeable {

    /* renamed from: E  reason: collision with root package name */
    public final u f37913E;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f37914f;

    /* renamed from: i  reason: collision with root package name */
    public final C4161g f37915i;

    /* renamed from: z  reason: collision with root package name */
    public final Inflater f37916z;

    public c(boolean z10) {
        this.f37914f = z10;
        C4161g gVar = new C4161g();
        this.f37915i = gVar;
        Inflater inflater = new Inflater(true);
        this.f37916z = inflater;
        this.f37913E = new u(a.l(gVar), inflater);
    }

    public final void close() {
        this.f37913E.close();
    }
}
