package Sc;

import Fc.K;
import Fc.L;
import Fc.y;
import Fc.z;
import Jc.h;
import Uc.C4156b;
import Uc.C4161g;
import Uc.C4164j;
import Uc.E;
import Uc.F;
import f7.M;
import io.ktor.http.ContentDisposition;
import io.netty.handler.codec.http.HttpHeaders;
import java.io.Closeable;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.zip.Inflater;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.n;
import xa.C4959D;

public final class d implements K {

    /* renamed from: w  reason: collision with root package name */
    public static final List<y> f37917w = M.s(y.HTTP_1_1);

    /* renamed from: a  reason: collision with root package name */
    public final L f37918a;

    /* renamed from: b  reason: collision with root package name */
    public final Random f37919b;

    /* renamed from: c  reason: collision with root package name */
    public final long f37920c;

    /* renamed from: d  reason: collision with root package name */
    public f f37921d = null;

    /* renamed from: e  reason: collision with root package name */
    public final long f37922e;

    /* renamed from: f  reason: collision with root package name */
    public final String f37923f;

    /* renamed from: g  reason: collision with root package name */
    public Jc.e f37924g;

    /* renamed from: h  reason: collision with root package name */
    public C0360d f37925h;

    /* renamed from: i  reason: collision with root package name */
    public g f37926i;

    /* renamed from: j  reason: collision with root package name */
    public h f37927j;

    /* renamed from: k  reason: collision with root package name */
    public final Ic.d f37928k;

    /* renamed from: l  reason: collision with root package name */
    public String f37929l;

    /* renamed from: m  reason: collision with root package name */
    public h f37930m;

    /* renamed from: n  reason: collision with root package name */
    public final ArrayDeque<C4164j> f37931n;

    /* renamed from: o  reason: collision with root package name */
    public final ArrayDeque<Object> f37932o;

    /* renamed from: p  reason: collision with root package name */
    public long f37933p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f37934q;

    /* renamed from: r  reason: collision with root package name */
    public int f37935r;

    /* renamed from: s  reason: collision with root package name */
    public String f37936s;

    /* renamed from: t  reason: collision with root package name */
    public boolean f37937t;

    /* renamed from: u  reason: collision with root package name */
    public int f37938u;

    /* renamed from: v  reason: collision with root package name */
    public boolean f37939v;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f37940a;

        /* renamed from: b  reason: collision with root package name */
        public final C4164j f37941b;

        public a(int i10, C4164j jVar) {
            this.f37940a = i10;
            this.f37941b = jVar;
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        public final int f37942a;

        /* renamed from: b  reason: collision with root package name */
        public final C4164j f37943b;

        public b(int i10, C4164j jVar) {
            this.f37942a = i10;
            this.f37943b = jVar;
        }
    }

    public static abstract class c implements Closeable {

        /* renamed from: f  reason: collision with root package name */
        public final F f37944f;

        /* renamed from: i  reason: collision with root package name */
        public final E f37945i;

        public c(F f10, E e10) {
            l.f(f10, "source");
            l.f(e10, "sink");
            this.f37944f = f10;
            this.f37945i = e10;
        }
    }

    /* renamed from: Sc.d$d  reason: collision with other inner class name */
    public final class C0360d extends Ic.a {

        /* renamed from: e  reason: collision with root package name */
        public final /* synthetic */ d f37946e;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0360d(d dVar) {
            super(l.k(" writer", dVar.f37929l));
            l.f(dVar, "this$0");
            this.f37946e = dVar;
        }

        public final long a() {
            d dVar = this.f37946e;
            try {
                if (dVar.l()) {
                    return 0;
                }
                return -1;
            } catch (IOException e10) {
                dVar.e(e10, (Fc.F) null);
                return -1;
            }
        }
    }

    public static final class e extends n implements Na.a<C4959D> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ d f37947f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public e(d dVar) {
            super(0);
            this.f37947f = dVar;
        }

        public final Object invoke() {
            this.f37947f.cancel();
            return C4959D.f44058a;
        }
    }

    public d(Ic.e eVar, z zVar, L l10, Random random, long j10, long j11) {
        l.f(eVar, "taskRunner");
        l.f(zVar, "originalRequest");
        l.f(l10, "listener");
        this.f37918a = l10;
        this.f37919b = random;
        this.f37920c = j10;
        this.f37922e = j11;
        this.f37928k = eVar.e();
        this.f37931n = new ArrayDeque<>();
        this.f37932o = new ArrayDeque<>();
        this.f37935r = -1;
        String str = zVar.f35327b;
        if ("GET".equals(str)) {
            C4164j jVar = C4164j.f38316E;
            byte[] bArr = new byte[16];
            random.nextBytes(bArr);
            C4959D d10 = C4959D.f44058a;
            this.f37923f = C4164j.a.d(C4156b.f38292b, bArr).b();
            return;
        }
        throw new IllegalArgumentException(l.k(str, "Request must be GET: ").toString());
    }

    public final boolean a(String str) {
        C4164j jVar = C4164j.f38316E;
        return k(1, C4164j.a.c(str));
    }

    public final boolean b(C4164j jVar) {
        return k(2, jVar);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:35:0x007f, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean c(int r7, java.lang.String r8) {
        /*
            r6 = this;
            monitor-enter(r6)
            r0 = 1000(0x3e8, float:1.401E-42)
            r1 = 0
            if (r7 < r0) goto L_0x0032
            r0 = 5000(0x1388, float:7.006E-42)
            if (r7 < r0) goto L_0x000b
            goto L_0x0032
        L_0x000b:
            r0 = 1004(0x3ec, float:1.407E-42)
            if (r0 > r7) goto L_0x0014
            r0 = 1006(0x3ee, float:1.41E-42)
            if (r7 > r0) goto L_0x0014
            goto L_0x001c
        L_0x0014:
            r0 = 1015(0x3f7, float:1.422E-42)
            if (r0 > r7) goto L_0x0030
            r0 = 2999(0xbb7, float:4.202E-42)
            if (r7 > r0) goto L_0x0030
        L_0x001c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ all -> 0x0061 }
            java.lang.String r2 = "Code "
            r0.<init>(r2)     // Catch:{ all -> 0x0061 }
            r0.append(r7)     // Catch:{ all -> 0x0061 }
            java.lang.String r2 = " is reserved and may not be used."
            r0.append(r2)     // Catch:{ all -> 0x0061 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0061 }
            goto L_0x003c
        L_0x0030:
            r0 = r1
            goto L_0x003c
        L_0x0032:
            java.lang.Integer r0 = java.lang.Integer.valueOf(r7)     // Catch:{ all -> 0x0061 }
            java.lang.String r2 = "Code must be in range [1000,5000): "
            java.lang.String r0 = kotlin.jvm.internal.l.k(r0, r2)     // Catch:{ all -> 0x0061 }
        L_0x003c:
            if (r0 != 0) goto L_0x0081
            if (r8 == 0) goto L_0x0063
            Uc.j r0 = Uc.C4164j.f38316E     // Catch:{ all -> 0x0061 }
            Uc.j r1 = Uc.C4164j.a.c(r8)     // Catch:{ all -> 0x0061 }
            byte[] r0 = r1.f38317f     // Catch:{ all -> 0x0061 }
            int r0 = r0.length     // Catch:{ all -> 0x0061 }
            long r2 = (long) r0     // Catch:{ all -> 0x0061 }
            r4 = 123(0x7b, double:6.1E-322)
            int r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r0 > 0) goto L_0x0051
            goto L_0x0063
        L_0x0051:
            java.lang.String r7 = "reason.size() > 123: "
            java.lang.String r7 = kotlin.jvm.internal.l.k(r8, r7)     // Catch:{ all -> 0x0061 }
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0061 }
            java.lang.String r7 = r7.toString()     // Catch:{ all -> 0x0061 }
            r8.<init>(r7)     // Catch:{ all -> 0x0061 }
            throw r8     // Catch:{ all -> 0x0061 }
        L_0x0061:
            r7 = move-exception
            goto L_0x008b
        L_0x0063:
            boolean r8 = r6.f37937t     // Catch:{ all -> 0x0061 }
            if (r8 != 0) goto L_0x007e
            boolean r8 = r6.f37934q     // Catch:{ all -> 0x0061 }
            if (r8 == 0) goto L_0x006c
            goto L_0x007e
        L_0x006c:
            r8 = 1
            r6.f37934q = r8     // Catch:{ all -> 0x0061 }
            java.util.ArrayDeque<java.lang.Object> r0 = r6.f37932o     // Catch:{ all -> 0x0061 }
            Sc.d$a r2 = new Sc.d$a     // Catch:{ all -> 0x0061 }
            r2.<init>(r7, r1)     // Catch:{ all -> 0x0061 }
            r0.add(r2)     // Catch:{ all -> 0x0061 }
            r6.j()     // Catch:{ all -> 0x0061 }
            monitor-exit(r6)
            return r8
        L_0x007e:
            monitor-exit(r6)
            r7 = 0
            return r7
        L_0x0081:
            java.lang.IllegalArgumentException r7 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0061 }
            java.lang.String r8 = r0.toString()     // Catch:{ all -> 0x0061 }
            r7.<init>(r8)     // Catch:{ all -> 0x0061 }
            throw r7     // Catch:{ all -> 0x0061 }
        L_0x008b:
            monitor-exit(r6)     // Catch:{ all -> 0x0061 }
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: Sc.d.c(int, java.lang.String):boolean");
    }

    public final void cancel() {
        Jc.e eVar = this.f37924g;
        l.c(eVar);
        eVar.cancel();
    }

    public final void d(Fc.F f10, Jc.c cVar) {
        int i10 = f10.f35059E;
        if (i10 == 101) {
            String d10 = Fc.F.d(f10, "Connection");
            if ("Upgrade".equalsIgnoreCase(d10)) {
                String d11 = Fc.F.d(f10, "Upgrade");
                if ("websocket".equalsIgnoreCase(d11)) {
                    String d12 = Fc.F.d(f10, HttpHeaders.Names.SEC_WEBSOCKET_ACCEPT);
                    C4164j jVar = C4164j.f38316E;
                    String b10 = C4164j.a.c(l.k("258EAFA5-E914-47DA-95CA-C5AB0DC85B11", this.f37923f)).e("SHA-1").b();
                    if (!l.a(b10, d12)) {
                        throw new ProtocolException("Expected 'Sec-WebSocket-Accept' header value '" + b10 + "' but was '" + d12 + '\'');
                    } else if (cVar == null) {
                        throw new ProtocolException("Web Socket exchange missing: bad interceptor?");
                    }
                } else {
                    throw new ProtocolException("Expected 'Upgrade' header value 'websocket' but was '" + d11 + '\'');
                }
            } else {
                throw new ProtocolException("Expected 'Connection' header value 'Upgrade' but was '" + d10 + '\'');
            }
        } else {
            StringBuilder sb2 = new StringBuilder("Expected HTTP 101 response but was '");
            sb2.append(i10);
            sb2.append(' ');
            throw new ProtocolException(D2.E.p(sb2, f10.f35072z, '\''));
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:?, code lost:
        r4.f37918a.onFailure(r4, r5, r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0024, code lost:
        if (r0 != null) goto L_0x0027;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0027, code lost:
        Gc.c.c(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002a, code lost:
        if (r2 != null) goto L_0x002d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x002d, code lost:
        Gc.c.c(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0030, code lost:
        if (r3 != null) goto L_0x0033;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0032, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0033, code lost:
        Gc.c.c(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0036, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0037, code lost:
        r5 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0038, code lost:
        if (r0 != null) goto L_0x003b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x003b, code lost:
        Gc.c.c(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x003e, code lost:
        if (r2 != null) goto L_0x0041;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0041, code lost:
        Gc.c.c(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0044, code lost:
        if (r3 != null) goto L_0x0047;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0047, code lost:
        Gc.c.c(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x004a, code lost:
        throw r5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void e(java.lang.Exception r5, Fc.F r6) {
        /*
            r4 = this;
            monitor-enter(r4)
            boolean r0 = r4.f37937t     // Catch:{ all -> 0x004b }
            if (r0 == 0) goto L_0x0007
            monitor-exit(r4)
            return
        L_0x0007:
            r0 = 1
            r4.f37937t = r0     // Catch:{ all -> 0x004b }
            Jc.h r0 = r4.f37930m     // Catch:{ all -> 0x004b }
            r1 = 0
            r4.f37930m = r1     // Catch:{ all -> 0x004b }
            Sc.g r2 = r4.f37926i     // Catch:{ all -> 0x004b }
            r4.f37926i = r1     // Catch:{ all -> 0x004b }
            Sc.h r3 = r4.f37927j     // Catch:{ all -> 0x004b }
            r4.f37927j = r1     // Catch:{ all -> 0x004b }
            Ic.d r1 = r4.f37928k     // Catch:{ all -> 0x004b }
            r1.g()     // Catch:{ all -> 0x004b }
            xa.D r1 = xa.C4959D.f44058a     // Catch:{ all -> 0x004b }
            monitor-exit(r4)
            Fc.L r1 = r4.f37918a     // Catch:{ all -> 0x0037 }
            r1.onFailure(r4, r5, r6)     // Catch:{ all -> 0x0037 }
            if (r0 != 0) goto L_0x0027
            goto L_0x002a
        L_0x0027:
            Gc.c.c(r0)
        L_0x002a:
            if (r2 != 0) goto L_0x002d
            goto L_0x0030
        L_0x002d:
            Gc.c.c(r2)
        L_0x0030:
            if (r3 != 0) goto L_0x0033
            return
        L_0x0033:
            Gc.c.c(r3)
            return
        L_0x0037:
            r5 = move-exception
            if (r0 != 0) goto L_0x003b
            goto L_0x003e
        L_0x003b:
            Gc.c.c(r0)
        L_0x003e:
            if (r2 != 0) goto L_0x0041
            goto L_0x0044
        L_0x0041:
            Gc.c.c(r2)
        L_0x0044:
            if (r3 != 0) goto L_0x0047
            goto L_0x004a
        L_0x0047:
            Gc.c.c(r3)
        L_0x004a:
            throw r5
        L_0x004b:
            r5 = move-exception
            monitor-exit(r4)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: Sc.d.e(java.lang.Exception, Fc.F):void");
    }

    public final void f(String str, h hVar) {
        l.f(str, ContentDisposition.Parameters.Name);
        f fVar = this.f37921d;
        l.c(fVar);
        synchronized (this) {
            try {
                this.f37929l = str;
                this.f37930m = hVar;
                this.f37927j = new h(hVar.f37945i, this.f37919b, fVar.f37950a, fVar.f37952c, this.f37922e);
                this.f37925h = new C0360d(this);
                long j10 = this.f37920c;
                if (j10 != 0) {
                    long nanos = TimeUnit.MILLISECONDS.toNanos(j10);
                    Ic.d dVar = this.f37928k;
                    String k10 = l.k(" ping", str);
                    e eVar = new e(this, nanos);
                    dVar.getClass();
                    l.f(k10, ContentDisposition.Parameters.Name);
                    dVar.d(new Ic.c(k10, eVar), nanos);
                }
                if (!this.f37932o.isEmpty()) {
                    j();
                }
                C4959D d10 = C4959D.f44058a;
            } catch (Throwable th) {
                throw th;
            }
        }
        this.f37926i = new g(hVar.f37944f, this, fVar.f37950a, fVar.f37954e);
    }

    public final void g() {
        while (this.f37935r == -1) {
            g gVar = this.f37926i;
            l.c(gVar);
            gVar.d();
            if (gVar.f37961J) {
                gVar.b();
            } else {
                int i10 = gVar.f37958G;
                if (i10 == 1 || i10 == 2) {
                    while (!gVar.f37957F) {
                        long j10 = gVar.f37959H;
                        int i11 = (j10 > 0 ? 1 : (j10 == 0 ? 0 : -1));
                        C4161g gVar2 = gVar.f37964M;
                        if (i11 > 0) {
                            gVar.f37967f.q0(gVar2, j10);
                        }
                        if (gVar.f37960I) {
                            if (!gVar.f37962K) {
                                d dVar = gVar.f37968i;
                                L l10 = dVar.f37918a;
                            } else {
                                c cVar = gVar.f37965N;
                                if (cVar == null) {
                                    cVar = new c(gVar.f37956E);
                                    gVar.f37965N = cVar;
                                }
                                l.f(gVar2, "buffer");
                                C4161g gVar3 = cVar.f37915i;
                                if (gVar3.f38306i == 0) {
                                    Inflater inflater = cVar.f37916z;
                                    if (cVar.f37914f) {
                                        inflater.reset();
                                    }
                                    gVar3.w0(gVar2);
                                    gVar3.writeInt(65535);
                                    long bytesRead = inflater.getBytesRead() + gVar3.f38306i;
                                    do {
                                        cVar.f37913E.b(gVar2, Long.MAX_VALUE);
                                    } while (inflater.getBytesRead() < bytesRead);
                                } else {
                                    throw new IllegalArgumentException("Failed requirement.");
                                }
                            }
                            d dVar2 = gVar.f37968i;
                            L l102 = dVar2.f37918a;
                            if (i10 == 1) {
                                l102.onMessage((K) dVar2, gVar2.L());
                            } else {
                                C4164j v10 = gVar2.v(gVar2.f38306i);
                                l.f(v10, "bytes");
                                l102.onMessage((K) dVar2, v10);
                            }
                        } else {
                            while (!gVar.f37957F) {
                                gVar.d();
                                if (!gVar.f37961J) {
                                    break;
                                }
                                gVar.b();
                            }
                            if (gVar.f37958G != 0) {
                                int i12 = gVar.f37958G;
                                byte[] bArr = Gc.c.f35370a;
                                String hexString = Integer.toHexString(i12);
                                l.e(hexString, "toHexString(this)");
                                throw new ProtocolException(l.k(hexString, "Expected continuation opcode. Got: "));
                            }
                        }
                    }
                    throw new IOException("closed");
                }
                byte[] bArr2 = Gc.c.f35370a;
                String hexString2 = Integer.toHexString(i10);
                l.e(hexString2, "toHexString(this)");
                throw new ProtocolException(l.k(hexString2, "Unknown opcode: "));
            }
        }
    }

    public final void h(int i10, String str) {
        h hVar;
        h hVar2;
        g gVar;
        if (i10 != -1) {
            synchronized (this) {
                try {
                    if (this.f37935r == -1) {
                        this.f37935r = i10;
                        this.f37936s = str;
                        hVar = null;
                        if (!this.f37934q || !this.f37932o.isEmpty()) {
                            gVar = null;
                            hVar2 = null;
                        } else {
                            h hVar3 = this.f37930m;
                            this.f37930m = null;
                            gVar = this.f37926i;
                            this.f37926i = null;
                            hVar2 = this.f37927j;
                            this.f37927j = null;
                            this.f37928k.g();
                            hVar = hVar3;
                        }
                        C4959D d10 = C4959D.f44058a;
                    } else {
                        throw new IllegalStateException("already closed");
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            try {
                this.f37918a.onClosing(this, i10, str);
                if (hVar != null) {
                    this.f37918a.onClosed(this, i10, str);
                }
                if (hVar != null) {
                    Gc.c.c(hVar);
                }
                if (gVar != null) {
                    Gc.c.c(gVar);
                }
                if (hVar2 != null) {
                    Gc.c.c(hVar2);
                }
            } catch (Throwable th2) {
                if (hVar != null) {
                    Gc.c.c(hVar);
                }
                if (gVar != null) {
                    Gc.c.c(gVar);
                }
                if (hVar2 != null) {
                    Gc.c.c(hVar2);
                }
                throw th2;
            }
        } else {
            throw new IllegalArgumentException("Failed requirement.");
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0024, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized void i(Uc.C4164j r2) {
        /*
            r1 = this;
            monitor-enter(r1)
            java.lang.String r0 = "payload"
            kotlin.jvm.internal.l.f(r2, r0)     // Catch:{ all -> 0x0017 }
            boolean r0 = r1.f37937t     // Catch:{ all -> 0x0017 }
            if (r0 != 0) goto L_0x0023
            boolean r0 = r1.f37934q     // Catch:{ all -> 0x0017 }
            if (r0 == 0) goto L_0x0019
            java.util.ArrayDeque<java.lang.Object> r0 = r1.f37932o     // Catch:{ all -> 0x0017 }
            boolean r0 = r0.isEmpty()     // Catch:{ all -> 0x0017 }
            if (r0 == 0) goto L_0x0019
            goto L_0x0023
        L_0x0017:
            r2 = move-exception
            goto L_0x0025
        L_0x0019:
            java.util.ArrayDeque<Uc.j> r0 = r1.f37931n     // Catch:{ all -> 0x0017 }
            r0.add(r2)     // Catch:{ all -> 0x0017 }
            r1.j()     // Catch:{ all -> 0x0017 }
            monitor-exit(r1)
            return
        L_0x0023:
            monitor-exit(r1)
            return
        L_0x0025:
            monitor-exit(r1)     // Catch:{ all -> 0x0017 }
            throw r2
        */
        throw new UnsupportedOperationException("Method not decompiled: Sc.d.i(Uc.j):void");
    }

    public final void j() {
        byte[] bArr = Gc.c.f35370a;
        C0360d dVar = this.f37925h;
        if (dVar != null) {
            this.f37928k.d(dVar, 0);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0039, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized boolean k(int r9, Uc.C4164j r10) {
        /*
            r8 = this;
            monitor-enter(r8)
            boolean r0 = r8.f37937t     // Catch:{ all -> 0x0021 }
            r1 = 0
            if (r0 != 0) goto L_0x0038
            boolean r0 = r8.f37934q     // Catch:{ all -> 0x0021 }
            if (r0 == 0) goto L_0x000b
            goto L_0x0038
        L_0x000b:
            long r2 = r8.f37933p     // Catch:{ all -> 0x0021 }
            byte[] r0 = r10.f38317f     // Catch:{ all -> 0x0021 }
            int r4 = r0.length     // Catch:{ all -> 0x0021 }
            long r4 = (long) r4     // Catch:{ all -> 0x0021 }
            long r4 = r4 + r2
            r6 = 16777216(0x1000000, double:8.289046E-317)
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 <= 0) goto L_0x0023
            r9 = 1001(0x3e9, float:1.403E-42)
            r10 = 0
            r8.c(r9, r10)     // Catch:{ all -> 0x0021 }
            monitor-exit(r8)
            return r1
        L_0x0021:
            r9 = move-exception
            goto L_0x003a
        L_0x0023:
            int r0 = r0.length     // Catch:{ all -> 0x0021 }
            long r0 = (long) r0     // Catch:{ all -> 0x0021 }
            long r2 = r2 + r0
            r8.f37933p = r2     // Catch:{ all -> 0x0021 }
            java.util.ArrayDeque<java.lang.Object> r0 = r8.f37932o     // Catch:{ all -> 0x0021 }
            Sc.d$b r1 = new Sc.d$b     // Catch:{ all -> 0x0021 }
            r1.<init>(r9, r10)     // Catch:{ all -> 0x0021 }
            r0.add(r1)     // Catch:{ all -> 0x0021 }
            r8.j()     // Catch:{ all -> 0x0021 }
            monitor-exit(r8)
            r9 = 1
            return r9
        L_0x0038:
            monitor-exit(r8)
            return r1
        L_0x003a:
            monitor-exit(r8)     // Catch:{ all -> 0x0021 }
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: Sc.d.k(int, Uc.j):boolean");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v0, resolved type: Sc.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v0, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v1, resolved type: Sc.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v2, resolved type: Sc.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: Sc.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v4, resolved type: Sc.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: Sc.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v4, resolved type: Sc.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v6, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v7, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v8, resolved type: java.lang.String} */
    /* JADX WARNING: Code restructure failed: missing block: B:100:0x0147, code lost:
        Gc.c.c(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x014a, code lost:
        if (r8 != null) goto L_0x014d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x014d, code lost:
        Gc.c.c(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x0150, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0070, code lost:
        if (r0 == null) goto L_0x0081;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:?, code lost:
        kotlin.jvm.internal.l.c(r2);
        r2.b(10, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x007e, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0083, code lost:
        if ((r5 instanceof Sc.d.b) == false) goto L_0x00a3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0085, code lost:
        r5 = (Sc.d.b) r5;
        kotlin.jvm.internal.l.c(r2);
        r2.d(r5.f37942a, r5.f37943b);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0091, code lost:
        monitor-enter(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:?, code lost:
        r13.f37933p -= (long) r5.f37943b.f38317f.length;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:?, code lost:
        monitor-exit(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00a5, code lost:
        if ((r5 instanceof Sc.d.a) == false) goto L_0x0138;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x00a7, code lost:
        r5 = (Sc.d.a) r5;
        kotlin.jvm.internal.l.c(r2);
        r0 = r5.f37940a;
        r5 = r5.f37941b;
        r10 = Uc.C4164j.f38316E;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00b2, code lost:
        if (r0 != 0) goto L_0x00b6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00b4, code lost:
        if (r5 == null) goto L_0x0110;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00b6, code lost:
        if (r0 == 0) goto L_0x00fd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x00ba, code lost:
        if (r0 < 1000) goto L_0x00e6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00be, code lost:
        if (r0 < 5000) goto L_0x00c1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x00c3, code lost:
        if (1004 > r0) goto L_0x00ca;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x00c7, code lost:
        if (r0 > 1006) goto L_0x00ca;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x00cc, code lost:
        if (1015 > r0) goto L_0x00f0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x00d0, code lost:
        if (r0 > 2999) goto L_0x00f0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x00d2, code lost:
        r3 = "Code " + r0 + " is reserved and may not be used.";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x00e6, code lost:
        r3 = kotlin.jvm.internal.l.k(java.lang.Integer.valueOf(r0), "Code must be in range [1000,5000): ");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x00f0, code lost:
        if (r3 != null) goto L_0x00f3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x00fc, code lost:
        throw new java.lang.IllegalArgumentException(r3.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x00fd, code lost:
        r3 = new Uc.C4161g();
        r3.E0(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0105, code lost:
        if (r5 == null) goto L_0x010a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0107, code lost:
        r3.n0(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x010a, code lost:
        r10 = r3.v(r3.f38306i);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:?, code lost:
        r2.b(8, r10);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:80:?, code lost:
        r2.f37974I = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0117, code lost:
        if (r4 == null) goto L_0x0121;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x0119, code lost:
        r0 = r13.f37918a;
        kotlin.jvm.internal.l.c(r6);
        r0.onClosed(r13, r1, r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x0121, code lost:
        if (r4 != null) goto L_0x0124;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x0124, code lost:
        Gc.c.c(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x0127, code lost:
        if (r7 != null) goto L_0x012a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:0x012a, code lost:
        Gc.c.c(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x012d, code lost:
        if (r8 != null) goto L_0x0130;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x012f, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x0130, code lost:
        Gc.c.c(r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:90:0x0133, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x0134, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:?, code lost:
        r2.f37974I = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x0137, code lost:
        throw r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x013d, code lost:
        throw new java.lang.AssertionError();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:97:0x013e, code lost:
        if (r4 != null) goto L_0x0141;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x0141, code lost:
        Gc.c.c(r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x0144, code lost:
        if (r7 != null) goto L_0x0147;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean l() {
        /*
            r13 = this;
            monitor-enter(r13)
            boolean r0 = r13.f37937t     // Catch:{ all -> 0x0036 }
            r1 = 0
            if (r0 == 0) goto L_0x0008
            monitor-exit(r13)
            return r1
        L_0x0008:
            Sc.h r2 = r13.f37927j     // Catch:{ all -> 0x0036 }
            java.util.ArrayDeque<Uc.j> r0 = r13.f37931n     // Catch:{ all -> 0x0036 }
            java.lang.Object r0 = r0.poll()     // Catch:{ all -> 0x0036 }
            r3 = 0
            r4 = -1
            if (r0 != 0) goto L_0x0069
            java.util.ArrayDeque<java.lang.Object> r5 = r13.f37932o     // Catch:{ all -> 0x0036 }
            java.lang.Object r5 = r5.poll()     // Catch:{ all -> 0x0036 }
            boolean r6 = r5 instanceof Sc.d.a     // Catch:{ all -> 0x0036 }
            if (r6 == 0) goto L_0x005f
            int r1 = r13.f37935r     // Catch:{ all -> 0x0036 }
            java.lang.String r6 = r13.f37936s     // Catch:{ all -> 0x0036 }
            if (r1 == r4) goto L_0x0039
            Jc.h r4 = r13.f37930m     // Catch:{ all -> 0x0036 }
            r13.f37930m = r3     // Catch:{ all -> 0x0036 }
            Sc.g r7 = r13.f37926i     // Catch:{ all -> 0x0036 }
            r13.f37926i = r3     // Catch:{ all -> 0x0036 }
            Sc.h r8 = r13.f37927j     // Catch:{ all -> 0x0036 }
            r13.f37927j = r3     // Catch:{ all -> 0x0036 }
            Ic.d r9 = r13.f37928k     // Catch:{ all -> 0x0036 }
            r9.g()     // Catch:{ all -> 0x0036 }
            goto L_0x006c
        L_0x0036:
            r0 = move-exception
            goto L_0x0151
        L_0x0039:
            r4 = r5
            Sc.d$a r4 = (Sc.d.a) r4     // Catch:{ all -> 0x0036 }
            r4.getClass()     // Catch:{ all -> 0x0036 }
            Ic.d r7 = r13.f37928k     // Catch:{ all -> 0x0036 }
            java.lang.String r4 = r13.f37929l     // Catch:{ all -> 0x0036 }
            java.lang.String r8 = " cancel"
            java.lang.String r8 = kotlin.jvm.internal.l.k(r8, r4)     // Catch:{ all -> 0x0036 }
            java.util.concurrent.TimeUnit r4 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ all -> 0x0036 }
            r9 = 60000(0xea60, double:2.9644E-319)
            long r9 = r4.toNanos(r9)     // Catch:{ all -> 0x0036 }
            Sc.d$e r11 = new Sc.d$e     // Catch:{ all -> 0x0036 }
            r11.<init>(r13)     // Catch:{ all -> 0x0036 }
            r12 = 4
            Ic.d.c(r7, r8, r9, r11, r12)     // Catch:{ all -> 0x0036 }
            r4 = r3
            r7 = r4
            r8 = r7
            goto L_0x006c
        L_0x005f:
            if (r5 != 0) goto L_0x0063
            monitor-exit(r13)
            return r1
        L_0x0063:
            r6 = r3
        L_0x0064:
            r7 = r6
            r8 = r7
            r1 = r4
            r4 = r8
            goto L_0x006c
        L_0x0069:
            r5 = r3
            r6 = r5
            goto L_0x0064
        L_0x006c:
            xa.D r9 = xa.C4959D.f44058a     // Catch:{ all -> 0x0036 }
            monitor-exit(r13)
            r9 = 1
            if (r0 == 0) goto L_0x0081
            kotlin.jvm.internal.l.c(r2)     // Catch:{ all -> 0x007e }
            Uc.j r0 = (Uc.C4164j) r0     // Catch:{ all -> 0x007e }
            r1 = 10
            r2.b(r1, r0)     // Catch:{ all -> 0x007e }
            goto L_0x0121
        L_0x007e:
            r0 = move-exception
            goto L_0x013e
        L_0x0081:
            boolean r0 = r5 instanceof Sc.d.b     // Catch:{ all -> 0x007e }
            if (r0 == 0) goto L_0x00a3
            Sc.d$b r5 = (Sc.d.b) r5     // Catch:{ all -> 0x007e }
            kotlin.jvm.internal.l.c(r2)     // Catch:{ all -> 0x007e }
            int r0 = r5.f37942a     // Catch:{ all -> 0x007e }
            Uc.j r1 = r5.f37943b     // Catch:{ all -> 0x007e }
            r2.d(r0, r1)     // Catch:{ all -> 0x007e }
            monitor-enter(r13)     // Catch:{ all -> 0x007e }
            long r0 = r13.f37933p     // Catch:{ all -> 0x00a0 }
            Uc.j r2 = r5.f37943b     // Catch:{ all -> 0x00a0 }
            byte[] r2 = r2.f38317f     // Catch:{ all -> 0x00a0 }
            int r2 = r2.length     // Catch:{ all -> 0x00a0 }
            long r2 = (long) r2     // Catch:{ all -> 0x00a0 }
            long r0 = r0 - r2
            r13.f37933p = r0     // Catch:{ all -> 0x00a0 }
            monitor-exit(r13)     // Catch:{ all -> 0x007e }
            goto L_0x0121
        L_0x00a0:
            r0 = move-exception
            monitor-exit(r13)     // Catch:{ all -> 0x007e }
            throw r0     // Catch:{ all -> 0x007e }
        L_0x00a3:
            boolean r0 = r5 instanceof Sc.d.a     // Catch:{ all -> 0x007e }
            if (r0 == 0) goto L_0x0138
            Sc.d$a r5 = (Sc.d.a) r5     // Catch:{ all -> 0x007e }
            kotlin.jvm.internal.l.c(r2)     // Catch:{ all -> 0x007e }
            int r0 = r5.f37940a     // Catch:{ all -> 0x007e }
            Uc.j r5 = r5.f37941b     // Catch:{ all -> 0x007e }
            Uc.j r10 = Uc.C4164j.f38316E     // Catch:{ all -> 0x007e }
            if (r0 != 0) goto L_0x00b6
            if (r5 == 0) goto L_0x0110
        L_0x00b6:
            if (r0 == 0) goto L_0x00fd
            r10 = 1000(0x3e8, float:1.401E-42)
            if (r0 < r10) goto L_0x00e6
            r10 = 5000(0x1388, float:7.006E-42)
            if (r0 < r10) goto L_0x00c1
            goto L_0x00e6
        L_0x00c1:
            r10 = 1004(0x3ec, float:1.407E-42)
            if (r10 > r0) goto L_0x00ca
            r10 = 1006(0x3ee, float:1.41E-42)
            if (r0 > r10) goto L_0x00ca
            goto L_0x00d2
        L_0x00ca:
            r10 = 1015(0x3f7, float:1.422E-42)
            if (r10 > r0) goto L_0x00f0
            r10 = 2999(0xbb7, float:4.202E-42)
            if (r0 > r10) goto L_0x00f0
        L_0x00d2:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x007e }
            java.lang.String r10 = "Code "
            r3.<init>(r10)     // Catch:{ all -> 0x007e }
            r3.append(r0)     // Catch:{ all -> 0x007e }
            java.lang.String r10 = " is reserved and may not be used."
            r3.append(r10)     // Catch:{ all -> 0x007e }
            java.lang.String r3 = r3.toString()     // Catch:{ all -> 0x007e }
            goto L_0x00f0
        L_0x00e6:
            java.lang.Integer r3 = java.lang.Integer.valueOf(r0)     // Catch:{ all -> 0x007e }
            java.lang.String r10 = "Code must be in range [1000,5000): "
            java.lang.String r3 = kotlin.jvm.internal.l.k(r3, r10)     // Catch:{ all -> 0x007e }
        L_0x00f0:
            if (r3 != 0) goto L_0x00f3
            goto L_0x00fd
        L_0x00f3:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x007e }
            java.lang.String r1 = r3.toString()     // Catch:{ all -> 0x007e }
            r0.<init>(r1)     // Catch:{ all -> 0x007e }
            throw r0     // Catch:{ all -> 0x007e }
        L_0x00fd:
            Uc.g r3 = new Uc.g     // Catch:{ all -> 0x007e }
            r3.<init>()     // Catch:{ all -> 0x007e }
            r3.E0(r0)     // Catch:{ all -> 0x007e }
            if (r5 == 0) goto L_0x010a
            r3.n0(r5)     // Catch:{ all -> 0x007e }
        L_0x010a:
            long r10 = r3.f38306i     // Catch:{ all -> 0x007e }
            Uc.j r10 = r3.v(r10)     // Catch:{ all -> 0x007e }
        L_0x0110:
            r0 = 8
            r2.b(r0, r10)     // Catch:{ all -> 0x0134 }
            r2.f37974I = r9     // Catch:{ all -> 0x007e }
            if (r4 == 0) goto L_0x0121
            Fc.L r0 = r13.f37918a     // Catch:{ all -> 0x007e }
            kotlin.jvm.internal.l.c(r6)     // Catch:{ all -> 0x007e }
            r0.onClosed(r13, r1, r6)     // Catch:{ all -> 0x007e }
        L_0x0121:
            if (r4 != 0) goto L_0x0124
            goto L_0x0127
        L_0x0124:
            Gc.c.c(r4)
        L_0x0127:
            if (r7 != 0) goto L_0x012a
            goto L_0x012d
        L_0x012a:
            Gc.c.c(r7)
        L_0x012d:
            if (r8 != 0) goto L_0x0130
            return r9
        L_0x0130:
            Gc.c.c(r8)
            return r9
        L_0x0134:
            r0 = move-exception
            r2.f37974I = r9     // Catch:{ all -> 0x007e }
            throw r0     // Catch:{ all -> 0x007e }
        L_0x0138:
            java.lang.AssertionError r0 = new java.lang.AssertionError     // Catch:{ all -> 0x007e }
            r0.<init>()     // Catch:{ all -> 0x007e }
            throw r0     // Catch:{ all -> 0x007e }
        L_0x013e:
            if (r4 != 0) goto L_0x0141
            goto L_0x0144
        L_0x0141:
            Gc.c.c(r4)
        L_0x0144:
            if (r7 != 0) goto L_0x0147
            goto L_0x014a
        L_0x0147:
            Gc.c.c(r7)
        L_0x014a:
            if (r8 != 0) goto L_0x014d
            goto L_0x0150
        L_0x014d:
            Gc.c.c(r8)
        L_0x0150:
            throw r0
        L_0x0151:
            monitor-exit(r13)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: Sc.d.l():boolean");
    }
}
