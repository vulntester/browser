package Sc;

import D1.d;
import Fc.F;
import Na.a;
import Uc.C4164j;
import java.io.IOException;
import java.net.SocketTimeoutException;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.n;
import xa.C4959D;

public final class e extends n implements a<Long> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ d f37948f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ long f37949i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public e(d dVar, long j10) {
        super(0);
        this.f37948f = dVar;
        this.f37949i = j10;
    }

    public final Object invoke() {
        int i10;
        d dVar = this.f37948f;
        synchronized (dVar) {
            try {
                if (!dVar.f37937t) {
                    h hVar = dVar.f37927j;
                    if (hVar != null) {
                        if (dVar.f37939v) {
                            i10 = dVar.f37938u;
                        } else {
                            i10 = -1;
                        }
                        dVar.f37938u++;
                        dVar.f37939v = true;
                        C4959D d10 = C4959D.f44058a;
                        if (i10 != -1) {
                            StringBuilder sb2 = new StringBuilder("sent ping but didn't receive pong within ");
                            sb2.append(dVar.f37920c);
                            sb2.append("ms (after ");
                            dVar.e(new SocketTimeoutException(d.d(sb2, i10 - 1, " successful ping/pongs)")), (F) null);
                        } else {
                            try {
                                C4164j jVar = C4164j.f38316E;
                                l.f(jVar, "payload");
                                hVar.b(9, jVar);
                            } catch (IOException e10) {
                                dVar.e(e10, (F) null);
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return Long.valueOf(this.f37949i);
    }
}
