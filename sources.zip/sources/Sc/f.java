package Sc;

import M.k;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f37950a;

    /* renamed from: b  reason: collision with root package name */
    public final Integer f37951b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f37952c;

    /* renamed from: d  reason: collision with root package name */
    public final Integer f37953d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f37954e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f37955f;

    public f() {
        this(false, (Integer) null, false, (Integer) null, false, false);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x000a, code lost:
        r5 = (Sc.f) r5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(java.lang.Object r5) {
        /*
            r4 = this;
            r0 = 1
            if (r4 != r5) goto L_0x0004
            return r0
        L_0x0004:
            boolean r1 = r5 instanceof Sc.f
            r2 = 0
            if (r1 != 0) goto L_0x000a
            return r2
        L_0x000a:
            Sc.f r5 = (Sc.f) r5
            boolean r1 = r5.f37950a
            boolean r3 = r4.f37950a
            if (r3 == r1) goto L_0x0013
            return r2
        L_0x0013:
            java.lang.Integer r1 = r4.f37951b
            java.lang.Integer r3 = r5.f37951b
            boolean r1 = kotlin.jvm.internal.l.a(r1, r3)
            if (r1 != 0) goto L_0x001e
            return r2
        L_0x001e:
            boolean r1 = r4.f37952c
            boolean r3 = r5.f37952c
            if (r1 == r3) goto L_0x0025
            return r2
        L_0x0025:
            java.lang.Integer r1 = r4.f37953d
            java.lang.Integer r3 = r5.f37953d
            boolean r1 = kotlin.jvm.internal.l.a(r1, r3)
            if (r1 != 0) goto L_0x0030
            return r2
        L_0x0030:
            boolean r1 = r4.f37954e
            boolean r3 = r5.f37954e
            if (r1 == r3) goto L_0x0037
            return r2
        L_0x0037:
            boolean r1 = r4.f37955f
            boolean r5 = r5.f37955f
            if (r1 == r5) goto L_0x003e
            return r2
        L_0x003e:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: Sc.f.equals(java.lang.Object):boolean");
    }

    public final int hashCode() {
        int i10;
        boolean z10 = true;
        boolean z11 = this.f37950a;
        if (z11) {
            z11 = true;
        }
        int i11 = (z11 ? 1 : 0) * true;
        int i12 = 0;
        Integer num = this.f37951b;
        if (num == null) {
            i10 = 0;
        } else {
            i10 = num.hashCode();
        }
        int i13 = (i11 + i10) * 31;
        boolean z12 = this.f37952c;
        if (z12) {
            z12 = true;
        }
        int i14 = (i13 + (z12 ? 1 : 0)) * 31;
        Integer num2 = this.f37953d;
        if (num2 != null) {
            i12 = num2.hashCode();
        }
        int i15 = (i14 + i12) * 31;
        boolean z13 = this.f37954e;
        if (z13) {
            z13 = true;
        }
        int i16 = (i15 + (z13 ? 1 : 0)) * 31;
        boolean z14 = this.f37955f;
        if (!z14) {
            z10 = z14;
        }
        return i16 + (z10 ? 1 : 0);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("WebSocketExtensions(perMessageDeflate=");
        sb2.append(this.f37950a);
        sb2.append(", clientMaxWindowBits=");
        sb2.append(this.f37951b);
        sb2.append(", clientNoContextTakeover=");
        sb2.append(this.f37952c);
        sb2.append(", serverMaxWindowBits=");
        sb2.append(this.f37953d);
        sb2.append(", serverNoContextTakeover=");
        sb2.append(this.f37954e);
        sb2.append(", unknownValues=");
        return k.n(sb2, this.f37955f, ')');
    }

    public f(boolean z10, Integer num, boolean z11, Integer num2, boolean z12, boolean z13) {
        this.f37950a = z10;
        this.f37951b = num;
        this.f37952c = z11;
        this.f37953d = num2;
        this.f37954e = z12;
        this.f37955f = z13;
    }
}
