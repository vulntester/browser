package Sc;

import A6.u;
import Gc.c;
import Uc.C4161g;
import Uc.C4164j;
import Uc.F;
import Uc.L;
import io.netty.handler.codec.http.HttpConstants;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.concurrent.TimeUnit;
import kotlin.jvm.internal.l;

public final class g implements Closeable {

    /* renamed from: E  reason: collision with root package name */
    public final boolean f37956E;

    /* renamed from: F  reason: collision with root package name */
    public boolean f37957F;

    /* renamed from: G  reason: collision with root package name */
    public int f37958G;

    /* renamed from: H  reason: collision with root package name */
    public long f37959H;

    /* renamed from: I  reason: collision with root package name */
    public boolean f37960I;

    /* renamed from: J  reason: collision with root package name */
    public boolean f37961J;

    /* renamed from: K  reason: collision with root package name */
    public boolean f37962K;

    /* renamed from: L  reason: collision with root package name */
    public final C4161g f37963L = new C4161g();

    /* renamed from: M  reason: collision with root package name */
    public final C4161g f37964M = new C4161g();

    /* renamed from: N  reason: collision with root package name */
    public c f37965N;

    /* renamed from: O  reason: collision with root package name */
    public final byte[] f37966O = null;

    /* renamed from: f  reason: collision with root package name */
    public final F f37967f;

    /* renamed from: i  reason: collision with root package name */
    public final d f37968i;

    /* renamed from: z  reason: collision with root package name */
    public final boolean f37969z;

    public g(F f10, d dVar, boolean z10, boolean z11) {
        l.f(f10, "source");
        this.f37967f = f10;
        this.f37968i = dVar;
        this.f37969z = z10;
        this.f37956E = z11;
    }

    public final void b() {
        String str;
        short s10;
        String str2;
        long j10 = this.f37959H;
        int i10 = (j10 > 0 ? 1 : (j10 == 0 ? 0 : -1));
        C4161g gVar = this.f37963L;
        if (i10 > 0) {
            this.f37967f.q0(gVar, j10);
        }
        int i11 = this.f37958G;
        d dVar = this.f37968i;
        switch (i11) {
            case 8:
                long j11 = gVar.f38306i;
                if (j11 != 1) {
                    if (j11 != 0) {
                        s10 = gVar.readShort();
                        str = gVar.L();
                        if (s10 < 1000 || s10 >= 5000) {
                            str2 = l.k(Integer.valueOf(s10), "Code must be in range [1000,5000): ");
                        } else if ((1004 > s10 || s10 > 1006) && (1015 > s10 || s10 > 2999)) {
                            str2 = null;
                        } else {
                            str2 = u.n(s10, "Code ", " is reserved and may not be used.");
                        }
                        if (str2 != null) {
                            throw new ProtocolException(str2);
                        }
                    } else {
                        str = "";
                        s10 = 1005;
                    }
                    dVar.h(s10, str);
                    this.f37957F = true;
                    return;
                }
                throw new ProtocolException("Malformed close payload length of 1.");
            case 9:
                dVar.i(gVar.v(gVar.f38306i));
                return;
            case 10:
                C4164j v10 = gVar.v(gVar.f38306i);
                synchronized (dVar) {
                    l.f(v10, "payload");
                    dVar.f37939v = false;
                }
                return;
            default:
                int i12 = this.f37958G;
                byte[] bArr = c.f35370a;
                String hexString = Integer.toHexString(i12);
                l.e(hexString, "toHexString(this)");
                throw new ProtocolException(l.k(hexString, "Unknown control opcode: "));
        }
    }

    public final void close() {
        c cVar = this.f37965N;
        if (cVar != null) {
            cVar.close();
        }
    }

    /* JADX INFO: finally extract failed */
    public final void d() {
        boolean z10;
        boolean z11;
        boolean z12;
        boolean z13;
        boolean z14;
        if (!this.f37957F) {
            F f10 = this.f37967f;
            long h10 = f10.f38265f.timeout().h();
            L l10 = f10.f38265f;
            l10.timeout().b();
            try {
                byte readByte = f10.readByte();
                byte[] bArr = c.f35370a;
                l10.timeout().g(h10, TimeUnit.NANOSECONDS);
                byte b10 = readByte & 15;
                this.f37958G = b10;
                int i10 = 0;
                if ((readByte & 128) != 0) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                this.f37960I = z10;
                if ((readByte & 8) != 0) {
                    z11 = true;
                } else {
                    z11 = false;
                }
                this.f37961J = z11;
                if (!z11 || z10) {
                    if ((readByte & 64) != 0) {
                        z12 = true;
                    } else {
                        z12 = false;
                    }
                    if (b10 == 1 || b10 == 2) {
                        if (!z12) {
                            z14 = false;
                        } else if (this.f37969z) {
                            z14 = true;
                        } else {
                            throw new ProtocolException("Unexpected rsv1 flag");
                        }
                        this.f37962K = z14;
                    } else if (z12) {
                        throw new ProtocolException("Unexpected rsv1 flag");
                    }
                    if ((readByte & HttpConstants.SP) != 0) {
                        throw new ProtocolException("Unexpected rsv2 flag");
                    } else if ((readByte & 16) == 0) {
                        byte readByte2 = f10.readByte();
                        if ((readByte2 & 128) != 0) {
                            z13 = true;
                        } else {
                            z13 = false;
                        }
                        if (!z13) {
                            long j10 = (long) (readByte2 & Byte.MAX_VALUE);
                            this.f37959H = j10;
                            int i11 = (j10 > 126 ? 1 : (j10 == 126 ? 0 : -1));
                            C4161g gVar = f10.f38266i;
                            if (i11 == 0) {
                                this.f37959H = (long) (f10.readShort() & 65535);
                            } else if (j10 == 127) {
                                f10.y0(8);
                                long readLong = gVar.readLong();
                                this.f37959H = readLong;
                                if (readLong < 0) {
                                    StringBuilder sb2 = new StringBuilder("Frame length 0x");
                                    String hexString = Long.toHexString(this.f37959H);
                                    l.e(hexString, "toHexString(this)");
                                    sb2.append(hexString);
                                    sb2.append(" > 0x7FFFFFFFFFFFFFFF");
                                    throw new ProtocolException(sb2.toString());
                                }
                            }
                            if (this.f37961J && this.f37959H > 125) {
                                throw new ProtocolException("Control frame must be less than 125B.");
                            } else if (z13) {
                                byte[] bArr2 = this.f37966O;
                                l.c(bArr2);
                                try {
                                    f10.y0((long) bArr2.length);
                                    gVar.y(bArr2);
                                } catch (EOFException e10) {
                                    while (true) {
                                        long j11 = gVar.f38306i;
                                        if (j11 > 0) {
                                            int read = gVar.read(bArr2, i10, (int) j11);
                                            if (read != -1) {
                                                i10 += read;
                                            } else {
                                                throw new AssertionError();
                                            }
                                        } else {
                                            throw e10;
                                        }
                                    }
                                }
                            }
                        } else {
                            throw new ProtocolException("Server-sent frames must not be masked.");
                        }
                    } else {
                        throw new ProtocolException("Unexpected rsv3 flag");
                    }
                } else {
                    throw new ProtocolException("Control frames must be final.");
                }
            } catch (Throwable th) {
                l10.timeout().g(h10, TimeUnit.NANOSECONDS);
                throw th;
            }
        } else {
            throw new IOException("closed");
        }
    }
}
