package Sc;

import A.o;
import Uc.C4156b;
import Uc.C4161g;
import Uc.C4164j;
import Uc.C4165k;
import Uc.E;
import Uc.G;
import Z7.b;
import io.netty.handler.codec.http.HttpObjectDecoder;
import java.io.Closeable;
import java.io.IOException;
import java.util.Random;
import kotlin.jvm.internal.l;

public final class h implements Closeable {

    /* renamed from: E  reason: collision with root package name */
    public final boolean f37970E;

    /* renamed from: F  reason: collision with root package name */
    public final long f37971F;

    /* renamed from: G  reason: collision with root package name */
    public final C4161g f37972G = new C4161g();

    /* renamed from: H  reason: collision with root package name */
    public final C4161g f37973H;

    /* renamed from: I  reason: collision with root package name */
    public boolean f37974I;

    /* renamed from: J  reason: collision with root package name */
    public a f37975J;

    /* renamed from: K  reason: collision with root package name */
    public final byte[] f37976K;

    /* renamed from: L  reason: collision with root package name */
    public final C4161g.a f37977L;

    /* renamed from: f  reason: collision with root package name */
    public final E f37978f;

    /* renamed from: i  reason: collision with root package name */
    public final Random f37979i;

    /* renamed from: z  reason: collision with root package name */
    public final boolean f37980z;

    public h(E e10, Random random, boolean z10, boolean z11, long j10) {
        l.f(e10, "sink");
        this.f37978f = e10;
        this.f37979i = random;
        this.f37980z = z10;
        this.f37970E = z11;
        this.f37971F = j10;
        this.f37973H = e10.f38262i;
        this.f37976K = new byte[4];
        this.f37977L = new C4161g.a();
    }

    public final void b(int i10, C4164j jVar) {
        if (!this.f37974I) {
            int f10 = jVar.f();
            if (((long) f10) <= 125) {
                int i11 = i10 | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE;
                C4161g gVar = this.f37973H;
                gVar.u0(i11);
                gVar.u0(f10 | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
                byte[] bArr = this.f37976K;
                l.c(bArr);
                this.f37979i.nextBytes(bArr);
                gVar.write(bArr);
                if (f10 > 0) {
                    long j10 = gVar.f38306i;
                    gVar.n0(jVar);
                    C4161g.a aVar = this.f37977L;
                    l.c(aVar);
                    gVar.p(aVar);
                    aVar.d(j10);
                    b.x(aVar, bArr);
                    aVar.close();
                }
                this.f37978f.flush();
                return;
            }
            throw new IllegalArgumentException("Payload size must be less than or equal to 125");
        }
        throw new IOException("closed");
    }

    public final void close() {
        a aVar = this.f37975J;
        if (aVar != null) {
            aVar.close();
        }
    }

    public final void d(int i10, C4164j jVar) {
        Throwable th;
        int i11 = i10;
        C4164j jVar2 = jVar;
        if (!this.f37974I) {
            C4161g gVar = this.f37972G;
            gVar.n0(jVar2);
            int i12 = i11 | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE;
            if (this.f37980z && ((long) jVar2.f38317f.length) >= this.f37971F) {
                a aVar = this.f37975J;
                if (aVar == null) {
                    aVar = new a(this.f37970E);
                    this.f37975J = aVar;
                }
                C4161g gVar2 = aVar.f37910i;
                if (gVar2.f38306i == 0) {
                    if (aVar.f37909f) {
                        aVar.f37911z.reset();
                    }
                    long j10 = gVar.f38306i;
                    C4165k kVar = aVar.f37908E;
                    kVar.t(gVar, j10);
                    kVar.flush();
                    C4164j jVar3 = b.f37912a;
                    if (gVar2.w(gVar2.f38306i - ((long) jVar3.f38317f.length), jVar3)) {
                        long j11 = gVar2.f38306i - ((long) 4);
                        C4161g.a p10 = gVar2.p(C4156b.f38291a);
                        try {
                            p10.b(j11);
                            p10.close();
                        } catch (Throwable th2) {
                            o.k(p10, th);
                            throw th2;
                        }
                    } else {
                        gVar2.u0(0);
                    }
                    gVar.t(gVar2, gVar2.f38306i);
                    i12 = i11 | 192;
                } else {
                    throw new IllegalArgumentException("Failed requirement.");
                }
            }
            long j12 = gVar.f38306i;
            C4161g gVar3 = this.f37973H;
            gVar3.u0(i12);
            if (j12 <= 125) {
                gVar3.u0(((int) j12) | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
            } else if (j12 <= 65535) {
                gVar3.u0(254);
                gVar3.E0((int) j12);
            } else {
                gVar3.u0(255);
                G e0 = gVar3.e0(8);
                int i13 = e0.f38271c;
                byte[] bArr = e0.f38269a;
                bArr[i13] = (byte) ((int) ((j12 >>> 56) & 255));
                bArr[i13 + 1] = (byte) ((int) ((j12 >>> 48) & 255));
                bArr[i13 + 2] = (byte) ((int) ((j12 >>> 40) & 255));
                bArr[i13 + 3] = (byte) ((int) ((j12 >>> 32) & 255));
                bArr[i13 + 4] = (byte) ((int) ((j12 >>> 24) & 255));
                bArr[i13 + 5] = (byte) ((int) ((j12 >>> 16) & 255));
                bArr[i13 + 6] = (byte) ((int) ((j12 >>> 8) & 255));
                bArr[i13 + 7] = (byte) ((int) (j12 & 255));
                e0.f38271c = i13 + 8;
                gVar3.f38306i += 8;
            }
            byte[] bArr2 = this.f37976K;
            l.c(bArr2);
            this.f37979i.nextBytes(bArr2);
            gVar3.write(bArr2);
            if (j12 > 0) {
                C4161g.a aVar2 = this.f37977L;
                l.c(aVar2);
                gVar.p(aVar2);
                aVar2.d(0);
                b.x(aVar2, bArr2);
                aVar2.close();
            }
            gVar3.t(gVar, j12);
            E e10 = this.f37978f;
            if (!e10.f38263z) {
                C4161g gVar4 = e10.f38262i;
                long j13 = gVar4.f38306i;
                if (j13 > 0) {
                    e10.f38261f.t(gVar4, j13);
                    return;
                }
                return;
            }
            throw new IllegalStateException("closed");
        }
        throw new IOException("closed");
    }
}
