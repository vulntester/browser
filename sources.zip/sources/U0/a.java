package U0;

import Q6.C0996q;
import android.text.SegmentFinder;

public final class a extends SegmentFinder {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0996q f10450a;

    public a(C0996q qVar) {
        this.f10450a = qVar;
    }

    public final int nextEndBoundary(int i10) {
        return this.f10450a.M(i10);
    }

    public final int nextStartBoundary(int i10) {
        return this.f10450a.z(i10);
    }

    public final int previousEndBoundary(int i10) {
        return this.f10450a.D(i10);
    }

    public final int previousStartBoundary(int i10) {
        return this.f10450a.L(i10);
    }
}
