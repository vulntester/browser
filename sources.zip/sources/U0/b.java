package U0;

import C7.a;
import android.text.TextPaint;

public final class b extends a {

    /* renamed from: i  reason: collision with root package name */
    public final CharSequence f10451i;

    /* renamed from: z  reason: collision with root package name */
    public final TextPaint f10452z;

    public b(CharSequence charSequence, TextPaint textPaint) {
        this.f10451i = charSequence;
        this.f10452z = textPaint;
    }

    public final int i0(int i10) {
        CharSequence charSequence = this.f10451i;
        return this.f10452z.getTextRunCursor(charSequence, 0, charSequence.length(), false, i10, 0);
    }

    public final int n0(int i10) {
        CharSequence charSequence = this.f10451i;
        return this.f10452z.getTextRunCursor(charSequence, 0, charSequence.length(), false, i10, 2);
    }
}
