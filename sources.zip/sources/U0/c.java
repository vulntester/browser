package U0;

import C7.a;
import java.text.BreakIterator;

public final class c extends a {

    /* renamed from: i  reason: collision with root package name */
    public final BreakIterator f10453i;

    public c(CharSequence charSequence) {
        BreakIterator characterInstance = BreakIterator.getCharacterInstance();
        characterInstance.setText(charSequence.toString());
        this.f10453i = characterInstance;
    }

    public final int i0(int i10) {
        return this.f10453i.following(i10);
    }

    public final int n0(int i10) {
        return this.f10453i.preceding(i10);
    }
}
