package U0;

public interface d {
    int D(int i10);

    int L(int i10);

    int M(int i10);

    int z(int i10);
}
