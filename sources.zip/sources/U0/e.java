package U0;

import H0.C0708z;
import androidx.emoji2.text.c;
import java.lang.Character;
import java.text.BreakIterator;
import java.util.Locale;
import kotlin.jvm.internal.l;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public final CharSequence f10454a;

    /* renamed from: b  reason: collision with root package name */
    public final int f10455b;

    /* renamed from: c  reason: collision with root package name */
    public final int f10456c;

    /* renamed from: d  reason: collision with root package name */
    public final BreakIterator f10457d;

    public static final class a {
        public static boolean a(int i10) {
            int type = Character.getType(i10);
            if (type == 23 || type == 20 || type == 22 || type == 30 || type == 29 || type == 24 || type == 21) {
                return true;
            }
            return false;
        }
    }

    public e(CharSequence charSequence, int i10, Locale locale) {
        this.f10454a = charSequence;
        if (charSequence.length() < 0) {
            Y0.a.a("input start index is outside the CharSequence");
        }
        if (i10 < 0 || i10 > charSequence.length()) {
            Y0.a.a("input end index is outside the CharSequence");
        }
        BreakIterator wordInstance = BreakIterator.getWordInstance(locale);
        this.f10457d = wordInstance;
        this.f10455b = Math.max(0, -50);
        this.f10456c = Math.min(charSequence.length(), i10 + 50);
        wordInstance.setText(new T0.e(charSequence, i10));
    }

    public final void a(int i10) {
        boolean z10 = false;
        int i11 = this.f10455b;
        int i12 = this.f10456c;
        if (i10 <= i12 && i11 <= i10) {
            z10 = true;
        }
        if (!z10) {
            StringBuilder m10 = C0708z.m(i10, i11, "Invalid offset: ", ". Valid range is [", " , ");
            m10.append(i12);
            m10.append(']');
            Y0.a.a(m10.toString());
        }
    }

    public final boolean b(int i10) {
        int i11 = this.f10455b + 1;
        if (i10 > this.f10456c || i11 > i10) {
            return false;
        }
        CharSequence charSequence = this.f10454a;
        if (!Character.isLetterOrDigit(Character.codePointBefore(charSequence, i10))) {
            int i12 = i10 - 1;
            if (!Character.isSurrogate(charSequence.charAt(i12))) {
                if (!c.d()) {
                    return false;
                }
                c a10 = c.a();
                if (a10.c() != 1 || a10.b(charSequence, i12) == -1) {
                    return false;
                }
            }
        }
        return true;
    }

    public final boolean c(int i10) {
        int i11 = this.f10455b + 1;
        if (i10 > this.f10456c || i11 > i10) {
            return false;
        }
        return a.a(Character.codePointBefore(this.f10454a, i10));
    }

    public final boolean d(int i10) {
        a(i10);
        if (!this.f10457d.isBoundary(i10)) {
            return false;
        }
        if (f(i10) && f(i10 - 1) && f(i10 + 1)) {
            return false;
        }
        if (i10 <= 0 || i10 >= this.f10454a.length() - 1 || (!e(i10) && !e(i10 + 1))) {
            return true;
        }
        return false;
    }

    public final boolean e(int i10) {
        int i11 = i10 - 1;
        CharSequence charSequence = this.f10454a;
        Character.UnicodeBlock of = Character.UnicodeBlock.of(charSequence.charAt(i11));
        Character.UnicodeBlock unicodeBlock = Character.UnicodeBlock.HIRAGANA;
        if (l.a(of, unicodeBlock) && l.a(Character.UnicodeBlock.of(charSequence.charAt(i10)), Character.UnicodeBlock.KATAKANA)) {
            return true;
        }
        if (!l.a(Character.UnicodeBlock.of(charSequence.charAt(i10)), unicodeBlock) || !l.a(Character.UnicodeBlock.of(charSequence.charAt(i11)), Character.UnicodeBlock.KATAKANA)) {
            return false;
        }
        return true;
    }

    public final boolean f(int i10) {
        if (i10 >= this.f10456c || this.f10455b > i10) {
            return false;
        }
        CharSequence charSequence = this.f10454a;
        if (!Character.isLetterOrDigit(Character.codePointAt(charSequence, i10)) && !Character.isSurrogate(charSequence.charAt(i10))) {
            if (!c.d()) {
                return false;
            }
            c a10 = c.a();
            if (a10.c() != 1 || a10.b(charSequence, i10) == -1) {
                return false;
            }
        }
        return true;
    }

    public final boolean g(int i10) {
        if (i10 >= this.f10456c || this.f10455b > i10) {
            return false;
        }
        return a.a(Character.codePointAt(this.f10454a, i10));
    }

    public final int h(int i10) {
        a(i10);
        int following = this.f10457d.following(i10);
        if (!f(following - 1) || !f(following) || e(following)) {
            return following;
        }
        return h(following);
    }

    public final int i(int i10) {
        a(i10);
        int preceding = this.f10457d.preceding(i10);
        if (!f(preceding) || !b(preceding) || e(preceding)) {
            return preceding;
        }
        return i(preceding);
    }
}
