package U1;

public final class a extends c {
    public a() {
        super(0);
    }
}
