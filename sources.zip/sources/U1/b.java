package U1;

public final class b extends c {
}
