package U1;

import C0.e;
import f7.M;
import io.netty.handler.codec.http.HttpObjectDecoder;
import java.nio.ByteBuffer;
import o2.C2756B;
import o2.t;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public int f10458a;

    /* renamed from: b  reason: collision with root package name */
    public int f10459b;

    /* renamed from: c  reason: collision with root package name */
    public int f10460c;

    /* renamed from: d  reason: collision with root package name */
    public Object f10461d;

    public c(int i10) {
        switch (i10) {
            case 1:
                this.f10461d = C2756B.f25813c;
                return;
            default:
                if (e.f1123i == null) {
                    e.f1123i = new e(6);
                    return;
                }
                return;
        }
    }

    public int a(int i10) {
        if (i10 < this.f10460c) {
            return ((ByteBuffer) this.f10461d).getShort(this.f10459b + i10);
        }
        return 0;
    }

    public void b() {
        boolean z10;
        int i10;
        int i11 = this.f10458a;
        if (i11 < 0 || (i11 >= (i10 = this.f10460c) && !(i11 == i10 && this.f10459b == 0))) {
            z10 = false;
        } else {
            z10 = true;
        }
        M.m(z10);
    }

    public int c() {
        return ((this.f10460c - this.f10458a) * 8) - this.f10459b;
    }

    public void d() {
        if (this.f10459b != 0) {
            this.f10459b = 0;
            this.f10458a++;
            b();
        }
    }

    public int e() {
        boolean z10;
        if (this.f10459b == 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.m(z10);
        return this.f10458a;
    }

    public int f() {
        return (this.f10458a * 8) + this.f10459b;
    }

    public boolean g() {
        boolean z10;
        if ((((byte[]) this.f10461d)[this.f10458a] & (HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE >> this.f10459b)) != 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        o();
        return z10;
    }

    public int h(int i10) {
        int i11;
        if (i10 == 0) {
            return 0;
        }
        this.f10459b += i10;
        int i12 = 0;
        while (true) {
            i11 = this.f10459b;
            if (i11 <= 8) {
                break;
            }
            int i13 = i11 - 8;
            this.f10459b = i13;
            int i14 = this.f10458a;
            this.f10458a = i14 + 1;
            i12 |= (((byte[]) this.f10461d)[i14] & 255) << i13;
        }
        int i15 = this.f10458a;
        int i16 = (-1 >>> (32 - i10)) & (i12 | ((((byte[]) this.f10461d)[i15] & 255) >> (8 - i11)));
        if (i11 == 8) {
            this.f10459b = 0;
            this.f10458a = i15 + 1;
        }
        b();
        return i16;
    }

    public void i(int i10, byte[] bArr) {
        int i11 = i10 >> 3;
        for (int i12 = 0; i12 < i11; i12++) {
            byte[] bArr2 = (byte[]) this.f10461d;
            int i13 = this.f10458a;
            int i14 = i13 + 1;
            this.f10458a = i14;
            byte b10 = bArr2[i13];
            int i15 = this.f10459b;
            byte b11 = (byte) (b10 << i15);
            bArr[i12] = b11;
            bArr[i12] = (byte) (((255 & bArr2[i14]) >> (8 - i15)) | b11);
        }
        int i16 = i10 & 7;
        if (i16 != 0) {
            byte b12 = (byte) (bArr[i11] & (255 >> i16));
            bArr[i11] = b12;
            int i17 = this.f10459b;
            if (i17 + i16 > 8) {
                int i18 = this.f10458a;
                this.f10458a = i18 + 1;
                bArr[i11] = (byte) (b12 | ((((byte[]) this.f10461d)[i18] & 255) << i17));
                this.f10459b = i17 - 8;
            }
            int i19 = this.f10459b + i16;
            this.f10459b = i19;
            int i20 = this.f10458a;
            bArr[i11] = (byte) (((byte) (((255 & ((byte[]) this.f10461d)[i20]) >> (8 - i19)) << (8 - i16))) | bArr[i11]);
            if (i19 == 8) {
                this.f10459b = 0;
                this.f10458a = i20 + 1;
            }
            b();
        }
    }

    public long j(int i10) {
        if (i10 <= 32) {
            int h10 = h(i10);
            int i11 = C2756B.f25811a;
            return 4294967295L & ((long) h10);
        }
        int h11 = h(i10 - 32);
        int h12 = h(32);
        int i12 = C2756B.f25811a;
        return (4294967295L & ((long) h12)) | ((((long) h11) & 4294967295L) << 32);
    }

    public void k(int i10, byte[] bArr) {
        boolean z10;
        if (this.f10459b == 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.m(z10);
        System.arraycopy((byte[]) this.f10461d, this.f10458a, bArr, 0, i10);
        this.f10458a += i10;
        b();
    }

    public void l(int i10, byte[] bArr) {
        this.f10461d = bArr;
        this.f10458a = 0;
        this.f10459b = 0;
        this.f10460c = i10;
    }

    public void m(t tVar) {
        l(tVar.f25887c, tVar.f25885a);
        n(tVar.f25886b * 8);
    }

    public void n(int i10) {
        int i11 = i10 / 8;
        this.f10458a = i11;
        this.f10459b = i10 - (i11 * 8);
        b();
    }

    public void o() {
        int i10 = this.f10459b + 1;
        this.f10459b = i10;
        if (i10 == 8) {
            this.f10459b = 0;
            this.f10458a++;
        }
        b();
    }

    public void p(int i10) {
        int i11 = i10 / 8;
        int i12 = this.f10458a + i11;
        this.f10458a = i12;
        int i13 = (i10 - (i11 * 8)) + this.f10459b;
        this.f10459b = i13;
        if (i13 > 7) {
            this.f10458a = i12 + 1;
            this.f10459b = i13 - 8;
        }
        b();
    }

    public void q(int i10) {
        boolean z10;
        if (this.f10459b == 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.m(z10);
        this.f10458a += i10;
        b();
    }

    public c(byte[] bArr, int i10) {
        this.f10461d = bArr;
        this.f10460c = i10;
    }
}
