package U6;

public interface b<T, U> {
    void accept(T t10, U u7);
}
