package U6;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public static final c f10509a = new Object();

    public final long a() {
        return System.currentTimeMillis();
    }
}
