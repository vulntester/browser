package U6;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static Boolean f10510a;

    /* renamed from: b  reason: collision with root package name */
    public static Boolean f10511b;

    /* renamed from: c  reason: collision with root package name */
    public static Boolean f10512c;

    /* renamed from: d  reason: collision with root package name */
    public static Boolean f10513d;

    @TargetApi(26)
    public static boolean a(Context context) {
        PackageManager packageManager = context.getPackageManager();
        if (f10510a == null) {
            f10510a = Boolean.valueOf(packageManager.hasSystemFeature("android.hardware.type.watch"));
        }
        if (f10510a.booleanValue() && Build.VERSION.SDK_INT < 24) {
            return true;
        }
        if (f10511b == null) {
            f10511b = Boolean.valueOf(context.getPackageManager().hasSystemFeature("cn.google"));
        }
        if (!f10511b.booleanValue()) {
            return false;
        }
        if (!g.a() || Build.VERSION.SDK_INT >= 30) {
            return true;
        }
        return false;
    }
}
