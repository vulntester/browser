package U6;

public final class h {

    /* renamed from: a  reason: collision with root package name */
    public static String f10516a;

    /* renamed from: b  reason: collision with root package name */
    public static int f10517b;

    /* renamed from: c  reason: collision with root package name */
    public static Boolean f10518c;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: java.lang.String} */
    /* JADX WARNING: type inference failed for: r2v1 */
    /* JADX WARNING: type inference failed for: r2v3, types: [java.io.Closeable] */
    /* JADX WARNING: type inference failed for: r2v4 */
    /* JADX WARNING: type inference failed for: r2v5 */
    /* JADX WARNING: type inference failed for: r2v7 */
    /* JADX WARNING: type inference failed for: r2v8 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String a() {
        /*
            java.lang.String r0 = "/proc/"
            java.lang.String r1 = f10516a
            if (r1 != 0) goto L_0x0064
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 28
            if (r1 < r2) goto L_0x0013
            java.lang.String r0 = android.app.Application.getProcessName()
            f10516a = r0
            goto L_0x0064
        L_0x0013:
            int r1 = f10517b
            if (r1 != 0) goto L_0x001d
            int r1 = android.os.Process.myPid()
            f10517b = r1
        L_0x001d:
            r2 = 0
            if (r1 > 0) goto L_0x0021
            goto L_0x0062
        L_0x0021:
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            r3.<init>(r0)     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            r3.append(r1)     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            java.lang.String r0 = "/cmdline"
            r3.append(r0)     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            java.lang.String r0 = r3.toString()     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            android.os.StrictMode$ThreadPolicy r1 = android.os.StrictMode.allowThreadDiskReads()     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            java.io.BufferedReader r3 = new java.io.BufferedReader     // Catch:{ all -> 0x0057 }
            java.io.FileReader r4 = new java.io.FileReader     // Catch:{ all -> 0x0057 }
            r4.<init>(r0)     // Catch:{ all -> 0x0057 }
            r3.<init>(r4)     // Catch:{ all -> 0x0057 }
            android.os.StrictMode.setThreadPolicy(r1)     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            java.lang.String r0 = r3.readLine()     // Catch:{ IOException -> 0x004e, all -> 0x0052 }
            com.google.android.gms.common.internal.C1438n.g(r0)     // Catch:{ IOException -> 0x004e, all -> 0x0052 }
            java.lang.String r2 = r0.trim()     // Catch:{ IOException -> 0x004e, all -> 0x0052 }
        L_0x004e:
            U6.f.a(r3)
            goto L_0x0062
        L_0x0052:
            r0 = move-exception
            r2 = r3
            goto L_0x005c
        L_0x0055:
            r0 = move-exception
            goto L_0x005c
        L_0x0057:
            r0 = move-exception
            android.os.StrictMode.setThreadPolicy(r1)     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
            throw r0     // Catch:{ IOException -> 0x0060, all -> 0x0055 }
        L_0x005c:
            U6.f.a(r2)
            throw r0
        L_0x0060:
            r3 = r2
            goto L_0x004e
        L_0x0062:
            f10516a = r2
        L_0x0064:
            java.lang.String r0 = f10516a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: U6.h.a():java.lang.String");
    }
}
