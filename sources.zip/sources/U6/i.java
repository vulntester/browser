package U6;

import java.util.regex.Pattern;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f10519a = 0;

    static {
        Pattern.compile("\\$\\{(.*?)\\}");
    }
}
