package U7;

import java.math.BigInteger;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int f10520a = 0;

    static {
        new BigInteger("16a09e667f3bcc908b2fb1366ea957d3e3adec17512775099da2f590b0667322a", 16);
        Math.log(10.0d);
        Math.log(2.0d);
    }
}
