package U8;

import P2.x;
import W8.i;
import X8.e;
import android.annotation.SuppressLint;
import android.os.Process;
import android.system.Os;
import android.system.OsConstants;
import io.ktor.sse.ServerSentEventKt;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class a {

    /* renamed from: g  reason: collision with root package name */
    public static final P8.a f38156g = P8.a.d();

    /* renamed from: h  reason: collision with root package name */
    public static final long f38157h = TimeUnit.SECONDS.toMicros(1);

    /* renamed from: a  reason: collision with root package name */
    public final ConcurrentLinkedQueue<e> f38158a = new ConcurrentLinkedQueue<>();

    /* renamed from: b  reason: collision with root package name */
    public final ScheduledExecutorService f38159b = Executors.newSingleThreadScheduledExecutor();

    /* renamed from: c  reason: collision with root package name */
    public final String f38160c;

    /* renamed from: d  reason: collision with root package name */
    public final long f38161d;

    /* renamed from: e  reason: collision with root package name */
    public ScheduledFuture f38162e = null;

    /* renamed from: f  reason: collision with root package name */
    public long f38163f = -1;

    @SuppressLint({"ThreadPoolCreation"})
    public a() {
        int myPid = Process.myPid();
        this.f38160c = "/proc/" + Integer.toString(myPid) + "/stat";
        this.f38161d = Os.sysconf(OsConstants._SC_CLK_TCK);
    }

    public final synchronized void a(long j10, i iVar) {
        try {
            this.f38163f = j10;
            this.f38162e = this.f38159b.scheduleAtFixedRate(new x(1, this, iVar), 0, j10, TimeUnit.MILLISECONDS);
        } catch (RejectedExecutionException e10) {
            RejectedExecutionException rejectedExecutionException = e10;
            P8.a aVar = f38156g;
            aVar.f("Unable to start collecting Cpu Metrics: " + rejectedExecutionException.getMessage());
        } catch (Throwable th) {
            while (true) {
                throw th;
            }
        }
    }

    public final e b(i iVar) {
        BufferedReader bufferedReader;
        Throwable th;
        i iVar2 = iVar;
        long j10 = this.f38161d;
        P8.a aVar = f38156g;
        if (iVar2 == null) {
            return null;
        }
        try {
            bufferedReader = new BufferedReader(new FileReader(this.f38160c));
            long a10 = iVar2.a() + iVar2.f38550f;
            String[] split = bufferedReader.readLine().split(ServerSentEventKt.SPACE);
            long parseLong = Long.parseLong(split[13]);
            long parseLong2 = Long.parseLong(split[15]);
            long parseLong3 = Long.parseLong(split[14]);
            long parseLong4 = Long.parseLong(split[16]);
            e.a I10 = e.I();
            I10.q();
            e.F((e) I10.f40037i, a10);
            double d10 = ((double) (parseLong3 + parseLong4)) / ((double) j10);
            long j11 = f38157h;
            long round = Math.round(d10 * ((double) j11));
            I10.q();
            e.H((e) I10.f40037i, round);
            long round2 = Math.round((((double) (parseLong + parseLong2)) / ((double) j10)) * ((double) j11));
            I10.q();
            e.G((e) I10.f40037i, round2);
            e eVar = (e) I10.Q();
            bufferedReader.close();
            return eVar;
        } catch (IOException e10) {
            aVar.f("Unable to read 'proc/[pid]/stat' file: " + e10.getMessage());
            return null;
        } catch (ArrayIndexOutOfBoundsException | NullPointerException | NumberFormatException e11) {
            aVar.f("Unexpected '/proc/[pid]/stat' file format encountered: " + e11.getMessage());
            return null;
        } catch (Throwable th2) {
            th.addSuppressed(th2);
        }
        throw th;
    }
}
