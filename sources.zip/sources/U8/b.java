package U8;

import I2.C0805u;
import I2.C0807w;
import X8.d;
import android.util.Pair;
import androidx.media3.exoplayer.i;
import com.google.firebase.perf.session.gauges.GaugeManager;
import u2.C3198a;

public final /* synthetic */ class b implements Runnable {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ Object f38164E;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f38165f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ Object f38166i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ Object f38167z;

    public /* synthetic */ b(Object obj, Object obj2, Object obj3, int i10) {
        this.f38165f = i10;
        this.f38166i = obj;
        this.f38167z = obj2;
        this.f38164E = obj3;
    }

    public final void run() {
        switch (this.f38165f) {
            case 0:
                ((GaugeManager) this.f38166i).lambda$startCollectingGauges$2((String) this.f38167z, (d) this.f38164E);
                return;
            default:
                C3198a aVar = i.this.f15333h;
                Pair pair = (Pair) this.f38167z;
                aVar.d0(((Integer) pair.first).intValue(), (C0807w.b) pair.second, (C0805u) this.f38164E);
                return;
        }
    }
}
