package U8;

import E8.C3895b;
import java.util.concurrent.Executors;

public final /* synthetic */ class c implements C3895b {
    public final Object get() {
        return Executors.newSingleThreadScheduledExecutor();
    }
}
