package U8;

import E8.C3895b;
import Z8.o;
import com.google.firebase.perf.session.gauges.GaugeManager;
import java.util.Random;

public final /* synthetic */ class d implements C3895b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f38168a;

    public /* synthetic */ d(int i10) {
        this.f38168a = i10;
    }

    public final Object get() {
        switch (this.f38168a) {
            case 0:
                return GaugeManager.lambda$new$0();
            case 1:
                Random random = o.f38949j;
                return null;
            default:
                return null;
        }
    }
}
