package U8;

import E8.C3895b;
import android.os.Build;
import android.os.StrictMode;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.perf.session.gauges.GaugeManager;
import g8.o;
import h8.b;
import h8.h;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public final /* synthetic */ class e implements C3895b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f38169a;

    public /* synthetic */ e(int i10) {
        this.f38169a = i10;
    }

    public final Object get() {
        switch (this.f38169a) {
            case 0:
                return GaugeManager.lambda$new$1();
            default:
                o<ScheduledExecutorService> oVar = ExecutorsRegistrar.f20059a;
                StrictMode.ThreadPolicy.Builder detectNetwork = new StrictMode.ThreadPolicy.Builder().detectNetwork();
                int i10 = Build.VERSION.SDK_INT;
                detectNetwork.detectResourceMismatches();
                if (i10 >= 26) {
                    detectNetwork.detectUnbufferedIo();
                }
                return new h(Executors.newFixedThreadPool(4, new b("Firebase Background", 10, detectNetwork.penaltyLog().build())), ExecutorsRegistrar.f20062d.get());
        }
    }
}
