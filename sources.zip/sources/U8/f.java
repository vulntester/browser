package U8;

import P8.a;
import android.app.ActivityManager;
import android.content.Context;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final Runtime f38170a = Runtime.getRuntime();

    /* renamed from: b  reason: collision with root package name */
    public final ActivityManager f38171b;

    /* renamed from: c  reason: collision with root package name */
    public final ActivityManager.MemoryInfo f38172c;

    static {
        a.d();
    }

    public f(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        this.f38171b = activityManager;
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        this.f38172c = memoryInfo;
        activityManager.getMemoryInfo(memoryInfo);
    }
}
