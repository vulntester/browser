package U8;

import W8.i;
import X8.b;
import androidx.media3.exoplayer.d;
import o2.C2756B;

public final /* synthetic */ class g implements Runnable {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f38173f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ Object f38174i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ Object f38175z;

    public /* synthetic */ g(int i10, Object obj, Object obj2) {
        this.f38173f = i10;
        this.f38174i = obj;
        this.f38175z = obj2;
    }

    public final void run() {
        Object obj = this.f38175z;
        Object obj2 = this.f38174i;
        switch (this.f38173f) {
            case 0:
                h hVar = (h) obj2;
                b c10 = hVar.c((i) obj);
                if (c10 != null) {
                    hVar.f38178b.add(c10);
                    return;
                }
                return;
            default:
                v2.i iVar = (v2.i) obj2;
                iVar.getClass();
                int i10 = C2756B.f25811a;
                d.this.f15053s.P((Exception) obj);
                return;
        }
    }
}
