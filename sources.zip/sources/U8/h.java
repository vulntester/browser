package U8;

import A2.c;
import P8.a;
import W8.i;
import W8.j;
import X8.b;
import android.annotation.SuppressLint;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class h {

    /* renamed from: f  reason: collision with root package name */
    public static final a f38176f = a.d();

    /* renamed from: a  reason: collision with root package name */
    public final ScheduledExecutorService f38177a;

    /* renamed from: b  reason: collision with root package name */
    public final ConcurrentLinkedQueue<b> f38178b;

    /* renamed from: c  reason: collision with root package name */
    public final Runtime f38179c;

    /* renamed from: d  reason: collision with root package name */
    public ScheduledFuture f38180d = null;

    /* renamed from: e  reason: collision with root package name */
    public long f38181e = -1;

    @SuppressLint({"ThreadPoolCreation"})
    public h() {
        ScheduledExecutorService newSingleThreadScheduledExecutor = Executors.newSingleThreadScheduledExecutor();
        Runtime runtime = Runtime.getRuntime();
        this.f38177a = newSingleThreadScheduledExecutor;
        this.f38178b = new ConcurrentLinkedQueue<>();
        this.f38179c = runtime;
    }

    public final void a(i iVar) {
        synchronized (this) {
            try {
                this.f38177a.schedule(new c(3, this, iVar), 0, TimeUnit.MILLISECONDS);
            } catch (RejectedExecutionException e10) {
                a aVar = f38176f;
                aVar.f("Unable to collect Memory Metric: " + e10.getMessage());
            }
        }
    }

    public final synchronized void b(long j10, i iVar) {
        try {
            this.f38181e = j10;
            this.f38180d = this.f38177a.scheduleAtFixedRate(new g(0, this, iVar), 0, j10, TimeUnit.MILLISECONDS);
        } catch (RejectedExecutionException e10) {
            RejectedExecutionException rejectedExecutionException = e10;
            a aVar = f38176f;
            aVar.f("Unable to start collecting Memory Metrics: " + rejectedExecutionException.getMessage());
        } catch (Throwable th) {
            while (true) {
                throw th;
            }
        }
    }

    public final b c(i iVar) {
        if (iVar == null) {
            return null;
        }
        long a10 = iVar.a() + iVar.f38550f;
        b.a H10 = b.H();
        H10.q();
        b.F((b) H10.f40037i, a10);
        Runtime runtime = this.f38179c;
        int b10 = j.b((runtime.totalMemory() - runtime.freeMemory()) / 1024);
        H10.q();
        b.G((b) H10.f40037i, b10);
        return (b) H10.Q();
    }
}
