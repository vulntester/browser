package U9;

import Na.l;
import Na.p;
import V.C1169i;
import V6.b;
import com.common.videofinder.VideoRecommendation;
import gc.e;
import ic.G;
import r6.J;
import xa.C4959D;

public final /* synthetic */ class a implements p {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ Object f38182E;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f38183f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ Object f38184i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ Object f38185z;

    public /* synthetic */ a(Object obj, Object obj2, Object obj3, int i10, int i11) {
        this.f38183f = i11;
        this.f38184i = obj;
        this.f38185z = obj2;
        this.f38182E = obj3;
    }

    public final Object invoke(Object obj, Object obj2) {
        int i10 = this.f38183f;
        C1169i iVar = (C1169i) obj;
        ((Integer) obj2).getClass();
        switch (i10) {
            case 0:
                int v10 = b.v(65);
                G.a((com.internet.tvbrowser.p) this.f38184i, (F5.a) this.f38185z, (String) this.f38182E, iVar, v10);
                return C4959D.f44058a;
            case 1:
                int v11 = b.v(1);
                J.a((VideoRecommendation) this.f38184i, (l) this.f38185z, (Na.a) this.f38182E, iVar, v11);
                return C4959D.f44058a;
            default:
                int v12 = b.v(1);
                e.a((Na.a) this.f38184i, (Na.a) this.f38185z, (Na.a) this.f38182E, iVar, v12);
                return C4959D.f44058a;
        }
    }
}
