package V0;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

public final class a extends MetricAffectingSpan {

    /* renamed from: a  reason: collision with root package name */
    public final float f10928a;

    public a(float f10) {
        this.f10928a = f10;
    }

    public final void updateDrawState(TextPaint textPaint) {
        textPaint.baselineShift += (int) ((float) Math.ceil((double) (textPaint.ascent() * this.f10928a)));
    }

    public final void updateMeasureState(TextPaint textPaint) {
        textPaint.baselineShift += (int) ((float) Math.ceil((double) (textPaint.ascent() * this.f10928a)));
    }
}
