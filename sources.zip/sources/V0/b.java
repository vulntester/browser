package V0;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

public final class b extends MetricAffectingSpan {

    /* renamed from: a  reason: collision with root package name */
    public final String f10929a;

    public b(String str) {
        this.f10929a = str;
    }

    public final void updateDrawState(TextPaint textPaint) {
        textPaint.setFontFeatureSettings(this.f10929a);
    }

    public final void updateMeasureState(TextPaint textPaint) {
        textPaint.setFontFeatureSettings(this.f10929a);
    }
}
