package V0;

import T0.s;
import T0.v;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Layout;
import android.text.style.LeadingMarginSpan;
import kotlin.jvm.internal.l;

public final class c implements LeadingMarginSpan {
    public final void drawLeadingMargin(Canvas canvas, Paint paint, int i10, int i11, int i12, int i13, int i14, CharSequence charSequence, int i15, int i16, boolean z10, Layout layout) {
        int lineForOffset;
        if (layout != null && paint != null && (lineForOffset = layout.getLineForOffset(i15)) == layout.getLineCount() - 1) {
            s sVar = v.f9998a;
            if (layout.getEllipsisCount(lineForOffset) > 0) {
                float b10 = d.b(layout, lineForOffset, paint) + d.a(layout, lineForOffset, paint);
                if (b10 != 0.0f) {
                    l.c(canvas);
                    canvas.translate(b10, 0.0f);
                }
            }
        }
    }

    public final int getLeadingMargin(boolean z10) {
        return 0;
    }
}
