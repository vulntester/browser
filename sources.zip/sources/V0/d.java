package V0;

import T0.s;
import T0.v;
import android.graphics.Paint;
import android.text.Layout;

public final class d {

    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f10930a;

        static {
            int[] iArr = new int[Layout.Alignment.values().length];
            try {
                iArr[Layout.Alignment.ALIGN_CENTER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            f10930a = iArr;
        }
    }

    public static final float a(Layout layout, int i10, Paint paint) {
        int i11;
        float abs;
        float width;
        float lineLeft = layout.getLineLeft(i10);
        s sVar = v.f9998a;
        if (layout.getEllipsisCount(i10) <= 0 || layout.getParagraphDirection(i10) != 1 || lineLeft >= 0.0f) {
            return 0.0f;
        }
        int lineStart = layout.getLineStart(i10);
        float measureText = paint.measureText("…") + (layout.getPrimaryHorizontal(layout.getEllipsisStart(i10) + lineStart) - lineLeft);
        Layout.Alignment paragraphAlignment = layout.getParagraphAlignment(i10);
        if (paragraphAlignment == null) {
            i11 = -1;
        } else {
            i11 = a.f10930a[paragraphAlignment.ordinal()];
        }
        if (i11 == 1) {
            abs = Math.abs(lineLeft);
            width = (((float) layout.getWidth()) - measureText) / 2.0f;
        } else {
            abs = Math.abs(lineLeft);
            width = ((float) layout.getWidth()) - measureText;
        }
        return width + abs;
    }

    public static final float b(Layout layout, int i10, Paint paint) {
        float width;
        float width2;
        s sVar = v.f9998a;
        if (layout.getEllipsisCount(i10) <= 0) {
            return 0.0f;
        }
        int i11 = -1;
        if (layout.getParagraphDirection(i10) != -1 || ((float) layout.getWidth()) >= layout.getLineRight(i10)) {
            return 0.0f;
        }
        float primaryHorizontal = layout.getPrimaryHorizontal(layout.getEllipsisStart(i10) + layout.getLineStart(i10));
        float measureText = paint.measureText("…") + (layout.getLineRight(i10) - primaryHorizontal);
        Layout.Alignment paragraphAlignment = layout.getParagraphAlignment(i10);
        if (paragraphAlignment != null) {
            i11 = a.f10930a[paragraphAlignment.ordinal()];
        }
        if (i11 == 1) {
            width = ((float) layout.getWidth()) - layout.getLineRight(i10);
            width2 = (((float) layout.getWidth()) - measureText) / 2.0f;
        } else {
            width = ((float) layout.getWidth()) - layout.getLineRight(i10);
            width2 = ((float) layout.getWidth()) - measureText;
        }
        return width - width2;
    }
}
