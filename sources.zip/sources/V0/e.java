package V0;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

public final class e extends MetricAffectingSpan {

    /* renamed from: a  reason: collision with root package name */
    public final float f10931a;

    public e(float f10) {
        this.f10931a = f10;
    }

    public final void updateDrawState(TextPaint textPaint) {
        textPaint.setLetterSpacing(this.f10931a);
    }

    public final void updateMeasureState(TextPaint textPaint) {
        textPaint.setLetterSpacing(this.f10931a);
    }
}
