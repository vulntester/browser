package V0;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

public final class f extends MetricAffectingSpan {

    /* renamed from: a  reason: collision with root package name */
    public final float f10932a;

    public f(float f10) {
        this.f10932a = f10;
    }

    public final void updateDrawState(TextPaint textPaint) {
        float textScaleX = textPaint.getTextScaleX() * textPaint.getTextSize();
        if (textScaleX != 0.0f) {
            textPaint.setLetterSpacing(this.f10932a / textScaleX);
        }
    }

    public final void updateMeasureState(TextPaint textPaint) {
        float textScaleX = textPaint.getTextScaleX() * textPaint.getTextSize();
        if (textScaleX != 0.0f) {
            textPaint.setLetterSpacing(this.f10932a / textScaleX);
        }
    }
}
