package V0;

import android.graphics.Paint;
import android.text.style.LineHeightSpan;

public final class g implements LineHeightSpan {

    /* renamed from: a  reason: collision with root package name */
    public final float f10933a;

    public g(float f10) {
        this.f10933a = f10;
    }

    public final void chooseHeight(CharSequence charSequence, int i10, int i11, int i12, int i13, Paint.FontMetricsInt fontMetricsInt) {
        int i14 = fontMetricsInt.descent - fontMetricsInt.ascent;
        if (i14 > 0) {
            int ceil = (int) ((float) Math.ceil((double) this.f10933a));
            int ceil2 = (int) Math.ceil(((double) fontMetricsInt.descent) * ((double) ((((float) ceil) * 1.0f) / ((float) i14))));
            fontMetricsInt.descent = ceil2;
            fontMetricsInt.ascent = ceil2 - ceil;
        }
    }
}
