package V0;

import Y0.a;
import android.graphics.Paint;
import android.text.style.LineHeightSpan;

public final class h implements LineHeightSpan {

    /* renamed from: a  reason: collision with root package name */
    public final float f10934a;

    /* renamed from: b  reason: collision with root package name */
    public final int f10935b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f10936c;

    /* renamed from: d  reason: collision with root package name */
    public final boolean f10937d;

    /* renamed from: e  reason: collision with root package name */
    public final float f10938e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean f10939f;

    /* renamed from: g  reason: collision with root package name */
    public int f10940g = Integer.MIN_VALUE;

    /* renamed from: h  reason: collision with root package name */
    public int f10941h = Integer.MIN_VALUE;

    /* renamed from: i  reason: collision with root package name */
    public int f10942i = Integer.MIN_VALUE;

    /* renamed from: j  reason: collision with root package name */
    public int f10943j = Integer.MIN_VALUE;

    /* renamed from: k  reason: collision with root package name */
    public int f10944k;

    /* renamed from: l  reason: collision with root package name */
    public int f10945l;

    public h(float f10, int i10, boolean z10, boolean z11, float f11, boolean z12) {
        this.f10934a = f10;
        this.f10935b = i10;
        this.f10936c = z10;
        this.f10937d = z11;
        this.f10938e = f11;
        this.f10939f = z12;
        if ((0.0f > f11 || f11 > 1.0f) && f11 != -1.0f) {
            a.b("topRatio should be in [0..1] range or -1");
        }
    }

    public final void chooseHeight(CharSequence charSequence, int i10, int i11, int i12, int i13, Paint.FontMetricsInt fontMetricsInt) {
        boolean z10;
        int i14;
        int i15;
        double ceil;
        int i16 = fontMetricsInt.descent;
        int i17 = fontMetricsInt.ascent;
        if (i16 - i17 > 0) {
            boolean z11 = true;
            if (i10 == 0) {
                z10 = true;
            } else {
                z10 = false;
            }
            if (i11 != this.f10935b) {
                z11 = false;
            }
            boolean z12 = this.f10937d;
            boolean z13 = this.f10936c;
            if (!z10 || !z11 || !z13 || !z12) {
                if (this.f10940g == Integer.MIN_VALUE) {
                    int i18 = i16 - i17;
                    int ceil2 = (int) ((float) Math.ceil((double) this.f10934a));
                    int i19 = ceil2 - i18;
                    if (!this.f10939f || i19 > 0) {
                        float f10 = this.f10938e;
                        if (f10 == -1.0f) {
                            f10 = Math.abs((float) fontMetricsInt.ascent) / ((float) (fontMetricsInt.descent - fontMetricsInt.ascent));
                        }
                        if (i19 <= 0) {
                            ceil = Math.ceil((double) (((float) i19) * f10));
                        } else {
                            ceil = Math.ceil((double) ((1.0f - f10) * ((float) i19)));
                        }
                        int i20 = (int) ((float) ceil);
                        int i21 = fontMetricsInt.descent;
                        int i22 = i20 + i21;
                        this.f10942i = i22;
                        int i23 = i22 - ceil2;
                        this.f10941h = i23;
                        if (z13) {
                            i23 = fontMetricsInt.ascent;
                        }
                        this.f10940g = i23;
                        if (z12) {
                            i22 = i21;
                        }
                        this.f10943j = i22;
                        this.f10944k = fontMetricsInt.ascent - i23;
                        this.f10945l = i22 - i21;
                    } else {
                        int i24 = fontMetricsInt.ascent;
                        this.f10941h = i24;
                        int i25 = fontMetricsInt.descent;
                        this.f10942i = i25;
                        this.f10940g = i24;
                        this.f10943j = i25;
                        this.f10944k = 0;
                        this.f10945l = 0;
                    }
                }
                if (z10) {
                    i14 = this.f10940g;
                } else {
                    i14 = this.f10941h;
                }
                fontMetricsInt.ascent = i14;
                if (z11) {
                    i15 = this.f10943j;
                } else {
                    i15 = this.f10942i;
                }
                fontMetricsInt.descent = i15;
            }
        }
    }
}
