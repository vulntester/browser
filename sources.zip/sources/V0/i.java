package V0;

import Y0.a;
import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.style.ReplacementSpan;
import kotlin.jvm.internal.l;

public final class i extends ReplacementSpan {

    /* renamed from: a  reason: collision with root package name */
    public Paint.FontMetricsInt f10946a;

    /* renamed from: b  reason: collision with root package name */
    public int f10947b;

    /* renamed from: c  reason: collision with root package name */
    public int f10948c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f10949d;

    public final Paint.FontMetricsInt a() {
        Paint.FontMetricsInt fontMetricsInt = this.f10946a;
        if (fontMetricsInt != null) {
            return fontMetricsInt;
        }
        l.m("fontMetrics");
        throw null;
    }

    public final int b() {
        if (!this.f10949d) {
            a.b("PlaceholderSpan is not laid out yet.");
        }
        return this.f10948c;
    }

    @SuppressLint({"DocumentExceptions"})
    public final int getSize(Paint paint, CharSequence charSequence, int i10, int i11, Paint.FontMetricsInt fontMetricsInt) {
        this.f10949d = true;
        paint.getTextSize();
        this.f10946a = paint.getFontMetricsInt();
        if (a().descent <= a().ascent) {
            a.a("Invalid fontMetrics: line height can not be negative.");
        }
        this.f10947b = (int) ((float) Math.ceil((double) 0.0f));
        this.f10948c = (int) ((float) Math.ceil((double) 0.0f));
        if (fontMetricsInt != null) {
            fontMetricsInt.ascent = a().ascent;
            fontMetricsInt.descent = a().descent;
            fontMetricsInt.leading = a().leading;
            if (fontMetricsInt.ascent > (-b())) {
                fontMetricsInt.ascent = -b();
            }
            fontMetricsInt.top = Math.min(a().top, fontMetricsInt.ascent);
            fontMetricsInt.bottom = Math.max(a().bottom, fontMetricsInt.descent);
        }
        if (!this.f10949d) {
            a.b("PlaceholderSpan is not laid out yet.");
        }
        return this.f10947b;
    }

    public final void draw(Canvas canvas, CharSequence charSequence, int i10, int i11, float f10, int i12, int i13, int i14, Paint paint) {
    }
}
