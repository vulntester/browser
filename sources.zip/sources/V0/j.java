package V0;

import android.text.TextPaint;
import android.text.style.CharacterStyle;

public final class j extends CharacterStyle {

    /* renamed from: a  reason: collision with root package name */
    public final int f10950a;

    /* renamed from: b  reason: collision with root package name */
    public final float f10951b;

    /* renamed from: c  reason: collision with root package name */
    public final float f10952c;

    /* renamed from: d  reason: collision with root package name */
    public final float f10953d;

    public j(float f10, float f11, float f12, int i10) {
        this.f10950a = i10;
        this.f10951b = f10;
        this.f10952c = f11;
        this.f10953d = f12;
    }

    public final void updateDrawState(TextPaint textPaint) {
        textPaint.setShadowLayer(this.f10953d, this.f10951b, this.f10952c, this.f10950a);
    }
}
