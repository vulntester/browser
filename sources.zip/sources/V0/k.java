package V0;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

public final class k extends MetricAffectingSpan {

    /* renamed from: a  reason: collision with root package name */
    public final float f10954a;

    public k(float f10) {
        this.f10954a = f10;
    }

    public final void updateDrawState(TextPaint textPaint) {
        textPaint.setTextSkewX(textPaint.getTextSkewX() + this.f10954a);
    }

    public final void updateMeasureState(TextPaint textPaint) {
        textPaint.setTextSkewX(textPaint.getTextSkewX() + this.f10954a);
    }
}
