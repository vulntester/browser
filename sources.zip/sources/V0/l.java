package V0;

import android.text.TextPaint;
import android.text.style.CharacterStyle;

public final class l extends CharacterStyle {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f10955a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f10956b;

    public l(boolean z10, boolean z11) {
        this.f10955a = z10;
        this.f10956b = z11;
    }

    public final void updateDrawState(TextPaint textPaint) {
        textPaint.setUnderlineText(this.f10955a);
        textPaint.setStrikeThruText(this.f10956b);
    }
}
