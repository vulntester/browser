package V0;

import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

public final class m extends MetricAffectingSpan {

    /* renamed from: a  reason: collision with root package name */
    public final Typeface f10957a;

    public m(Typeface typeface) {
        this.f10957a = typeface;
    }

    public final void updateDrawState(TextPaint textPaint) {
        textPaint.setTypeface(this.f10957a);
    }

    public final void updateMeasureState(TextPaint textPaint) {
        textPaint.setTypeface(this.f10957a);
    }
}
