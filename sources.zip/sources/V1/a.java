package V1;

import android.widget.EditText;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public final C0102a f10958a;

    /* renamed from: V1.a$a  reason: collision with other inner class name */
    public static class C0102a extends b {

        /* renamed from: a  reason: collision with root package name */
        public final EditText f10959a;

        /* renamed from: b  reason: collision with root package name */
        public final g f10960b;

        /* JADX WARNING: type inference failed for: r1v1, types: [android.text.Editable$Factory, V1.b] */
        /* JADX WARNING: Can't wrap try/catch for region: R(6:7|8|9|10|11|12) */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x002e */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public C0102a(android.widget.EditText r6) {
            /*
                r5 = this;
                r5.<init>()
                r5.f10959a = r6
                V1.g r0 = new V1.g
                r0.<init>(r6)
                r5.f10960b = r0
                r6.addTextChangedListener(r0)
                V1.b r0 = V1.b.f10962b
                if (r0 != 0) goto L_0x0037
                java.lang.Object r0 = V1.b.f10961a
                monitor-enter(r0)
                V1.b r1 = V1.b.f10962b     // Catch:{ all -> 0x0031 }
                if (r1 != 0) goto L_0x0033
                V1.b r1 = new V1.b     // Catch:{ all -> 0x0031 }
                r1.<init>()     // Catch:{ all -> 0x0031 }
                java.lang.String r2 = "android.text.DynamicLayout$ChangeWatcher"
                java.lang.Class<V1.b> r3 = V1.b.class
                java.lang.ClassLoader r3 = r3.getClassLoader()     // Catch:{ all -> 0x002e }
                r4 = 0
                java.lang.Class r2 = java.lang.Class.forName(r2, r4, r3)     // Catch:{ all -> 0x002e }
                V1.b.f10963c = r2     // Catch:{ all -> 0x002e }
            L_0x002e:
                V1.b.f10962b = r1     // Catch:{ all -> 0x0031 }
                goto L_0x0033
            L_0x0031:
                r6 = move-exception
                goto L_0x0035
            L_0x0033:
                monitor-exit(r0)     // Catch:{ all -> 0x0031 }
                goto L_0x0037
            L_0x0035:
                monitor-exit(r0)     // Catch:{ all -> 0x0031 }
                throw r6
            L_0x0037:
                V1.b r0 = V1.b.f10962b
                r6.setEditableFactory(r0)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: V1.a.C0102a.<init>(android.widget.EditText):void");
        }
    }

    public static class b {
    }

    public a(EditText editText) {
        this.f10958a = new C0102a(editText);
    }
}
