package V1;

import T1.j;
import android.text.Editable;

public final class b extends Editable.Factory {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f10961a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public static volatile b f10962b;

    /* renamed from: c  reason: collision with root package name */
    public static Class<?> f10963c;

    public final Editable newEditable(CharSequence charSequence) {
        Class<?> cls = f10963c;
        if (cls != null) {
            return new j(cls, charSequence);
        }
        return super.newEditable(charSequence);
    }
}
