package V1;

import android.text.Editable;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.widget.EditText;

public final class c extends InputConnectionWrapper {

    /* renamed from: a  reason: collision with root package name */
    public final EditText f10964a;

    /* renamed from: b  reason: collision with root package name */
    public final a f10965b;

    public static class a {
        /* JADX WARNING: Code restructure failed: missing block: B:24:0x0045, code lost:
            if (java.lang.Character.isHighSurrogate(r5) != false) goto L_0x0048;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:41:0x0075, code lost:
            if (r11 != false) goto L_0x006c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:45:0x0082, code lost:
            if (java.lang.Character.isLowSurrogate(r5) != false) goto L_0x0085;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:54:0x00a2, code lost:
            if (r10 != -1) goto L_0x00b3;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public static boolean a(V1.c r7, android.text.Editable r8, int r9, int r10, boolean r11) {
            /*
                r0 = 0
                if (r8 == 0) goto L_0x00ef
                if (r9 < 0) goto L_0x00ef
                if (r10 >= 0) goto L_0x0009
                goto L_0x00ef
            L_0x0009:
                int r1 = android.text.Selection.getSelectionStart(r8)
                int r2 = android.text.Selection.getSelectionEnd(r8)
                r3 = -1
                if (r1 == r3) goto L_0x00ef
                if (r2 == r3) goto L_0x00ef
                if (r1 == r2) goto L_0x001a
                goto L_0x00ef
            L_0x001a:
                r4 = 1
                if (r11 == 0) goto L_0x00a5
                int r9 = java.lang.Math.max(r9, r0)
                int r11 = r8.length()
                if (r1 < 0) goto L_0x002c
                if (r11 >= r1) goto L_0x002a
                goto L_0x002c
            L_0x002a:
                if (r9 >= 0) goto L_0x002e
            L_0x002c:
                r1 = r3
                goto L_0x005d
            L_0x002e:
                r11 = r0
            L_0x002f:
                if (r9 != 0) goto L_0x0032
                goto L_0x005d
            L_0x0032:
                int r1 = r1 + -1
                if (r1 >= 0) goto L_0x003b
                if (r11 == 0) goto L_0x0039
                goto L_0x002c
            L_0x0039:
                r1 = r0
                goto L_0x005d
            L_0x003b:
                char r5 = r8.charAt(r1)
                if (r11 == 0) goto L_0x004b
                boolean r11 = java.lang.Character.isHighSurrogate(r5)
                if (r11 != 0) goto L_0x0048
                goto L_0x002c
            L_0x0048:
                int r9 = r9 + -1
                goto L_0x002e
            L_0x004b:
                boolean r6 = java.lang.Character.isSurrogate(r5)
                if (r6 != 0) goto L_0x0054
                int r9 = r9 + -1
                goto L_0x002f
            L_0x0054:
                boolean r11 = java.lang.Character.isHighSurrogate(r5)
                if (r11 == 0) goto L_0x005b
                goto L_0x002c
            L_0x005b:
                r11 = r4
                goto L_0x002f
            L_0x005d:
                int r9 = java.lang.Math.max(r10, r0)
                int r10 = r8.length()
                if (r2 < 0) goto L_0x006c
                if (r10 >= r2) goto L_0x006a
                goto L_0x006c
            L_0x006a:
                if (r9 >= 0) goto L_0x006e
            L_0x006c:
                r10 = r3
                goto L_0x00a0
            L_0x006e:
                r11 = r0
            L_0x006f:
                if (r9 != 0) goto L_0x0073
                r10 = r2
                goto L_0x00a0
            L_0x0073:
                if (r2 < r10) goto L_0x0078
                if (r11 == 0) goto L_0x00a0
                goto L_0x006c
            L_0x0078:
                char r5 = r8.charAt(r2)
                if (r11 == 0) goto L_0x008a
                boolean r11 = java.lang.Character.isLowSurrogate(r5)
                if (r11 != 0) goto L_0x0085
                goto L_0x006c
            L_0x0085:
                int r9 = r9 + -1
                int r2 = r2 + 1
                goto L_0x006e
            L_0x008a:
                boolean r6 = java.lang.Character.isSurrogate(r5)
                if (r6 != 0) goto L_0x0095
                int r9 = r9 + -1
                int r2 = r2 + 1
                goto L_0x006f
            L_0x0095:
                boolean r11 = java.lang.Character.isLowSurrogate(r5)
                if (r11 == 0) goto L_0x009c
                goto L_0x006c
            L_0x009c:
                int r2 = r2 + 1
                r11 = r4
                goto L_0x006f
            L_0x00a0:
                if (r1 == r3) goto L_0x00ef
                if (r10 != r3) goto L_0x00b3
                goto L_0x00ef
            L_0x00a5:
                int r1 = r1 - r9
                int r1 = java.lang.Math.max(r1, r0)
                int r2 = r2 + r10
                int r9 = r8.length()
                int r10 = java.lang.Math.min(r2, r9)
            L_0x00b3:
                java.lang.Class<T1.h> r9 = T1.h.class
                java.lang.Object[] r9 = r8.getSpans(r1, r10, r9)
                T1.h[] r9 = (T1.h[]) r9
                if (r9 == 0) goto L_0x00ef
                int r11 = r9.length
                if (r11 <= 0) goto L_0x00ef
                int r11 = r9.length
                r2 = r0
            L_0x00c2:
                if (r2 >= r11) goto L_0x00d9
                r3 = r9[r2]
                int r5 = r8.getSpanStart(r3)
                int r3 = r8.getSpanEnd(r3)
                int r1 = java.lang.Math.min(r5, r1)
                int r10 = java.lang.Math.max(r3, r10)
                int r2 = r2 + 1
                goto L_0x00c2
            L_0x00d9:
                int r9 = java.lang.Math.max(r1, r0)
                int r11 = r8.length()
                int r10 = java.lang.Math.min(r10, r11)
                r7.beginBatchEdit()
                r8.delete(r9, r10)
                r7.endBatchEdit()
                return r4
            L_0x00ef:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: V1.c.a.a(V1.c, android.text.Editable, int, int, boolean):boolean");
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [V1.c$a, java.lang.Object] */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c(EditText editText, InputConnection inputConnection, EditorInfo editorInfo) {
        super(inputConnection, false);
        ? obj = new Object();
        this.f10964a = editText;
        this.f10965b = obj;
        if (androidx.emoji2.text.c.d()) {
            androidx.emoji2.text.c.a().i(editorInfo);
        }
    }

    public final boolean deleteSurroundingText(int i10, int i11) {
        Editable editableText = this.f10964a.getEditableText();
        this.f10965b.getClass();
        if (a.a(this, editableText, i10, i11, false) || super.deleteSurroundingText(i10, i11)) {
            return true;
        }
        return false;
    }

    public final boolean deleteSurroundingTextInCodePoints(int i10, int i11) {
        Editable editableText = this.f10964a.getEditableText();
        this.f10965b.getClass();
        if (a.a(this, editableText, i10, i11, true) || super.deleteSurroundingTextInCodePoints(i10, i11)) {
            return true;
        }
        return false;
    }
}
