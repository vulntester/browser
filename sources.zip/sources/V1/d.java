package V1;

import android.os.Handler;
import android.text.InputFilter;
import android.text.Selection;
import android.text.Spannable;
import android.text.Spanned;
import android.widget.TextView;
import androidx.emoji2.text.c;
import java.lang.ref.WeakReference;

public final class d implements InputFilter {

    /* renamed from: a  reason: collision with root package name */
    public final TextView f10966a;

    /* renamed from: b  reason: collision with root package name */
    public a f10967b;

    public static class a extends c.e implements Runnable {

        /* renamed from: f  reason: collision with root package name */
        public final WeakReference f10968f;

        /* renamed from: i  reason: collision with root package name */
        public final WeakReference f10969i;

        public a(TextView textView, d dVar) {
            this.f10968f = new WeakReference(textView);
            this.f10969i = new WeakReference(dVar);
        }

        public final void b() {
            Handler handler;
            TextView textView = (TextView) this.f10968f.get();
            if (textView != null && (handler = textView.getHandler()) != null) {
                handler.post(this);
            }
        }

        public final void run() {
            InputFilter[] filters;
            int i10;
            TextView textView = (TextView) this.f10968f.get();
            InputFilter inputFilter = (InputFilter) this.f10969i.get();
            if (inputFilter != null && textView != null && (filters = textView.getFilters()) != null) {
                int i11 = 0;
                while (i11 < filters.length) {
                    if (filters[i11] != inputFilter) {
                        i11++;
                    } else if (textView.isAttachedToWindow()) {
                        CharSequence text = textView.getText();
                        c a10 = c.a();
                        if (text == null) {
                            i10 = 0;
                        } else {
                            a10.getClass();
                            i10 = text.length();
                        }
                        CharSequence g6 = a10.g(0, i10, 0, text);
                        if (text != g6) {
                            int selectionStart = Selection.getSelectionStart(g6);
                            int selectionEnd = Selection.getSelectionEnd(g6);
                            textView.setText(g6);
                            if (g6 instanceof Spannable) {
                                Spannable spannable = (Spannable) g6;
                                if (selectionStart >= 0 && selectionEnd >= 0) {
                                    Selection.setSelection(spannable, selectionStart, selectionEnd);
                                    return;
                                } else if (selectionStart >= 0) {
                                    Selection.setSelection(spannable, selectionStart);
                                    return;
                                } else if (selectionEnd >= 0) {
                                    Selection.setSelection(spannable, selectionEnd);
                                    return;
                                } else {
                                    return;
                                }
                            } else {
                                return;
                            }
                        } else {
                            return;
                        }
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public d(TextView textView) {
        this.f10966a = textView;
    }

    public final CharSequence filter(CharSequence charSequence, int i10, int i11, Spanned spanned, int i12, int i13) {
        TextView textView = this.f10966a;
        if (textView.isInEditMode()) {
            return charSequence;
        }
        int c10 = c.a().c();
        if (c10 != 0) {
            if (c10 != 1) {
                if (c10 != 3) {
                    return charSequence;
                }
            } else if ((i13 == 0 && i12 == 0 && spanned.length() == 0 && charSequence == textView.getText()) || charSequence == null) {
                return charSequence;
            } else {
                if (!(i10 == 0 && i11 == charSequence.length())) {
                    charSequence = charSequence.subSequence(i10, i11);
                }
                return c.a().g(0, charSequence.length(), 0, charSequence);
            }
        }
        c a10 = c.a();
        if (this.f10967b == null) {
            this.f10967b = new a(textView, this);
        }
        a10.h(this.f10967b);
        return charSequence;
    }
}
