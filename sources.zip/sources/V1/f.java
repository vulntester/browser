package V1;

import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.SparseArray;
import android.widget.TextView;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final b f10972a;

    public static class a extends b {

        /* renamed from: a  reason: collision with root package name */
        public final TextView f10973a;

        /* renamed from: b  reason: collision with root package name */
        public final d f10974b;

        /* renamed from: c  reason: collision with root package name */
        public boolean f10975c = true;

        public a(TextView textView) {
            this.f10973a = textView;
            this.f10974b = new d(textView);
        }

        public final InputFilter[] a(InputFilter[] inputFilterArr) {
            if (!this.f10975c) {
                SparseArray sparseArray = new SparseArray(1);
                for (int i10 = 0; i10 < inputFilterArr.length; i10++) {
                    InputFilter inputFilter = inputFilterArr[i10];
                    if (inputFilter instanceof d) {
                        sparseArray.put(i10, inputFilter);
                    }
                }
                if (sparseArray.size() == 0) {
                    return inputFilterArr;
                }
                int length = inputFilterArr.length;
                InputFilter[] inputFilterArr2 = new InputFilter[(inputFilterArr.length - sparseArray.size())];
                int i11 = 0;
                for (int i12 = 0; i12 < length; i12++) {
                    if (sparseArray.indexOfKey(i12) < 0) {
                        inputFilterArr2[i11] = inputFilterArr[i12];
                        i11++;
                    }
                }
                return inputFilterArr2;
            }
            int length2 = inputFilterArr.length;
            int i13 = 0;
            while (true) {
                d dVar = this.f10974b;
                if (i13 >= length2) {
                    InputFilter[] inputFilterArr3 = new InputFilter[(inputFilterArr.length + 1)];
                    System.arraycopy(inputFilterArr, 0, inputFilterArr3, 0, length2);
                    inputFilterArr3[length2] = dVar;
                    return inputFilterArr3;
                } else if (inputFilterArr[i13] == dVar) {
                    return inputFilterArr;
                } else {
                    i13++;
                }
            }
        }

        public final boolean b() {
            return this.f10975c;
        }

        public final void c(boolean z10) {
            if (z10) {
                TextView textView = this.f10973a;
                textView.setTransformationMethod(e(textView.getTransformationMethod()));
            }
        }

        public final void d(boolean z10) {
            this.f10975c = z10;
            TextView textView = this.f10973a;
            textView.setTransformationMethod(e(textView.getTransformationMethod()));
            textView.setFilters(a(textView.getFilters()));
        }

        public final TransformationMethod e(TransformationMethod transformationMethod) {
            if (this.f10975c) {
                if (!(transformationMethod instanceof h) && !(transformationMethod instanceof PasswordTransformationMethod)) {
                    return new h(transformationMethod);
                }
                return transformationMethod;
            } else if (transformationMethod instanceof h) {
                return ((h) transformationMethod).f10981a;
            } else {
                return transformationMethod;
            }
        }
    }

    public static class b {
        public InputFilter[] a(InputFilter[] inputFilterArr) {
            throw null;
        }

        public boolean b() {
            throw null;
        }

        public void c(boolean z10) {
            throw null;
        }

        public void d(boolean z10) {
            throw null;
        }

        public TransformationMethod e(TransformationMethod transformationMethod) {
            throw null;
        }
    }

    public static class c extends b {

        /* renamed from: a  reason: collision with root package name */
        public final a f10976a;

        public c(TextView textView) {
            this.f10976a = new a(textView);
        }

        public final InputFilter[] a(InputFilter[] inputFilterArr) {
            if (!androidx.emoji2.text.c.d()) {
                return inputFilterArr;
            }
            return this.f10976a.a(inputFilterArr);
        }

        public final boolean b() {
            return this.f10976a.f10975c;
        }

        public final void c(boolean z10) {
            if (androidx.emoji2.text.c.d()) {
                this.f10976a.c(z10);
            }
        }

        public final void d(boolean z10) {
            boolean d10 = androidx.emoji2.text.c.d();
            a aVar = this.f10976a;
            if (!d10) {
                aVar.f10975c = z10;
            } else {
                aVar.d(z10);
            }
        }

        public final TransformationMethod e(TransformationMethod transformationMethod) {
            if (!androidx.emoji2.text.c.d()) {
                return transformationMethod;
            }
            return this.f10976a.e(transformationMethod);
        }
    }

    public f(TextView textView) {
        this.f10972a = new c(textView);
    }
}
