package V1;

import android.os.Handler;
import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.TextWatcher;
import android.widget.EditText;
import androidx.emoji2.text.c;
import java.lang.ref.WeakReference;

public final class g implements TextWatcher {

    /* renamed from: f  reason: collision with root package name */
    public final EditText f10977f;

    /* renamed from: i  reason: collision with root package name */
    public a f10978i;

    /* renamed from: z  reason: collision with root package name */
    public boolean f10979z = true;

    public static class a extends c.e implements Runnable {

        /* renamed from: f  reason: collision with root package name */
        public final WeakReference f10980f;

        public a(EditText editText) {
            this.f10980f = new WeakReference(editText);
        }

        public final void b() {
            Handler handler;
            EditText editText = (EditText) this.f10980f.get();
            if (editText != null && (handler = editText.getHandler()) != null) {
                handler.post(this);
            }
        }

        public final void run() {
            g.a((EditText) this.f10980f.get(), 1);
        }
    }

    public g(EditText editText) {
        this.f10977f = editText;
    }

    public static void a(EditText editText, int i10) {
        int i11;
        if (i10 == 1 && editText != null && editText.isAttachedToWindow()) {
            Editable editableText = editText.getEditableText();
            int selectionStart = Selection.getSelectionStart(editableText);
            int selectionEnd = Selection.getSelectionEnd(editableText);
            c a10 = c.a();
            if (editableText == null) {
                i11 = 0;
            } else {
                a10.getClass();
                i11 = editableText.length();
            }
            a10.g(0, i11, 0, editableText);
            if (selectionStart >= 0 && selectionEnd >= 0) {
                Selection.setSelection(editableText, selectionStart, selectionEnd);
            } else if (selectionStart >= 0) {
                Selection.setSelection(editableText, selectionStart);
            } else if (selectionEnd >= 0) {
                Selection.setSelection(editableText, selectionEnd);
            }
        }
    }

    public final void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        EditText editText = this.f10977f;
        if (!editText.isInEditMode() && this.f10979z && c.d() && i11 <= i12 && (charSequence instanceof Spannable)) {
            int c10 = c.a().c();
            if (c10 != 0) {
                if (c10 == 1) {
                    c.a().g(i10, i12 + i10, 0, (Spannable) charSequence);
                    return;
                } else if (c10 != 3) {
                    return;
                }
            }
            c a10 = c.a();
            if (this.f10978i == null) {
                this.f10978i = new a(editText);
            }
            a10.h(this.f10978i);
        }
    }

    public final void afterTextChanged(Editable editable) {
    }

    public final void beforeTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
    }
}
