package V6;

import Cc.c;
import E.C0585n;
import F0.C0631s;
import H0.C0681i0;
import Uc.I;
import W0.l;
import android.content.Context;
import ba.k;
import com.google.android.gms.internal.measurement.C1539d5;
import com.google.android.gms.internal.measurement.R5;
import com.google.android.gms.internal.measurement.U5;
import com.google.android.gms.internal.measurement.j6;
import com.google.android.gms.internal.measurement.k6;
import com.google.android.gms.internal.measurement.m6;
import com.google.gson.internal.i;
import f7.O;
import f7.Q;
import gc.C4455b;
import gc.C4456c;
import gc.d;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import jb.C4572j;
import l2.v;
import o0.C2747c;
import o2.C2756B;

public final class b implements i, O {

    /* renamed from: E  reason: collision with root package name */
    public static b f11194E;

    /* renamed from: i  reason: collision with root package name */
    public static Context f11195i;

    /* renamed from: z  reason: collision with root package name */
    public static Boolean f11196z;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11197f;

    public /* synthetic */ b(int i10) {
        this.f11197f = i10;
    }

    public static final C2747c a(C0631s sVar) {
        C0631s G10 = sVar.G();
        if (G10 != null) {
            return G10.O(sVar, true);
        }
        return new C2747c(0.0f, 0.0f, (float) ((int) (sVar.d() >> 32)), (float) ((int) (sVar.d() & 4294967295L)));
    }

    public static final C2747c b(C0631s sVar) {
        C0631s k10 = k(sVar);
        float d10 = (float) ((int) (k10.d() >> 32));
        float d11 = (float) ((int) (k10.d() & 4294967295L));
        C2747c O10 = k10.O(sVar, true);
        float f10 = O10.f25769a;
        float f11 = 0.0f;
        if (f10 < 0.0f) {
            f10 = 0.0f;
        }
        if (f10 > d10) {
            f10 = d10;
        }
        float f12 = O10.f25770b;
        if (f12 < 0.0f) {
            f12 = 0.0f;
        }
        if (f12 > d11) {
            f12 = d11;
        }
        float f13 = O10.f25771c;
        if (f13 < 0.0f) {
            f13 = 0.0f;
        }
        if (f13 <= d10) {
            d10 = f13;
        }
        float f14 = O10.f25772d;
        if (f14 >= 0.0f) {
            f11 = f14;
        }
        if (f11 <= d11) {
            d11 = f11;
        }
        if (f10 == d10 || f12 == d11) {
            return C2747c.f25768e;
        }
        long r10 = k10.r((((long) Float.floatToRawIntBits(f10)) << 32) | (((long) Float.floatToRawIntBits(f12)) & 4294967295L));
        long r11 = k10.r((((long) Float.floatToRawIntBits(f12)) & 4294967295L) | (((long) Float.floatToRawIntBits(d10)) << 32));
        long r12 = k10.r((((long) Float.floatToRawIntBits(d10)) << 32) | (((long) Float.floatToRawIntBits(d11)) & 4294967295L));
        long r13 = k10.r((((long) Float.floatToRawIntBits(d11)) & 4294967295L) | (((long) Float.floatToRawIntBits(f10)) << 32));
        float intBitsToFloat = Float.intBitsToFloat((int) (r10 >> 32));
        float intBitsToFloat2 = Float.intBitsToFloat((int) (r11 >> 32));
        float intBitsToFloat3 = Float.intBitsToFloat((int) (r13 >> 32));
        float intBitsToFloat4 = Float.intBitsToFloat((int) (r12 >> 32));
        float min = Math.min(intBitsToFloat, Math.min(intBitsToFloat2, Math.min(intBitsToFloat3, intBitsToFloat4)));
        float max = Math.max(intBitsToFloat, Math.max(intBitsToFloat2, Math.max(intBitsToFloat3, intBitsToFloat4)));
        float intBitsToFloat5 = Float.intBitsToFloat((int) (r10 & 4294967295L));
        float intBitsToFloat6 = Float.intBitsToFloat((int) (r11 & 4294967295L));
        float intBitsToFloat7 = Float.intBitsToFloat((int) (r13 & 4294967295L));
        float intBitsToFloat8 = Float.intBitsToFloat((int) (4294967295L & r12));
        return new C2747c(min, Math.min(intBitsToFloat5, Math.min(intBitsToFloat6, Math.min(intBitsToFloat7, intBitsToFloat8))), max, Math.max(intBitsToFloat5, Math.max(intBitsToFloat6, Math.max(intBitsToFloat7, intBitsToFloat8))));
    }

    public static void c(String str, boolean z10) {
        if (!z10) {
            throw new IllegalArgumentException(str);
        }
    }

    public static void d(String str, boolean z10) {
        if (!z10) {
            throw v.a((RuntimeException) null, str);
        }
    }

    public static void e(Object obj) {
        f(obj, "Argument must not be null");
    }

    public static void f(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }

    public static final void g(AutoCloseable autoCloseable, Throwable th) {
        if (autoCloseable == null) {
            return;
        }
        if (th == null) {
            autoCloseable.close();
            return;
        }
        try {
            autoCloseable.close();
        } catch (Throwable th2) {
            C4572j.d(th, th2);
        }
    }

    public static final boolean h(k kVar, X9.b bVar) {
        int i10;
        int i11 = kVar.f39305f;
        if (i11 < 400) {
            bVar.f38645m.log("Flushing failed with " + i11 + ", let's try again soon.");
            return false;
        } else if (i11 != 413 || (i10 = bVar.f38640h) <= 1) {
            return true;
        } else {
            int i12 = i10 / 2;
            if ((i10 ^ 2) < 0 && i12 * 2 != i10) {
                i12--;
            }
            bVar.f38640h = Math.max(i12, 1);
            int i13 = bVar.f38638f;
            int i14 = i13 / 2;
            if ((i13 ^ 2) < 0 && i14 * 2 != i13) {
                i14--;
            }
            bVar.f38638f = Math.max(i14, 1);
            bVar.f38645m.log("Flushing failed with " + i11 + ", let's try again with a smaller batch.");
            return false;
        }
    }

    public static final long i(long j10) {
        long j11 = (j10 << 1) + 1;
        int i10 = C4455b.f40974E;
        int i11 = C4456c.f40978a;
        return j11;
    }

    public static final int j(C0585n nVar, Object obj, int i10) {
        int b10;
        if (obj == null || nVar.e() == 0 || ((i10 < nVar.e() && obj.equals(nVar.f(i10))) || (b10 = nVar.b(obj)) == -1)) {
            return i10;
        }
        return b10;
    }

    public static final C0631s k(C0631s sVar) {
        C0631s sVar2;
        C0681i0 i0Var;
        C0631s G10 = sVar.G();
        while (true) {
            C0631s sVar3 = G10;
            sVar2 = sVar;
            sVar = sVar3;
            if (sVar == null) {
                break;
            }
            G10 = sVar.G();
        }
        if (sVar2 instanceof C0681i0) {
            i0Var = (C0681i0) sVar2;
        } else {
            i0Var = null;
        }
        if (i0Var == null) {
            return sVar2;
        }
        C0681i0 i0Var2 = i0Var.f3410R;
        while (true) {
            C0681i0 i0Var3 = i0Var2;
            C0681i0 i0Var4 = i0Var;
            i0Var = i0Var3;
            if (i0Var == null) {
                return i0Var4;
            }
            i0Var2 = i0Var.f3410R;
        }
    }

    public static final int l(l lVar, int i10) {
        boolean z10;
        boolean z11;
        if (kotlin.jvm.internal.l.h(lVar.f11291f, l.f11284E.f11291f) >= 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (i10 == 1) {
            z11 = true;
        } else {
            z11 = false;
        }
        if (z11 && z10) {
            return 3;
        }
        if (z10) {
            return 1;
        }
        if (z11) {
            return 2;
        }
        return 0;
    }

    public static final long m(long j10) {
        return (((j10 << 32) >> 33) & 4294967295L) | ((j10 >> 33) << 32);
    }

    public static final int n(c cVar, c[] cVarArr) {
        boolean z10;
        boolean z11;
        int i10;
        kotlin.jvm.internal.l.f(cVar, "<this>");
        kotlin.jvm.internal.l.f(cVarArr, "typeParams");
        int hashCode = (cVar.f().hashCode() * 31) + Arrays.hashCode(cVarArr);
        int h10 = cVar.h();
        int i11 = 1;
        while (true) {
            int i12 = 0;
            if (h10 > 0) {
                z10 = true;
            } else {
                z10 = false;
            }
            if (!z10) {
                break;
            }
            int i13 = h10 - 1;
            int i14 = i11 * 31;
            String f10 = cVar.j(cVar.h() - h10).f();
            if (f10 != null) {
                i12 = f10.hashCode();
            }
            i11 = i14 + i12;
            h10 = i13;
        }
        int h11 = cVar.h();
        int i15 = 1;
        while (true) {
            if (h11 > 0) {
                z11 = true;
            } else {
                z11 = false;
            }
            if (!z11) {
                return (((hashCode * 31) + i11) * 31) + i15;
            }
            int i16 = h11 - 1;
            int i17 = i15 * 31;
            Cc.i e10 = cVar.j(cVar.h() - h11).e();
            if (e10 != null) {
                i10 = e10.hashCode();
            } else {
                i10 = 0;
            }
            i15 = i17 + i10;
            h11 = i16;
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(4:18|19|20|21) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:20:0x0040 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static synchronized boolean p(android.content.Context r4) {
        /*
            java.lang.Class<V6.b> r0 = V6.b.class
            monitor-enter(r0)
            android.content.Context r1 = r4.getApplicationContext()     // Catch:{ all -> 0x0018 }
            android.content.Context r2 = f11195i     // Catch:{ all -> 0x0018 }
            if (r2 == 0) goto L_0x001a
            java.lang.Boolean r3 = f11196z     // Catch:{ all -> 0x0018 }
            if (r3 == 0) goto L_0x001a
            if (r2 == r1) goto L_0x0012
            goto L_0x001a
        L_0x0012:
            boolean r4 = r3.booleanValue()     // Catch:{ all -> 0x0018 }
            monitor-exit(r0)
            return r4
        L_0x0018:
            r4 = move-exception
            goto L_0x004e
        L_0x001a:
            r2 = 0
            f11196z = r2     // Catch:{ all -> 0x0018 }
            boolean r2 = U6.g.a()     // Catch:{ all -> 0x0018 }
            if (r2 == 0) goto L_0x0032
            android.content.pm.PackageManager r4 = r1.getPackageManager()     // Catch:{ all -> 0x0018 }
            boolean r4 = r4.isInstantApp()     // Catch:{ all -> 0x0018 }
            java.lang.Boolean r4 = java.lang.Boolean.valueOf(r4)     // Catch:{ all -> 0x0018 }
            f11196z = r4     // Catch:{ all -> 0x0018 }
            goto L_0x0044
        L_0x0032:
            java.lang.ClassLoader r4 = r4.getClassLoader()     // Catch:{ ClassNotFoundException -> 0x0040 }
            java.lang.String r2 = "com.google.android.instantapps.supervisor.InstantAppsRuntime"
            r4.loadClass(r2)     // Catch:{ ClassNotFoundException -> 0x0040 }
            java.lang.Boolean r4 = java.lang.Boolean.TRUE     // Catch:{ ClassNotFoundException -> 0x0040 }
            f11196z = r4     // Catch:{ ClassNotFoundException -> 0x0040 }
            goto L_0x0044
        L_0x0040:
            java.lang.Boolean r4 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x0018 }
            f11196z = r4     // Catch:{ all -> 0x0018 }
        L_0x0044:
            f11195i = r1     // Catch:{ all -> 0x0018 }
            java.lang.Boolean r4 = f11196z     // Catch:{ all -> 0x0018 }
            boolean r4 = r4.booleanValue()     // Catch:{ all -> 0x0018 }
            monitor-exit(r0)
            return r4
        L_0x004e:
            monitor-exit(r0)     // Catch:{ all -> 0x0018 }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: V6.b.p(android.content.Context):boolean");
    }

    public static final int q(I i10, int i11) {
        int i12;
        kotlin.jvm.internal.l.f(i10, "<this>");
        int i13 = i11 + 1;
        int length = i10.f38279F.length;
        int[] iArr = i10.f38280G;
        kotlin.jvm.internal.l.f(iArr, "<this>");
        int i14 = length - 1;
        int i15 = 0;
        while (true) {
            if (i15 <= i14) {
                i12 = (i15 + i14) >>> 1;
                int i16 = iArr[i12];
                if (i16 >= i13) {
                    if (i16 <= i13) {
                        break;
                    }
                    i14 = i12 - 1;
                } else {
                    i15 = i12 + 1;
                }
            } else {
                i12 = (-i15) - 1;
                break;
            }
        }
        if (i12 >= 0) {
            return i12;
        }
        return ~i12;
    }

    public static final long r(int i10, d dVar) {
        kotlin.jvm.internal.l.f(dVar, "unit");
        if (dVar.compareTo(d.SECONDS) > 0) {
            return s((long) i10, dVar);
        }
        long i11 = Z7.b.i((long) i10, dVar, d.NANOSECONDS) << 1;
        int i12 = C4455b.f40974E;
        int i13 = C4456c.f40978a;
        return i11;
    }

    public static final long s(long j10, d dVar) {
        kotlin.jvm.internal.l.f(dVar, "unit");
        d dVar2 = d.NANOSECONDS;
        long i10 = Z7.b.i(4611686018426999999L, dVar2, dVar);
        if ((-i10) > j10 || j10 > i10) {
            return i(Ta.k.S(Z7.b.h(j10, dVar, d.MILLISECONDS), -4611686018427387903L, 4611686018427387903L));
        }
        long i11 = Z7.b.i(j10, dVar, dVar2) << 1;
        int i12 = C4455b.f40974E;
        int i13 = C4456c.f40978a;
        return i11;
    }

    public static long t(int i10, long j10, long j11, long j12) {
        long j13 = (long) i10;
        int i11 = C2756B.f25811a;
        return j10 + C2756B.W(j11 - j12, 1000000, j13, RoundingMode.DOWN);
    }

    public static final long u(long j10) {
        return (((long) Float.floatToRawIntBits((float) ((int) (j10 & 4294967295L)))) & 4294967295L) | (((long) Float.floatToRawIntBits((float) ((int) (j10 >> 32)))) << 32);
    }

    public static final int v(int i10) {
        int i11 = 306783378 & i10;
        int i12 = 613566756 & i10;
        return (i10 & -920350135) | (i12 >> 1) | i11 | ((i11 << 1) & i12);
    }

    public static Class w(Class cls) {
        if (cls == Integer.TYPE) {
            return Integer.class;
        }
        if (cls == Float.TYPE) {
            return Float.class;
        }
        if (cls == Byte.TYPE) {
            return Byte.class;
        }
        if (cls == Double.TYPE) {
            return Double.class;
        }
        if (cls == Long.TYPE) {
            return Long.class;
        }
        if (cls == Character.TYPE) {
            return Character.class;
        }
        if (cls == Boolean.TYPE) {
            return Boolean.class;
        }
        if (cls == Short.TYPE) {
            return Short.class;
        }
        if (cls == Void.TYPE) {
            return Void.class;
        }
        return cls;
    }

    public static boolean x(byte b10) {
        if (b10 > -65) {
            return true;
        }
        return false;
    }

    public Object o() {
        return new TreeSet();
    }

    public Object zza() {
        switch (this.f11197f) {
            case 20:
                List list = Q.f21606a;
                return Boolean.valueOf(m6.f17856i.get().zzg());
            case 21:
                List list2 = Q.f21606a;
                return Boolean.valueOf(U5.f17640i.get().zzi());
            case 22:
                List list3 = Q.f21606a;
                return Integer.valueOf((int) C1539d5.f17721i.get().v());
            case 23:
                List list4 = Q.f21606a;
                return C1539d5.f17721i.get().y();
            case 24:
                List list5 = Q.f21606a;
                return Long.valueOf(C1539d5.f17721i.get().L());
            case 25:
                return Boolean.valueOf(((k6) j6.f17837i.f17838f.f8315f).zza());
            case 26:
                List list6 = Q.f21606a;
                return Integer.valueOf((int) R5.f17614i.get().zzc());
            case 27:
                List list7 = Q.f21606a;
                return C1539d5.f17721i.get().E();
            default:
                List list8 = Q.f21606a;
                return Boolean.valueOf(C1539d5.f17721i.get().V());
        }
    }
}
