package V6;

import U6.g;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Binder;
import android.os.Process;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final Context f11198a;

    public c(Context context) {
        this.f11198a = context;
    }

    public final ApplicationInfo a(int i10, String str) {
        return this.f11198a.getPackageManager().getApplicationInfo(str, i10);
    }

    public final PackageInfo b(int i10, String str) {
        return this.f11198a.getPackageManager().getPackageInfo(str, i10);
    }

    public final boolean c() {
        String nameForUid;
        int callingUid = Binder.getCallingUid();
        int myUid = Process.myUid();
        Context context = this.f11198a;
        if (callingUid == myUid) {
            return b.p(context);
        }
        if (!g.a() || (nameForUid = context.getPackageManager().getNameForUid(Binder.getCallingUid())) == null) {
            return false;
        }
        return context.getPackageManager().isInstantApp(nameForUid);
    }
}
