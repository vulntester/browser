package V6;

import android.content.Context;

public final class d {

    /* renamed from: b  reason: collision with root package name */
    public static final d f11199b;

    /* renamed from: a  reason: collision with root package name */
    public c f11200a;

    /* JADX WARNING: type inference failed for: r0v0, types: [V6.d, java.lang.Object] */
    static {
        ? obj = new Object();
        obj.f11200a = null;
        f11199b = obj;
    }

    public static c a(Context context) {
        c cVar;
        d dVar = f11199b;
        synchronized (dVar) {
            try {
                if (dVar.f11200a == null) {
                    if (context.getApplicationContext() != null) {
                        context = context.getApplicationContext();
                    }
                    dVar.f11200a = new c(context);
                }
                cVar = dVar.f11200a;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        return cVar;
    }
}
