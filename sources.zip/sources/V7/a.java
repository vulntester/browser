package V7;

import C0.e;
import H6.v;
import R7.b;
import R7.c;
import R7.f;
import R7.i;
import R7.l;
import R7.m;
import S7.C1150x;
import S7.O;
import io.ktor.util.date.GMTDateParser;
import java.util.Collection;
import p9.C4772a;
import p9.C4773b;
import z0.C3542c;

public final class a {

    /* renamed from: d  reason: collision with root package name */
    public static final c f11201d = c.b(".。．｡");

    /* renamed from: e  reason: collision with root package name */
    public static final m f11202e = m.a('.');

    /* renamed from: f  reason: collision with root package name */
    public static final v f11203f = new v(String.valueOf('.'));

    /* renamed from: g  reason: collision with root package name */
    public static final c f11204g;

    /* renamed from: h  reason: collision with root package name */
    public static final c.d f11205h;

    /* renamed from: i  reason: collision with root package name */
    public static final c f11206i;

    /* renamed from: a  reason: collision with root package name */
    public final String f11207a;

    /* renamed from: b  reason: collision with root package name */
    public final C1150x<String> f11208b;

    /* renamed from: c  reason: collision with root package name */
    public int f11209c = -2;

    static {
        c b10 = c.b("-_");
        f11204g = b10;
        c.d dVar = new c.d('0', '9');
        f11205h = dVar;
        f11206i = new c.k(new c.k(dVar, new c.k(new c.d('a', GMTDateParser.ZONE), new c.d('A', 'Z'))), b10);
    }

    public a(String str) {
        C1150x<String> xVar;
        String N3 = A1.a.N(f11201d.h(str));
        boolean z10 = false;
        N3 = N3.endsWith(".") ? N3.substring(0, N3.length() - 1) : N3;
        C3542c.o(N3.length() <= 253, "Domain name too long: '%s':", N3);
        this.f11207a = N3;
        m mVar = f11202e;
        mVar.getClass();
        l lVar = new l(mVar, N3);
        C1150x.b bVar = C1150x.f9860i;
        if (lVar instanceof Collection) {
            xVar = C1150x.o((Collection) lVar);
        } else {
            b bVar2 = (b) lVar.iterator();
            if (!bVar2.hasNext()) {
                xVar = O.f9711F;
            } else {
                Object next = bVar2.next();
                if (!bVar2.hasNext()) {
                    xVar = C1150x.u(next);
                } else {
                    C1150x.a aVar = new C1150x.a();
                    aVar.c(next);
                    while (bVar2.hasNext()) {
                        aVar.c(bVar2.next());
                    }
                    xVar = aVar.g();
                }
            }
        }
        this.f11208b = xVar;
        C3542c.o(xVar.size() <= 127, "Domain has too many parts: '%s'", N3);
        int size = xVar.size() - 1;
        if (c(xVar.get(size), true)) {
            int i10 = 0;
            while (true) {
                if (i10 >= size) {
                    z10 = true;
                    break;
                } else if (!c(xVar.get(i10), false)) {
                    break;
                } else {
                    i10++;
                }
            }
        }
        C3542c.o(z10, "Not a valid domain name: '%s'", N3);
    }

    public static boolean c(String str, boolean z10) {
        if (str.length() >= 1 && str.length() <= 63) {
            c.b bVar = c.b.f8278i;
            bVar.getClass();
            c.h hVar = new c.h(bVar);
            String str2 = str.toString();
            int d10 = hVar.d(str2);
            if (d10 != -1) {
                char[] charArray = str2.toCharArray();
                int i10 = 1;
                loop0:
                while (true) {
                    d10++;
                    while (d10 != charArray.length) {
                        if (hVar.e(charArray[d10])) {
                            i10++;
                        } else {
                            charArray[d10 - i10] = charArray[d10];
                            d10++;
                        }
                    }
                    break loop0;
                }
                str2 = new String(charArray, 0, d10 - i10);
            }
            if (f11206i.f(str2)) {
                char charAt = str.charAt(0);
                c cVar = f11204g;
                if (cVar.e(charAt) || cVar.e(str.charAt(str.length() - 1)) || (z10 && f11205h.e(str.charAt(0)))) {
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    public final int a() {
        f fVar;
        f fVar2;
        int i10 = this.f11209c;
        if (i10 != -2) {
            return i10;
        }
        R7.a<Object> aVar = R7.a.f8269f;
        C1150x<String> xVar = this.f11208b;
        int size = xVar.size();
        int i11 = 0;
        while (true) {
            if (i11 >= size) {
                i11 = -1;
                break;
            }
            String c10 = f11203f.c(xVar.subList(i11, size));
            if (i11 > 0) {
                C4773b bVar = (C4773b) C4772a.f42963b.get(c10);
                if (bVar == null) {
                    fVar2 = R7.a.f8269f;
                } else {
                    fVar2 = new i(bVar);
                }
                aVar.getClass();
                if (fVar2.b()) {
                    i11--;
                    break;
                }
            }
            C4773b bVar2 = (C4773b) C4772a.f42962a.get(c10);
            if (bVar2 == null) {
                fVar = R7.a.f8269f;
            } else {
                fVar = new i(bVar2);
            }
            aVar.getClass();
            if (fVar.b()) {
                break;
            } else if (C4772a.f42964c.containsKey(c10)) {
                i11++;
                break;
            } else {
                i11++;
            }
        }
        this.f11209c = i11;
        return i11;
    }

    public final a b() {
        boolean z10;
        if (a() == 1) {
            return this;
        }
        if (a() > 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        String str = this.f11207a;
        if (z10) {
            int a10 = a() - 1;
            C1150x<String> xVar = this.f11208b;
            C1150x<String> E10 = xVar.subList(a10, xVar.size());
            int i10 = a10;
            for (int i11 = 0; i11 < a10; i11++) {
                i10 += xVar.get(i11).length();
            }
            return new a(str.substring(i10), E10);
        }
        throw new IllegalStateException(e.m("Not under a public suffix: %s", str));
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof a) {
            return this.f11207a.equals(((a) obj).f11207a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f11207a.hashCode();
    }

    public final String toString() {
        return this.f11207a;
    }

    public a(String str, C1150x<String> xVar) {
        C3542c.m("Cannot create an InternetDomainName with zero parts.", !xVar.isEmpty());
        this.f11207a = str;
        this.f11208b = xVar;
    }
}
