package V8;

import E8.C3895b;
import X8.i;
import x6.C3470f;
import x6.C3471g;

public final class a {

    /* renamed from: d  reason: collision with root package name */
    public static final P8.a f38364d = P8.a.d();

    /* renamed from: a  reason: collision with root package name */
    public final String f38365a;

    /* renamed from: b  reason: collision with root package name */
    public final C3895b<C3471g> f38366b;

    /* renamed from: c  reason: collision with root package name */
    public C3470f<i> f38367c;

    public a(C3895b<C3471g> bVar, String str) {
        this.f38365a = str;
        this.f38366b = bVar;
    }
}
