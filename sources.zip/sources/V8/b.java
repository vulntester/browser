package V8;

import X8.d;
import X8.i;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final i.a f38368a;

    /* renamed from: b  reason: collision with root package name */
    public final d f38369b;

    public b(i.a aVar, d dVar) {
        this.f38368a = aVar;
        this.f38369b = dVar;
    }
}
