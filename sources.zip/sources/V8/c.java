package V8;

import N8.s;
import N8.t;
import V6.b;
import W8.e;
import W8.g;
import W8.i;
import W8.j;
import X8.k;
import X8.l;
import android.content.Context;
import com.google.firebase.perf.config.RemoteConfigManager;
import com.google.protobuf.C4277x;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final N8.a f38370a;

    /* renamed from: b  reason: collision with root package name */
    public final double f38371b;

    /* renamed from: c  reason: collision with root package name */
    public final double f38372c;

    /* renamed from: d  reason: collision with root package name */
    public final a f38373d = null;

    /* renamed from: e  reason: collision with root package name */
    public final a f38374e = null;

    public static class a {

        /* renamed from: i  reason: collision with root package name */
        public static final long f38375i = TimeUnit.SECONDS.toMicros(1);

        /* renamed from: a  reason: collision with root package name */
        public i f38376a;

        /* renamed from: b  reason: collision with root package name */
        public g f38377b;

        /* renamed from: c  reason: collision with root package name */
        public long f38378c = 500;

        /* renamed from: d  reason: collision with root package name */
        public double f38379d;

        /* renamed from: e  reason: collision with root package name */
        public final g f38380e;

        /* renamed from: f  reason: collision with root package name */
        public final g f38381f;

        /* renamed from: g  reason: collision with root package name */
        public final long f38382g;

        /* renamed from: h  reason: collision with root package name */
        public final long f38383h;

        static {
            P8.a.d();
        }

        /* JADX WARNING: type inference failed for: r13v9, types: [N8.t, java.lang.Object] */
        public a(g gVar, b bVar, N8.a aVar, String str) {
            long o10;
            long n10;
            long o11;
            t tVar;
            this.f38377b = gVar;
            this.f38379d = (double) 500;
            this.f38376a = new i();
            if (str == "Trace") {
                o10 = aVar.o();
            } else {
                o10 = aVar.o();
            }
            long j10 = o10;
            if (str == "Trace") {
                synchronized (t.class) {
                    try {
                        if (t.f37001i == null) {
                            t.f37001i = new Object();
                        }
                        tVar = t.f37001i;
                    } catch (Throwable th) {
                        while (true) {
                            throw th;
                        }
                    }
                }
                RemoteConfigManager remoteConfigManager = aVar.f36979a;
                tVar.getClass();
                e<Long> eVar = remoteConfigManager.getLong("fpr_rl_trace_event_count_fg");
                if (!eVar.b() || !N8.a.r(eVar.a().longValue())) {
                    e<Long> c10 = aVar.c(tVar);
                    if (!c10.b() || !N8.a.r(c10.a().longValue())) {
                        n10 = 300;
                    } else {
                        n10 = c10.a().longValue();
                    }
                } else {
                    aVar.f36981c.d(eVar.a().longValue(), "com.google.firebase.perf.TraceEventCountForeground");
                    n10 = eVar.a().longValue();
                }
            } else {
                n10 = aVar.n();
            }
            long j11 = n10;
            TimeUnit timeUnit = TimeUnit.SECONDS;
            this.f38380e = new g(j11, j10, timeUnit);
            this.f38382g = j11;
            if (str == "Trace") {
                o11 = aVar.o();
            } else {
                o11 = aVar.o();
            }
            long j12 = o11;
            long c11 = c(aVar, str);
            this.f38381f = new g(c11, j12, timeUnit);
            this.f38383h = c11;
        }

        /* JADX WARNING: type inference failed for: r0v5, types: [java.lang.Object, N8.s] */
        public static long c(N8.a aVar, String str) {
            s sVar;
            if (str != "Trace") {
                return aVar.m();
            }
            aVar.getClass();
            synchronized (s.class) {
                try {
                    if (s.f37000i == null) {
                        s.f37000i = new Object();
                    }
                    sVar = s.f37000i;
                } catch (Throwable th) {
                    while (true) {
                        throw th;
                    }
                }
            }
            RemoteConfigManager remoteConfigManager = aVar.f36979a;
            sVar.getClass();
            e<Long> eVar = remoteConfigManager.getLong("fpr_rl_trace_event_count_bg");
            if (!eVar.b() || !N8.a.r(eVar.a().longValue())) {
                e<Long> c10 = aVar.c(sVar);
                if (!c10.b() || !N8.a.r(c10.a().longValue())) {
                    return 30;
                }
                return c10.a().longValue();
            }
            aVar.f36981c.d(eVar.a().longValue(), "com.google.firebase.perf.TraceEventCountBackground");
            return eVar.a().longValue();
        }

        public final synchronized void a(boolean z10) {
            g gVar;
            long j10;
            if (z10) {
                try {
                    gVar = this.f38380e;
                } catch (Throwable th) {
                    while (true) {
                        throw th;
                    }
                }
            } else {
                gVar = this.f38381f;
            }
            this.f38377b = gVar;
            if (z10) {
                j10 = this.f38382g;
            } else {
                j10 = this.f38383h;
            }
            this.f38378c = j10;
        }

        /* JADX WARNING: Removed duplicated region for block: B:15:0x0063 A[Catch:{ all -> 0x0072 }] */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x007c A[Catch:{ all -> 0x0072 }] */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0081 A[DONT_GENERATE] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final synchronized boolean b() {
            /*
                r13 = this;
                monitor-enter(r13)
                W8.i r0 = new W8.i     // Catch:{ all -> 0x0072 }
                r0.<init>()     // Catch:{ all -> 0x0072 }
                W8.i r1 = r13.f38376a     // Catch:{ all -> 0x0072 }
                r1.getClass()     // Catch:{ all -> 0x0072 }
                long r2 = r0.f38551i     // Catch:{ all -> 0x0072 }
                long r4 = r1.f38551i     // Catch:{ all -> 0x0072 }
                long r2 = r2 - r4
                double r1 = (double) r2     // Catch:{ all -> 0x0072 }
                W8.g r3 = r13.f38377b     // Catch:{ all -> 0x0072 }
                r3.getClass()     // Catch:{ all -> 0x0072 }
                int[] r4 = W8.g.a.f38548a     // Catch:{ all -> 0x0072 }
                java.util.concurrent.TimeUnit r5 = r3.f38547c     // Catch:{ all -> 0x0072 }
                int r6 = r5.ordinal()     // Catch:{ all -> 0x0072 }
                r4 = r4[r6]     // Catch:{ all -> 0x0072 }
                long r6 = r3.f38546b     // Catch:{ all -> 0x0072 }
                long r8 = r3.f38545a     // Catch:{ all -> 0x0072 }
                r3 = 1
                r10 = 1
                if (r4 == r3) goto L_0x004e
                r12 = 2
                if (r4 == r12) goto L_0x0044
                r12 = 3
                if (r4 == r12) goto L_0x0037
                double r8 = (double) r8     // Catch:{ all -> 0x0072 }
                long r4 = r5.toSeconds(r6)     // Catch:{ all -> 0x0072 }
                double r4 = (double) r4     // Catch:{ all -> 0x0072 }
                double r8 = r8 / r4
                goto L_0x0058
            L_0x0037:
                double r4 = (double) r8     // Catch:{ all -> 0x0072 }
                double r6 = (double) r6     // Catch:{ all -> 0x0072 }
                double r4 = r4 / r6
                java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ all -> 0x0072 }
                long r6 = r6.toMillis(r10)     // Catch:{ all -> 0x0072 }
            L_0x0040:
                double r6 = (double) r6     // Catch:{ all -> 0x0072 }
                double r8 = r4 * r6
                goto L_0x0058
            L_0x0044:
                double r4 = (double) r8     // Catch:{ all -> 0x0072 }
                double r6 = (double) r6     // Catch:{ all -> 0x0072 }
                double r4 = r4 / r6
                java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ all -> 0x0072 }
                long r6 = r6.toMicros(r10)     // Catch:{ all -> 0x0072 }
                goto L_0x0040
            L_0x004e:
                double r4 = (double) r8     // Catch:{ all -> 0x0072 }
                double r6 = (double) r6     // Catch:{ all -> 0x0072 }
                double r4 = r4 / r6
                java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ all -> 0x0072 }
                long r6 = r6.toNanos(r10)     // Catch:{ all -> 0x0072 }
                goto L_0x0040
            L_0x0058:
                double r1 = r1 * r8
                long r4 = f38375i     // Catch:{ all -> 0x0072 }
                double r4 = (double) r4     // Catch:{ all -> 0x0072 }
                double r1 = r1 / r4
                r4 = 0
                int r4 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
                if (r4 <= 0) goto L_0x0074
                double r4 = r13.f38379d     // Catch:{ all -> 0x0072 }
                double r4 = r4 + r1
                long r1 = r13.f38378c     // Catch:{ all -> 0x0072 }
                double r1 = (double) r1     // Catch:{ all -> 0x0072 }
                double r1 = java.lang.Math.min(r4, r1)     // Catch:{ all -> 0x0072 }
                r13.f38379d = r1     // Catch:{ all -> 0x0072 }
                r13.f38376a = r0     // Catch:{ all -> 0x0072 }
                goto L_0x0074
            L_0x0072:
                r0 = move-exception
                goto L_0x0084
            L_0x0074:
                double r0 = r13.f38379d     // Catch:{ all -> 0x0072 }
                r4 = 4607182418800017408(0x3ff0000000000000, double:1.0)
                int r2 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
                if (r2 < 0) goto L_0x0081
                double r0 = r0 - r4
                r13.f38379d = r0     // Catch:{ all -> 0x0072 }
                monitor-exit(r13)
                return r3
            L_0x0081:
                monitor-exit(r13)
                r0 = 0
                return r0
            L_0x0084:
                monitor-exit(r13)     // Catch:{ all -> 0x0072 }
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: V8.c.a.b():boolean");
        }
    }

    public c(Context context, g gVar) {
        boolean z10;
        b bVar = new b(13);
        double nextDouble = new Random().nextDouble();
        double nextDouble2 = new Random().nextDouble();
        N8.a e10 = N8.a.e();
        boolean z11 = false;
        if (0.0d > nextDouble || nextDouble >= 1.0d) {
            z10 = false;
        } else {
            z10 = true;
        }
        if (z10) {
            if (0.0d <= nextDouble2 && nextDouble2 < 1.0d) {
                z11 = true;
            }
            if (z11) {
                this.f38371b = nextDouble;
                this.f38372c = nextDouble2;
                this.f38370a = e10;
                this.f38373d = new a(gVar, bVar, e10, "Trace");
                this.f38374e = new a(gVar, bVar, e10, "Network");
                j.a(context);
                return;
            }
            throw new IllegalArgumentException("Fragment sampling bucket ID should be in range [0.0, 1.0).");
        }
        throw new IllegalArgumentException("Sampling bucket ID should be in range [0.0, 1.0).");
    }

    public static boolean a(C4277x.d dVar) {
        if (dVar.size() <= 0 || ((k) dVar.get(0)).I() <= 0 || ((k) dVar.get(0)).H() != l.GAUGES_AND_SYSTEM_EVENTS) {
            return false;
        }
        return true;
    }

    /* JADX WARNING: type inference failed for: r2v3, types: [N8.e, java.lang.Object] */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0035, code lost:
        if (N8.a.v(r3) != false) goto L_0x0099;
     */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x009f A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00a1 A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b() {
        /*
            r7 = this;
            N8.a r0 = r7.f38370a
            r0.getClass()
            java.lang.Class<N8.e> r1 = N8.e.class
            monitor-enter(r1)
            N8.e r2 = N8.e.f36985i     // Catch:{ all -> 0x0014 }
            if (r2 != 0) goto L_0x0017
            N8.e r2 = new N8.e     // Catch:{ all -> 0x0014 }
            r2.<init>()     // Catch:{ all -> 0x0014 }
            N8.e.f36985i = r2     // Catch:{ all -> 0x0014 }
            goto L_0x0017
        L_0x0014:
            r0 = move-exception
            goto L_0x00a3
        L_0x0017:
            N8.e r2 = N8.e.f36985i     // Catch:{ all -> 0x0014 }
            monitor-exit(r1)
            W8.e r1 = r0.k(r2)
            boolean r3 = r1.b()
            if (r3 == 0) goto L_0x0038
            java.lang.Object r1 = r1.a()
            java.lang.Double r1 = (java.lang.Double) r1
            double r3 = r1.doubleValue()
            r5 = 4636737291354636288(0x4059000000000000, double:100.0)
            double r3 = r3 / r5
            boolean r1 = N8.a.v(r3)
            if (r1 == 0) goto L_0x0038
            goto L_0x0099
        L_0x0038:
            com.google.firebase.perf.config.RemoteConfigManager r1 = r0.f36979a
            java.lang.String r3 = "fpr_vc_fragment_sampling_rate"
            W8.e r1 = r1.getDouble(r3)
            boolean r3 = r1.b()
            if (r3 == 0) goto L_0x0072
            java.lang.Object r3 = r1.a()
            java.lang.Double r3 = (java.lang.Double) r3
            double r3 = r3.doubleValue()
            boolean r3 = N8.a.v(r3)
            if (r3 == 0) goto L_0x0072
            N8.v r0 = r0.f36981c
            java.lang.String r2 = "com.google.firebase.perf.FragmentSamplingRate"
            java.lang.Object r3 = r1.a()
            java.lang.Double r3 = (java.lang.Double) r3
            double r3 = r3.doubleValue()
            r0.e(r2, r3)
            java.lang.Object r0 = r1.a()
            java.lang.Double r0 = (java.lang.Double) r0
            double r3 = r0.doubleValue()
            goto L_0x0099
        L_0x0072:
            W8.e r0 = r0.b(r2)
            boolean r1 = r0.b()
            if (r1 == 0) goto L_0x0097
            java.lang.Object r1 = r0.a()
            java.lang.Double r1 = (java.lang.Double) r1
            double r1 = r1.doubleValue()
            boolean r1 = N8.a.v(r1)
            if (r1 == 0) goto L_0x0097
            java.lang.Object r0 = r0.a()
            java.lang.Double r0 = (java.lang.Double) r0
            double r3 = r0.doubleValue()
            goto L_0x0099
        L_0x0097:
            r3 = 0
        L_0x0099:
            double r0 = r7.f38372c
            int r0 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
            if (r0 >= 0) goto L_0x00a1
            r0 = 1
            return r0
        L_0x00a1:
            r0 = 0
            return r0
        L_0x00a3:
            monitor-exit(r1)     // Catch:{ all -> 0x0014 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: V8.c.b():boolean");
    }

    /* JADX WARNING: type inference failed for: r2v9, types: [N8.i, java.lang.Object] */
    public final boolean c() {
        N8.i iVar;
        double d10;
        N8.a aVar = this.f38370a;
        aVar.getClass();
        synchronized (N8.i.class) {
            try {
                if (N8.i.f36990i == null) {
                    N8.i.f36990i = new Object();
                }
                iVar = N8.i.f36990i;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        RemoteConfigManager remoteConfigManager = aVar.f36979a;
        iVar.getClass();
        e<Double> eVar = remoteConfigManager.getDouble("fpr_vc_network_request_sampling_rate");
        if (!eVar.b() || !N8.a.v(eVar.a().doubleValue())) {
            e<Double> b10 = aVar.b(iVar);
            if (b10.b() && N8.a.v(b10.a().doubleValue())) {
                d10 = b10.a().doubleValue();
            } else if (aVar.f36979a.isLastFetchFailed()) {
                d10 = 0.001d;
            } else {
                d10 = 1.0d;
            }
        } else {
            aVar.f36981c.e("com.google.firebase.perf.NetworkRequestSamplingRate", eVar.a().doubleValue());
            d10 = eVar.a().doubleValue();
        }
        if (this.f38371b < d10) {
            return true;
        }
        return false;
    }
}
