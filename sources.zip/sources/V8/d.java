package V8;

import X8.g;
import X8.i;

public final /* synthetic */ class d implements Runnable {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ f f38384f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ g f38385i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ X8.d f38386z;

    public /* synthetic */ d(f fVar, g gVar, X8.d dVar) {
        this.f38384f = fVar;
        this.f38385i = gVar;
        this.f38386z = dVar;
    }

    public final void run() {
        f fVar = this.f38384f;
        fVar.getClass();
        i.a L10 = i.L();
        L10.q();
        i.G((i) L10.f40037i, this.f38385i);
        fVar.d(L10, this.f38386z);
    }
}
