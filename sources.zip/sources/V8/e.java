package V8;

import U6.b;
import X8.d;
import X8.h;
import X8.i;

public final /* synthetic */ class e implements Runnable {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ Object f38387E;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f38388f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ Object f38389i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ Object f38390z;

    public /* synthetic */ e(Object obj, Object obj2, Object obj3, int i10) {
        this.f38388f = i10;
        this.f38389i = obj;
        this.f38390z = obj2;
        this.f38387E = obj3;
    }

    public final void run() {
        switch (this.f38388f) {
            case 0:
                f fVar = (f) this.f38389i;
                fVar.getClass();
                i.a L10 = i.L();
                L10.q();
                i.I((i) L10.f40037i, (h) this.f38390z);
                fVar.d(L10, (d) this.f38387E);
                return;
            default:
                ((b) this.f38389i).accept((String) this.f38390z, (com.google.firebase.remoteconfig.internal.b) this.f38387E);
                return;
        }
    }
}
