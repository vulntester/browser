package V8;

import A6.u;
import D1.b;
import D2.C0557h;
import E8.C3895b;
import L8.d;
import M8.a;
import X8.c;
import X8.g;
import X8.h;
import X8.i;
import X8.j;
import X8.m;
import Z7.e;
import android.annotation.SuppressLint;
import android.content.Context;
import j$.util.concurrent.ConcurrentHashMap;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import x.i0;
import x6.C3471g;

public final class f implements a.b {

    /* renamed from: S  reason: collision with root package name */
    public static final P8.a f38391S = P8.a.d();

    /* renamed from: T  reason: collision with root package name */
    public static final f f38392T = new f();

    /* renamed from: E  reason: collision with root package name */
    public e f38393E;

    /* renamed from: F  reason: collision with root package name */
    public d f38394F;

    /* renamed from: G  reason: collision with root package name */
    public F8.f f38395G;

    /* renamed from: H  reason: collision with root package name */
    public C3895b<C3471g> f38396H;

    /* renamed from: I  reason: collision with root package name */
    public a f38397I;

    /* renamed from: J  reason: collision with root package name */
    public final ThreadPoolExecutor f38398J = new ThreadPoolExecutor(0, 1, 10, TimeUnit.SECONDS, new LinkedBlockingQueue());

    /* renamed from: K  reason: collision with root package name */
    public Context f38399K;

    /* renamed from: L  reason: collision with root package name */
    public N8.a f38400L;

    /* renamed from: M  reason: collision with root package name */
    public c f38401M;

    /* renamed from: N  reason: collision with root package name */
    public a f38402N;

    /* renamed from: O  reason: collision with root package name */
    public c.a f38403O;

    /* renamed from: P  reason: collision with root package name */
    public String f38404P;

    /* renamed from: Q  reason: collision with root package name */
    public String f38405Q;

    /* renamed from: R  reason: collision with root package name */
    public boolean f38406R = false;

    /* renamed from: f  reason: collision with root package name */
    public final ConcurrentHashMap f38407f;

    /* renamed from: i  reason: collision with root package name */
    public final ConcurrentLinkedQueue<b> f38408i = new ConcurrentLinkedQueue<>();

    /* renamed from: z  reason: collision with root package name */
    public final AtomicBoolean f38409z = new AtomicBoolean(false);

    @SuppressLint({"ThreadPoolCreation"})
    public f() {
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        this.f38407f = concurrentHashMap;
        concurrentHashMap.put("KEY_AVAILABLE_TRACES_FOR_CACHING", 50);
        concurrentHashMap.put("KEY_AVAILABLE_NETWORK_REQUESTS_FOR_CACHING", 50);
        concurrentHashMap.put("KEY_AVAILABLE_GAUGES_FOR_CACHING", 50);
    }

    public static String a(j jVar) {
        long j10;
        String str;
        if (jVar.g()) {
            m h10 = jVar.h();
            long U10 = h10.U();
            Locale locale = Locale.ENGLISH;
            return b.k("trace metric: ", h10.V(), " (duration: ", new DecimalFormat("#.####").format(((double) U10) / 1000.0d), "ms)");
        } else if (jVar.i()) {
            h j11 = jVar.j();
            if (j11.k0()) {
                j10 = j11.b0();
            } else {
                j10 = 0;
            }
            if (j11.g0()) {
                str = String.valueOf(j11.W());
            } else {
                str = "UNKNOWN";
            }
            Locale locale2 = Locale.ENGLISH;
            String d02 = j11.d0();
            return i0.c(u.o("network request trace: ", d02, " (responseCode: ", str, ", responseTime: "), new DecimalFormat("#.####").format(((double) j10) / 1000.0d), "ms)");
        } else if (!jVar.e()) {
            return "log";
        } else {
            g k10 = jVar.k();
            Locale locale3 = Locale.ENGLISH;
            boolean N3 = k10.N();
            int K10 = k10.K();
            int J5 = k10.J();
            StringBuilder sb2 = new StringBuilder("gauges (hasMetadata: ");
            sb2.append(N3);
            sb2.append(", cpuGaugeCount: ");
            sb2.append(K10);
            sb2.append(", memoryGaugeCount: ");
            return D1.d.d(sb2, J5, ")");
        }
    }

    public final void b(i iVar) {
        if (iVar.g()) {
            this.f38402N.b("_fstec");
        } else if (iVar.i()) {
            this.f38402N.b("_fsntc");
        }
    }

    public final void c(m mVar, X8.d dVar) {
        this.f38398J.execute(new T1.d(this, mVar, dVar, 1));
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v61, resolved type: com.google.protobuf.v$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v15, resolved type: X8.c$a} */
    /* JADX WARNING: type inference failed for: r8v21, types: [N8.u, java.lang.Object] */
    /* JADX WARNING: Code restructure failed: missing block: B:108:0x02ed, code lost:
        if (V8.c.a(r0.h().W()) != false) goto L_0x02f2;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x03c8  */
    /* JADX WARNING: Removed duplicated region for block: B:177:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00fe  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x010b  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x015b  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0163  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0191  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x01a3  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void d(X8.i.a r18, X8.d r19) {
        /*
            r17 = this;
            r1 = r17
            r2 = r18
            r3 = r19
            r4 = 2
            r5 = 0
            r6 = 1
            java.util.concurrent.atomic.AtomicBoolean r0 = r1.f38409z
            boolean r0 = r0.get()
            if (r0 != 0) goto L_0x009b
            j$.util.concurrent.ConcurrentHashMap r0 = r1.f38407f
            java.lang.String r7 = "KEY_AVAILABLE_TRACES_FOR_CACHING"
            java.lang.Object r8 = r0.get(r7)
            java.lang.Integer r8 = (java.lang.Integer) r8
            int r9 = r8.intValue()
            java.lang.String r10 = "KEY_AVAILABLE_NETWORK_REQUESTS_FOR_CACHING"
            java.lang.Object r11 = r0.get(r10)
            java.lang.Integer r11 = (java.lang.Integer) r11
            int r12 = r11.intValue()
            java.lang.String r13 = "KEY_AVAILABLE_GAUGES_FOR_CACHING"
            java.lang.Object r14 = r0.get(r13)
            java.lang.Integer r14 = (java.lang.Integer) r14
            int r15 = r14.intValue()
            boolean r16 = r2.g()
            if (r16 == 0) goto L_0x0048
            if (r9 <= 0) goto L_0x0048
            int r9 = r9 - r6
            java.lang.Integer r4 = java.lang.Integer.valueOf(r9)
            r0.put(r7, r4)
            goto L_0x0069
        L_0x0048:
            boolean r7 = r2.i()
            if (r7 == 0) goto L_0x0059
            if (r12 <= 0) goto L_0x0059
            int r12 = r12 - r6
            java.lang.Integer r4 = java.lang.Integer.valueOf(r12)
            r0.put(r10, r4)
            goto L_0x0069
        L_0x0059:
            boolean r7 = r2.e()
            if (r7 == 0) goto L_0x0083
            if (r15 <= 0) goto L_0x0083
            int r15 = r15 - r6
            java.lang.Integer r4 = java.lang.Integer.valueOf(r15)
            r0.put(r13, r4)
        L_0x0069:
            P8.a r0 = f38391S
            java.lang.String r4 = "Transport is not initialized yet, %s will be queued for to be dispatched later"
            java.lang.String r7 = a(r2)
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r6[r5] = r7
            r0.b(r4, r6)
            java.util.concurrent.ConcurrentLinkedQueue<V8.b> r0 = r1.f38408i
            V8.b r4 = new V8.b
            r4.<init>(r2, r3)
            r0.add(r4)
            return
        L_0x0083:
            java.lang.String r0 = a(r2)
            r2 = 4
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r2[r5] = r0
            r2[r6] = r8
            r2[r4] = r11
            r0 = 3
            r2[r0] = r14
            P8.a r0 = f38391S
            java.lang.String r3 = "%s is not allowed to cache. Cache exhausted the limit (availableTracesForCaching: %d, availableNetworkRequestsForCaching: %d, availableGaugesForCaching: %d)."
            r0.b(r3, r2)
            return
        L_0x009b:
            P8.a r7 = f38391S
            N8.a r0 = r1.f38400L
            boolean r0 = r0.u()
            if (r0 == 0) goto L_0x0110
            X8.c$a r0 = r1.f38403O
            MessageType r0 = r0.f40037i
            X8.c r0 = (X8.c) r0
            boolean r0 = r0.N()
            if (r0 == 0) goto L_0x00b6
            boolean r0 = r1.f38406R
            if (r0 != 0) goto L_0x00b6
            goto L_0x0110
        L_0x00b6:
            F8.f r0 = r1.f38395G     // Catch:{ ExecutionException -> 0x00cc, InterruptedException -> 0x00ca, TimeoutException -> 0x00c8 }
            j7.y r0 = r0.getId()     // Catch:{ ExecutionException -> 0x00cc, InterruptedException -> 0x00ca, TimeoutException -> 0x00c8 }
            java.util.concurrent.TimeUnit r8 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ ExecutionException -> 0x00cc, InterruptedException -> 0x00ca, TimeoutException -> 0x00c8 }
            r9 = 60000(0xea60, double:2.9644E-319)
            java.lang.Object r0 = j7.m.b(r0, r9, r8)     // Catch:{ ExecutionException -> 0x00cc, InterruptedException -> 0x00ca, TimeoutException -> 0x00c8 }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ ExecutionException -> 0x00cc, InterruptedException -> 0x00ca, TimeoutException -> 0x00c8 }
            goto L_0x00f8
        L_0x00c8:
            r0 = move-exception
            goto L_0x00ce
        L_0x00ca:
            r0 = move-exception
            goto L_0x00dc
        L_0x00cc:
            r0 = move-exception
            goto L_0x00ea
        L_0x00ce:
            java.lang.String r0 = r0.getMessage()
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r0
            java.lang.String r0 = "Task to retrieve Installation Id is timed out: %s"
            r7.c(r0, r8)
            goto L_0x00f7
        L_0x00dc:
            java.lang.String r0 = r0.getMessage()
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r0
            java.lang.String r0 = "Task to retrieve Installation Id is interrupted: %s"
            r7.c(r0, r8)
            goto L_0x00f7
        L_0x00ea:
            java.lang.String r0 = r0.getMessage()
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r0
            java.lang.String r0 = "Unable to retrieve Installation Id: %s"
            r7.c(r0, r8)
        L_0x00f7:
            r0 = 0
        L_0x00f8:
            boolean r8 = android.text.TextUtils.isEmpty(r0)
            if (r8 != 0) goto L_0x010b
            X8.c$a r7 = r1.f38403O
            r7.q()
            MessageType r7 = r7.f40037i
            X8.c r7 = (X8.c) r7
            X8.c.I(r7, r0)
            goto L_0x0110
        L_0x010b:
            java.lang.String r0 = "Firebase Installation Id is empty, contact Firebase Support for debugging."
            r7.f(r0)
        L_0x0110:
            X8.c$a r0 = r1.f38403O
            r0.q()
            MessageType r7 = r0.f40037i
            X8.c r7 = (X8.c) r7
            X8.c.G(r7, r3)
            boolean r3 = r2.g()
            if (r3 != 0) goto L_0x0128
            boolean r3 = r2.i()
            if (r3 == 0) goto L_0x0173
        L_0x0128:
            com.google.protobuf.v$f r3 = com.google.protobuf.C4275v.f.f40040F
            MessageType r7 = r0.f40036f
            java.lang.Object r3 = r7.t(r3)
            com.google.protobuf.v$a r3 = (com.google.protobuf.C4275v.a) r3
            com.google.protobuf.v r0 = r0.p()
            r3.f40037i = r0
            r0 = r3
            X8.c$a r0 = (X8.c.a) r0
            L8.d r3 = r1.f38394F
            if (r3 != 0) goto L_0x0157
            java.util.concurrent.atomic.AtomicBoolean r3 = r1.f38409z
            boolean r3 = r3.get()
            if (r3 == 0) goto L_0x0157
            P8.a r3 = L8.d.f36611g
            Z7.e r3 = Z7.e.c()
            java.lang.Class<L8.d> r7 = L8.d.class
            java.lang.Object r3 = r3.b(r7)
            L8.d r3 = (L8.d) r3
            r1.f38394F = r3
        L_0x0157:
            L8.d r3 = r1.f38394F
            if (r3 == 0) goto L_0x0163
            java.util.HashMap r7 = new java.util.HashMap
            j$.util.concurrent.ConcurrentHashMap r3 = r3.f36612a
            r7.<init>(r3)
            goto L_0x0165
        L_0x0163:
            java.util.Map r7 = java.util.Collections.EMPTY_MAP
        L_0x0165:
            r0.q()
            MessageType r3 = r0.f40037i
            X8.c r3 = (X8.c) r3
            com.google.protobuf.J r3 = X8.c.H(r3)
            r3.putAll(r7)
        L_0x0173:
            r2.q()
            MessageType r3 = r2.f40037i
            X8.i r3 = (X8.i) r3
            com.google.protobuf.v r0 = r0.Q()
            X8.c r0 = (X8.c) r0
            X8.i.F(r3, r0)
            com.google.protobuf.v r0 = r2.Q()
            X8.i r0 = (X8.i) r0
            N8.a r2 = r1.f38400L
            boolean r2 = r2.u()
            if (r2 != 0) goto L_0x01a3
            P8.a r2 = f38391S
            java.lang.String r3 = "Performance collection is not enabled, dropping %s"
            java.lang.String r7 = a(r0)
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r7
            r2.e(r3, r8)
        L_0x01a0:
            r2 = r5
            goto L_0x03c6
        L_0x01a3:
            X8.c r2 = r0.J()
            boolean r2 = r2.N()
            if (r2 != 0) goto L_0x01bd
            P8.a r2 = f38391S
            java.lang.String r3 = "App Instance ID is null or empty, dropping %s"
            java.lang.String r7 = a(r0)
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r7
            r2.g(r3, r8)
            goto L_0x01a0
        L_0x01bd:
            android.content.Context r2 = r1.f38399K
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            boolean r7 = r0.g()
            if (r7 == 0) goto L_0x01d6
            R8.d r7 = new R8.d
            X8.m r8 = r0.h()
            r7.<init>(r8)
            r3.add(r7)
        L_0x01d6:
            boolean r7 = r0.i()
            if (r7 == 0) goto L_0x01e8
            R8.c r7 = new R8.c
            X8.h r8 = r0.j()
            r7.<init>(r8, r2)
            r3.add(r7)
        L_0x01e8:
            boolean r2 = r0.K()
            if (r2 == 0) goto L_0x01fa
            R8.a r2 = new R8.a
            X8.c r7 = r0.J()
            r2.<init>(r7)
            r3.add(r2)
        L_0x01fa:
            boolean r2 = r0.e()
            if (r2 == 0) goto L_0x020c
            R8.b r2 = new R8.b
            X8.g r7 = r0.k()
            r2.<init>(r7)
            r3.add(r2)
        L_0x020c:
            boolean r2 = r3.isEmpty()
            if (r2 == 0) goto L_0x021c
            P8.a r2 = P8.a.d()
            java.lang.String r3 = "No validators found for PerfMetric."
            r2.a(r3)
            goto L_0x0232
        L_0x021c:
            java.util.Iterator r2 = r3.iterator()
        L_0x0220:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0243
            java.lang.Object r3 = r2.next()
            R8.e r3 = (R8.e) r3
            boolean r3 = r3.a()
            if (r3 != 0) goto L_0x0220
        L_0x0232:
            P8.a r2 = f38391S
            java.lang.String r3 = "Unable to process the PerfMetric (%s) due to missing or invalid values. See earlier log statements for additional information on the specific missing/invalid values."
            java.lang.String r7 = a(r0)
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r7
            r2.g(r3, r8)
            goto L_0x01a0
        L_0x0243:
            V8.c r2 = r1.f38401M
            r2.getClass()
            boolean r3 = r0.g()
            if (r3 == 0) goto L_0x02f2
            N8.a r3 = r2.f38370a
            r3.getClass()
            java.lang.Class<N8.u> r7 = N8.u.class
            monitor-enter(r7)
            N8.u r8 = N8.u.f37002i     // Catch:{ all -> 0x0262 }
            if (r8 != 0) goto L_0x0265
            N8.u r8 = new N8.u     // Catch:{ all -> 0x0262 }
            r8.<init>()     // Catch:{ all -> 0x0262 }
            N8.u.f37002i = r8     // Catch:{ all -> 0x0262 }
            goto L_0x0265
        L_0x0262:
            r0 = move-exception
            goto L_0x02f0
        L_0x0265:
            N8.u r8 = N8.u.f37002i     // Catch:{ all -> 0x0262 }
            monitor-exit(r7)
            com.google.firebase.perf.config.RemoteConfigManager r7 = r3.f36979a
            r8.getClass()
            java.lang.String r9 = "fpr_vc_trace_sampling_rate"
            W8.e r7 = r7.getDouble(r9)
            boolean r9 = r7.b()
            if (r9 == 0) goto L_0x02a5
            java.lang.Object r9 = r7.a()
            java.lang.Double r9 = (java.lang.Double) r9
            double r9 = r9.doubleValue()
            boolean r9 = N8.a.v(r9)
            if (r9 == 0) goto L_0x02a5
            N8.v r3 = r3.f36981c
            java.lang.String r8 = "com.google.firebase.perf.TraceSamplingRate"
            java.lang.Object r9 = r7.a()
            java.lang.Double r9 = (java.lang.Double) r9
            double r9 = r9.doubleValue()
            r3.e(r8, r9)
            java.lang.Object r3 = r7.a()
            java.lang.Double r3 = (java.lang.Double) r3
            double r7 = r3.doubleValue()
            goto L_0x02da
        L_0x02a5:
            W8.e r7 = r3.b(r8)
            boolean r8 = r7.b()
            if (r8 == 0) goto L_0x02ca
            java.lang.Object r8 = r7.a()
            java.lang.Double r8 = (java.lang.Double) r8
            double r8 = r8.doubleValue()
            boolean r8 = N8.a.v(r8)
            if (r8 == 0) goto L_0x02ca
            java.lang.Object r3 = r7.a()
            java.lang.Double r3 = (java.lang.Double) r3
            double r7 = r3.doubleValue()
            goto L_0x02da
        L_0x02ca:
            com.google.firebase.perf.config.RemoteConfigManager r3 = r3.f36979a
            boolean r3 = r3.isLastFetchFailed()
            if (r3 == 0) goto L_0x02d8
            r7 = 4562254508917369340(0x3f50624dd2f1a9fc, double:0.001)
            goto L_0x02da
        L_0x02d8:
            r7 = 4607182418800017408(0x3ff0000000000000, double:1.0)
        L_0x02da:
            double r9 = r2.f38371b
            int r3 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r3 >= 0) goto L_0x02e1
            goto L_0x02f2
        L_0x02e1:
            X8.m r3 = r0.h()
            com.google.protobuf.x$d r3 = r3.W()
            boolean r3 = V8.c.a(r3)
            if (r3 != 0) goto L_0x02f2
            goto L_0x0341
        L_0x02f0:
            monitor-exit(r7)     // Catch:{ all -> 0x0262 }
            throw r0
        L_0x02f2:
            boolean r3 = r0.g()
            if (r3 == 0) goto L_0x0327
            X8.m r3 = r0.h()
            java.lang.String r3 = r3.V()
            java.lang.String r7 = "_st_"
            boolean r3 = r3.startsWith(r7)
            if (r3 == 0) goto L_0x0327
            X8.m r3 = r0.h()
            boolean r3 = r3.O()
            if (r3 == 0) goto L_0x0327
            boolean r3 = r2.b()
            if (r3 != 0) goto L_0x0327
            X8.m r3 = r0.h()
            com.google.protobuf.x$d r3 = r3.W()
            boolean r3 = V8.c.a(r3)
            if (r3 != 0) goto L_0x0327
            goto L_0x0341
        L_0x0327:
            boolean r3 = r0.i()
            if (r3 == 0) goto L_0x0355
            boolean r2 = r2.c()
            if (r2 != 0) goto L_0x0355
            X8.h r2 = r0.j()
            com.google.protobuf.x$d r2 = r2.X()
            boolean r2 = V8.c.a(r2)
            if (r2 != 0) goto L_0x0355
        L_0x0341:
            r1.b(r0)
            P8.a r2 = f38391S
            java.lang.String r3 = "Event dropped due to device sampling - %s"
            java.lang.String r7 = a(r0)
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r7
            r2.e(r3, r8)
            goto L_0x01a0
        L_0x0355:
            V8.c r2 = r1.f38401M
            r2.getClass()
            boolean r3 = r0.g()
            if (r3 == 0) goto L_0x038b
            X8.m r3 = r0.h()
            java.lang.String r3 = r3.V()
            java.lang.String r7 = "_fs"
            boolean r3 = r3.equals(r7)
            if (r3 != 0) goto L_0x0380
            X8.m r3 = r0.h()
            java.lang.String r3 = r3.V()
            java.lang.String r7 = "_bs"
            boolean r3 = r3.equals(r7)
            if (r3 == 0) goto L_0x038b
        L_0x0380:
            X8.m r3 = r0.h()
            int r3 = r3.P()
            if (r3 <= 0) goto L_0x038b
            goto L_0x0391
        L_0x038b:
            boolean r3 = r0.e()
            if (r3 == 0) goto L_0x0393
        L_0x0391:
            r2 = r5
            goto L_0x03af
        L_0x0393:
            boolean r3 = r0.i()
            if (r3 == 0) goto L_0x03a1
            V8.c$a r2 = r2.f38374e
            boolean r2 = r2.b()
        L_0x039f:
            r2 = r2 ^ r6
            goto L_0x03af
        L_0x03a1:
            boolean r3 = r0.g()
            if (r3 == 0) goto L_0x03ae
            V8.c$a r2 = r2.f38373d
            boolean r2 = r2.b()
            goto L_0x039f
        L_0x03ae:
            r2 = r6
        L_0x03af:
            if (r2 == 0) goto L_0x03c5
            r1.b(r0)
            P8.a r2 = f38391S
            java.lang.String r3 = "Rate limited (per device) - %s"
            java.lang.String r7 = a(r0)
            java.lang.Object[] r8 = new java.lang.Object[r6]
            r8[r5] = r7
            r2.e(r3, r8)
            goto L_0x01a0
        L_0x03c5:
            r2 = r6
        L_0x03c6:
            if (r2 == 0) goto L_0x048c
            boolean r2 = r0.g()
            P8.a r3 = f38391S
            if (r2 == 0) goto L_0x0431
            java.lang.String r2 = a(r0)
            X8.m r7 = r0.h()
            java.lang.String r7 = r7.V()
            java.lang.String r8 = "_st_"
            boolean r8 = r7.startsWith(r8)
            java.lang.String r9 = "?utm_source=perf-android-sdk&utm_medium=android-ide"
            if (r8 == 0) goto L_0x0406
            java.lang.String r8 = r1.f38405Q
            java.lang.String r10 = r1.f38404P
            java.lang.String r8 = A.o.H(r8, r10)
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            r10.append(r8)
            java.lang.String r8 = "/troubleshooting/trace/SCREEN_TRACE/"
            r10.append(r8)
            r10.append(r7)
            r10.append(r9)
            java.lang.String r7 = r10.toString()
            goto L_0x0425
        L_0x0406:
            java.lang.String r8 = r1.f38405Q
            java.lang.String r10 = r1.f38404P
            java.lang.String r8 = A.o.H(r8, r10)
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            r10.append(r8)
            java.lang.String r8 = "/troubleshooting/trace/DURATION_TRACE/"
            r10.append(r8)
            r10.append(r7)
            r10.append(r9)
            java.lang.String r7 = r10.toString()
        L_0x0425:
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r4[r5] = r2
            r4[r6] = r7
            java.lang.String r2 = "Logging %s. In a minute, visit the Firebase console to view your data: %s"
            r3.e(r2, r4)
            goto L_0x043e
        L_0x0431:
            java.lang.String r2 = a(r0)
            java.lang.Object[] r4 = new java.lang.Object[r6]
            r4[r5] = r2
            java.lang.String r2 = "Logging %s"
            r3.e(r2, r4)
        L_0x043e:
            V8.a r2 = r1.f38397I
            x6.f<X8.i> r3 = r2.f38367c
            P8.a r4 = V8.a.f38364d
            if (r3 != 0) goto L_0x046a
            E8.b<x6.g> r3 = r2.f38366b
            java.lang.Object r3 = r3.get()
            x6.g r3 = (x6.C3471g) r3
            if (r3 == 0) goto L_0x0465
            x6.b r7 = new x6.b
            java.lang.String r8 = "proto"
            r7.<init>(r8)
            L8.b r8 = new L8.b
            r8.<init>(r6)
            java.lang.String r6 = r2.f38365a
            A6.v r3 = r3.a(r6, r7, r8)
            r2.f38367c = r3
            goto L_0x046a
        L_0x0465:
            java.lang.String r3 = "Flg TransportFactory is not available at the moment"
            r4.f(r3)
        L_0x046a:
            x6.f<X8.i> r2 = r2.f38367c
            if (r2 == 0) goto L_0x0480
            x6.a r3 = new x6.a
            x6.d r4 = x6.C3468d.f30610f
            r3.<init>(r0, r4)
            A6.v r2 = (A6.v) r2
            A6.u r0 = new A6.u
            r0.<init>(r5)
            r2.a(r3, r0)
            goto L_0x0485
        L_0x0480:
            java.lang.String r0 = "Unable to dispatch event because Flg Transport is not available"
            r4.f(r0)
        L_0x0485:
            com.google.firebase.perf.session.SessionManager r0 = com.google.firebase.perf.session.SessionManager.getInstance()
            r0.stopGaugeCollectionIfSessionRunningTooLong()
        L_0x048c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: V8.f.d(X8.i$a, X8.d):void");
    }

    public final void onUpdateAppState(X8.d dVar) {
        boolean z10;
        if (dVar == X8.d.FOREGROUND) {
            z10 = true;
        } else {
            z10 = false;
        }
        this.f38406R = z10;
        if (this.f38409z.get()) {
            this.f38398J.execute(new C0557h(this, 4));
        }
    }
}
