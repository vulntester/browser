package V9;

import Na.l;
import ic.C4521q;
import kotlin.jvm.internal.n;
import retrofit2.Call;
import xa.C4959D;

public final class a extends n implements l<Throwable, C4959D> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C4521q f38410f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ Call f38411i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(C4521q qVar, Call call) {
        super(1);
        this.f38410f = qVar;
        this.f38411i = call;
    }

    public final Object invoke(Object obj) {
        Throwable th = (Throwable) obj;
        if (this.f38410f.isCancelled()) {
            this.f38411i.cancel();
        }
        return C4959D.f44058a;
    }
}
