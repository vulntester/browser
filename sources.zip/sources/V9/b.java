package V9;

import ic.C4521q;
import kotlin.jvm.internal.l;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.HttpException;
import retrofit2.Response;
import xa.C4966f;

public final class b implements Callback<Object> {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C4521q f38412a;

    public b(C4521q qVar) {
        this.f38412a = qVar;
    }

    public final void onFailure(Call<Object> call, Throwable th) {
        l.g(call, "call");
        l.g(th, "t");
        this.f38412a.d(th);
    }

    public final void onResponse(Call<Object> call, Response<Object> response) {
        l.g(call, "call");
        l.g(response, "response");
        boolean isSuccessful = response.isSuccessful();
        C4521q qVar = this.f38412a;
        if (isSuccessful) {
            Object body = response.body();
            if (body != null) {
                qVar.R(body);
                return;
            }
            C4966f fVar = new C4966f();
            l.j(fVar, l.class.getName());
            throw fVar;
        }
        qVar.d(new HttpException(response));
    }
}
