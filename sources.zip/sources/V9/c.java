package V9;

import ic.C4496c0;
import ic.C4521q;
import ic.J;
import java.lang.annotation.Annotation;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import kotlin.jvm.internal.l;
import retrofit2.Call;
import retrofit2.CallAdapter;
import retrofit2.Response;
import retrofit2.Retrofit;

public final class c extends CallAdapter.Factory {

    public static final class a<T> implements CallAdapter<T, J<? extends T>> {

        /* renamed from: a  reason: collision with root package name */
        public final Type f38413a;

        public a(Type type) {
            this.f38413a = type;
        }

        public final Object adapt(Call call) {
            l.g(call, "call");
            C4521q a10 = C4496c0.a();
            a10.C(new a(a10, call));
            call.enqueue(new b(a10));
            return a10;
        }

        public final Type responseType() {
            return this.f38413a;
        }
    }

    public static final class b<T> implements CallAdapter<T, J<? extends Response<T>>> {

        /* renamed from: a  reason: collision with root package name */
        public final Type f38414a;

        public b(Type type) {
            this.f38414a = type;
        }

        public final Object adapt(Call call) {
            l.g(call, "call");
            C4521q a10 = C4496c0.a();
            a10.C(new d(a10, call));
            call.enqueue(new e(a10));
            return a10;
        }

        public final Type responseType() {
            return this.f38414a;
        }
    }

    public final CallAdapter<?, ?> get(Type type, Annotation[] annotationArr, Retrofit retrofit) {
        l.g(type, "returnType");
        l.g(annotationArr, "annotations");
        l.g(retrofit, "retrofit");
        if (!J.class.equals(CallAdapter.Factory.getRawType(type))) {
            return null;
        }
        if (type instanceof ParameterizedType) {
            Type parameterUpperBound = CallAdapter.Factory.getParameterUpperBound(0, (ParameterizedType) type);
            if (!l.a(CallAdapter.Factory.getRawType(parameterUpperBound), Response.class)) {
                l.b(parameterUpperBound, "responseType");
                return new a(parameterUpperBound);
            } else if (parameterUpperBound instanceof ParameterizedType) {
                Type parameterUpperBound2 = CallAdapter.Factory.getParameterUpperBound(0, (ParameterizedType) parameterUpperBound);
                l.b(parameterUpperBound2, "getParameterUpperBound(0, responseType)");
                return new b(parameterUpperBound2);
            } else {
                throw new IllegalStateException("Response must be parameterized as Response<Foo> or Response<out Foo>");
            }
        } else {
            throw new IllegalStateException("Deferred return type must be parameterized as Deferred<Foo> or Deferred<out Foo>");
        }
    }
}
