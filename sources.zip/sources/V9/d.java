package V9;

import Na.l;
import ic.C4521q;
import kotlin.jvm.internal.n;
import retrofit2.Call;
import xa.C4959D;

public final class d extends n implements l<Throwable, C4959D> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C4521q f38415f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ Call f38416i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(C4521q qVar, Call call) {
        super(1);
        this.f38415f = qVar;
        this.f38416i = call;
    }

    public final Object invoke(Object obj) {
        Throwable th = (Throwable) obj;
        if (this.f38415f.isCancelled()) {
            this.f38416i.cancel();
        }
        return C4959D.f44058a;
    }
}
