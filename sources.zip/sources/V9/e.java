package V9;

import ic.C4521q;
import kotlin.jvm.internal.l;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class e implements Callback<Object> {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C4521q f38417a;

    public e(C4521q qVar) {
        this.f38417a = qVar;
    }

    public final void onFailure(Call<Object> call, Throwable th) {
        l.g(call, "call");
        l.g(th, "t");
        this.f38417a.d(th);
    }

    public final void onResponse(Call<Object> call, Response<Object> response) {
        l.g(call, "call");
        l.g(response, "response");
        this.f38417a.R(response);
    }
}
