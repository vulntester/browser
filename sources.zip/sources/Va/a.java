package Va;

import com.google.android.gms.common.internal.C1438n;

public class a extends Exception {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(String str) {
        super(str);
        C1438n.e(str, "Detail message must not be empty");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(String str, Throwable th) {
        super(str, th);
        C1438n.e(str, "Detail message must not be empty");
    }
}
