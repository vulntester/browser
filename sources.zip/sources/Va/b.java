package Va;

public final class b extends Exception {
}
