package Va;

import Ua.d;
import Ua.g;
import java.util.ArrayList;
import kotlin.jvm.internal.l;

public final class c {
    public static final ArrayList a(d dVar) {
        l.f(dVar, "<this>");
        ArrayList arrayList = new ArrayList();
        for (Object next : dVar.q()) {
            if (next instanceof g) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }
}
