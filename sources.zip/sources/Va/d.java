package Va;

import Tb.C;
import Tb.C4154z;
import Tb.N;
import Tb.W;
import Tb.Y;
import Tb.e0;
import Tb.o0;
import Ua.e;
import Ua.q;
import Ua.r;
import Ub.f;
import Xa.C4189v;
import Xa.O;
import Xa.S;
import db.C4318h;
import db.c0;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;
import ya.n;

public final class d {

    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f38418a;

        /* JADX WARNING: Can't wrap try/catch for region: R(9:0|(2:1|2)|3|5|6|7|8|9|11) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0012 */
        static {
            /*
                Ua.r[] r0 = Ua.r.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                r1 = 1
                Ua.r r2 = Ua.r.f38196f     // Catch:{ NoSuchFieldError -> 0x000d }
                r2 = 0
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x000d }
            L_0x000d:
                r2 = 2
                Ua.r r3 = Ua.r.f38196f     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                Ua.r r1 = Ua.r.f38196f     // Catch:{ NoSuchFieldError -> 0x0017 }
                r1 = 3
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0017 }
            L_0x0017:
                f38418a = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: Va.d.a.<clinit>():void");
        }
    }

    public static final O a(e eVar, List list, boolean z10, List list2) {
        C4189v vVar;
        C4318h descriptor;
        W w10;
        C4154z zVar;
        int i10;
        Object obj;
        l.f(eVar, "<this>");
        l.f(list, "arguments");
        l.f(list2, "annotations");
        if (eVar instanceof C4189v) {
            vVar = (C4189v) eVar;
        } else {
            vVar = null;
        }
        if (vVar == null || (descriptor = vVar.getDescriptor()) == null) {
            throw new S("Cannot create type for an unsupported classifier: " + eVar + " (" + eVar.getClass() + ')');
        }
        Y h10 = descriptor.h();
        l.e(h10, "getTypeConstructor(...)");
        List<c0> parameters = h10.getParameters();
        l.e(parameters, "getParameters(...)");
        if (parameters.size() == list.size()) {
            if (list2.isEmpty()) {
                W.f38074i.getClass();
                w10 = W.f38075z;
            } else {
                W.f38074i.getClass();
                w10 = W.f38075z;
            }
            List<c0> parameters2 = h10.getParameters();
            l.e(parameters2, "getParameters(...)");
            ArrayList arrayList = new ArrayList(n.v(10, list));
            int i11 = 0;
            for (Object next : list) {
                int i12 = i11 + 1;
                if (i11 >= 0) {
                    q qVar = (q) next;
                    O o10 = (O) qVar.f38193b;
                    if (o10 != null) {
                        zVar = o10.f38720f;
                    } else {
                        zVar = null;
                    }
                    r rVar = qVar.f38192a;
                    if (rVar == null) {
                        i10 = -1;
                    } else {
                        i10 = a.f38418a[rVar.ordinal()];
                    }
                    if (i10 == -1) {
                        c0 c0Var = parameters2.get(i11);
                        l.e(c0Var, "get(...)");
                        obj = new N(c0Var);
                    } else if (i10 == 1) {
                        o0 o0Var = o0.INVARIANT;
                        l.c(zVar);
                        obj = new e0(zVar, o0Var);
                    } else if (i10 == 2) {
                        o0 o0Var2 = o0.IN_VARIANCE;
                        l.c(zVar);
                        obj = new e0(zVar, o0Var2);
                    } else if (i10 == 3) {
                        o0 o0Var3 = o0.OUT_VARIANCE;
                        l.c(zVar);
                        obj = new e0(zVar, o0Var3);
                    } else {
                        throw new RuntimeException();
                    }
                    arrayList.add(obj);
                    i11 = i12;
                } else {
                    n.C();
                    throw null;
                }
            }
            return new O(C.c(w10, h10, arrayList, z10, (f) null), (Na.a<? extends Type>) null);
        }
        throw new IllegalArgumentException("Class declares " + parameters.size() + " type parameters, but " + list.size() + " were provided.");
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.util.List, ya.u] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ Xa.O b(Ua.d r1, java.util.ArrayList r2, int r3) {
        /*
            r3 = r3 & 1
            ya.u r0 = ya.u.f44685f
            if (r3 == 0) goto L_0x0007
            r2 = r0
        L_0x0007:
            r3 = 0
            Xa.O r1 = a(r1, r2, r3, r0)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: Va.d.b(Ua.d, java.util.ArrayList, int):Xa.O");
    }
}
