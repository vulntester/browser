package Y2;

import R2.B;
import R2.C1013i;
import R2.E;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import java.util.List;
import o2.t;

public final class a implements n {

    /* renamed from: a  reason: collision with root package name */
    public final t f11897a = new t(4);

    /* renamed from: b  reason: collision with root package name */
    public final E f11898b = new E(-1, -1, "image/heif");

    public final void a(long j10, long j11) {
        this.f11898b.a(j10, j11);
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f11898b.d(pVar);
    }

    public final boolean g(o oVar) {
        C1013i iVar = (C1013i) oVar;
        iVar.b(4, false);
        t tVar = this.f11897a;
        tVar.D(4);
        iVar.l(tVar.f25885a, 0, 4, false);
        if (tVar.w() == ((long) 1718909296)) {
            tVar.D(4);
            iVar.l(tVar.f25885a, 0, 4, false);
            if (tVar.w() == ((long) 1751476579)) {
                return true;
            }
        }
        return false;
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    public final int i(o oVar, B b10) {
        return this.f11898b.i(oVar, b10);
    }

    public final void release() {
    }
}
