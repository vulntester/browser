package Y3;

import android.os.Trace;

public final class b {
    public static boolean a() {
        return Trace.isEnabled();
    }
}
