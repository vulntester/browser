package Y4;

public interface a {
}
