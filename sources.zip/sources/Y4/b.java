package Y4;

import N5.f;
import Na.a;
import Z5.e;
import com.browser.App;

public final /* synthetic */ class b implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11901f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11902i;

    public /* synthetic */ b(l lVar, int i10) {
        this.f11901f = i10;
        this.f11902i = lVar;
    }

    public final Object invoke() {
        switch (this.f11901f) {
            case 0:
                return new e(this.f11902i.f11923a);
            default:
                l lVar = this.f11902i;
                App app = lVar.f11923a;
                e k10 = lVar.k();
                return new f(lVar.h(), k10, lVar.n(), lVar.l(), app);
        }
    }
}
