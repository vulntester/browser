package Y4;

import Na.a;
import O3.k;
import O3.l;
import com.browser.App;
import com.common.components.database.AppDatabase;
import f6.C2287d;
import kotlin.jvm.internal.l;
import xa.C4959D;

public final /* synthetic */ class c implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11903f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11904i;

    public /* synthetic */ c(l lVar, int i10) {
        this.f11903f = i10;
        this.f11904i = lVar;
    }

    public final Object invoke() {
        switch (this.f11903f) {
            case 0:
                App app = this.f11904i.f11923a;
                if (C2287d.f21265i == null) {
                    synchronized (C2287d.class) {
                        try {
                            if (C2287d.f21265i == null) {
                                C2287d.f21265i = new C2287d(app);
                            }
                            C4959D d10 = C4959D.f44058a;
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                }
                C2287d dVar = C2287d.f21265i;
                l.c(dVar);
                return dVar;
            default:
                l.a<AppDatabase> a10 = k.a(this.f11904i.f11923a, AppDatabase.class, "app_database");
                a10.f6823l = false;
                a10.f6824m = true;
                return a10.b();
        }
    }
}
