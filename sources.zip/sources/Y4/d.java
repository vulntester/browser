package Y4;

import Na.a;
import com.common.components.database.AppDatabase;

public final /* synthetic */ class d implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11905f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11906i;

    public /* synthetic */ d(l lVar, int i10) {
        this.f11905f = i10;
        this.f11906i = lVar;
    }

    public final Object invoke() {
        switch (this.f11905f) {
            case 0:
                l lVar = this.f11906i;
                return new G5.d(lVar.f11923a, lVar.j(), lVar.d());
            default:
                return ((AppDatabase) this.f11906i.f11933k.getValue()).p();
        }
    }
}
