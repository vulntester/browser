package Y4;

import Na.a;
import U5.b;
import com.common.components.database.AppDatabase;
import h6.C2479i;

public final /* synthetic */ class e implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11907f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11908i;

    public /* synthetic */ e(l lVar, int i10) {
        this.f11907f = i10;
        this.f11908i = lVar;
    }

    public final Object invoke() {
        switch (this.f11907f) {
            case 0:
                b bVar = new b();
                l lVar = this.f11908i;
                l lVar2 = lVar;
                l lVar3 = lVar2;
                l lVar4 = lVar3;
                l lVar5 = lVar4;
                l lVar6 = lVar5;
                return new C2479i(lVar.f11923a, lVar2.k(), new k(lVar3, (Ba.e<? super k>) null), lVar4.h(), lVar5.d(), lVar6.l(), lVar6.m(), new j(bVar, 0));
            default:
                return ((AppDatabase) this.f11908i.f11933k.getValue()).s();
        }
    }
}
