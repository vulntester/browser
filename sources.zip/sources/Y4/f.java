package Y4;

import N5.g;
import Na.a;
import a6.C1285a;
import com.common.components.database.AppDatabase;

public final /* synthetic */ class f implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11909f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11910i;

    public /* synthetic */ f(l lVar, int i10) {
        this.f11909f = i10;
        this.f11910i = lVar;
    }

    public final Object invoke() {
        switch (this.f11909f) {
            case 0:
                return new g(this.f11910i.k());
            default:
                return new C1285a(((AppDatabase) this.f11910i.f11933k.getValue()).r());
        }
    }
}
