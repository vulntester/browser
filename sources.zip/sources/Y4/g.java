package Y4;

import Na.a;
import P5.v;
import Y5.c;
import q6.C3002n;

public final /* synthetic */ class g implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11911f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11912i;

    public /* synthetic */ g(l lVar, int i10) {
        this.f11911f = i10;
        this.f11912i = lVar;
    }

    public final Object invoke() {
        switch (this.f11911f) {
            case 0:
                l lVar = this.f11912i;
                return new C3002n(lVar.d(), lVar.f(), lVar.h());
            default:
                l lVar2 = this.f11912i;
                return new c((v) lVar2.f11935m.getValue(), lVar2.m(), lVar2.k());
        }
    }
}
