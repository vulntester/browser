package Y4;

import Na.a;
import P5.I;
import Z5.g;
import s6.C3074a;

public final /* synthetic */ class h implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11913f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11914i;

    public /* synthetic */ h(l lVar, int i10) {
        this.f11913f = i10;
        this.f11914i = lVar;
    }

    public final Object invoke() {
        switch (this.f11913f) {
            case 0:
                return new C3074a(this.f11914i.f11923a);
            default:
                return new g((I) this.f11914i.f11936n.getValue());
        }
    }
}
