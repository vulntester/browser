package Y4;

import E5.f;
import Na.a;
import d6.x;

public final /* synthetic */ class i implements a {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11915f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11916i;

    public /* synthetic */ i(l lVar, int i10) {
        this.f11915f = i10;
        this.f11916i = lVar;
    }

    public final Object invoke() {
        switch (this.f11915f) {
            case 0:
                l lVar = this.f11916i;
                return new x(lVar.f11923a, lVar.k());
            default:
                return new f(this.f11916i.f11923a);
        }
    }
}
