package Y4;

import L.C0866g;
import Na.l;
import U5.a;
import Z5.e;
import android.net.Uri;
import com.internet.tvbrowser.BrowserActivity;
import ic.W;
import io.ktor.client.plugins.HttpRequestLifecycleKt;
import io.ktor.http.CodecsKt;
import io.netty.handler.codec.rtsp.RtspHeaders;
import java.util.Set;
import t9.C4838a;
import wc.C4941a;
import xa.C4959D;

public final /* synthetic */ class j implements l {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11917f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ Object f11918i;

    public /* synthetic */ j(Object obj, int i10) {
        this.f11917f = i10;
        this.f11918i = obj;
    }

    public final Object invoke(Object obj) {
        Object obj2 = this.f11918i;
        switch (this.f11917f) {
            case 0:
                String str = (String) obj;
                kotlin.jvm.internal.l.f(str, RtspHeaders.Values.URL);
                a.C0100a aVar = new a.C0100a(str, false);
                C4838a aVar2 = (C4838a) obj2;
                aVar2.getClass();
                String encode = Uri.encode(aVar.f10497a.toString());
                StringBuilder sb2 = new StringBuilder();
                C0866g.j(sb2, aVar2.f10508a, "/open?url=", encode, "&fullscreen=");
                sb2.append(aVar.f10498b);
                return Uri.parse(sb2.toString());
            case 1:
                N5.l lVar = (N5.l) obj;
                kotlin.jvm.internal.l.f(lVar, "enumVal");
                e eVar = (e) obj2;
                eVar.h(e.f12244P, C0.e.p(lVar));
                return C4959D.f44058a;
            case 2:
                String str2 = (String) obj;
                kotlin.jvm.internal.l.f(str2, "it");
                return Boolean.valueOf(((Set) obj2).contains(str2));
            case 3:
                return HttpRequestLifecycleKt.attachToClientEngineJob$lambda$2((W) obj2, (Throwable) obj);
            case 4:
                return Boolean.valueOf(CodecsKt.forEach$lambda$11((l) obj2, (C4941a) obj));
            default:
                float floatValue = ((Float) obj).floatValue();
                int i10 = BrowserActivity.f40053k0;
                return Float.valueOf(floatValue * ((BrowserActivity) obj2).getResources().getDisplayMetrics().density);
        }
    }
}
