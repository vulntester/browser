package Y4;

import Ca.a;
import Da.e;
import Da.i;
import Na.l;
import h6.C2473c;
import h6.C2475e;
import java.io.Serializable;
import java.util.List;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.browser.di.CustomAppModuleImpl$topSitesTvRecommendations$2$1", f = "CustomAppModule.kt", l = {202}, m = "invokeSuspend")
public final class k extends i implements l<Ba.e<? super List<? extends C2475e>>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public int f11919f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ l f11920i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public k(l lVar, Ba.e<? super k> eVar) {
        super(1, eVar);
        this.f11920i = lVar;
    }

    public final Ba.e<C4959D> create(Ba.e<?> eVar) {
        return new k(this.f11920i, eVar);
    }

    public final Object invoke(Object obj) {
        return ((k) create((Ba.e) obj)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.f33640f;
        int i10 = this.f11919f;
        if (i10 == 0) {
            C4976p.b(obj);
            this.f11919f = 1;
            Serializable a10 = ((C2473c) this.f11920i.f11946x.getValue()).a(this);
            if (a10 == aVar) {
                return aVar;
            }
            return a10;
        } else if (i10 == 1) {
            C4976p.b(obj);
            return obj;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
