package Y4;

import A4.r;
import A9.C3766f;
import A9.y;
import B9.C3782h;
import B9.G;
import B9.L;
import C3.n;
import D4.g;
import E5.f;
import G5.d;
import G5.t;
import L9.c;
import T5.e;
import W5.a;
import c6.C1422b;
import com.browser.App;
import d6.x;
import f6.C2287d;
import s6.C3074a;
import u9.u;
import v9.C4911b;
import xa.C4969i;
import xa.C4978r;

public final class l implements a {

    /* renamed from: A  reason: collision with root package name */
    public final C4978r f11921A = C4969i.e(new f(this, 0));

    /* renamed from: B  reason: collision with root package name */
    public final C4978r f11922B = C4969i.e(new g(this, 0));

    /* renamed from: a  reason: collision with root package name */
    public final App f11923a;

    /* renamed from: b  reason: collision with root package name */
    public final C4978r f11924b = C4969i.e(new b(this, 0));

    /* renamed from: c  reason: collision with root package name */
    public final C4978r f11925c = C4969i.e(new c(this, 0));

    /* renamed from: d  reason: collision with root package name */
    public final C4911b f11926d = new C4911b();

    /* renamed from: e  reason: collision with root package name */
    public final C4978r f11927e = C4969i.e(new h(this, 0));

    /* renamed from: f  reason: collision with root package name */
    public final C4978r f11928f = C4969i.e(new r(4));

    /* renamed from: g  reason: collision with root package name */
    public final C4978r f11929g = C4969i.e(new i(this, 0));

    /* renamed from: h  reason: collision with root package name */
    public final C4978r f11930h = C4969i.e(new C3766f(this, 6));

    /* renamed from: i  reason: collision with root package name */
    public final C4978r f11931i = C4969i.e(new b(this, 1));

    /* renamed from: j  reason: collision with root package name */
    public final C4978r f11932j = C4969i.e(new n(this, 7));

    /* renamed from: k  reason: collision with root package name */
    public final C4978r f11933k = C4969i.e(new c(this, 1));

    /* renamed from: l  reason: collision with root package name */
    public final C4978r f11934l = C4969i.e(new d(this, 1));

    /* renamed from: m  reason: collision with root package name */
    public final C4978r f11935m = C4969i.e(new L(this, 2));

    /* renamed from: n  reason: collision with root package name */
    public final C4978r f11936n = C4969i.e(new e(this, 1));

    /* renamed from: o  reason: collision with root package name */
    public final C4978r f11937o = C4969i.e(new G(this, 4));

    /* renamed from: p  reason: collision with root package name */
    public final C4978r f11938p = C4969i.e(new f(this, 1));

    /* renamed from: q  reason: collision with root package name */
    public final C4978r f11939q = C4969i.e(new g(this, 1));

    /* renamed from: r  reason: collision with root package name */
    public final C4978r f11940r = C4969i.e(new h(this, 1));

    /* renamed from: s  reason: collision with root package name */
    public final C4978r f11941s = C4969i.e(new A9.r(this, 3));

    /* renamed from: t  reason: collision with root package name */
    public final C4978r f11942t = C4969i.e(new c(2));

    /* renamed from: u  reason: collision with root package name */
    public final C4978r f11943u = C4969i.e(new i(this, 1));

    /* renamed from: v  reason: collision with root package name */
    public final C4978r f11944v = C4969i.e(new g(4));

    /* renamed from: w  reason: collision with root package name */
    public final C4978r f11945w = C4969i.e(new d(this, 0));

    /* renamed from: x  reason: collision with root package name */
    public final C4978r f11946x = C4969i.e(new y(this, 5));

    /* renamed from: y  reason: collision with root package name */
    public final C4978r f11947y = C4969i.e(new e(this, 0));

    /* renamed from: z  reason: collision with root package name */
    public final C4978r f11948z = C4969i.e(new C3782h(3));

    public l(App app) {
        this.f11923a = app;
    }

    public final f a() {
        return (f) this.f11943u.getValue();
    }

    public final N5.f b() {
        return (N5.f) this.f11931i.getValue();
    }

    public final N5.g c() {
        return (N5.g) this.f11921A.getValue();
    }

    public final C2287d d() {
        return (C2287d) this.f11925c.getValue();
    }

    public final C3074a e() {
        return (C3074a) this.f11927e.getValue();
    }

    public final d f() {
        return (d) this.f11945w.getValue();
    }

    public final a g() {
        return (a) this.f11937o.getValue();
    }

    public final e h() {
        return (e) this.f11928f.getValue();
    }

    public final Y5.c i() {
        return (Y5.c) this.f11939q.getValue();
    }

    public final t j() {
        return (t) this.f11944v.getValue();
    }

    public final Z5.e k() {
        return (Z5.e) this.f11924b.getValue();
    }

    public final C1422b l() {
        return (C1422b) this.f11941s.getValue();
    }

    public final x m() {
        return (x) this.f11929g.getValue();
    }

    public final Z5.g n() {
        return (Z5.g) this.f11940r.getValue();
    }

    public final u o() {
        return (u) this.f11948z.getValue();
    }

    public final e6.d p() {
        return (e6.d) this.f11930h.getValue();
    }
}
