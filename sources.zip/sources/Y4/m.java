package Y4;

import D1.b;
import Na.a;
import Ua.d;
import androidx.lifecycle.L;
import androidx.lifecycle.N;
import h2.C2457d;
import kotlin.jvm.internal.l;

public final class m implements N.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a<Object> f11949a;

    public m(a<Object> aVar) {
        this.f11949a = aVar;
    }

    public final <T extends L> T a(Class<T> cls) {
        T invoke = this.f11949a.invoke();
        l.d(invoke, "null cannot be cast to non-null type T of com.browser.di.ViewModelFactoryHelperKt.viewModelFactory.<no name provided>.create");
        return (L) invoke;
    }

    public final /* synthetic */ L b(d dVar, C2457d dVar2) {
        return b.c(this, dVar, dVar2);
    }

    public final L c(Class cls, C2457d dVar) {
        return a(cls);
    }
}
