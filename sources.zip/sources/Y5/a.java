package Y5;

import Da.c;
import Da.e;

@e(c = "com.common.components.repository.history.HistoryRepository", f = "HistoryRepository.kt", l = {179}, m = "clearCache")
public final class a extends c {

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f11950f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ c f11951i;

    /* renamed from: z  reason: collision with root package name */
    public int f11952z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(c cVar, c cVar2) {
        super(cVar2);
        this.f11951i = cVar;
    }

    public final Object invokeSuspend(Object obj) {
        this.f11950f = obj;
        this.f11952z |= Integer.MIN_VALUE;
        return this.f11951i.a(this);
    }
}
