package Y5;

import Ca.a;
import Da.e;
import Da.i;
import Na.p;
import ic.C4487C;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.common.components.repository.history.HistoryRepository$clearCache$2", f = "HistoryRepository.kt", l = {}, m = "invokeSuspend")
public final class b extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ c f11953f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public b(c cVar, Ba.e<? super b> eVar) {
        super(2, eVar);
        this.f11953f = cVar;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new b(this.f11953f, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((b) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.f33640f;
        C4976p.b(obj);
        this.f11953f.f11960g = null;
        return C4959D.f44058a;
    }
}
