package Y5;

import A9.C3766f;
import Ba.h;
import Da.e;
import Da.i;
import Na.p;
import P5.v;
import Q5.d;
import V.C1187r0;
import Z5.l;
import d6.x;
import ic.C4487C;
import ic.C4488D;
import ic.C4528y;
import ic.G;
import ic.U;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import nc.C4732d;
import xa.C4959D;
import xa.C4969i;
import xa.C4976p;
import xa.C4978r;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final v f11954a;

    /* renamed from: b  reason: collision with root package name */
    public final x f11955b;

    /* renamed from: c  reason: collision with root package name */
    public final C4732d f11956c = C4488D.a(C4528y.limitedParallelism$default(pc.b.f43037f, 1, (String) null, 2, (Object) null));

    /* renamed from: d  reason: collision with root package name */
    public d f11957d;

    /* renamed from: e  reason: collision with root package name */
    public final C4978r f11958e = C4969i.e(new C3766f(this, 7));

    /* renamed from: f  reason: collision with root package name */
    public final l f11959f;

    /* renamed from: g  reason: collision with root package name */
    public List<d> f11960g;

    /* renamed from: h  reason: collision with root package name */
    public final C1187r0 f11961h;

    @e(c = "com.common.components.repository.history.HistoryRepository$deleteAll$1", f = "HistoryRepository.kt", l = {309}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public int f11962f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ c f11963i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(c cVar, Ba.e<? super a> eVar) {
            super(2, eVar);
            this.f11963i = cVar;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new a(this.f11963i, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            int i10 = this.f11962f;
            if (i10 == 0) {
                C4976p.b(obj);
                c cVar = this.f11963i;
                cVar.f11954a.b();
                d f10 = cVar.f();
                C4732d dVar = f10.f11970c;
                U u7 = U.f41134a;
                G.y(dVar, nc.p.f42446a, new e(f10, (Ba.e<? super e>) null), 2);
                this.f11962f = 1;
                if (cVar.a(this) == aVar) {
                    return aVar;
                }
            } else if (i10 == 1) {
                C4976p.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return C4959D.f44058a;
        }
    }

    @e(c = "com.common.components.repository.history.HistoryRepository$deleteEntry$2", f = "HistoryRepository.kt", l = {337}, m = "invokeSuspend")
    public static final class b extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public int f11964f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ c f11965i;

        /* renamed from: z  reason: collision with root package name */
        public final /* synthetic */ int f11966z;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(c cVar, int i10, Ba.e<? super b> eVar) {
            super(2, eVar);
            this.f11965i = cVar;
            this.f11966z = i10;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new b(this.f11965i, this.f11966z, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((b) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            int i10 = this.f11964f;
            if (i10 == 0) {
                C4976p.b(obj);
                c cVar = this.f11965i;
                cVar.f11954a.g(this.f11966z);
                this.f11964f = 1;
                if (cVar.a(this) == aVar) {
                    return aVar;
                }
            } else if (i10 == 1) {
                C4976p.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return C4959D.f44058a;
        }
    }

    public c(v vVar, x xVar, Z5.e eVar) {
        kotlin.jvm.internal.l.f(vVar, "historyDao");
        kotlin.jvm.internal.l.f(xVar, "serverApi");
        kotlin.jvm.internal.l.f(eVar, "rawAppPrefs");
        this.f11954a = vVar;
        this.f11955b = xVar;
        U u7 = U.f41134a;
        this.f11959f = eVar.f12312p;
        new LinkedHashMap();
        this.f11961h = R1.a.t(-1);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0053  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0067  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object a(Da.c r6) {
        /*
            r5 = this;
            boolean r0 = r6 instanceof Y5.a
            if (r0 == 0) goto L_0x0013
            r0 = r6
            Y5.a r0 = (Y5.a) r0
            int r1 = r0.f11952z
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f11952z = r1
            goto L_0x0018
        L_0x0013:
            Y5.a r0 = new Y5.a
            r0.<init>(r5, r6)
        L_0x0018:
            java.lang.Object r6 = r0.f11950f
            Ca.a r1 = Ca.a.f33640f
            int r2 = r0.f11952z
            r3 = 1
            if (r2 == 0) goto L_0x002f
            if (r2 != r3) goto L_0x0027
            xa.C4976p.b(r6)
            goto L_0x0045
        L_0x0027:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L_0x002f:
            xa.C4976p.b(r6)
            ic.U r6 = ic.U.f41134a
            jc.e r6 = nc.p.f42446a
            Y5.b r2 = new Y5.b
            r4 = 0
            r2.<init>(r5, r4)
            r0.f11952z = r3
            java.lang.Object r6 = ic.G.M(r6, r2, r0)
            if (r6 != r1) goto L_0x0045
            return r1
        L_0x0045:
            V.r0 r6 = r5.f11961h
            java.lang.Object r0 = r6.getValue()
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            if (r0 >= 0) goto L_0x0067
            java.lang.Object r0 = r6.getValue()
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            int r0 = r0 - r3
            java.lang.Integer r1 = new java.lang.Integer
            r1.<init>(r0)
            r6.setValue(r1)
            goto L_0x0070
        L_0x0067:
            java.lang.Integer r0 = new java.lang.Integer
            r1 = -1
            r0.<init>(r1)
            r6.setValue(r0)
        L_0x0070:
            xa.D r6 = xa.C4959D.f44058a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: Y5.c.a(Da.c):java.lang.Object");
    }

    public final void b() {
        this.f11957d = null;
        G.y(this.f11956c, (h) null, new a(this, (Ba.e<? super a>) null), 3);
    }

    public final void c(d dVar) {
        T t10;
        kotlin.jvm.internal.l.f(dVar, "entry");
        List<d> list = this.f11960g;
        int i10 = dVar.f7785a;
        if (list != null) {
            Iterator<T> it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    t10 = null;
                    break;
                }
                t10 = it.next();
                if (((d) t10).f7785a == i10) {
                    break;
                }
            }
            if (((d) t10) != null) {
                List<d> list2 = this.f11960g;
                kotlin.jvm.internal.l.c(list2);
                ArrayList arrayList = new ArrayList();
                for (T next : list2) {
                    if (((d) next).f7785a != i10) {
                        arrayList.add(next);
                    }
                }
                this.f11960g = arrayList;
            }
        }
        this.f11957d = null;
        G.y(this.f11956c, (h) null, new b(this, i10, (Ba.e<? super b>) null), 3);
    }

    public final Object d(String str, i iVar) {
        this.f11957d = null;
        this.f11954a.h("%".concat(str));
        d f10 = f();
        f10.getClass();
        G.y(f10.f11970c, (h) null, new f(f10, str, (Ba.e<? super f>) null), 3);
        Object a10 = a(iVar);
        if (a10 == Ca.a.f33640f) {
            return a10;
        }
        return C4959D.f44058a;
    }

    public final List e(int i10) {
        boolean z10;
        kotlin.jvm.internal.l.f("getHistory: offset: 0, limit: " + i10, "string");
        if (i10 == 20) {
            z10 = true;
        } else {
            z10 = false;
        }
        List<d> list = this.f11960g;
        if (z10 && list != null) {
            return list;
        }
        ArrayList i11 = this.f11954a.i(i10);
        if (z10) {
            this.f11960g = i11;
        }
        return i11;
    }

    public final d f() {
        return (d) this.f11958e.getValue();
    }
}
