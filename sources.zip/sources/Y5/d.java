package Y5;

import Ba.h;
import Da.e;
import Da.i;
import H0.C0705w;
import Na.p;
import V.C1187r0;
import ic.C4487C;
import ic.C4488D;
import ic.G;
import ic.U;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.jvm.internal.l;
import nc.C4732d;
import pc.b;
import xa.C4959D;
import xa.C4976p;
import ya.n;
import ya.u;

public final class d {

    /* renamed from: e  reason: collision with root package name */
    public static final C0705w f11967e;

    /* renamed from: a  reason: collision with root package name */
    public final c f11968a;

    /* renamed from: b  reason: collision with root package name */
    public final C1187r0 f11969b = R1.a.t(u.f44685f);

    /* renamed from: c  reason: collision with root package name */
    public final C4732d f11970c;

    /* renamed from: d  reason: collision with root package name */
    public final LinkedHashMap f11971d;

    @e(c = "com.common.components.repository.history.TopHostVisits$1", f = "HistoryRepository.kt", l = {82}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public int f11972f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ d f11973i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(d dVar, Ba.e<? super a> eVar) {
            super(2, eVar);
            this.f11973i = dVar;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new a(this.f11973i, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            int i10 = this.f11972f;
            if (i10 == 0) {
                C4976p.b(obj);
                this.f11972f = 1;
                if (d.a(this.f11973i, this) == aVar) {
                    return aVar;
                }
            } else if (i10 == 1) {
                C4976p.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return C4959D.f44058a;
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [H0.w, java.lang.Object] */
    static {
        List x10 = n.x("accounts.google.com", "tsyndicate.com", "bit.ly", "google.de", "google.com", "youtu.be", "startpage.com", "googleadservices.com", "syndicatedsearch.goog", "doubleclick.net", "handyhaus.de", "gaga-tv-app.de");
        List x11 = n.x("click", "login");
        ? obj = new Object();
        obj.f3494a = x10;
        obj.f3495b = x11;
        f11967e = obj;
    }

    public d(c cVar) {
        l.f(cVar, "historyRepository");
        this.f11968a = cVar;
        U u7 = U.f41134a;
        C4732d a10 = C4488D.a(b.f43037f);
        this.f11970c = a10;
        this.f11971d = new LinkedHashMap();
        G.y(a10, (h) null, new a(this, (Ba.e<? super a>) null), 3);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0042, code lost:
        if (r7 == r1) goto L_0x0059;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0057, code lost:
        if (ic.G.M(r2, r4, r0) != r1) goto L_0x005a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0059, code lost:
        return r1;
     */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0039  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final java.lang.Object a(Y5.d r6, Da.c r7) {
        /*
            r6.getClass()
            boolean r0 = r7 instanceof Y5.h
            if (r0 == 0) goto L_0x0016
            r0 = r7
            Y5.h r0 = (Y5.h) r0
            int r1 = r0.f11983z
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0016
            int r1 = r1 - r2
            r0.f11983z = r1
            goto L_0x001b
        L_0x0016:
            Y5.h r0 = new Y5.h
            r0.<init>(r6, r7)
        L_0x001b:
            java.lang.Object r7 = r0.f11981f
            Ca.a r1 = Ca.a.f33640f
            int r2 = r0.f11983z
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L_0x0039
            if (r2 == r4) goto L_0x0035
            if (r2 != r3) goto L_0x002d
            xa.C4976p.b(r7)
            goto L_0x005a
        L_0x002d:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L_0x0035:
            xa.C4976p.b(r7)
            goto L_0x0045
        L_0x0039:
            xa.C4976p.b(r7)
            r0.f11983z = r4
            java.io.Serializable r7 = r6.c(r0)
            if (r7 != r1) goto L_0x0045
            goto L_0x0059
        L_0x0045:
            java.util.List r7 = (java.util.List) r7
            ic.U r2 = ic.U.f41134a
            jc.e r2 = nc.p.f42446a
            Y5.i r4 = new Y5.i
            r5 = 0
            r4.<init>(r6, r7, r5)
            r0.f11983z = r3
            java.lang.Object r6 = ic.G.M(r2, r4, r0)
            if (r6 != r1) goto L_0x005a
        L_0x0059:
            return r1
        L_0x005a:
            xa.D r6 = xa.C4959D.f44058a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: Y5.d.a(Y5.d, Da.c):java.lang.Object");
    }

    public final int b(String str) {
        l.f("getHostVisits: host: ".concat(str), "string");
        Integer num = (Integer) this.f11971d.get(s6.i.a(str));
        if (num != null) {
            return num.intValue();
        }
        return 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x006b  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00d9  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x010b A[LOOP:2: B:32:0x0105->B:34:0x010b, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00c4 A[EDGE_INSN: B:37:0x00c4->B:25:0x00c4 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.io.Serializable c(Da.c r8) {
        /*
            r7 = this;
            boolean r0 = r8 instanceof Y5.g
            if (r0 == 0) goto L_0x0013
            r0 = r8
            Y5.g r0 = (Y5.g) r0
            int r1 = r0.f11980z
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f11980z = r1
            goto L_0x0018
        L_0x0013:
            Y5.g r0 = new Y5.g
            r0.<init>(r7, r8)
        L_0x0018:
            java.lang.Object r8 = r0.f11978f
            Ca.a r1 = Ca.a.f33640f
            int r2 = r0.f11980z
            r3 = 1
            if (r2 == 0) goto L_0x002f
            if (r2 != r3) goto L_0x0027
            xa.C4976p.b(r8)
            goto L_0x0058
        L_0x0027:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L_0x002f:
            xa.C4976p.b(r8)
            r0.f11980z = r3
            Y5.c r8 = r7.f11968a
            r8.getClass()
            java.util.Date r0 = new java.util.Date
            r0.<init>()
            r2 = 2592000(0x278d00, float:3.632166E-39)
            long r2 = (long) r2
            r4 = 1000(0x3e8, double:4.94E-321)
            long r2 = r2 * r4
            java.util.Date r4 = new java.util.Date
            long r5 = r0.getTime()
            long r5 = r5 - r2
            r4.<init>(r5)
            P5.v r8 = r8.f11954a
            java.util.ArrayList r8 = r8.e(r4)
            if (r8 != r1) goto L_0x0058
            return r1
        L_0x0058:
            java.util.List r8 = (java.util.List) r8
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Iterator r8 = r8.iterator()
        L_0x0063:
            boolean r1 = r8.hasNext()
            H0.w r2 = f11967e
            if (r1 == 0) goto L_0x00c4
            java.lang.Object r1 = r8.next()
            P5.C r1 = (P5.C) r1
            java.lang.String r3 = r1.f7454a
            java.lang.String r3 = s6.i.a(r3)
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "getMostVisitedWebsites: host: "
            r4.<init>(r5)
            java.lang.String r5 = r1.f7454a
            r4.append(r5)
            java.lang.String r6 = ", topPrivateDomain: "
            r4.append(r6)
            r4.append(r3)
            java.lang.String r4 = r4.toString()
            java.lang.String r6 = "string"
            kotlin.jvm.internal.l.f(r4, r6)
            java.util.LinkedHashMap r4 = r7.f11971d
            java.lang.Integer r6 = new java.lang.Integer
            int r1 = r1.f7455b
            r6.<init>(r1)
            r4.put(r3, r6)
            boolean r2 = r2.b(r5)
            if (r2 == 0) goto L_0x00a7
            goto L_0x0063
        L_0x00a7:
            java.lang.Object r2 = r0.get(r3)
            Y5.j r2 = (Y5.j) r2
            if (r2 == 0) goto L_0x00bb
            java.lang.String r2 = r2.f11986a
            int r2 = r2.length()
            int r4 = r5.length()
            if (r2 >= r4) goto L_0x0063
        L_0x00bb:
            Y5.j r2 = new Y5.j
            r2.<init>(r5, r1)
            r0.put(r3, r2)
            goto L_0x0063
        L_0x00c4:
            java.util.Set r8 = r0.entrySet()
            java.lang.Iterable r8 = (java.lang.Iterable) r8
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.Iterator r8 = r8.iterator()
        L_0x00d3:
            boolean r1 = r8.hasNext()
            if (r1 == 0) goto L_0x00f2
            java.lang.Object r1 = r8.next()
            r3 = r1
            java.util.Map$Entry r3 = (java.util.Map.Entry) r3
            java.lang.Object r3 = r3.getValue()
            Y5.j r3 = (Y5.j) r3
            java.lang.String r3 = r3.f11986a
            boolean r3 = r2.b(r3)
            if (r3 != 0) goto L_0x00d3
            r0.add(r1)
            goto L_0x00d3
        L_0x00f2:
            r8 = 10
            java.util.List r0 = ya.s.s0(r8, r0)
            java.util.ArrayList r1 = new java.util.ArrayList
            int r8 = ya.n.v(r8, r0)
            r1.<init>(r8)
            java.util.Iterator r8 = r0.iterator()
        L_0x0105:
            boolean r0 = r8.hasNext()
            if (r0 == 0) goto L_0x0138
            java.lang.Object r0 = r8.next()
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            Y5.j r2 = new Y5.j
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "https://"
            r3.<init>(r4)
            java.lang.Object r4 = r0.getValue()
            Y5.j r4 = (Y5.j) r4
            java.lang.String r4 = r4.f11986a
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            java.lang.Object r0 = r0.getValue()
            Y5.j r0 = (Y5.j) r0
            int r0 = r0.f11987b
            r2.<init>(r3, r0)
            r1.add(r2)
            goto L_0x0105
        L_0x0138:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: Y5.d.c(Da.c):java.io.Serializable");
    }
}
