package Y5;

import Da.e;
import Da.i;
import Na.p;
import ic.C4487C;
import xa.C4959D;

@e(c = "com.common.components.repository.history.TopHostVisits$deleteHost$1", f = "HistoryRepository.kt", l = {89, 90}, m = "invokeSuspend")
public final class f extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public int f11975f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ d f11976i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ String f11977z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public f(d dVar, String str, Ba.e<? super f> eVar) {
        super(2, eVar);
        this.f11976i = dVar;
        this.f11977z = str;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new f(this.f11976i, this.f11977z, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((f) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0034, code lost:
        if (Y5.d.a(r2, r5) == r0) goto L_0x0036;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0036, code lost:
        return r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x002b, code lost:
        if (r6.d(r5.f11977z, r5) == r0) goto L_0x0036;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r6) {
        /*
            r5 = this;
            Ca.a r0 = Ca.a.f33640f
            int r1 = r5.f11975f
            Y5.d r2 = r5.f11976i
            r3 = 2
            r4 = 1
            if (r1 == 0) goto L_0x001e
            if (r1 == r4) goto L_0x001a
            if (r1 != r3) goto L_0x0012
            xa.C4976p.b(r6)
            goto L_0x0037
        L_0x0012:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L_0x001a:
            xa.C4976p.b(r6)
            goto L_0x002e
        L_0x001e:
            xa.C4976p.b(r6)
            Y5.c r6 = r2.f11968a
            r5.f11975f = r4
            java.lang.String r1 = r5.f11977z
            java.lang.Object r6 = r6.d(r1, r5)
            if (r6 != r0) goto L_0x002e
            goto L_0x0036
        L_0x002e:
            r5.f11975f = r3
            java.lang.Object r6 = Y5.d.a(r2, r5)
            if (r6 != r0) goto L_0x0037
        L_0x0036:
            return r0
        L_0x0037:
            xa.D r6 = xa.C4959D.f44058a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: Y5.f.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
