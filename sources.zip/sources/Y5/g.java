package Y5;

import Da.c;
import Da.e;
import H0.C0705w;

@e(c = "com.common.components.repository.history.TopHostVisits", f = "HistoryRepository.kt", l = {111}, m = "getMostVisitedWebsites")
public final class g extends c {

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f11978f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ d f11979i;

    /* renamed from: z  reason: collision with root package name */
    public int f11980z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public g(d dVar, c cVar) {
        super(cVar);
        this.f11979i = dVar;
    }

    public final Object invokeSuspend(Object obj) {
        this.f11978f = obj;
        this.f11980z |= Integer.MIN_VALUE;
        C0705w wVar = d.f11967e;
        return this.f11979i.c(this);
    }
}
