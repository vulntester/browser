package Y5;

import Da.c;
import Da.e;

@e(c = "com.common.components.repository.history.TopHostVisits", f = "HistoryRepository.kt", l = {102, 103}, m = "updateMostVisitedWebsites")
public final class h extends c {

    /* renamed from: f  reason: collision with root package name */
    public /* synthetic */ Object f11981f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ d f11982i;

    /* renamed from: z  reason: collision with root package name */
    public int f11983z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public h(d dVar, c cVar) {
        super(cVar);
        this.f11982i = dVar;
    }

    public final Object invokeSuspend(Object obj) {
        this.f11981f = obj;
        this.f11983z |= Integer.MIN_VALUE;
        return d.a(this.f11982i, this);
    }
}
