package Y5;

import Ca.a;
import Da.e;
import Na.p;
import ic.C4487C;
import java.util.List;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.common.components.repository.history.TopHostVisits$updateMostVisitedWebsites$2", f = "HistoryRepository.kt", l = {}, m = "invokeSuspend")
public final class i extends Da.i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ d f11984f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ List<j> f11985i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public i(d dVar, List<j> list, Ba.e<? super i> eVar) {
        super(2, eVar);
        this.f11984f = dVar;
        this.f11985i = list;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new i(this.f11984f, this.f11985i, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((i) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.f33640f;
        C4976p.b(obj);
        this.f11984f.f11969b.setValue(this.f11985i);
        return C4959D.f44058a;
    }
}
