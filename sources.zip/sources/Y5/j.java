package Y5;

import H0.C0708z;
import io.netty.handler.codec.rtsp.RtspHeaders;
import kotlin.jvm.internal.l;

public final class j {

    /* renamed from: a  reason: collision with root package name */
    public final String f11986a;

    /* renamed from: b  reason: collision with root package name */
    public final int f11987b;

    public j(String str, int i10) {
        l.f(str, RtspHeaders.Values.URL);
        this.f11986a = str;
        this.f11987b = i10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        if (l.a(this.f11986a, jVar.f11986a) && this.f11987b == jVar.f11987b) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return (this.f11986a.hashCode() * 31) + this.f11987b;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("VisitedWebsite(url=");
        sb2.append(this.f11986a);
        sb2.append(", visits=");
        return C0708z.l(sb2, this.f11987b, ')');
    }
}
