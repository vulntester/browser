package Yb;

import D1.d;
import kotlin.jvm.internal.l;

public final class a<T> {

    /* renamed from: a  reason: collision with root package name */
    public final T f38920a;

    /* renamed from: b  reason: collision with root package name */
    public final T f38921b;

    public a(T t10, T t11) {
        this.f38920a = t10;
        this.f38921b = t11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        if (l.a(this.f38920a, aVar.f38920a) && l.a(this.f38921b, aVar.f38921b)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i10;
        int i11 = 0;
        T t10 = this.f38920a;
        if (t10 == null) {
            i10 = 0;
        } else {
            i10 = t10.hashCode();
        }
        int i12 = i10 * 31;
        T t11 = this.f38921b;
        if (t11 != null) {
            i11 = t11.hashCode();
        }
        return i12 + i11;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("ApproximationBounds(lower=");
        sb2.append(this.f38920a);
        sb2.append(", upper=");
        return d.g(sb2, this.f38921b, ')');
    }
}
