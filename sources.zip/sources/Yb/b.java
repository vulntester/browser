package Yb;

import Na.l;
import Tb.n0;

public final class b implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final b f38922f = new Object();

    public final Object invoke(Object obj) {
        n0 n0Var = (n0) obj;
        kotlin.jvm.internal.l.c(n0Var);
        return Boolean.valueOf(n0Var.z0() instanceof Gb.b);
    }
}
