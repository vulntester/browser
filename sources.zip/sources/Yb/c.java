package Yb;

import Gb.b;
import Tb.Y;
import Tb.a0;
import Tb.c0;
import Tb.e0;
import Tb.o0;
import kotlin.jvm.internal.l;

public final class c extends a0 {
    public final c0 g(Y y10) {
        b bVar;
        l.f(y10, "key");
        if (y10 instanceof b) {
            bVar = (b) y10;
        } else {
            bVar = null;
        }
        if (bVar == null) {
            return null;
        }
        if (!bVar.b().c()) {
            return bVar.b();
        }
        return new e0(bVar.b().getType(), o0.OUT_VARIANCE);
    }
}
