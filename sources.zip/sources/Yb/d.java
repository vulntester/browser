package Yb;

import A.g;
import A.o;
import A1.a;
import Gb.b;
import Tb.C;
import Tb.C4154z;
import Tb.H;
import Tb.Y;
import Tb.c0;
import Tb.j0;
import Tb.l0;
import Tb.o0;
import io.ktor.http.LinkHeader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.l;
import xa.C4973m;
import ya.s;

public final class d {
    public static final a<C4154z> a(C4154z zVar) {
        Object obj;
        o0 o0Var;
        e eVar;
        l.f(zVar, LinkHeader.Parameters.Type);
        if (a.B(zVar)) {
            a<C4154z> a10 = a(a.D(zVar));
            a<C4154z> a11 = a(a.Q(zVar));
            return new a<>(g.l(C.a(a.D((C4154z) a10.f38920a), a.Q((C4154z) a11.f38920a)), zVar), g.l(C.a(a.D((C4154z) a10.f38921b), a.Q((C4154z) a11.f38921b)), zVar));
        }
        Y z02 = zVar.z0();
        boolean z10 = true;
        if (zVar.z0() instanceof b) {
            l.d(z02, "null cannot be cast to non-null type org.jetbrains.kotlin.resolve.calls.inference.CapturedTypeConstructor");
            c0 b10 = ((b) z02).b();
            C4154z type = b10.getType();
            l.e(type, "getType(...)");
            C4154z h10 = l0.h(type, zVar.E0());
            l.e(h10, "makeNullableIfNeeded(...)");
            int ordinal = b10.a().ordinal();
            if (ordinal == 1) {
                return new a<>(h10, o.A(zVar).n());
            }
            if (ordinal == 2) {
                C4154z h11 = l0.h(o.A(zVar).m(), zVar.E0());
                l.e(h11, "makeNullableIfNeeded(...)");
                return new a<>(h11, h10);
            }
            throw new AssertionError("Only nontrivial projections should have been captured, not: " + b10);
        } else if (zVar.X().isEmpty() || zVar.X().size() != z02.getParameters().size()) {
            return new a<>(zVar, zVar);
        } else {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            List<c0> X10 = zVar.X();
            List<db.c0> parameters = z02.getParameters();
            l.e(parameters, "getParameters(...)");
            Iterator it = s.C0(X10, parameters).iterator();
            while (it.hasNext()) {
                C4973m mVar = (C4973m) it.next();
                c0 c0Var = (c0) mVar.f44071f;
                db.c0 c0Var2 = (db.c0) mVar.f44072i;
                l.c(c0Var2);
                o0 J5 = c0Var2.J();
                if (J5 == null) {
                    j0.a(35);
                    throw null;
                } else if (c0Var != null) {
                    j0 j0Var = j0.f38113b;
                    if (c0Var.c()) {
                        o0Var = o0.OUT_VARIANCE;
                    } else {
                        o0Var = j0.b(J5, c0Var.a());
                    }
                    int ordinal2 = o0Var.ordinal();
                    if (ordinal2 == 0) {
                        C4154z type2 = c0Var.getType();
                        l.e(type2, "getType(...)");
                        C4154z type3 = c0Var.getType();
                        l.e(type3, "getType(...)");
                        eVar = new e(c0Var2, type2, type3);
                    } else if (ordinal2 == 1) {
                        C4154z type4 = c0Var.getType();
                        l.e(type4, "getType(...)");
                        eVar = new e(c0Var2, type4, Jb.d.e(c0Var2).n());
                    } else if (ordinal2 == 2) {
                        H m10 = Jb.d.e(c0Var2).m();
                        C4154z type5 = c0Var.getType();
                        l.e(type5, "getType(...)");
                        eVar = new e(c0Var2, m10, type5);
                    } else {
                        throw new RuntimeException();
                    }
                    if (c0Var.c()) {
                        arrayList.add(eVar);
                        arrayList2.add(eVar);
                    } else {
                        a<C4154z> a12 = a(eVar.f38924b);
                        a<C4154z> a13 = a(eVar.f38925c);
                        db.c0 c0Var3 = eVar.f38923a;
                        e eVar2 = new e(c0Var3, (C4154z) a12.f38921b, (C4154z) a13.f38920a);
                        e eVar3 = new e(c0Var3, (C4154z) a12.f38920a, (C4154z) a13.f38921b);
                        arrayList.add(eVar2);
                        arrayList2.add(eVar3);
                    }
                } else {
                    j0.a(36);
                    throw null;
                }
            }
            if (!arrayList.isEmpty()) {
                Iterator it2 = arrayList.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        break;
                    }
                    e eVar4 = (e) it2.next();
                    eVar4.getClass();
                    if (!Ub.d.f38216a.d(eVar4.f38924b, eVar4.f38925c)) {
                        break;
                    }
                }
            }
            z10 = false;
            if (z10) {
                obj = o.A(zVar).m();
            } else {
                obj = b(zVar, arrayList);
            }
            return new a<>(obj, b(zVar, arrayList2));
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0038, code lost:
        r1 = r1.f38923a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final Tb.C4154z b(Tb.C4154z r7, java.util.ArrayList r8) {
        /*
            java.util.List r0 = r7.X()
            r0.size()
            r8.size()
            java.util.ArrayList r0 = new java.util.ArrayList
            r1 = 10
            int r1 = ya.n.v(r1, r8)
            r0.<init>(r1)
            java.util.Iterator r8 = r8.iterator()
        L_0x0019:
            boolean r1 = r8.hasNext()
            r2 = 0
            if (r1 == 0) goto L_0x009b
            java.lang.Object r1 = r8.next()
            Yb.e r1 = (Yb.e) r1
            r1.getClass()
            Ub.l r3 = Ub.d.f38216a
            Tb.z r4 = r1.f38924b
            Tb.z r5 = r1.f38925c
            r3.d(r4, r5)
            boolean r3 = kotlin.jvm.internal.l.a(r4, r5)
            if (r3 != 0) goto L_0x0091
            db.c0 r1 = r1.f38923a
            Tb.o0 r3 = r1.J()
            Tb.o0 r6 = Tb.o0.IN_VARIANCE
            if (r3 != r6) goto L_0x0043
            goto L_0x0091
        L_0x0043:
            boolean r3 = ab.k.D(r4)
            if (r3 == 0) goto L_0x005f
            Tb.o0 r3 = r1.J()
            if (r3 == r6) goto L_0x005f
            Tb.e0 r2 = new Tb.e0
            Tb.o0 r3 = Tb.o0.OUT_VARIANCE
            Tb.o0 r1 = r1.J()
            if (r3 != r1) goto L_0x005b
            Tb.o0 r3 = Tb.o0.INVARIANT
        L_0x005b:
            r2.<init>(r5, r3)
            goto L_0x0096
        L_0x005f:
            if (r5 == 0) goto L_0x008b
            boolean r2 = ab.k.w(r5)
            if (r2 == 0) goto L_0x007b
            boolean r2 = r5.E0()
            if (r2 == 0) goto L_0x007b
            Tb.e0 r2 = new Tb.e0
            Tb.o0 r1 = r1.J()
            if (r6 != r1) goto L_0x0077
            Tb.o0 r6 = Tb.o0.INVARIANT
        L_0x0077:
            r2.<init>(r4, r6)
            goto L_0x0096
        L_0x007b:
            Tb.e0 r2 = new Tb.e0
            Tb.o0 r3 = Tb.o0.OUT_VARIANCE
            Tb.o0 r1 = r1.J()
            if (r3 != r1) goto L_0x0087
            Tb.o0 r3 = Tb.o0.INVARIANT
        L_0x0087:
            r2.<init>(r5, r3)
            goto L_0x0096
        L_0x008b:
            r7 = 141(0x8d, float:1.98E-43)
            ab.k.a(r7)
            throw r2
        L_0x0091:
            Tb.e0 r2 = new Tb.e0
            r2.<init>(r4)
        L_0x0096:
            r0.add(r2)
            goto L_0x0019
        L_0x009b:
            r8 = 6
            Tb.z r7 = Tb.h0.c(r7, r0, r2, r8)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: Yb.d.b(Tb.z, java.util.ArrayList):Tb.z");
    }
}
