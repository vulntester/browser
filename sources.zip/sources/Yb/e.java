package Yb;

import Tb.C4154z;
import db.c0;
import kotlin.jvm.internal.l;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public final c0 f38923a;

    /* renamed from: b  reason: collision with root package name */
    public final C4154z f38924b;

    /* renamed from: c  reason: collision with root package name */
    public final C4154z f38925c;

    public e(c0 c0Var, C4154z zVar, C4154z zVar2) {
        l.f(c0Var, "typeParameter");
        l.f(zVar, "inProjection");
        l.f(zVar2, "outProjection");
        this.f38923a = c0Var;
        this.f38924b = zVar;
        this.f38925c = zVar2;
    }
}
