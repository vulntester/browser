package Z2;

import R2.B;
import R2.E;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import java.util.List;

public final class a implements n {

    /* renamed from: a  reason: collision with root package name */
    public final n f12035a;

    public a(int i10) {
        if ((i10 & 1) != 0) {
            this.f12035a = new E(65496, 2, "image/jpeg");
        } else {
            this.f12035a = new b();
        }
    }

    public final void a(long j10, long j11) {
        this.f12035a.a(j10, j11);
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f12035a.d(pVar);
    }

    public final boolean g(o oVar) {
        return this.f12035a.g(oVar);
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    public final int i(o oVar, B b10) {
        return this.f12035a.i(oVar, b10);
    }

    public final void release() {
        this.f12035a.release();
    }
}
