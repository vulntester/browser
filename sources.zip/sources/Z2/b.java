package Z2;

import R2.C;
import R2.C1013i;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import g3.C2418a;
import java.util.List;
import l3.C2631f;
import o2.t;

public final class b implements n {

    /* renamed from: a  reason: collision with root package name */
    public final t f12036a = new t(6);

    /* renamed from: b  reason: collision with root package name */
    public p f12037b;

    /* renamed from: c  reason: collision with root package name */
    public int f12038c;

    /* renamed from: d  reason: collision with root package name */
    public int f12039d;

    /* renamed from: e  reason: collision with root package name */
    public int f12040e;

    /* renamed from: f  reason: collision with root package name */
    public long f12041f = -1;

    /* renamed from: g  reason: collision with root package name */
    public C2418a f12042g;

    /* renamed from: h  reason: collision with root package name */
    public C1013i f12043h;

    /* renamed from: i  reason: collision with root package name */
    public d f12044i;

    /* renamed from: j  reason: collision with root package name */
    public C2631f f12045j;

    public final void a(long j10, long j11) {
        if (j10 == 0) {
            this.f12038c = 0;
            this.f12045j = null;
        } else if (this.f12038c == 5) {
            C2631f fVar = this.f12045j;
            fVar.getClass();
            fVar.a(j10, j11);
        }
    }

    public final void b() {
        p pVar = this.f12037b;
        pVar.getClass();
        pVar.b();
        this.f12037b.a(new C.b(-9223372036854775807L));
        this.f12038c = 6;
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f12037b = pVar;
    }

    public final boolean g(o oVar) {
        C1013i iVar = (C1013i) oVar;
        t tVar = this.f12036a;
        tVar.D(2);
        iVar.l(tVar.f25885a, 0, 2, false);
        if (tVar.A() == 65496) {
            tVar.D(2);
            iVar.l(tVar.f25885a, 0, 2, false);
            int A10 = tVar.A();
            this.f12039d = A10;
            if (A10 == 65504) {
                tVar.D(2);
                iVar.l(tVar.f25885a, 0, 2, false);
                iVar.b(tVar.A() - 2, false);
                tVar.D(2);
                iVar.l(tVar.f25885a, 0, 2, false);
                this.f12039d = tVar.A();
            }
            if (this.f12039d == 65505) {
                iVar.b(2, false);
                tVar.D(6);
                iVar.l(tVar.f25885a, 0, 6, false);
                if (tVar.w() == 1165519206 && tVar.A() == 0) {
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    /* JADX WARNING: Removed duplicated region for block: B:82:0x018d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int i(R2.o r29, R2.B r30) {
        /*
            r28 = this;
            r0 = r28
            r1 = r29
            r2 = r30
            r3 = -1
            r4 = 1
            r5 = 0
            int r6 = r0.f12038c
            r7 = -1
            o2.t r9 = r0.f12036a
            r10 = 4
            r11 = 2
            if (r6 == 0) goto L_0x01b0
            if (r6 == r4) goto L_0x019c
            if (r6 == r11) goto L_0x00d1
            r7 = 5
            if (r6 == r10) goto L_0x0050
            if (r6 == r7) goto L_0x0026
            r1 = 6
            if (r6 != r1) goto L_0x0020
            return r3
        L_0x0020:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x0026:
            Z2.d r3 = r0.f12044i
            if (r3 == 0) goto L_0x002e
            R2.i r3 = r0.f12043h
            if (r1 == r3) goto L_0x003b
        L_0x002e:
            R2.i r1 = (R2.C1013i) r1
            r0.f12043h = r1
            Z2.d r3 = new Z2.d
            long r5 = r0.f12041f
            r3.<init>((R2.C1013i) r1, (long) r5)
            r0.f12044i = r3
        L_0x003b:
            l3.f r1 = r0.f12045j
            r1.getClass()
            Z2.d r3 = r0.f12044i
            int r1 = r1.i(r3, r2)
            if (r1 != r4) goto L_0x004f
            long r3 = r2.f8054a
            long r5 = r0.f12041f
            long r3 = r3 + r5
            r2.f8054a = r3
        L_0x004f:
            return r1
        L_0x0050:
            r3 = r1
            R2.i r3 = (R2.C1013i) r3
            long r11 = r3.f8167E
            long r13 = r0.f12041f
            int r3 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r3 == 0) goto L_0x005e
            r2.f8054a = r13
            return r4
        L_0x005e:
            byte[] r2 = r9.f25885a
            R2.i r1 = (R2.C1013i) r1
            boolean r2 = r1.l(r2, r5, r4, r4)
            if (r2 != 0) goto L_0x006c
            r0.b()
            return r5
        L_0x006c:
            r1.f8169G = r5
            l3.f r2 = r0.f12045j
            if (r2 != 0) goto L_0x007d
            l3.f r2 = new l3.f
            o3.n$a$a r3 = o3.C2772n.a.f25925a
            r6 = 8
            r2.<init>(r3, r6)
            r0.f12045j = r2
        L_0x007d:
            Z2.d r2 = new Z2.d
            long r8 = r0.f12041f
            r2.<init>((R2.C1013i) r1, (long) r8)
            r0.f12044i = r2
            l3.f r1 = r0.f12045j
            boolean r1 = r1.g(r2)
            if (r1 == 0) goto L_0x00cd
            l3.f r1 = r0.f12045j
            Z2.e r2 = new Z2.e
            long r8 = r0.f12041f
            R2.p r3 = r0.f12037b
            r3.getClass()
            r2.<init>(r8, r3)
            r1.d(r2)
            g3.a r1 = r0.f12042g
            r1.getClass()
            R2.p r2 = r0.f12037b
            r2.getClass()
            r3 = 1024(0x400, float:1.435E-42)
            R2.H r2 = r2.k(r3, r10)
            l2.n$a r3 = new l2.n$a
            r3.<init>()
            java.lang.String r6 = "image/jpeg"
            java.lang.String r6 = l2.u.p(r6)
            r3.f24327l = r6
            l2.t r6 = new l2.t
            l2.t$a[] r4 = new l2.t.a[r4]
            r4[r5] = r1
            r6.<init>((l2.t.a[]) r4)
            r3.f24326k = r6
            D2.E.r(r3, r2)
            r0.f12038c = r7
            return r5
        L_0x00cd:
            r0.b()
            return r5
        L_0x00d1:
            int r2 = r0.f12039d
            r6 = 65505(0xffe1, float:9.1792E-41)
            if (r2 != r6) goto L_0x0192
            o2.t r2 = new o2.t
            int r6 = r0.f12040e
            r2.<init>((int) r6)
            byte[] r6 = r2.f25885a
            int r9 = r0.f12040e
            r10 = r1
            R2.i r10 = (R2.C1013i) r10
            r10.e(r6, r5, r9, r5)
            g3.a r6 = r0.f12042g
            if (r6 != 0) goto L_0x0199
            java.lang.String r6 = "http://ns.adobe.com/xap/1.0/"
            java.lang.String r9 = r2.p()
            boolean r6 = r6.equals(r9)
            if (r6 == 0) goto L_0x0199
            java.lang.String r2 = r2.p()
            if (r2 == 0) goto L_0x0199
            R2.i r1 = (R2.C1013i) r1
            long r9 = r1.f8173z
            int r1 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r1 != 0) goto L_0x010a
        L_0x0107:
            r6 = 0
            goto L_0x0189
        L_0x010a:
            Z2.c r1 = Z2.f.a(r2)     // Catch:{ NumberFormatException | v | XmlPullParserException -> 0x010f }
            goto L_0x0117
        L_0x010f:
            java.lang.String r1 = "MotionPhotoXmpParser"
            java.lang.String r2 = "Ignoring unexpected XMP metadata"
            o2.n.f(r1, r2)
            r1 = 0
        L_0x0117:
            if (r1 != 0) goto L_0x011a
            goto L_0x0107
        L_0x011a:
            S7.O r2 = r1.f12047b
            int r12 = r2.f9712E
            if (r12 >= r11) goto L_0x0121
            goto L_0x0107
        L_0x0121:
            int r12 = r12 - r4
            r4 = r5
            r14 = r7
            r16 = r14
            r20 = r16
            r22 = r20
        L_0x012a:
            if (r12 < 0) goto L_0x016c
            java.lang.Object r11 = r2.get(r12)
            Z2.c$a r11 = (Z2.c.a) r11
            java.lang.String r13 = r11.f12048a
            r18 = r3
            java.lang.String r3 = "video/mp4"
            boolean r3 = r3.equals(r13)
            r3 = r3 | r4
            if (r12 != 0) goto L_0x014c
            r24 = r7
            long r6 = r11.f12050c
            long r9 = r9 - r6
            r6 = 0
        L_0x0146:
            r26 = r9
            r9 = r6
            r6 = r26
            goto L_0x0153
        L_0x014c:
            r24 = r7
            long r6 = r11.f12049b
            long r6 = r9 - r6
            goto L_0x0146
        L_0x0153:
            if (r3 == 0) goto L_0x015f
            int r4 = (r9 > r6 ? 1 : (r9 == r6 ? 0 : -1))
            if (r4 == 0) goto L_0x015f
            long r22 = r6 - r9
            r4 = r5
            r20 = r9
            goto L_0x0160
        L_0x015f:
            r4 = r3
        L_0x0160:
            if (r12 != 0) goto L_0x0165
            r16 = r6
            r14 = r9
        L_0x0165:
            int r12 = r12 + -1
            r3 = r18
            r7 = r24
            goto L_0x012a
        L_0x016c:
            r24 = r7
            int r2 = (r20 > r24 ? 1 : (r20 == r24 ? 0 : -1))
            if (r2 == 0) goto L_0x0107
            int r2 = (r22 > r24 ? 1 : (r22 == r24 ? 0 : -1))
            if (r2 == 0) goto L_0x0107
            int r2 = (r14 > r24 ? 1 : (r14 == r24 ? 0 : -1))
            if (r2 == 0) goto L_0x0107
            int r2 = (r16 > r24 ? 1 : (r16 == r24 ? 0 : -1))
            if (r2 != 0) goto L_0x017f
            goto L_0x0107
        L_0x017f:
            g3.a r13 = new g3.a
            long r1 = r1.f12046a
            r18 = r1
            r13.<init>(r14, r16, r18, r20, r22)
            r6 = r13
        L_0x0189:
            r0.f12042g = r6
            if (r6 == 0) goto L_0x0199
            long r1 = r6.f22475d
            r0.f12041f = r1
            goto L_0x0199
        L_0x0192:
            int r2 = r0.f12040e
            R2.i r1 = (R2.C1013i) r1
            r1.s(r2)
        L_0x0199:
            r0.f12038c = r5
            goto L_0x01e5
        L_0x019c:
            r9.D(r11)
            byte[] r2 = r9.f25885a
            R2.i r1 = (R2.C1013i) r1
            r1.e(r2, r5, r11, r5)
            int r1 = r9.A()
            int r1 = r1 - r11
            r0.f12040e = r1
            r0.f12038c = r11
            return r5
        L_0x01b0:
            r24 = r7
            r9.D(r11)
            byte[] r2 = r9.f25885a
            R2.i r1 = (R2.C1013i) r1
            r1.e(r2, r5, r11, r5)
            int r1 = r9.A()
            r0.f12039d = r1
            r2 = 65498(0xffda, float:9.1782E-41)
            if (r1 != r2) goto L_0x01d4
            long r1 = r0.f12041f
            int r1 = (r1 > r24 ? 1 : (r1 == r24 ? 0 : -1))
            if (r1 == 0) goto L_0x01d0
            r0.f12038c = r10
            return r5
        L_0x01d0:
            r0.b()
            return r5
        L_0x01d4:
            r2 = 65488(0xffd0, float:9.1768E-41)
            if (r1 < r2) goto L_0x01de
            r2 = 65497(0xffd9, float:9.1781E-41)
            if (r1 <= r2) goto L_0x01e5
        L_0x01de:
            r2 = 65281(0xff01, float:9.1478E-41)
            if (r1 == r2) goto L_0x01e5
            r0.f12038c = r4
        L_0x01e5:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: Z2.b.i(R2.o, R2.B):int");
    }

    public final void release() {
        C2631f fVar = this.f12045j;
        if (fVar != null) {
            fVar.getClass();
        }
    }
}
