package Z2;

import S7.O;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final long f12046a;

    /* renamed from: b  reason: collision with root package name */
    public final O f12047b;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final String f12048a;

        /* renamed from: b  reason: collision with root package name */
        public final long f12049b;

        /* renamed from: c  reason: collision with root package name */
        public final long f12050c;

        public a(String str, long j10, long j11) {
            this.f12048a = str;
            this.f12049b = j10;
            this.f12050c = j11;
        }
    }

    public c(long j10, O o10) {
        this.f12046a = j10;
        this.f12047b = o10;
    }
}
