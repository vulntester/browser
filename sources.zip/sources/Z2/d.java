package Z2;

import R2.C1011g;
import R2.C1013i;
import R2.o;
import f7.M;
import o2.C2756B;
import w2.e;
import x2.i;

public final class d implements o, e {

    /* renamed from: f  reason: collision with root package name */
    public final long f12051f;

    /* renamed from: i  reason: collision with root package name */
    public final Object f12052i;

    public d(C1013i iVar, long j10) {
        this.f12052i = iVar;
        M.h(iVar.f8167E >= j10);
        this.f12051f = j10;
    }

    public long a() {
        return ((C1013i) this.f12052i).f8173z - this.f12051f;
    }

    public long b(long j10) {
        return ((C1011g) this.f12052i).f8158e[(int) j10] - this.f12051f;
    }

    public long d(long j10, long j11) {
        return ((C1011g) this.f12052i).f8157d[(int) j10];
    }

    public boolean e(byte[] bArr, int i10, int i11, boolean z10) {
        return ((C1013i) this.f12052i).e(bArr, 0, i11, z10);
    }

    public long f(long j10, long j11) {
        return 0;
    }

    public void g(int i10, byte[] bArr, int i11) {
        ((C1013i) this.f12052i).l(bArr, i10, i11, false);
    }

    public long h(long j10, long j11) {
        return -9223372036854775807L;
    }

    public i i(long j10) {
        C1011g gVar = (C1011g) this.f12052i;
        int i10 = (int) j10;
        return new i((String) null, gVar.f8156c[i10], (long) gVar.f8155b[i10]);
    }

    public boolean l(byte[] bArr, int i10, int i11, boolean z10) {
        return ((C1013i) this.f12052i).l(bArr, i10, i11, z10);
    }

    public long m() {
        return ((C1013i) this.f12052i).m() - this.f12051f;
    }

    public void o(int i10) {
        ((C1013i) this.f12052i).b(i10, false);
    }

    public long p(long j10, long j11) {
        return (long) C2756B.e(((C1011g) this.f12052i).f8158e, j10 + this.f12051f, true);
    }

    public void r() {
        ((C1013i) this.f12052i).f8169G = 0;
    }

    public int read(byte[] bArr, int i10, int i11) {
        return ((C1013i) this.f12052i).read(bArr, i10, i11);
    }

    public void readFully(byte[] bArr, int i10, int i11) {
        ((C1013i) this.f12052i).e(bArr, i10, i11, false);
    }

    public void s(int i10) {
        ((C1013i) this.f12052i).s(i10);
    }

    public boolean u() {
        return true;
    }

    public long v() {
        return 0;
    }

    public long w(long j10) {
        return (long) ((C1011g) this.f12052i).f8154a;
    }

    public long x(long j10, long j11) {
        return (long) ((C1011g) this.f12052i).f8154a;
    }

    public long y() {
        return ((C1013i) this.f12052i).f8167E - this.f12051f;
    }

    public d(C1011g gVar, long j10) {
        this.f12052i = gVar;
        this.f12051f = j10;
    }
}
