package Z2;

import R2.C;
import R2.D;
import R2.H;
import R2.p;
import R2.v;

public final class e implements p {

    /* renamed from: f  reason: collision with root package name */
    public final long f12053f;

    /* renamed from: i  reason: collision with root package name */
    public final p f12054i;

    public class a extends v {

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ C f12055b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(C c10, C c11) {
            super(c10);
            this.f12055b = c11;
        }

        public final C.a j(long j10) {
            C.a j11 = this.f12055b.j(j10);
            D d10 = j11.f8055a;
            long j12 = d10.f8060a;
            long j13 = e.this.f12053f;
            D d11 = new D(j12, d10.f8061b + j13);
            D d12 = j11.f8056b;
            return new C.a(d11, new D(d12.f8060a, d12.f8061b + j13));
        }
    }

    public e(long j10, p pVar) {
        this.f12053f = j10;
        this.f12054i = pVar;
    }

    public final void a(C c10) {
        this.f12054i.a(new a(c10, c10));
    }

    public final void b() {
        this.f12054i.b();
    }

    public final H k(int i10, int i11) {
        return this.f12054i.k(i10, i11);
    }
}
