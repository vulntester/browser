package Z2;

import A.o;
import S7.C1150x;
import S7.O;
import Z2.c;
import org.xmlpull.v1.XmlPullParser;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public static final String[] f12057a = {"Camera:MotionPhoto", "GCamera:MotionPhoto", "Camera:MicroVideo", "GCamera:MicroVideo"};

    /* renamed from: b  reason: collision with root package name */
    public static final String[] f12058b = {"Camera:MotionPhotoPresentationTimestampUs", "GCamera:MotionPhotoPresentationTimestampUs", "Camera:MicroVideoPresentationTimestampUs", "GCamera:MicroVideoPresentationTimestampUs"};

    /* renamed from: c  reason: collision with root package name */
    public static final String[] f12059c = {"Camera:MicroVideoOffset", "GCamera:MicroVideoOffset"};

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x005e, code lost:
        if (r8 == -1) goto L_0x0060;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static Z2.c a(java.lang.String r21) {
        /*
            r0 = 1
            org.xmlpull.v1.XmlPullParserFactory r1 = org.xmlpull.v1.XmlPullParserFactory.newInstance()
            org.xmlpull.v1.XmlPullParser r1 = r1.newPullParser()
            java.io.StringReader r2 = new java.io.StringReader
            r3 = r21
            r2.<init>(r3)
            r1.setInput(r2)
            r1.next()
            java.lang.String r2 = "x:xmpmeta"
            boolean r3 = A.o.R(r1, r2)
            r4 = 0
            if (r3 == 0) goto L_0x00cd
            S7.x$b r3 = S7.C1150x.f9860i
            S7.O r3 = S7.O.f9711F
            r5 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r7 = r5
        L_0x0029:
            r1.next()
            java.lang.String r9 = "rdf:Description"
            boolean r9 = A.o.R(r1, r9)
            if (r9 == 0) goto L_0x0099
            java.lang.String[] r3 = f12057a
            r7 = 0
            r8 = r7
        L_0x0038:
            r9 = 4
            if (r8 >= r9) goto L_0x00c6
            r10 = r3[r8]
            java.lang.String r10 = A.o.z(r1, r10)
            if (r10 == 0) goto L_0x0097
            int r3 = java.lang.Integer.parseInt(r10)
            if (r3 != r0) goto L_0x00c6
            java.lang.String[] r3 = f12058b
            r8 = r7
        L_0x004c:
            if (r8 >= r9) goto L_0x0060
            r10 = r3[r8]
            java.lang.String r10 = A.o.z(r1, r10)
            if (r10 == 0) goto L_0x0062
            long r8 = java.lang.Long.parseLong(r10)
            r10 = -1
            int r3 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r3 != 0) goto L_0x0064
        L_0x0060:
            r8 = r5
            goto L_0x0064
        L_0x0062:
            int r8 = r8 + r0
            goto L_0x004c
        L_0x0064:
            java.lang.String[] r3 = f12059c
        L_0x0066:
            r10 = 2
            if (r7 >= r10) goto L_0x0091
            r10 = r3[r7]
            java.lang.String r10 = A.o.z(r1, r10)
            if (r10 == 0) goto L_0x008f
            long r13 = java.lang.Long.parseLong(r10)
            Z2.c$a r15 = new Z2.c$a
            r17 = 0
            r19 = 0
            java.lang.String r16 = "image/jpeg"
            r15.<init>(r16, r17, r19)
            r3 = r15
            Z2.c$a r11 = new Z2.c$a
            r15 = 0
            java.lang.String r12 = "video/mp4"
            r11.<init>(r12, r13, r15)
            S7.O r3 = S7.C1150x.w(r3, r11)
            goto L_0x0095
        L_0x008f:
            int r7 = r7 + r0
            goto L_0x0066
        L_0x0091:
            S7.x$b r3 = S7.C1150x.f9860i
            S7.O r3 = S7.O.f9711F
        L_0x0095:
            r7 = r8
            goto L_0x00ba
        L_0x0097:
            int r8 = r8 + r0
            goto L_0x0038
        L_0x0099:
            java.lang.String r9 = "Container:Directory"
            boolean r9 = A.o.R(r1, r9)
            if (r9 == 0) goto L_0x00aa
            java.lang.String r3 = "Container"
            java.lang.String r9 = "Item"
            S7.O r3 = b(r1, r3, r9)
            goto L_0x00ba
        L_0x00aa:
            java.lang.String r9 = "GContainer:Directory"
            boolean r9 = A.o.R(r1, r9)
            if (r9 == 0) goto L_0x00ba
            java.lang.String r3 = "GContainer"
            java.lang.String r9 = "GContainerItem"
            S7.O r3 = b(r1, r3, r9)
        L_0x00ba:
            boolean r9 = A.o.N(r1, r2)
            if (r9 == 0) goto L_0x0029
            boolean r0 = r3.isEmpty()
            if (r0 == 0) goto L_0x00c7
        L_0x00c6:
            return r4
        L_0x00c7:
            Z2.c r0 = new Z2.c
            r0.<init>(r7, r3)
            return r0
        L_0x00cd:
            java.lang.String r0 = "Couldn't find xmp metadata"
            l2.v r0 = l2.v.a(r4, r0)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: Z2.f.a(java.lang.String):Z2.c");
    }

    public static O b(XmlPullParser xmlPullParser, String str, String str2) {
        long j10;
        C1150x.b bVar = C1150x.f9860i;
        C1150x.a aVar = new C1150x.a();
        String concat = str.concat(":Item");
        String concat2 = str.concat(":Directory");
        do {
            xmlPullParser.next();
            if (o.R(xmlPullParser, concat)) {
                String concat3 = str2.concat(":Mime");
                String concat4 = str2.concat(":Semantic");
                String concat5 = str2.concat(":Length");
                String concat6 = str2.concat(":Padding");
                String z10 = o.z(xmlPullParser, concat3);
                String z11 = o.z(xmlPullParser, concat4);
                String z12 = o.z(xmlPullParser, concat5);
                String z13 = o.z(xmlPullParser, concat6);
                if (z10 == null || z11 == null) {
                    return O.f9711F;
                }
                long j11 = 0;
                if (z12 != null) {
                    j10 = Long.parseLong(z12);
                } else {
                    j10 = 0;
                }
                if (z13 != null) {
                    j11 = Long.parseLong(z13);
                }
                aVar.c(new c.a(z10, j10, j11));
            }
        } while (!o.N(xmlPullParser, concat2));
        return aVar.g();
    }
}
