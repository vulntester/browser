package Z3;

import android.graphics.PointF;
import android.graphics.Rect;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import java.util.HashMap;

public final class b extends g {

    /* renamed from: b0  reason: collision with root package name */
    public static final String[] f12060b0 = {"android:changeBounds:bounds", "android:changeBounds:clip", "android:changeBounds:parent", "android:changeBounds:windowX", "android:changeBounds:windowY"};

    /* renamed from: c0  reason: collision with root package name */
    public static final a f12061c0;

    /* renamed from: d0  reason: collision with root package name */
    public static final C0117b f12062d0;
    public static final c e0;

    /* renamed from: f0  reason: collision with root package name */
    public static final d f12063f0;

    /* renamed from: g0  reason: collision with root package name */
    public static final e f12064g0;

    public class a extends Property<g, PointF> {
        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            g gVar = (g) obj;
            return null;
        }

        public final void set(Object obj, Object obj2) {
            g gVar = (g) obj;
            PointF pointF = (PointF) obj2;
            gVar.getClass();
            gVar.f12067a = Math.round(pointF.x);
            int round = Math.round(pointF.y);
            gVar.f12068b = round;
            int i10 = gVar.f12072f + 1;
            gVar.f12072f = i10;
            if (i10 == gVar.f12073g) {
                p.a(gVar.f12071e, gVar.f12067a, round, gVar.f12069c, gVar.f12070d);
                gVar.f12072f = 0;
                gVar.f12073g = 0;
            }
        }
    }

    /* renamed from: Z3.b$b  reason: collision with other inner class name */
    public class C0117b extends Property<g, PointF> {
        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            g gVar = (g) obj;
            return null;
        }

        public final void set(Object obj, Object obj2) {
            g gVar = (g) obj;
            PointF pointF = (PointF) obj2;
            gVar.getClass();
            gVar.f12069c = Math.round(pointF.x);
            int round = Math.round(pointF.y);
            gVar.f12070d = round;
            int i10 = gVar.f12073g + 1;
            gVar.f12073g = i10;
            if (gVar.f12072f == i10) {
                p.a(gVar.f12071e, gVar.f12067a, gVar.f12068b, gVar.f12069c, round);
                gVar.f12072f = 0;
                gVar.f12073g = 0;
            }
        }
    }

    public class c extends Property<View, PointF> {
        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            View view = (View) obj;
            return null;
        }

        public final void set(Object obj, Object obj2) {
            View view = (View) obj;
            PointF pointF = (PointF) obj2;
            p.a(view, view.getLeft(), view.getTop(), Math.round(pointF.x), Math.round(pointF.y));
        }
    }

    public class d extends Property<View, PointF> {
        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            View view = (View) obj;
            return null;
        }

        public final void set(Object obj, Object obj2) {
            View view = (View) obj;
            PointF pointF = (PointF) obj2;
            p.a(view, Math.round(pointF.x), Math.round(pointF.y), view.getRight(), view.getBottom());
        }
    }

    public class e extends Property<View, PointF> {
        public final /* bridge */ /* synthetic */ Object get(Object obj) {
            View view = (View) obj;
            return null;
        }

        public final void set(Object obj, Object obj2) {
            View view = (View) obj;
            PointF pointF = (PointF) obj2;
            int round = Math.round(pointF.x);
            int round2 = Math.round(pointF.y);
            p.a(view, round, round2, view.getWidth() + round, view.getHeight() + round2);
        }
    }

    public static class f extends j {

        /* renamed from: a  reason: collision with root package name */
        public boolean f12065a = false;

        /* renamed from: b  reason: collision with root package name */
        public final ViewGroup f12066b;

        public f(ViewGroup viewGroup) {
            this.f12066b = viewGroup;
        }

        public final void a() {
            o.a(this.f12066b, false);
        }

        public final void c(g gVar) {
            if (!this.f12065a) {
                o.a(this.f12066b, false);
            }
            gVar.w(this);
        }

        public final void d(g gVar) {
            o.a(this.f12066b, false);
            this.f12065a = true;
        }

        public final void f() {
            o.a(this.f12066b, true);
        }
    }

    public static class g {

        /* renamed from: a  reason: collision with root package name */
        public int f12067a;

        /* renamed from: b  reason: collision with root package name */
        public int f12068b;

        /* renamed from: c  reason: collision with root package name */
        public int f12069c;

        /* renamed from: d  reason: collision with root package name */
        public int f12070d;

        /* renamed from: e  reason: collision with root package name */
        public final View f12071e;

        /* renamed from: f  reason: collision with root package name */
        public int f12072f;

        /* renamed from: g  reason: collision with root package name */
        public int f12073g;

        public g(View view) {
            this.f12071e = view;
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [Z3.b$a, android.util.Property] */
    /* JADX WARNING: type inference failed for: r0v3, types: [Z3.b$b, android.util.Property] */
    /* JADX WARNING: type inference failed for: r0v4, types: [Z3.b$c, android.util.Property] */
    /* JADX WARNING: type inference failed for: r0v5, types: [Z3.b$d, android.util.Property] */
    /* JADX WARNING: type inference failed for: r0v6, types: [Z3.b$e, android.util.Property] */
    static {
        Class<PointF> cls = PointF.class;
        f12061c0 = new Property(cls, "topLeft");
        f12062d0 = new Property(cls, "bottomRight");
        e0 = new Property(cls, "bottomRight");
        f12063f0 = new Property(cls, "topLeft");
        f12064g0 = new Property(cls, "position");
    }

    public static void I(n nVar) {
        View view = nVar.f12131b;
        if (view.isLaidOut() || view.getWidth() != 0 || view.getHeight() != 0) {
            HashMap hashMap = nVar.f12130a;
            hashMap.put("android:changeBounds:bounds", new Rect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()));
            hashMap.put("android:changeBounds:parent", nVar.f12131b.getParent());
        }
    }

    public final void c(n nVar) {
        I(nVar);
    }

    public final void f(n nVar) {
        I(nVar);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v1, resolved type: android.animation.ObjectAnimator} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v4, resolved type: android.animation.ObjectAnimator} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: android.animation.ObjectAnimator} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v6, resolved type: android.animation.AnimatorSet} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v9, resolved type: android.animation.ObjectAnimator} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v12, resolved type: android.animation.ObjectAnimator} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.animation.Animator j(android.widget.FrameLayout r19, Z3.n r20, Z3.n r21) {
        /*
            r18 = this;
            r1 = r20
            r2 = r21
            if (r1 == 0) goto L_0x0008
            if (r2 != 0) goto L_0x000c
        L_0x0008:
            r1 = r18
            goto L_0x012d
        L_0x000c:
            java.util.HashMap r1 = r1.f12130a
            java.util.HashMap r6 = r2.f12130a
            java.lang.String r7 = "android:changeBounds:parent"
            java.lang.Object r8 = r1.get(r7)
            android.view.ViewGroup r8 = (android.view.ViewGroup) r8
            java.lang.Object r7 = r6.get(r7)
            android.view.ViewGroup r7 = (android.view.ViewGroup) r7
            if (r8 == 0) goto L_0x0008
            if (r7 != 0) goto L_0x0023
            goto L_0x0008
        L_0x0023:
            java.lang.String r7 = "android:changeBounds:bounds"
            java.lang.Object r8 = r1.get(r7)
            android.graphics.Rect r8 = (android.graphics.Rect) r8
            java.lang.Object r7 = r6.get(r7)
            android.graphics.Rect r7 = (android.graphics.Rect) r7
            int r9 = r8.left
            int r10 = r7.left
            int r11 = r8.top
            int r12 = r7.top
            int r13 = r8.right
            int r14 = r7.right
            int r8 = r8.bottom
            int r7 = r7.bottom
            int r15 = r13 - r9
            r19 = 0
            int r4 = r8 - r11
            r16 = 1
            int r5 = r14 - r10
            int r3 = r7 - r12
            java.lang.String r0 = "android:changeBounds:clip"
            java.lang.Object r1 = r1.get(r0)
            android.graphics.Rect r1 = (android.graphics.Rect) r1
            java.lang.Object r0 = r6.get(r0)
            android.graphics.Rect r0 = (android.graphics.Rect) r0
            if (r15 == 0) goto L_0x005f
            if (r4 != 0) goto L_0x0063
        L_0x005f:
            if (r5 == 0) goto L_0x0074
            if (r3 == 0) goto L_0x0074
        L_0x0063:
            if (r9 != r10) goto L_0x006b
            if (r11 == r12) goto L_0x0068
            goto L_0x006b
        L_0x0068:
            r6 = r19
            goto L_0x006d
        L_0x006b:
            r6 = r16
        L_0x006d:
            if (r13 != r14) goto L_0x0071
            if (r8 == r7) goto L_0x0076
        L_0x0071:
            int r6 = r6 + 1
            goto L_0x0076
        L_0x0074:
            r6 = r19
        L_0x0076:
            if (r1 == 0) goto L_0x007e
            boolean r17 = r1.equals(r0)
            if (r17 == 0) goto L_0x0082
        L_0x007e:
            if (r1 != 0) goto L_0x0084
            if (r0 == 0) goto L_0x0084
        L_0x0082:
            int r6 = r6 + 1
        L_0x0084:
            if (r6 <= 0) goto L_0x0008
            android.view.View r0 = r2.f12131b
            Z3.p.a(r0, r9, r11, r13, r8)
            r1 = 2
            if (r6 != r1) goto L_0x00e5
            if (r15 != r5) goto L_0x00a5
            if (r4 != r3) goto L_0x00a5
            r1 = r18
            Z3.g$a r2 = r1.f12098W
            float r3 = (float) r9
            float r4 = (float) r11
            float r5 = (float) r10
            float r6 = (float) r12
            android.graphics.Path r2 = r2.r0(r3, r4, r5, r6)
            Z3.b$e r3 = f12064g0
            android.animation.ObjectAnimator r2 = Z3.e.a(r0, r3, r2)
            goto L_0x010d
        L_0x00a5:
            r1 = r18
            Z3.b$g r2 = new Z3.b$g
            r2.<init>(r0)
            Z3.g$a r3 = r1.f12098W
            float r4 = (float) r9
            float r5 = (float) r11
            float r6 = (float) r10
            float r9 = (float) r12
            android.graphics.Path r3 = r3.r0(r4, r5, r6, r9)
            Z3.b$a r4 = f12061c0
            android.animation.ObjectAnimator r3 = Z3.e.a(r2, r4, r3)
            Z3.g$a r4 = r1.f12098W
            float r5 = (float) r13
            float r6 = (float) r8
            float r8 = (float) r14
            float r7 = (float) r7
            android.graphics.Path r4 = r4.r0(r5, r6, r8, r7)
            Z3.b$b r5 = f12062d0
            android.animation.ObjectAnimator r4 = Z3.e.a(r2, r5, r4)
            android.animation.AnimatorSet r5 = new android.animation.AnimatorSet
            r5.<init>()
            r6 = 2
            android.animation.Animator[] r6 = new android.animation.Animator[r6]
            r6[r19] = r3
            r6[r16] = r4
            r5.playTogether(r6)
            Z3.c r3 = new Z3.c
            r3.<init>(r2)
            r5.addListener(r3)
            r2 = r5
            goto L_0x010d
        L_0x00e5:
            r1 = r18
            if (r9 != r10) goto L_0x00fd
            if (r11 == r12) goto L_0x00ec
            goto L_0x00fd
        L_0x00ec:
            Z3.g$a r2 = r1.f12098W
            float r3 = (float) r13
            float r4 = (float) r8
            float r5 = (float) r14
            float r6 = (float) r7
            android.graphics.Path r2 = r2.r0(r3, r4, r5, r6)
            Z3.b$c r3 = e0
            android.animation.ObjectAnimator r2 = Z3.e.a(r0, r3, r2)
            goto L_0x010d
        L_0x00fd:
            Z3.g$a r2 = r1.f12098W
            float r3 = (float) r9
            float r4 = (float) r11
            float r5 = (float) r10
            float r6 = (float) r12
            android.graphics.Path r2 = r2.r0(r3, r4, r5, r6)
            Z3.b$d r3 = f12063f0
            android.animation.ObjectAnimator r2 = Z3.e.a(r0, r3, r2)
        L_0x010d:
            android.view.ViewParent r3 = r0.getParent()
            boolean r3 = r3 instanceof android.view.ViewGroup
            if (r3 == 0) goto L_0x012c
            android.view.ViewParent r0 = r0.getParent()
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            r3 = r16
            Z3.o.a(r0, r3)
            Z3.g r3 = r1.n()
            Z3.b$f r4 = new Z3.b$f
            r4.<init>(r0)
            r3.a(r4)
        L_0x012c:
            return r2
        L_0x012d:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: Z3.b.j(android.widget.FrameLayout, Z3.n, Z3.n):android.animation.Animator");
    }

    public final String[] q() {
        return f12060b0;
    }
}
