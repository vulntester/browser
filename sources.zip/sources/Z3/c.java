package Z3;

import Z3.b;
import android.animation.AnimatorListenerAdapter;

public final class c extends AnimatorListenerAdapter {
    private final b.g mViewBounds;

    public c(b.g gVar) {
        this.mViewBounds = gVar;
    }
}
