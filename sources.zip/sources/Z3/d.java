package Z3;

import Z3.g;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.graphics.Paint;
import android.view.View;
import com.internet.tvbrowser.R;

public final class d extends v {

    public static class a extends AnimatorListenerAdapter implements g.d {

        /* renamed from: a  reason: collision with root package name */
        public final View f12074a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f12075b = false;

        public a(View view) {
            this.f12074a = view;
        }

        public final void a() {
            float f10;
            View view = this.f12074a;
            if (view.getVisibility() == 0) {
                f10 = p.f12134a.a(view);
            } else {
                f10 = 0.0f;
            }
            view.setTag(R.id.transition_pause_alpha, Float.valueOf(f10));
        }

        public final void b(g gVar) {
        }

        public final void c(g gVar) {
            throw null;
        }

        public final void f() {
            this.f12074a.setTag(R.id.transition_pause_alpha, (Object) null);
        }

        public final void g(g gVar) {
            throw null;
        }

        public final void onAnimationCancel(Animator animator) {
            p.f12134a.b(this.f12074a, 1.0f);
        }

        public final void onAnimationEnd(Animator animator) {
            onAnimationEnd(animator, false);
        }

        public final void onAnimationStart(Animator animator) {
            View view = this.f12074a;
            if (view.hasOverlappingRendering() && view.getLayerType() == 0) {
                this.f12075b = true;
                view.setLayerType(2, (Paint) null);
            }
        }

        public final void onAnimationEnd(Animator animator, boolean z10) {
            boolean z11 = this.f12075b;
            View view = this.f12074a;
            if (z11) {
                view.setLayerType(0, (Paint) null);
            }
            if (!z10) {
                t tVar = p.f12134a;
                tVar.b(view, 1.0f);
                tVar.getClass();
            }
        }

        public final void d(g gVar) {
        }

        public final void e(g gVar) {
        }
    }

    public d(int i10) {
        this.f12144b0 = i10;
    }

    public static float L(n nVar, float f10) {
        Float f11;
        if (nVar == null || (f11 = (Float) nVar.f12130a.get("android:fade:transitionAlpha")) == null) {
            return f10;
        }
        return f11.floatValue();
    }

    public final ObjectAnimator K(View view, float f10, float f11) {
        if (f10 == f11) {
            return null;
        }
        p.f12134a.b(view, f10);
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, p.f12135b, new float[]{f11});
        a aVar = new a(view);
        ofFloat.addListener(aVar);
        n().a(aVar);
        return ofFloat;
    }

    public final void f(n nVar) {
        v.I(nVar);
        View view = nVar.f12131b;
        Float f10 = (Float) view.getTag(R.id.transition_pause_alpha);
        if (f10 == null) {
            if (view.getVisibility() == 0) {
                f10 = Float.valueOf(p.f12134a.a(view));
            } else {
                f10 = Float.valueOf(0.0f);
            }
        }
        nVar.f12130a.put("android:fade:transitionAlpha", f10);
    }
}
