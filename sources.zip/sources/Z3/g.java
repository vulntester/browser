package Z3;

import A6.u;
import D2.E;
import F1.S;
import F1.b0;
import H0.C0708z;
import M.k;
import Pb.J;
import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.graphics.Path;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowId;
import android.widget.FrameLayout;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;
import t.C3104a;
import t.C3125v;

public abstract class g implements Cloneable {

    /* renamed from: X  reason: collision with root package name */
    public static final Animator[] f12076X = new Animator[0];

    /* renamed from: Y  reason: collision with root package name */
    public static final int[] f12077Y = {2, 1, 3, 4};

    /* renamed from: Z  reason: collision with root package name */
    public static final a f12078Z = new Object();

    /* renamed from: a0  reason: collision with root package name */
    public static final ThreadLocal<C3104a<Animator, b>> f12079a0 = new ThreadLocal<>();

    /* renamed from: E  reason: collision with root package name */
    public TimeInterpolator f12080E = null;

    /* renamed from: F  reason: collision with root package name */
    public final ArrayList<Integer> f12081F = new ArrayList<>();

    /* renamed from: G  reason: collision with root package name */
    public final ArrayList<View> f12082G = new ArrayList<>();

    /* renamed from: H  reason: collision with root package name */
    public J f12083H = new J();

    /* renamed from: I  reason: collision with root package name */
    public J f12084I = new J();

    /* renamed from: J  reason: collision with root package name */
    public l f12085J = null;

    /* renamed from: K  reason: collision with root package name */
    public final int[] f12086K = f12077Y;

    /* renamed from: L  reason: collision with root package name */
    public ArrayList<n> f12087L;

    /* renamed from: M  reason: collision with root package name */
    public ArrayList<n> f12088M;

    /* renamed from: N  reason: collision with root package name */
    public d[] f12089N;

    /* renamed from: O  reason: collision with root package name */
    public final ArrayList<Animator> f12090O = new ArrayList<>();

    /* renamed from: P  reason: collision with root package name */
    public Animator[] f12091P = f12076X;

    /* renamed from: Q  reason: collision with root package name */
    public int f12092Q = 0;

    /* renamed from: R  reason: collision with root package name */
    public boolean f12093R = false;

    /* renamed from: S  reason: collision with root package name */
    public boolean f12094S = false;

    /* renamed from: T  reason: collision with root package name */
    public g f12095T = null;

    /* renamed from: U  reason: collision with root package name */
    public ArrayList<d> f12096U = null;

    /* renamed from: V  reason: collision with root package name */
    public ArrayList<Animator> f12097V = new ArrayList<>();

    /* renamed from: W  reason: collision with root package name */
    public a f12098W = f12078Z;

    /* renamed from: f  reason: collision with root package name */
    public final String f12099f = getClass().getName();

    /* renamed from: i  reason: collision with root package name */
    public long f12100i = -1;

    /* renamed from: z  reason: collision with root package name */
    public long f12101z = -1;

    public class a extends C7.a {
        public final Path r0(float f10, float f11, float f12, float f13) {
            Path path = new Path();
            path.moveTo(f10, f11);
            path.lineTo(f12, f13);
            return path;
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public View f12102a;

        /* renamed from: b  reason: collision with root package name */
        public String f12103b;

        /* renamed from: c  reason: collision with root package name */
        public n f12104c;

        /* renamed from: d  reason: collision with root package name */
        public WindowId f12105d;

        /* renamed from: e  reason: collision with root package name */
        public g f12106e;

        /* renamed from: f  reason: collision with root package name */
        public Animator f12107f;
    }

    public static abstract class c {
    }

    public interface d {
        void a();

        void b(g gVar);

        void c(g gVar);

        void d(g gVar);

        void e(g gVar);

        void f();

        void g(g gVar);
    }

    public interface e {

        /* renamed from: l  reason: collision with root package name */
        public static final k f12108l = new k(3);

        /* renamed from: m  reason: collision with root package name */
        public static final E f12109m = new E(6);

        /* renamed from: n  reason: collision with root package name */
        public static final u f12110n = new u(5);

        /* renamed from: o  reason: collision with root package name */
        public static final C0708z f12111o = new C0708z(4);

        /* renamed from: p  reason: collision with root package name */
        public static final D1.b f12112p = new D1.b(7);

        void b(d dVar, g gVar);
    }

    public static void b(J j10, View view, n nVar) {
        ((C3104a) j10.f37463f).put(view, nVar);
        int id = view.getId();
        if (id >= 0) {
            SparseArray sparseArray = (SparseArray) j10.f37464i;
            if (sparseArray.indexOfKey(id) >= 0) {
                sparseArray.put(id, (Object) null);
            } else {
                sparseArray.put(id, view);
            }
        }
        WeakHashMap<View, b0> weakHashMap = S.f2461a;
        String f10 = S.d.f(view);
        if (f10 != null) {
            C3104a aVar = (C3104a) j10.f37462E;
            if (aVar.containsKey(f10)) {
                aVar.put(f10, null);
            } else {
                aVar.put(f10, view);
            }
        }
        if (view.getParent() instanceof ListView) {
            ListView listView = (ListView) view.getParent();
            if (listView.getAdapter().hasStableIds()) {
                long itemIdAtPosition = listView.getItemIdAtPosition(listView.getPositionForView(view));
                C3125v vVar = (C3125v) j10.f37465z;
                if (vVar.f(itemIdAtPosition) >= 0) {
                    View view2 = (View) vVar.d(itemIdAtPosition);
                    if (view2 != null) {
                        view2.setHasTransientState(false);
                        vVar.h(itemIdAtPosition, null);
                        return;
                    }
                    return;
                }
                view.setHasTransientState(true);
                vVar.h(itemIdAtPosition, view);
            }
        }
    }

    public static C3104a<Animator, b> p() {
        ThreadLocal<C3104a<Animator, b>> threadLocal = f12079a0;
        C3104a<Animator, b> aVar = threadLocal.get();
        if (aVar != null) {
            return aVar;
        }
        C3104a<Animator, b> aVar2 = new C3104a<>();
        threadLocal.set(aVar2);
        return aVar2;
    }

    public void B(TimeInterpolator timeInterpolator) {
        this.f12080E = timeInterpolator;
    }

    public void D(a aVar) {
        if (aVar == null) {
            this.f12098W = f12078Z;
        } else {
            this.f12098W = aVar;
        }
    }

    public void F(long j10) {
        this.f12100i = j10;
    }

    public final void G() {
        if (this.f12092Q == 0) {
            u(this, e.f12108l);
            this.f12094S = false;
        }
        this.f12092Q++;
    }

    public String H(String str) {
        StringBuilder sb2 = new StringBuilder(str);
        sb2.append(getClass().getSimpleName());
        sb2.append("@");
        sb2.append(Integer.toHexString(hashCode()));
        sb2.append(": ");
        if (this.f12101z != -1) {
            sb2.append("dur(");
            sb2.append(this.f12101z);
            sb2.append(") ");
        }
        if (this.f12100i != -1) {
            sb2.append("dly(");
            sb2.append(this.f12100i);
            sb2.append(") ");
        }
        if (this.f12080E != null) {
            sb2.append("interp(");
            sb2.append(this.f12080E);
            sb2.append(") ");
        }
        ArrayList<Integer> arrayList = this.f12081F;
        int size = arrayList.size();
        ArrayList<View> arrayList2 = this.f12082G;
        if (size > 0 || arrayList2.size() > 0) {
            sb2.append("tgts(");
            if (arrayList.size() > 0) {
                for (int i10 = 0; i10 < arrayList.size(); i10++) {
                    if (i10 > 0) {
                        sb2.append(", ");
                    }
                    sb2.append(arrayList.get(i10));
                }
            }
            if (arrayList2.size() > 0) {
                for (int i11 = 0; i11 < arrayList2.size(); i11++) {
                    if (i11 > 0) {
                        sb2.append(", ");
                    }
                    sb2.append(arrayList2.get(i11));
                }
            }
            sb2.append(")");
        }
        return sb2.toString();
    }

    public void a(d dVar) {
        if (this.f12096U == null) {
            this.f12096U = new ArrayList<>();
        }
        this.f12096U.add(dVar);
    }

    public abstract void c(n nVar);

    public void cancel() {
        ArrayList<Animator> arrayList = this.f12090O;
        int size = arrayList.size();
        Animator[] animatorArr = (Animator[]) arrayList.toArray(this.f12091P);
        this.f12091P = f12076X;
        for (int i10 = size - 1; i10 >= 0; i10--) {
            Animator animator = animatorArr[i10];
            animatorArr[i10] = null;
            animator.cancel();
        }
        this.f12091P = animatorArr;
        u(this, e.f12110n);
    }

    public final void d(View view, boolean z10) {
        if (view != null) {
            view.getId();
            if (view.getParent() instanceof ViewGroup) {
                n nVar = new n(view);
                if (z10) {
                    f(nVar);
                } else {
                    c(nVar);
                }
                nVar.f12132c.add(this);
                e(nVar);
                if (z10) {
                    b(this.f12083H, view, nVar);
                } else {
                    b(this.f12084I, view, nVar);
                }
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i10 = 0; i10 < viewGroup.getChildCount(); i10++) {
                    d(viewGroup.getChildAt(i10), z10);
                }
            }
        }
    }

    public abstract void f(n nVar);

    public final void g(FrameLayout frameLayout, boolean z10) {
        h(z10);
        ArrayList<Integer> arrayList = this.f12081F;
        int size = arrayList.size();
        ArrayList<View> arrayList2 = this.f12082G;
        if (size > 0 || arrayList2.size() > 0) {
            for (int i10 = 0; i10 < arrayList.size(); i10++) {
                View findViewById = frameLayout.findViewById(arrayList.get(i10).intValue());
                if (findViewById != null) {
                    n nVar = new n(findViewById);
                    if (z10) {
                        f(nVar);
                    } else {
                        c(nVar);
                    }
                    nVar.f12132c.add(this);
                    e(nVar);
                    if (z10) {
                        b(this.f12083H, findViewById, nVar);
                    } else {
                        b(this.f12084I, findViewById, nVar);
                    }
                }
            }
            for (int i11 = 0; i11 < arrayList2.size(); i11++) {
                View view = arrayList2.get(i11);
                n nVar2 = new n(view);
                if (z10) {
                    f(nVar2);
                } else {
                    c(nVar2);
                }
                nVar2.f12132c.add(this);
                e(nVar2);
                if (z10) {
                    b(this.f12083H, view, nVar2);
                } else {
                    b(this.f12084I, view, nVar2);
                }
            }
            return;
        }
        d(frameLayout, z10);
    }

    public final void h(boolean z10) {
        if (z10) {
            ((C3104a) this.f12083H.f37463f).clear();
            ((SparseArray) this.f12083H.f37464i).clear();
            ((C3125v) this.f12083H.f37465z).b();
            return;
        }
        ((C3104a) this.f12084I.f37463f).clear();
        ((SparseArray) this.f12084I.f37464i).clear();
        ((C3125v) this.f12084I.f37465z).b();
    }

    /* renamed from: i */
    public g clone() {
        try {
            g gVar = (g) super.clone();
            gVar.f12097V = new ArrayList<>();
            gVar.f12083H = new J();
            gVar.f12084I = new J();
            gVar.f12087L = null;
            gVar.f12088M = null;
            gVar.f12095T = this;
            gVar.f12096U = null;
            return gVar;
        } catch (CloneNotSupportedException e10) {
            throw new RuntimeException(e10);
        }
    }

    public Animator j(FrameLayout frameLayout, n nVar, n nVar2) {
        return null;
    }

    /* JADX WARNING: type inference failed for: r3v11, types: [Z3.g$b, java.lang.Object] */
    public void k(FrameLayout frameLayout, J j10, J j11, ArrayList arrayList, ArrayList arrayList2) {
        int i10;
        int i11;
        n nVar;
        View view;
        n nVar2;
        Animator animator;
        C3104a<Animator, b> p10 = p();
        SparseIntArray sparseIntArray = new SparseIntArray();
        int size = arrayList.size();
        n().getClass();
        int i12 = 0;
        while (i12 < size) {
            n nVar3 = (n) arrayList.get(i12);
            n nVar4 = (n) arrayList2.get(i12);
            if (nVar3 != null && !nVar3.f12132c.contains(this)) {
                nVar3 = null;
            }
            if (nVar4 != null && !nVar4.f12132c.contains(this)) {
                nVar4 = null;
            }
            if (!(nVar3 == null && nVar4 == null) && (nVar3 == null || nVar4 == null || s(nVar3, nVar4))) {
                FrameLayout frameLayout2 = frameLayout;
                Animator j12 = j(frameLayout2, nVar3, nVar4);
                if (j12 != null) {
                    String str = this.f12099f;
                    if (nVar4 != null) {
                        String[] q10 = q();
                        view = nVar4.f12131b;
                        if (q10 != null && q10.length > 0) {
                            nVar2 = new n(view);
                            n nVar5 = (n) ((C3104a) j11.f37463f).get(view);
                            i11 = size;
                            if (nVar5 != null) {
                                int i13 = 0;
                                while (i13 < q10.length) {
                                    HashMap hashMap = nVar2.f12130a;
                                    int i14 = i12;
                                    String str2 = q10[i13];
                                    hashMap.put(str2, nVar5.f12130a.get(str2));
                                    i13++;
                                    ArrayList arrayList3 = arrayList;
                                    i12 = i14;
                                }
                            }
                            i10 = i12;
                            int i15 = p10.f28023z;
                            int i16 = 0;
                            while (true) {
                                if (i16 >= i15) {
                                    animator = j12;
                                    break;
                                }
                                b bVar = p10.get(p10.h(i16));
                                if (bVar.f12104c != null && bVar.f12102a == view && bVar.f12103b.equals(str) && bVar.f12104c.equals(nVar2)) {
                                    animator = null;
                                    break;
                                }
                                i16++;
                            }
                        } else {
                            J j13 = j11;
                            i11 = size;
                            i10 = i12;
                            animator = j12;
                            nVar2 = null;
                        }
                        j12 = animator;
                        nVar = nVar2;
                    } else {
                        J j14 = j11;
                        i11 = size;
                        i10 = i12;
                        view = nVar3.f12131b;
                        nVar = null;
                    }
                    if (j12 != null) {
                        WindowId windowId = frameLayout2.getWindowId();
                        ? obj = new Object();
                        obj.f12102a = view;
                        obj.f12103b = str;
                        obj.f12104c = nVar;
                        obj.f12105d = windowId;
                        obj.f12106e = this;
                        obj.f12107f = j12;
                        p10.put(j12, obj);
                        this.f12097V.add(j12);
                    }
                    i12 = i10 + 1;
                    size = i11;
                }
            } else {
                FrameLayout frameLayout3 = frameLayout;
            }
            J j15 = j11;
            i11 = size;
            i10 = i12;
            i12 = i10 + 1;
            size = i11;
        }
        if (sparseIntArray.size() != 0) {
            for (int i17 = 0; i17 < sparseIntArray.size(); i17++) {
                b bVar2 = p10.get(this.f12097V.get(sparseIntArray.keyAt(i17)));
                long startDelay = bVar2.f12107f.getStartDelay();
                bVar2.f12107f.setStartDelay(startDelay + (((long) sparseIntArray.valueAt(i17)) - Long.MAX_VALUE));
            }
        }
    }

    public final void l() {
        int i10 = this.f12092Q - 1;
        this.f12092Q = i10;
        if (i10 == 0) {
            u(this, e.f12109m);
            for (int i11 = 0; i11 < ((C3125v) this.f12083H.f37465z).j(); i11++) {
                View view = (View) ((C3125v) this.f12083H.f37465z).k(i11);
                if (view != null) {
                    view.setHasTransientState(false);
                }
            }
            for (int i12 = 0; i12 < ((C3125v) this.f12084I.f37465z).j(); i12++) {
                View view2 = (View) ((C3125v) this.f12084I.f37465z).k(i12);
                if (view2 != null) {
                    view2.setHasTransientState(false);
                }
            }
            this.f12094S = true;
        }
    }

    public final n m(View view, boolean z10) {
        ArrayList<n> arrayList;
        ArrayList<n> arrayList2;
        l lVar = this.f12085J;
        if (lVar != null) {
            return lVar.m(view, z10);
        }
        if (z10) {
            arrayList = this.f12087L;
        } else {
            arrayList = this.f12088M;
        }
        if (arrayList == null) {
            return null;
        }
        int size = arrayList.size();
        int i10 = 0;
        while (true) {
            if (i10 >= size) {
                i10 = -1;
                break;
            }
            n nVar = arrayList.get(i10);
            if (nVar == null) {
                return null;
            }
            if (nVar.f12131b == view) {
                break;
            }
            i10++;
        }
        if (i10 < 0) {
            return null;
        }
        if (z10) {
            arrayList2 = this.f12088M;
        } else {
            arrayList2 = this.f12087L;
        }
        return arrayList2.get(i10);
    }

    public final g n() {
        l lVar = this.f12085J;
        if (lVar != null) {
            return lVar.n();
        }
        return this;
    }

    public String[] q() {
        return null;
    }

    public final n r(View view, boolean z10) {
        J j10;
        l lVar = this.f12085J;
        if (lVar != null) {
            return lVar.r(view, z10);
        }
        if (z10) {
            j10 = this.f12083H;
        } else {
            j10 = this.f12084I;
        }
        return (n) ((C3104a) j10.f37463f).get(view);
    }

    public boolean s(n nVar, n nVar2) {
        boolean z10;
        boolean z11;
        if (!(nVar == null || nVar2 == null)) {
            String[] q10 = q();
            HashMap hashMap = nVar.f12130a;
            HashMap hashMap2 = nVar2.f12130a;
            if (q10 != null) {
                int length = q10.length;
                int i10 = 0;
                while (i10 < length) {
                    String str = q10[i10];
                    Object obj = hashMap.get(str);
                    Object obj2 = hashMap2.get(str);
                    if (obj == null && obj2 == null) {
                        z11 = false;
                    } else if (obj == null || obj2 == null) {
                        z11 = true;
                    } else {
                        z11 = !obj.equals(obj2);
                    }
                    if (!z11) {
                        i10++;
                    }
                }
            } else {
                for (String str2 : hashMap.keySet()) {
                    Object obj3 = hashMap.get(str2);
                    Object obj4 = hashMap2.get(str2);
                    if (obj3 == null && obj4 == null) {
                        z10 = false;
                        continue;
                    } else if (obj3 == null || obj4 == null) {
                        z10 = true;
                        continue;
                    } else {
                        z10 = !obj3.equals(obj4);
                        continue;
                    }
                    if (z10) {
                    }
                }
            }
            return true;
        }
        return false;
    }

    public final boolean t(View view) {
        int id = view.getId();
        ArrayList<Integer> arrayList = this.f12081F;
        int size = arrayList.size();
        ArrayList<View> arrayList2 = this.f12082G;
        if ((size != 0 || arrayList2.size() != 0) && !arrayList.contains(Integer.valueOf(id)) && !arrayList2.contains(view)) {
            return false;
        }
        return true;
    }

    public final String toString() {
        return H("");
    }

    public final void u(g gVar, e eVar) {
        g gVar2 = this.f12095T;
        if (gVar2 != null) {
            gVar2.u(gVar, eVar);
        }
        ArrayList<d> arrayList = this.f12096U;
        if (arrayList != null && !arrayList.isEmpty()) {
            int size = this.f12096U.size();
            d[] dVarArr = this.f12089N;
            if (dVarArr == null) {
                dVarArr = new d[size];
            }
            this.f12089N = null;
            d[] dVarArr2 = (d[]) this.f12096U.toArray(dVarArr);
            for (int i10 = 0; i10 < size; i10++) {
                eVar.b(dVarArr2[i10], gVar);
                dVarArr2[i10] = null;
            }
            this.f12089N = dVarArr2;
        }
    }

    public void v(ViewGroup viewGroup) {
        if (!this.f12094S) {
            ArrayList<Animator> arrayList = this.f12090O;
            int size = arrayList.size();
            Animator[] animatorArr = (Animator[]) arrayList.toArray(this.f12091P);
            this.f12091P = f12076X;
            for (int i10 = size - 1; i10 >= 0; i10--) {
                Animator animator = animatorArr[i10];
                animatorArr[i10] = null;
                animator.pause();
            }
            this.f12091P = animatorArr;
            u(this, e.f12111o);
            this.f12093R = true;
        }
    }

    public g w(d dVar) {
        g gVar;
        ArrayList<d> arrayList = this.f12096U;
        if (arrayList != null) {
            if (!arrayList.remove(dVar) && (gVar = this.f12095T) != null) {
                gVar.w(dVar);
            }
            if (this.f12096U.size() == 0) {
                this.f12096U = null;
            }
        }
        return this;
    }

    public void x(FrameLayout frameLayout) {
        if (this.f12093R) {
            if (!this.f12094S) {
                ArrayList<Animator> arrayList = this.f12090O;
                int size = arrayList.size();
                Animator[] animatorArr = (Animator[]) arrayList.toArray(this.f12091P);
                this.f12091P = f12076X;
                for (int i10 = size - 1; i10 >= 0; i10--) {
                    Animator animator = animatorArr[i10];
                    animatorArr[i10] = null;
                    animator.resume();
                }
                this.f12091P = animatorArr;
                u(this, e.f12112p);
            }
            this.f12093R = false;
        }
    }

    public void y() {
        G();
        C3104a<Animator, b> p10 = p();
        Iterator<Animator> it = this.f12097V.iterator();
        while (it.hasNext()) {
            Animator next = it.next();
            if (p10.containsKey(next)) {
                G();
                if (next != null) {
                    next.addListener(new h(this, p10));
                    long j10 = this.f12101z;
                    if (j10 >= 0) {
                        next.setDuration(j10);
                    }
                    long j11 = this.f12100i;
                    if (j11 >= 0) {
                        next.setStartDelay(next.getStartDelay() + j11);
                    }
                    TimeInterpolator timeInterpolator = this.f12080E;
                    if (timeInterpolator != null) {
                        next.setInterpolator(timeInterpolator);
                    }
                    next.addListener(new i(this));
                    next.start();
                }
            }
        }
        this.f12097V.clear();
        l();
    }

    public void z(long j10) {
        this.f12101z = j10;
    }

    public void E() {
    }

    public void A(c cVar) {
    }

    public void e(n nVar) {
    }
}
