package Z3;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import t.C3104a;

public final class h extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C3104a f12113a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ g f12114b;

    public h(g gVar, C3104a aVar) {
        this.f12114b = gVar;
        this.f12113a = aVar;
    }

    public final void onAnimationEnd(Animator animator) {
        this.f12113a.remove(animator);
        this.f12114b.f12090O.remove(animator);
    }

    public final void onAnimationStart(Animator animator) {
        this.f12114b.f12090O.add(animator);
    }
}
