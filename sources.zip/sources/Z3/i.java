package Z3;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

public final class i extends AnimatorListenerAdapter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f12115a;

    public i(g gVar) {
        this.f12115a = gVar;
    }

    public final void onAnimationEnd(Animator animator) {
        this.f12115a.l();
        animator.removeListener(this);
    }
}
