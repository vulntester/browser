package Z3;

import Z3.g;

public class j implements g.d {
    public final void b(g gVar) {
        c(gVar);
    }

    public final void e(g gVar) {
        g(gVar);
    }

    public void a() {
    }

    public void f() {
    }

    public void d(g gVar) {
    }

    public void g(g gVar) {
    }
}
