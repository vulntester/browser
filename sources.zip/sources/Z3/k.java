package Z3;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import com.internet.tvbrowser.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import t.C3104a;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    public static final a f12116a;

    /* renamed from: b  reason: collision with root package name */
    public static final ThreadLocal<WeakReference<C3104a<ViewGroup, ArrayList<g>>>> f12117b = new ThreadLocal<>();

    /* renamed from: c  reason: collision with root package name */
    public static final ArrayList<ViewGroup> f12118c = new ArrayList<>();

    /* JADX WARNING: type inference failed for: r0v0, types: [Z3.a, Z3.l] */
    static {
        ? lVar = new l();
        lVar.f12124c0 = false;
        lVar.I(new d(2));
        lVar.I(new g());
        lVar.I(new d(1));
        f12116a = lVar;
    }

    /* JADX WARNING: type inference failed for: r0v6, types: [android.view.ViewTreeObserver$OnPreDrawListener, java.lang.Object, Z3.k$a, android.view.View$OnAttachStateChangeListener] */
    public static void a(FrameLayout frameLayout, g gVar) {
        ArrayList<ViewGroup> arrayList = f12118c;
        if (!arrayList.contains(frameLayout) && frameLayout.isLaidOut()) {
            arrayList.add(frameLayout);
            if (gVar == null) {
                gVar = f12116a;
            }
            g i10 = gVar.clone();
            ArrayList arrayList2 = b().get(frameLayout);
            if (arrayList2 != null && arrayList2.size() > 0) {
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    ((g) it.next()).v(frameLayout);
                }
            }
            i10.g(frameLayout, true);
            if (((f) frameLayout.getTag(R.id.transition_current_scene)) == null) {
                frameLayout.setTag(R.id.transition_current_scene, (Object) null);
                ? obj = new Object();
                obj.f12119f = i10;
                obj.f12120i = frameLayout;
                frameLayout.addOnAttachStateChangeListener(obj);
                frameLayout.getViewTreeObserver().addOnPreDrawListener(obj);
                return;
            }
            throw null;
        }
    }

    public static C3104a<ViewGroup, ArrayList<g>> b() {
        C3104a<ViewGroup, ArrayList<g>> aVar;
        ThreadLocal<WeakReference<C3104a<ViewGroup, ArrayList<g>>>> threadLocal = f12117b;
        WeakReference weakReference = threadLocal.get();
        if (weakReference != null && (aVar = (C3104a) weakReference.get()) != null) {
            return aVar;
        }
        C3104a<ViewGroup, ArrayList<g>> aVar2 = new C3104a<>();
        threadLocal.set(new WeakReference(aVar2));
        return aVar2;
    }

    public static class a implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

        /* renamed from: f  reason: collision with root package name */
        public g f12119f;

        /* renamed from: i  reason: collision with root package name */
        public FrameLayout f12120i;

        /* renamed from: Z3.k$a$a  reason: collision with other inner class name */
        public class C0118a extends j {

            /* renamed from: a  reason: collision with root package name */
            public final /* synthetic */ C3104a f12121a;

            public C0118a(C3104a aVar) {
                this.f12121a = aVar;
            }

            public final void c(g gVar) {
                ((ArrayList) this.f12121a.get(a.this.f12120i)).remove(gVar);
                gVar.w(this);
            }
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v5, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v6, resolved type: Z3.n} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:106:0x0249  */
        /* JADX WARNING: Removed duplicated region for block: B:12:0x004e  */
        /* JADX WARNING: Removed duplicated region for block: B:132:0x01f5 A[EDGE_INSN: B:132:0x01f5->B:89:0x01f5 ?: BREAK  , SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:19:0x008c  */
        /* JADX WARNING: Removed duplicated region for block: B:92:0x01fc  */
        /* JADX WARNING: Removed duplicated region for block: B:99:0x021d  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final boolean onPreDraw() {
            /*
                r18 = this;
                r0 = r18
                android.widget.FrameLayout r1 = r0.f12120i
                android.view.ViewTreeObserver r2 = r1.getViewTreeObserver()
                r2.removeOnPreDrawListener(r0)
                r1.removeOnAttachStateChangeListener(r0)
                java.util.ArrayList<android.view.ViewGroup> r1 = Z3.k.f12118c
                android.widget.FrameLayout r3 = r0.f12120i
                boolean r1 = r1.remove(r3)
                r8 = 1
                if (r1 != 0) goto L_0x001a
                return r8
            L_0x001a:
                t.a r1 = Z3.k.b()
                java.lang.Object r2 = r1.get(r3)
                java.util.ArrayList r2 = (java.util.ArrayList) r2
                if (r2 != 0) goto L_0x0030
                java.util.ArrayList r2 = new java.util.ArrayList
                r2.<init>()
                r1.put(r3, r2)
            L_0x002e:
                r5 = 0
                goto L_0x003b
            L_0x0030:
                int r5 = r2.size()
                if (r5 <= 0) goto L_0x002e
                java.util.ArrayList r5 = new java.util.ArrayList
                r5.<init>(r2)
            L_0x003b:
                Z3.g r6 = r0.f12119f
                r2.add(r6)
                Z3.k$a$a r2 = new Z3.k$a$a
                r2.<init>(r1)
                r6.a(r2)
                r1 = 0
                r6.g(r3, r1)
                if (r5 == 0) goto L_0x0062
                java.util.Iterator r2 = r5.iterator()
            L_0x0052:
                boolean r5 = r2.hasNext()
                if (r5 == 0) goto L_0x0062
                java.lang.Object r5 = r2.next()
                Z3.g r5 = (Z3.g) r5
                r5.x(r3)
                goto L_0x0052
            L_0x0062:
                java.util.ArrayList r2 = new java.util.ArrayList
                r2.<init>()
                r6.f12087L = r2
                java.util.ArrayList r2 = new java.util.ArrayList
                r2.<init>()
                r6.f12088M = r2
                Pb.J r2 = r6.f12083H
                Pb.J r5 = r6.f12084I
                t.a r7 = new t.a
                java.lang.Object r9 = r2.f37463f
                t.a r9 = (t.C3104a) r9
                r7.<init>(r9)
                t.a r9 = new t.a
                java.lang.Object r10 = r5.f37463f
                t.a r10 = (t.C3104a) r10
                r9.<init>(r10)
                r10 = r1
            L_0x0087:
                int[] r11 = r6.f12086K
                int r12 = r11.length
                if (r10 >= r12) goto L_0x01f5
                r11 = r11[r10]
                if (r11 == r8) goto L_0x01b1
                r12 = 2
                if (r11 == r12) goto L_0x015e
                r12 = 3
                if (r11 == r12) goto L_0x0105
                r12 = 4
                if (r11 == r12) goto L_0x009e
                r1 = r2
                r17 = r8
                goto L_0x01eb
            L_0x009e:
                java.lang.Object r11 = r2.f37465z
                t.v r11 = (t.C3125v) r11
                int r12 = r11.j()
                r13 = r1
            L_0x00a7:
                if (r13 >= r12) goto L_0x0100
                java.lang.Object r14 = r11.k(r13)
                android.view.View r14 = (android.view.View) r14
                if (r14 == 0) goto L_0x00f5
                boolean r15 = r6.t(r14)
                if (r15 == 0) goto L_0x00f5
                r16 = r2
                long r1 = r11.g(r13)
                java.lang.Object r15 = r5.f37465z
                t.v r15 = (t.C3125v) r15
                java.lang.Object r1 = r15.d(r1)
                android.view.View r1 = (android.view.View) r1
                if (r1 == 0) goto L_0x00f2
                boolean r2 = r6.t(r1)
                if (r2 == 0) goto L_0x00f2
                java.lang.Object r2 = r7.get(r14)
                Z3.n r2 = (Z3.n) r2
                java.lang.Object r15 = r9.get(r1)
                Z3.n r15 = (Z3.n) r15
                if (r2 == 0) goto L_0x00f2
                if (r15 == 0) goto L_0x00f2
                r17 = r8
                java.util.ArrayList<Z3.n> r8 = r6.f12087L
                r8.add(r2)
                java.util.ArrayList<Z3.n> r2 = r6.f12088M
                r2.add(r15)
                r7.remove(r14)
                r9.remove(r1)
                goto L_0x00f8
            L_0x00f2:
                r17 = r8
                goto L_0x00f8
            L_0x00f5:
                r16 = r2
                goto L_0x00f2
            L_0x00f8:
                int r13 = r13 + 1
                r2 = r16
                r8 = r17
                r1 = 0
                goto L_0x00a7
            L_0x0100:
                r17 = r8
                r1 = r2
                goto L_0x01eb
            L_0x0105:
                r1 = r2
                r17 = r8
                java.lang.Object r2 = r1.f37464i
                android.util.SparseArray r2 = (android.util.SparseArray) r2
                java.lang.Object r8 = r5.f37464i
                android.util.SparseArray r8 = (android.util.SparseArray) r8
                int r11 = r2.size()
                r12 = 0
            L_0x0115:
                if (r12 >= r11) goto L_0x01eb
                java.lang.Object r13 = r2.valueAt(r12)
                android.view.View r13 = (android.view.View) r13
                if (r13 == 0) goto L_0x0159
                boolean r14 = r6.t(r13)
                if (r14 == 0) goto L_0x0159
                int r14 = r2.keyAt(r12)
                java.lang.Object r14 = r8.get(r14)
                android.view.View r14 = (android.view.View) r14
                if (r14 == 0) goto L_0x0159
                boolean r15 = r6.t(r14)
                if (r15 == 0) goto L_0x0159
                java.lang.Object r15 = r7.get(r13)
                Z3.n r15 = (Z3.n) r15
                java.lang.Object r16 = r9.get(r14)
                r4 = r16
                Z3.n r4 = (Z3.n) r4
                if (r15 == 0) goto L_0x0159
                if (r4 == 0) goto L_0x0159
                java.util.ArrayList<Z3.n> r0 = r6.f12087L
                r0.add(r15)
                java.util.ArrayList<Z3.n> r0 = r6.f12088M
                r0.add(r4)
                r7.remove(r13)
                r9.remove(r14)
            L_0x0159:
                int r12 = r12 + 1
                r0 = r18
                goto L_0x0115
            L_0x015e:
                r1 = r2
                r17 = r8
                java.lang.Object r0 = r1.f37462E
                t.a r0 = (t.C3104a) r0
                java.lang.Object r2 = r5.f37462E
                t.a r2 = (t.C3104a) r2
                int r4 = r0.f28023z
                r8 = 0
            L_0x016c:
                if (r8 >= r4) goto L_0x01eb
                java.lang.Object r11 = r0.m(r8)
                android.view.View r11 = (android.view.View) r11
                if (r11 == 0) goto L_0x01ae
                boolean r12 = r6.t(r11)
                if (r12 == 0) goto L_0x01ae
                java.lang.Object r12 = r0.h(r8)
                java.lang.Object r12 = r2.get(r12)
                android.view.View r12 = (android.view.View) r12
                if (r12 == 0) goto L_0x01ae
                boolean r13 = r6.t(r12)
                if (r13 == 0) goto L_0x01ae
                java.lang.Object r13 = r7.get(r11)
                Z3.n r13 = (Z3.n) r13
                java.lang.Object r14 = r9.get(r12)
                Z3.n r14 = (Z3.n) r14
                if (r13 == 0) goto L_0x01ae
                if (r14 == 0) goto L_0x01ae
                java.util.ArrayList<Z3.n> r15 = r6.f12087L
                r15.add(r13)
                java.util.ArrayList<Z3.n> r13 = r6.f12088M
                r13.add(r14)
                r7.remove(r11)
                r9.remove(r12)
            L_0x01ae:
                int r8 = r8 + 1
                goto L_0x016c
            L_0x01b1:
                r1 = r2
                r17 = r8
                int r0 = r7.f28023z
                int r0 = r0 + -1
            L_0x01b8:
                if (r0 < 0) goto L_0x01eb
                java.lang.Object r2 = r7.h(r0)
                android.view.View r2 = (android.view.View) r2
                if (r2 == 0) goto L_0x01e8
                boolean r4 = r6.t(r2)
                if (r4 == 0) goto L_0x01e8
                java.lang.Object r2 = r9.remove(r2)
                Z3.n r2 = (Z3.n) r2
                if (r2 == 0) goto L_0x01e8
                android.view.View r4 = r2.f12131b
                boolean r4 = r6.t(r4)
                if (r4 == 0) goto L_0x01e8
                java.lang.Object r4 = r7.k(r0)
                Z3.n r4 = (Z3.n) r4
                java.util.ArrayList<Z3.n> r8 = r6.f12087L
                r8.add(r4)
                java.util.ArrayList<Z3.n> r4 = r6.f12088M
                r4.add(r2)
            L_0x01e8:
                int r0 = r0 + -1
                goto L_0x01b8
            L_0x01eb:
                int r10 = r10 + 1
                r0 = r18
                r2 = r1
                r8 = r17
                r1 = 0
                goto L_0x0087
            L_0x01f5:
                r17 = r8
                r0 = 0
            L_0x01f8:
                int r1 = r7.f28023z
                if (r0 >= r1) goto L_0x0218
                java.lang.Object r1 = r7.m(r0)
                Z3.n r1 = (Z3.n) r1
                android.view.View r2 = r1.f12131b
                boolean r2 = r6.t(r2)
                if (r2 == 0) goto L_0x0215
                java.util.ArrayList<Z3.n> r2 = r6.f12087L
                r2.add(r1)
                java.util.ArrayList<Z3.n> r1 = r6.f12088M
                r2 = 0
                r1.add(r2)
            L_0x0215:
                int r0 = r0 + 1
                goto L_0x01f8
            L_0x0218:
                r1 = 0
            L_0x0219:
                int r0 = r9.f28023z
                if (r1 >= r0) goto L_0x023b
                java.lang.Object r0 = r9.m(r1)
                Z3.n r0 = (Z3.n) r0
                android.view.View r2 = r0.f12131b
                boolean r2 = r6.t(r2)
                if (r2 == 0) goto L_0x0237
                java.util.ArrayList<Z3.n> r2 = r6.f12088M
                r2.add(r0)
                java.util.ArrayList<Z3.n> r0 = r6.f12087L
                r2 = 0
                r0.add(r2)
                goto L_0x0238
            L_0x0237:
                r2 = 0
            L_0x0238:
                int r1 = r1 + 1
                goto L_0x0219
            L_0x023b:
                t.a r0 = Z3.g.p()
                int r1 = r0.f28023z
                android.view.WindowId r2 = r3.getWindowId()
                int r1 = r1 + -1
            L_0x0247:
                if (r1 < 0) goto L_0x02ae
                java.lang.Object r4 = r0.h(r1)
                android.animation.Animator r4 = (android.animation.Animator) r4
                if (r4 == 0) goto L_0x02a9
                java.lang.Object r5 = r0.get(r4)
                Z3.g$b r5 = (Z3.g.b) r5
                if (r5 == 0) goto L_0x02a9
                android.view.View r7 = r5.f12102a
                if (r7 == 0) goto L_0x02a9
                android.view.WindowId r8 = r5.f12105d
                boolean r8 = r2.equals(r8)
                if (r8 == 0) goto L_0x02a9
                r8 = r17
                Z3.n r9 = r6.r(r7, r8)
                Z3.n r10 = r6.m(r7, r8)
                if (r9 != 0) goto L_0x0280
                if (r10 != 0) goto L_0x0280
                Pb.J r8 = r6.f12084I
                java.lang.Object r8 = r8.f37463f
                t.a r8 = (t.C3104a) r8
                java.lang.Object r7 = r8.get(r7)
                r10 = r7
                Z3.n r10 = (Z3.n) r10
            L_0x0280:
                if (r9 != 0) goto L_0x0284
                if (r10 == 0) goto L_0x02a9
            L_0x0284:
                Z3.n r7 = r5.f12104c
                Z3.g r5 = r5.f12106e
                boolean r7 = r5.s(r7, r10)
                if (r7 == 0) goto L_0x02a9
                Z3.g r5 = r5.n()
                r5.getClass()
                boolean r5 = r4.isRunning()
                if (r5 != 0) goto L_0x02a6
                boolean r5 = r4.isStarted()
                if (r5 == 0) goto L_0x02a2
                goto L_0x02a6
            L_0x02a2:
                r0.remove(r4)
                goto L_0x02a9
            L_0x02a6:
                r4.cancel()
            L_0x02a9:
                int r1 = r1 + -1
                r17 = 1
                goto L_0x0247
            L_0x02ae:
                Pb.J r4 = r6.f12083H
                Pb.J r5 = r6.f12084I
                java.util.ArrayList<Z3.n> r0 = r6.f12087L
                java.util.ArrayList<Z3.n> r7 = r6.f12088M
                r2 = r6
                r6 = r0
                r2.k(r3, r4, r5, r6, r7)
                r2.y()
                r17 = 1
                return r17
            */
            throw new UnsupportedOperationException("Method not decompiled: Z3.k.a.onPreDraw():boolean");
        }

        public final void onViewDetachedFromWindow(View view) {
            FrameLayout frameLayout = this.f12120i;
            frameLayout.getViewTreeObserver().removeOnPreDrawListener(this);
            frameLayout.removeOnAttachStateChangeListener(this);
            ArrayList<ViewGroup> arrayList = k.f12118c;
            FrameLayout frameLayout2 = this.f12120i;
            arrayList.remove(frameLayout2);
            ArrayList arrayList2 = k.b().get(frameLayout2);
            if (arrayList2 != null && arrayList2.size() > 0) {
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    ((g) it.next()).x(frameLayout2);
                }
            }
            this.f12119f.h(true);
        }

        public final void onViewAttachedToWindow(View view) {
        }
    }
}
