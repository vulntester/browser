package Z3;

import D2.B;
import Pb.J;
import Z3.g;
import android.animation.TimeInterpolator;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.Iterator;

public class l extends g {

    /* renamed from: b0  reason: collision with root package name */
    public ArrayList<g> f12123b0 = new ArrayList<>();

    /* renamed from: c0  reason: collision with root package name */
    public boolean f12124c0 = true;

    /* renamed from: d0  reason: collision with root package name */
    public int f12125d0;
    public boolean e0 = false;

    /* renamed from: f0  reason: collision with root package name */
    public int f12126f0 = 0;

    public class a extends j {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ g f12127a;

        public a(g gVar) {
            this.f12127a = gVar;
        }

        public final void c(g gVar) {
            this.f12127a.y();
            gVar.w(this);
        }
    }

    public static class b extends j {

        /* renamed from: a  reason: collision with root package name */
        public l f12128a;

        public final void c(g gVar) {
            l lVar = this.f12128a;
            int i10 = lVar.f12125d0 - 1;
            lVar.f12125d0 = i10;
            if (i10 == 0) {
                lVar.e0 = false;
                lVar.l();
            }
            gVar.w(this);
        }

        public final void g(g gVar) {
            l lVar = this.f12128a;
            if (!lVar.e0) {
                lVar.G();
                lVar.e0 = true;
            }
        }
    }

    public final void A(g.c cVar) {
        this.f12126f0 |= 8;
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f12123b0.get(i10).A(cVar);
        }
    }

    public final void B(TimeInterpolator timeInterpolator) {
        this.f12126f0 |= 1;
        ArrayList<g> arrayList = this.f12123b0;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                this.f12123b0.get(i10).B(timeInterpolator);
            }
        }
        this.f12080E = timeInterpolator;
    }

    public final void D(g.a aVar) {
        super.D(aVar);
        this.f12126f0 |= 4;
        if (this.f12123b0 != null) {
            for (int i10 = 0; i10 < this.f12123b0.size(); i10++) {
                this.f12123b0.get(i10).D(aVar);
            }
        }
    }

    public final void E() {
        this.f12126f0 |= 2;
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f12123b0.get(i10).E();
        }
    }

    public final void F(long j10) {
        this.f12100i = j10;
    }

    public final String H(String str) {
        String H10 = super.H(str);
        for (int i10 = 0; i10 < this.f12123b0.size(); i10++) {
            StringBuilder y10 = B.y(H10, "\n");
            y10.append(this.f12123b0.get(i10).H(str + "  "));
            H10 = y10.toString();
        }
        return H10;
    }

    public final void I(g gVar) {
        this.f12123b0.add(gVar);
        gVar.f12085J = this;
        long j10 = this.f12101z;
        if (j10 >= 0) {
            gVar.z(j10);
        }
        if ((this.f12126f0 & 1) != 0) {
            gVar.B(this.f12080E);
        }
        if ((this.f12126f0 & 2) != 0) {
            gVar.E();
        }
        if ((this.f12126f0 & 4) != 0) {
            gVar.D(this.f12098W);
        }
        if ((this.f12126f0 & 8) != 0) {
            gVar.A((g.c) null);
        }
    }

    public final void c(n nVar) {
        if (t(nVar.f12131b)) {
            Iterator<g> it = this.f12123b0.iterator();
            while (it.hasNext()) {
                g next = it.next();
                if (next.t(nVar.f12131b)) {
                    next.c(nVar);
                    nVar.f12132c.add(next);
                }
            }
        }
    }

    public final void cancel() {
        super.cancel();
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f12123b0.get(i10).cancel();
        }
    }

    public final void e(n nVar) {
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f12123b0.get(i10).e(nVar);
        }
    }

    public final void f(n nVar) {
        if (t(nVar.f12131b)) {
            Iterator<g> it = this.f12123b0.iterator();
            while (it.hasNext()) {
                g next = it.next();
                if (next.t(nVar.f12131b)) {
                    next.f(nVar);
                    nVar.f12132c.add(next);
                }
            }
        }
    }

    /* renamed from: i */
    public final g clone() {
        l lVar = (l) super.clone();
        lVar.f12123b0 = new ArrayList<>();
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            g i11 = this.f12123b0.get(i10).clone();
            lVar.f12123b0.add(i11);
            i11.f12085J = lVar;
        }
        return lVar;
    }

    public final void k(FrameLayout frameLayout, J j10, J j11, ArrayList arrayList, ArrayList arrayList2) {
        long j12 = this.f12100i;
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            g gVar = this.f12123b0.get(i10);
            if (j12 > 0 && (this.f12124c0 || i10 == 0)) {
                long j13 = gVar.f12100i;
                if (j13 > 0) {
                    gVar.F(j13 + j12);
                } else {
                    gVar.F(j12);
                }
            }
            gVar.k(frameLayout, j10, j11, arrayList, arrayList2);
        }
    }

    public final void v(ViewGroup viewGroup) {
        super.v(viewGroup);
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f12123b0.get(i10).v(viewGroup);
        }
    }

    public final g w(g.d dVar) {
        super.w(dVar);
        return this;
    }

    public final void x(FrameLayout frameLayout) {
        super.x(frameLayout);
        int size = this.f12123b0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f12123b0.get(i10).x(frameLayout);
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, Z3.g$d, Z3.l$b] */
    public final void y() {
        if (this.f12123b0.isEmpty()) {
            G();
            l();
            return;
        }
        ? obj = new Object();
        obj.f12128a = this;
        Iterator<g> it = this.f12123b0.iterator();
        while (it.hasNext()) {
            it.next().a(obj);
        }
        this.f12125d0 = this.f12123b0.size();
        if (!this.f12124c0) {
            for (int i10 = 1; i10 < this.f12123b0.size(); i10++) {
                this.f12123b0.get(i10 - 1).a(new a(this.f12123b0.get(i10)));
            }
            g gVar = this.f12123b0.get(0);
            if (gVar != null) {
                gVar.y();
                return;
            }
            return;
        }
        Iterator<g> it2 = this.f12123b0.iterator();
        while (it2.hasNext()) {
            it2.next().y();
        }
    }

    public final void z(long j10) {
        ArrayList<g> arrayList;
        this.f12101z = j10;
        if (j10 >= 0 && (arrayList = this.f12123b0) != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                this.f12123b0.get(i10).z(j10);
            }
        }
    }
}
