package Z3;

import android.graphics.Bitmap;
import android.graphics.Picture;
import android.os.Build;

public final class m {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f12129a;

    public static class a {
        public static Bitmap a(Picture picture) {
            return Bitmap.createBitmap(picture);
        }
    }

    static {
        boolean z10;
        if (Build.VERSION.SDK_INT >= 28) {
            z10 = true;
        } else {
            z10 = false;
        }
        f12129a = z10;
    }
}
