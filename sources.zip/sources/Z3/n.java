package Z3;

import D2.B;
import L.C0866g;
import android.annotation.SuppressLint;
import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    public final HashMap f12130a = new HashMap();
    @SuppressLint({"UnknownNullness"})

    /* renamed from: b  reason: collision with root package name */
    public final View f12131b;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayList<g> f12132c = new ArrayList<>();

    @Deprecated
    public n() {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r3 = (Z3.n) r3;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(java.lang.Object r3) {
        /*
            r2 = this;
            boolean r0 = r3 instanceof Z3.n
            if (r0 == 0) goto L_0x0018
            Z3.n r3 = (Z3.n) r3
            android.view.View r0 = r3.f12131b
            android.view.View r1 = r2.f12131b
            if (r1 != r0) goto L_0x0018
            java.util.HashMap r0 = r2.f12130a
            java.util.HashMap r3 = r3.f12130a
            boolean r3 = r0.equals(r3)
            if (r3 == 0) goto L_0x0018
            r3 = 1
            return r3
        L_0x0018:
            r3 = 0
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: Z3.n.equals(java.lang.Object):boolean");
    }

    public final int hashCode() {
        return this.f12130a.hashCode() + (this.f12131b.hashCode() * 31);
    }

    public final String toString() {
        StringBuilder y10 = B.y("TransitionValues@" + Integer.toHexString(hashCode()) + ":\n", "    view = ");
        y10.append(this.f12131b);
        y10.append("\n");
        String i10 = C0866g.i(y10.toString(), "    values:");
        HashMap hashMap = this.f12130a;
        for (String str : hashMap.keySet()) {
            i10 = i10 + "    " + str + ": " + hashMap.get(str) + "\n";
        }
        return i10;
    }

    public n(View view) {
        this.f12131b = view;
    }
}
