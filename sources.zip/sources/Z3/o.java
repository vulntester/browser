package Z3;

import android.os.Build;
import android.view.ViewGroup;

public final class o {

    /* renamed from: a  reason: collision with root package name */
    public static boolean f12133a = true;

    public static class a {
        public static int a(ViewGroup viewGroup, int i10) {
            return viewGroup.getChildDrawingOrder(i10);
        }

        public static void b(ViewGroup viewGroup, boolean z10) {
            viewGroup.suppressLayout(z10);
        }
    }

    public static void a(ViewGroup viewGroup, boolean z10) {
        if (Build.VERSION.SDK_INT >= 29) {
            a.b(viewGroup, z10);
        } else if (f12133a) {
            try {
                a.b(viewGroup, z10);
            } catch (NoSuchMethodError unused) {
                f12133a = false;
            }
        }
    }
}
