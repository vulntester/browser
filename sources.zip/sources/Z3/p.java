package Z3;

import android.graphics.Rect;
import android.os.Build;
import android.util.Property;
import android.view.View;

public final class p {

    /* renamed from: a  reason: collision with root package name */
    public static final t f12134a;

    /* renamed from: b  reason: collision with root package name */
    public static final a f12135b = new Property(Float.class, "translationAlpha");

    public class a extends Property<View, Float> {
        public final Object get(Object obj) {
            return Float.valueOf(p.f12134a.a((View) obj));
        }

        public final void set(Object obj, Object obj2) {
            float floatValue = ((Float) obj2).floatValue();
            p.f12134a.b((View) obj, floatValue);
        }
    }

    public class b extends Property<View, Rect> {
        public final Object get(Object obj) {
            return ((View) obj).getClipBounds();
        }

        public final void set(Object obj, Object obj2) {
            ((View) obj).setClipBounds((Rect) obj2);
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [Z3.p$a, android.util.Property] */
    /* JADX WARNING: type inference failed for: r0v3, types: [Z3.t, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v4, types: [Z3.t, java.lang.Object] */
    static {
        if (Build.VERSION.SDK_INT >= 29) {
            f12134a = new Object();
        } else {
            f12134a = new Object();
        }
        new Property(Rect.class, "clipBounds");
    }

    public static void a(View view, int i10, int i11, int i12, int i13) {
        f12134a.f(view, i10, i11, i12, i13);
    }

    public static void b(View view, int i10) {
        f12134a.c(view, i10);
    }
}
