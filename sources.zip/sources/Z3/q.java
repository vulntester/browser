package Z3;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Field;

public class q {

    /* renamed from: a  reason: collision with root package name */
    public static boolean f12136a = true;

    /* renamed from: b  reason: collision with root package name */
    public static Field f12137b;

    /* renamed from: c  reason: collision with root package name */
    public static boolean f12138c;

    public static class a {
        public static float a(View view) {
            return view.getTransitionAlpha();
        }

        public static void b(View view, float f10) {
            view.setTransitionAlpha(f10);
        }
    }

    @SuppressLint({"NewApi"})
    public float a(View view) {
        if (f12136a) {
            try {
                return a.a(view);
            } catch (NoSuchMethodError unused) {
                f12136a = false;
            }
        }
        return view.getAlpha();
    }

    @SuppressLint({"NewApi"})
    public void b(View view, float f10) {
        if (f12136a) {
            try {
                a.b(view, f10);
                return;
            } catch (NoSuchMethodError unused) {
                f12136a = false;
            }
        }
        view.setAlpha(f10);
    }

    @SuppressLint({"SoonBlockedPrivateApi"})
    public void c(View view, int i10) {
        if (!f12138c) {
            try {
                Field declaredField = View.class.getDeclaredField("mViewFlags");
                f12137b = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException unused) {
                Log.i("ViewUtilsApi19", "fetchViewFlagsField: ");
            }
            f12138c = true;
        }
        Field field = f12137b;
        if (field != null) {
            try {
                f12137b.setInt(view, i10 | (field.getInt(view) & -13));
            } catch (IllegalAccessException unused2) {
            }
        }
    }
}
