package Z3;

import android.annotation.SuppressLint;
import android.graphics.Matrix;
import android.view.View;

public class r extends q {

    /* renamed from: d  reason: collision with root package name */
    public static boolean f12139d = true;

    /* renamed from: e  reason: collision with root package name */
    public static boolean f12140e = true;

    public static class a {
        public static void a(View view, Matrix matrix) {
            view.setAnimationMatrix(matrix);
        }

        public static void b(View view, Matrix matrix) {
            view.transformMatrixToGlobal(matrix);
        }

        public static void c(View view, Matrix matrix) {
            view.transformMatrixToLocal(matrix);
        }
    }

    @SuppressLint({"NewApi"})
    public void d(View view, Matrix matrix) {
        if (f12139d) {
            try {
                a.b(view, matrix);
            } catch (NoSuchMethodError unused) {
                f12139d = false;
            }
        }
    }

    @SuppressLint({"NewApi"})
    public void e(View view, Matrix matrix) {
        if (f12140e) {
            try {
                a.c(view, matrix);
            } catch (NoSuchMethodError unused) {
                f12140e = false;
            }
        }
    }
}
