package Z3;

import android.annotation.SuppressLint;
import android.view.View;

public class s extends r {

    /* renamed from: f  reason: collision with root package name */
    public static boolean f12141f = true;

    public static class a {
        public static void a(View view, int i10, int i11, int i12, int i13) {
            view.setLeftTopRightBottom(i10, i11, i12, i13);
        }
    }

    @SuppressLint({"NewApi"})
    public void f(View view, int i10, int i11, int i12, int i13) {
        if (f12141f) {
            try {
                a.a(view, i10, i11, i12, i13);
            } catch (NoSuchMethodError unused) {
                f12141f = false;
            }
        }
    }
}
