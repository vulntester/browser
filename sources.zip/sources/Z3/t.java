package Z3;

import android.annotation.SuppressLint;
import android.os.Build;
import android.view.View;

public class t extends s {

    /* renamed from: g  reason: collision with root package name */
    public static boolean f12142g = true;

    public static class a {
        public static void a(View view, int i10) {
            view.setTransitionVisibility(i10);
        }
    }

    @SuppressLint({"NewApi"})
    public void c(View view, int i10) {
        if (Build.VERSION.SDK_INT == 28) {
            super.c(view, i10);
        } else if (f12142g) {
            try {
                a.a(view, i10);
            } catch (NoSuchMethodError unused) {
                f12142g = false;
            }
        }
    }
}
