package Z3;

import android.graphics.Matrix;
import android.view.View;

public final class u extends t {
    public final float a(View view) {
        return view.getTransitionAlpha();
    }

    public final void b(View view, float f10) {
        view.setTransitionAlpha(f10);
    }

    public final void c(View view, int i10) {
        view.setTransitionVisibility(i10);
    }

    public final void d(View view, Matrix matrix) {
        view.transformMatrixToGlobal(matrix);
    }

    public final void e(View view, Matrix matrix) {
        view.transformMatrixToLocal(matrix);
    }

    public final void f(View view, int i10, int i11, int i12, int i13) {
        view.setLeftTopRightBottom(i10, i11, i12, i13);
    }
}
