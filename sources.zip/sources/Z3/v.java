package Z3;

import Z3.g;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.internet.tvbrowser.R;
import java.util.HashMap;

public abstract class v extends g {

    /* renamed from: c0  reason: collision with root package name */
    public static final String[] f12143c0 = {"android:visibility:visibility", "android:visibility:parent"};

    /* renamed from: b0  reason: collision with root package name */
    public int f12144b0 = 3;

    public static class a extends AnimatorListenerAdapter implements g.d {

        /* renamed from: a  reason: collision with root package name */
        public final View f12145a;

        /* renamed from: b  reason: collision with root package name */
        public final int f12146b;

        /* renamed from: c  reason: collision with root package name */
        public final ViewGroup f12147c;

        /* renamed from: d  reason: collision with root package name */
        public final boolean f12148d;

        /* renamed from: e  reason: collision with root package name */
        public boolean f12149e;

        /* renamed from: f  reason: collision with root package name */
        public boolean f12150f = false;

        public a(View view, int i10) {
            this.f12145a = view;
            this.f12146b = i10;
            this.f12147c = (ViewGroup) view.getParent();
            this.f12148d = true;
            h(true);
        }

        public final void a() {
            h(false);
            if (!this.f12150f) {
                p.b(this.f12145a, this.f12146b);
            }
        }

        public final void b(g gVar) {
            gVar.w(this);
        }

        public final void c(g gVar) {
            gVar.w(this);
        }

        public final void e(g gVar) {
        }

        public final void f() {
            h(true);
            if (!this.f12150f) {
                p.b(this.f12145a, 0);
            }
        }

        public final void g(g gVar) {
            throw null;
        }

        public final void h(boolean z10) {
            ViewGroup viewGroup;
            if (this.f12148d && this.f12149e != z10 && (viewGroup = this.f12147c) != null) {
                this.f12149e = z10;
                o.a(viewGroup, z10);
            }
        }

        public final void onAnimationCancel(Animator animator) {
            this.f12150f = true;
        }

        public final void onAnimationEnd(Animator animator) {
            if (!this.f12150f) {
                p.b(this.f12145a, this.f12146b);
                ViewGroup viewGroup = this.f12147c;
                if (viewGroup != null) {
                    viewGroup.invalidate();
                }
            }
            h(false);
        }

        public final void onAnimationStart(Animator animator) {
        }

        public final void onAnimationStart(Animator animator, boolean z10) {
            if (z10) {
                p.b(this.f12145a, 0);
                ViewGroup viewGroup = this.f12147c;
                if (viewGroup != null) {
                    viewGroup.invalidate();
                }
            }
        }

        public final void onAnimationEnd(Animator animator, boolean z10) {
            if (!z10) {
                if (!this.f12150f) {
                    p.b(this.f12145a, this.f12146b);
                    ViewGroup viewGroup = this.f12147c;
                    if (viewGroup != null) {
                        viewGroup.invalidate();
                    }
                }
                h(false);
            }
        }

        public final void d(g gVar) {
        }

        public final void onAnimationRepeat(Animator animator) {
        }
    }

    public class b extends AnimatorListenerAdapter implements g.d {

        /* renamed from: a  reason: collision with root package name */
        public final FrameLayout f12151a;

        /* renamed from: b  reason: collision with root package name */
        public final View f12152b;

        /* renamed from: c  reason: collision with root package name */
        public final View f12153c;

        /* renamed from: d  reason: collision with root package name */
        public boolean f12154d = true;

        public b(FrameLayout frameLayout, View view, View view2) {
            this.f12151a = frameLayout;
            this.f12152b = view;
            this.f12153c = view2;
        }

        public final void b(g gVar) {
            gVar.w(this);
        }

        public final void c(g gVar) {
            gVar.w(this);
        }

        public final void d(g gVar) {
            if (this.f12154d) {
                h();
            }
        }

        public final void e(g gVar) {
        }

        public final void g(g gVar) {
            throw null;
        }

        public final void h() {
            this.f12153c.setTag(R.id.save_overlay_view, (Object) null);
            this.f12151a.getOverlay().remove(this.f12152b);
            this.f12154d = false;
        }

        public final void onAnimationEnd(Animator animator) {
            h();
        }

        public final void onAnimationPause(Animator animator) {
            this.f12151a.getOverlay().remove(this.f12152b);
        }

        public final void onAnimationResume(Animator animator) {
            View view = this.f12152b;
            if (view.getParent() == null) {
                this.f12151a.getOverlay().add(view);
            } else {
                v.this.cancel();
            }
        }

        public final void onAnimationStart(Animator animator, boolean z10) {
            if (z10) {
                View view = this.f12153c;
                View view2 = this.f12152b;
                view.setTag(R.id.save_overlay_view, view2);
                this.f12151a.getOverlay().add(view2);
                this.f12154d = true;
            }
        }

        public final void onAnimationEnd(Animator animator, boolean z10) {
            if (!z10) {
                h();
            }
        }

        public final void a() {
        }

        public final void f() {
        }
    }

    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public boolean f12156a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f12157b;

        /* renamed from: c  reason: collision with root package name */
        public int f12158c;

        /* renamed from: d  reason: collision with root package name */
        public int f12159d;

        /* renamed from: e  reason: collision with root package name */
        public ViewGroup f12160e;

        /* renamed from: f  reason: collision with root package name */
        public ViewGroup f12161f;
    }

    public static void I(n nVar) {
        int visibility = nVar.f12131b.getVisibility();
        HashMap hashMap = nVar.f12130a;
        hashMap.put("android:visibility:visibility", Integer.valueOf(visibility));
        View view = nVar.f12131b;
        hashMap.put("android:visibility:parent", view.getParent());
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        hashMap.put("android:visibility:screenLocation", iArr);
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [Z3.v$c, java.lang.Object] */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0059 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0090  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0095 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:7:0x0035  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static Z3.v.c J(Z3.n r8, Z3.n r9) {
        /*
            Z3.v$c r0 = new Z3.v$c
            r0.<init>()
            r1 = 0
            r0.f12156a = r1
            r0.f12157b = r1
            r2 = 0
            r3 = -1
            java.lang.String r4 = "android:visibility:parent"
            java.lang.String r5 = "android:visibility:visibility"
            if (r8 == 0) goto L_0x002f
            java.util.HashMap r6 = r8.f12130a
            boolean r7 = r6.containsKey(r5)
            if (r7 == 0) goto L_0x002f
            java.lang.Object r7 = r6.get(r5)
            java.lang.Integer r7 = (java.lang.Integer) r7
            int r7 = r7.intValue()
            r0.f12158c = r7
            java.lang.Object r6 = r6.get(r4)
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            r0.f12160e = r6
            goto L_0x0033
        L_0x002f:
            r0.f12158c = r3
            r0.f12160e = r2
        L_0x0033:
            if (r9 == 0) goto L_0x0052
            java.util.HashMap r6 = r9.f12130a
            boolean r7 = r6.containsKey(r5)
            if (r7 == 0) goto L_0x0052
            java.lang.Object r2 = r6.get(r5)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            r0.f12159d = r2
            java.lang.Object r2 = r6.get(r4)
            android.view.ViewGroup r2 = (android.view.ViewGroup) r2
            r0.f12161f = r2
            goto L_0x0056
        L_0x0052:
            r0.f12159d = r3
            r0.f12161f = r2
        L_0x0056:
            r2 = 1
            if (r8 == 0) goto L_0x008a
            if (r9 == 0) goto L_0x008a
            int r8 = r0.f12158c
            int r9 = r0.f12159d
            if (r8 != r9) goto L_0x0068
            android.view.ViewGroup r3 = r0.f12160e
            android.view.ViewGroup r4 = r0.f12161f
            if (r3 != r4) goto L_0x0068
            goto L_0x009f
        L_0x0068:
            if (r8 == r9) goto L_0x0078
            if (r8 != 0) goto L_0x0071
            r0.f12157b = r1
            r0.f12156a = r2
            return r0
        L_0x0071:
            if (r9 != 0) goto L_0x009f
            r0.f12157b = r2
            r0.f12156a = r2
            return r0
        L_0x0078:
            android.view.ViewGroup r8 = r0.f12161f
            if (r8 != 0) goto L_0x0081
            r0.f12157b = r1
            r0.f12156a = r2
            return r0
        L_0x0081:
            android.view.ViewGroup r8 = r0.f12160e
            if (r8 != 0) goto L_0x009f
            r0.f12157b = r2
            r0.f12156a = r2
            return r0
        L_0x008a:
            if (r8 != 0) goto L_0x0095
            int r8 = r0.f12159d
            if (r8 != 0) goto L_0x0095
            r0.f12157b = r2
            r0.f12156a = r2
            return r0
        L_0x0095:
            if (r9 != 0) goto L_0x009f
            int r8 = r0.f12158c
            if (r8 != 0) goto L_0x009f
            r0.f12157b = r1
            r0.f12156a = r2
        L_0x009f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: Z3.v.J(Z3.n, Z3.n):Z3.v$c");
    }

    public final void c(n nVar) {
        I(nVar);
    }

    /* JADX WARNING: type inference failed for: r19v3, types: [android.view.ViewParent] */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0047, code lost:
        if (J(m(r3, false), r(r3, false)).f12156a != false) goto L_0x0019;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00a3  */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x01e9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.animation.Animator j(android.widget.FrameLayout r24, Z3.n r25, Z3.n r26) {
        /*
            r23 = this;
            r0 = r23
            r1 = r24
            r2 = r25
            r3 = r26
            Z3.v$c r4 = J(r25, r26)
            boolean r5 = r4.f12156a
            if (r5 == 0) goto L_0x0019
            android.view.ViewGroup r5 = r4.f12160e
            if (r5 != 0) goto L_0x001e
            android.view.ViewGroup r5 = r4.f12161f
            if (r5 == 0) goto L_0x0019
            goto L_0x001e
        L_0x0019:
            r3 = r0
            r16 = 0
            goto L_0x02ea
        L_0x001e:
            boolean r5 = r4.f12157b
            r7 = 0
            r8 = 1065353216(0x3f800000, float:1.0)
            r9 = 0
            r10 = 1
            if (r5 == 0) goto L_0x005b
            int r1 = r0.f12144b0
            r1 = r1 & r10
            if (r1 != r10) goto L_0x0019
            if (r3 != 0) goto L_0x002f
            goto L_0x0019
        L_0x002f:
            android.view.View r1 = r3.f12131b
            if (r2 != 0) goto L_0x004a
            android.view.ViewParent r3 = r1.getParent()
            android.view.View r3 = (android.view.View) r3
            Z3.n r4 = r0.m(r3, r9)
            Z3.n r3 = r0.r(r3, r9)
            Z3.v$c r3 = J(r4, r3)
            boolean r3 = r3.f12156a
            if (r3 == 0) goto L_0x004a
            goto L_0x0019
        L_0x004a:
            r3 = r0
            Z3.d r3 = (Z3.d) r3
            Z3.t r4 = Z3.p.f12134a
            r4.getClass()
            float r2 = Z3.d.L(r2, r7)
            android.animation.ObjectAnimator r1 = r3.K(r1, r2, r8)
            return r1
        L_0x005b:
            int r4 = r4.f12159d
            int r5 = r0.f12144b0
            r11 = 2
            r5 = r5 & r11
            if (r5 == r11) goto L_0x0064
            goto L_0x0019
        L_0x0064:
            if (r2 != 0) goto L_0x0067
            goto L_0x0019
        L_0x0067:
            if (r3 == 0) goto L_0x006c
            android.view.View r5 = r3.f12131b
            goto L_0x006d
        L_0x006c:
            r5 = 0
        L_0x006d:
            android.view.View r12 = r2.f12131b
            r13 = 2131427951(0x7f0b026f, float:1.8477533E38)
            java.lang.Object r14 = r12.getTag(r13)
            android.view.View r14 = (android.view.View) r14
            if (r14 == 0) goto L_0x0086
            r22 = r4
            r17 = r9
            r9 = r10
            r18 = r9
            r6 = 0
            r16 = 0
            goto L_0x0229
        L_0x0086:
            if (r5 == 0) goto L_0x009d
            android.view.ViewParent r14 = r5.getParent()
            if (r14 != 0) goto L_0x008f
            goto L_0x009d
        L_0x008f:
            r14 = 4
            if (r4 != r14) goto L_0x0093
            goto L_0x0095
        L_0x0093:
            if (r12 != r5) goto L_0x0099
        L_0x0095:
            r14 = r5
            r15 = r9
            r5 = 0
            goto L_0x00a1
        L_0x0099:
            r15 = r10
            r5 = 0
        L_0x009b:
            r14 = 0
            goto L_0x00a1
        L_0x009d:
            if (r5 == 0) goto L_0x0099
            r15 = r9
            goto L_0x009b
        L_0x00a1:
            if (r15 == 0) goto L_0x021d
            android.view.ViewParent r15 = r12.getParent()
            if (r15 != 0) goto L_0x00b5
            r22 = r4
            r17 = r9
            r18 = r10
            r6 = r14
            r16 = 0
            r14 = r12
            goto L_0x0229
        L_0x00b5:
            android.view.ViewParent r15 = r12.getParent()
            boolean r15 = r15 instanceof android.view.View
            if (r15 == 0) goto L_0x021d
            android.view.ViewParent r15 = r12.getParent()
            android.view.View r15 = (android.view.View) r15
            r16 = 0
            Z3.n r6 = r0.r(r15, r10)
            r17 = r9
            Z3.n r9 = r0.m(r15, r10)
            Z3.v$c r6 = J(r6, r9)
            boolean r6 = r6.f12156a
            if (r6 != 0) goto L_0x0206
            boolean r5 = Z3.m.f12129a
            android.graphics.Matrix r5 = new android.graphics.Matrix
            r5.<init>()
            int r6 = r15.getScrollX()
            int r6 = -r6
            float r6 = (float) r6
            int r9 = r15.getScrollY()
            int r9 = -r9
            float r9 = (float) r9
            r5.setTranslate(r6, r9)
            Z3.t r6 = Z3.p.f12134a
            r6.d(r12, r5)
            r6.e(r1, r5)
            android.graphics.RectF r6 = new android.graphics.RectF
            int r9 = r12.getWidth()
            float r9 = (float) r9
            int r15 = r12.getHeight()
            float r15 = (float) r15
            r6.<init>(r7, r7, r9, r15)
            r5.mapRect(r6)
            float r9 = r6.left
            int r9 = java.lang.Math.round(r9)
            float r15 = r6.top
            int r15 = java.lang.Math.round(r15)
            r18 = r10
            float r10 = r6.right
            int r10 = java.lang.Math.round(r10)
            float r13 = r6.bottom
            int r13 = java.lang.Math.round(r13)
            android.widget.ImageView r7 = new android.widget.ImageView
            android.content.Context r11 = r12.getContext()
            r7.<init>(r11)
            android.widget.ImageView$ScaleType r11 = android.widget.ImageView.ScaleType.CENTER_CROP
            r7.setScaleType(r11)
            boolean r11 = r12.isAttachedToWindow()
            if (r1 == 0) goto L_0x013e
            boolean r19 = r1.isAttachedToWindow()
            if (r19 == 0) goto L_0x013e
            r19 = r18
            goto L_0x0140
        L_0x013e:
            r19 = r17
        L_0x0140:
            if (r11 != 0) goto L_0x0169
            if (r19 != 0) goto L_0x014c
            r22 = r4
            r21 = r14
            r0 = r16
            goto L_0x01e7
        L_0x014c:
            android.view.ViewParent r19 = r12.getParent()
            r8 = r19
            android.view.ViewGroup r8 = (android.view.ViewGroup) r8
            int r19 = r8.indexOfChild(r12)
            r20 = r8
            android.view.ViewGroupOverlay r8 = r1.getOverlay()
            r8.add(r12)
            r8 = r19
            r19 = r11
            r11 = r8
            r8 = r20
            goto L_0x016f
        L_0x0169:
            r19 = r11
            r8 = r16
            r11 = r17
        L_0x016f:
            float r20 = r6.width()
            r21 = r14
            int r14 = java.lang.Math.round(r20)
            float r20 = r6.height()
            r22 = r4
            int r4 = java.lang.Math.round(r20)
            if (r14 <= 0) goto L_0x01d9
            if (r4 <= 0) goto L_0x01d9
            int r0 = r14 * r4
            float r0 = (float) r0
            r20 = 1233125376(0x49800000, float:1048576.0)
            float r0 = r20 / r0
            r3 = 1065353216(0x3f800000, float:1.0)
            float r0 = java.lang.Math.min(r3, r0)
            float r3 = (float) r14
            float r3 = r3 * r0
            int r3 = java.lang.Math.round(r3)
            float r4 = (float) r4
            float r4 = r4 * r0
            int r4 = java.lang.Math.round(r4)
            float r14 = r6.left
            float r14 = -r14
            float r6 = r6.top
            float r6 = -r6
            r5.postTranslate(r14, r6)
            r5.postScale(r0, r0)
            boolean r0 = Z3.m.f12129a
            if (r0 == 0) goto L_0x01c7
            android.graphics.Picture r0 = new android.graphics.Picture
            r0.<init>()
            android.graphics.Canvas r3 = r0.beginRecording(r3, r4)
            r3.concat(r5)
            r12.draw(r3)
            r0.endRecording()
            android.graphics.Bitmap r0 = Z3.m.a.a(r0)
            goto L_0x01db
        L_0x01c7:
            android.graphics.Bitmap$Config r0 = android.graphics.Bitmap.Config.ARGB_8888
            android.graphics.Bitmap r0 = android.graphics.Bitmap.createBitmap(r3, r4, r0)
            android.graphics.Canvas r3 = new android.graphics.Canvas
            r3.<init>(r0)
            r3.concat(r5)
            r12.draw(r3)
            goto L_0x01db
        L_0x01d9:
            r0 = r16
        L_0x01db:
            if (r19 != 0) goto L_0x01e7
            android.view.ViewGroupOverlay r3 = r1.getOverlay()
            r3.remove(r12)
            r8.addView(r12, r11)
        L_0x01e7:
            if (r0 == 0) goto L_0x01ec
            r7.setImageBitmap(r0)
        L_0x01ec:
            int r0 = r10 - r9
            r3 = 1073741824(0x40000000, float:2.0)
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r3)
            int r4 = r13 - r15
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r3)
            r7.measure(r0, r3)
            r7.layout(r9, r15, r10, r13)
            r14 = r7
        L_0x0201:
            r9 = r17
            r6 = r21
            goto L_0x0229
        L_0x0206:
            r22 = r4
            r18 = r10
            r21 = r14
            int r0 = r15.getId()
            android.view.ViewParent r3 = r15.getParent()
            if (r3 != 0) goto L_0x0227
            r3 = -1
            if (r0 == r3) goto L_0x0227
            r1.findViewById(r0)
            goto L_0x0227
        L_0x021d:
            r22 = r4
            r17 = r9
            r18 = r10
            r21 = r14
            r16 = 0
        L_0x0227:
            r14 = r5
            goto L_0x0201
        L_0x0229:
            if (r14 == 0) goto L_0x02a7
            if (r9 != 0) goto L_0x025e
            java.util.HashMap r0 = r2.f12130a
            java.lang.String r3 = "android:visibility:screenLocation"
            java.lang.Object r0 = r0.get(r3)
            int[] r0 = (int[]) r0
            r3 = r0[r17]
            r0 = r0[r18]
            r4 = 2
            int[] r4 = new int[r4]
            r1.getLocationOnScreen(r4)
            r5 = r4[r17]
            int r3 = r3 - r5
            int r5 = r14.getLeft()
            int r3 = r3 - r5
            r14.offsetLeftAndRight(r3)
            r3 = r4[r18]
            int r0 = r0 - r3
            int r3 = r14.getTop()
            int r0 = r0 - r3
            r14.offsetTopAndBottom(r0)
            android.view.ViewGroupOverlay r0 = r1.getOverlay()
            r0.add(r14)
        L_0x025e:
            r0 = r23
            Z3.d r0 = (Z3.d) r0
            Z3.t r3 = Z3.p.f12134a
            r3.getClass()
            r4 = 1065353216(0x3f800000, float:1.0)
            float r2 = Z3.d.L(r2, r4)
            r5 = 0
            android.animation.ObjectAnimator r0 = r0.K(r14, r2, r5)
            if (r0 != 0) goto L_0x027d
            r5 = r26
            float r2 = Z3.d.L(r5, r4)
            r3.b(r14, r2)
        L_0x027d:
            if (r9 != 0) goto L_0x02a4
            if (r0 != 0) goto L_0x0289
            android.view.ViewGroupOverlay r1 = r1.getOverlay()
            r1.remove(r14)
            return r0
        L_0x0289:
            r2 = 2131427951(0x7f0b026f, float:1.8477533E38)
            r12.setTag(r2, r14)
            Z3.v$b r2 = new Z3.v$b
            r3 = r23
            r2.<init>(r1, r14, r12)
            r0.addListener(r2)
            r0.addPauseListener(r2)
            Z3.g r1 = r3.n()
            r1.a(r2)
            return r0
        L_0x02a4:
            r3 = r23
            return r0
        L_0x02a7:
            r3 = r23
            r5 = r26
            if (r6 == 0) goto L_0x02ea
            int r0 = r6.getVisibility()
            r1 = r17
            Z3.p.b(r6, r1)
            r1 = r3
            Z3.d r1 = (Z3.d) r1
            Z3.t r4 = Z3.p.f12134a
            r4.getClass()
            r7 = 1065353216(0x3f800000, float:1.0)
            float r2 = Z3.d.L(r2, r7)
            r8 = 0
            android.animation.ObjectAnimator r1 = r1.K(r6, r2, r8)
            if (r1 != 0) goto L_0x02d2
            float r2 = Z3.d.L(r5, r7)
            r4.b(r6, r2)
        L_0x02d2:
            if (r1 == 0) goto L_0x02e6
            Z3.v$a r0 = new Z3.v$a
            r2 = r22
            r0.<init>(r6, r2)
            r1.addListener(r0)
            Z3.g r2 = r3.n()
            r2.a(r0)
            return r1
        L_0x02e6:
            Z3.p.b(r6, r0)
            return r1
        L_0x02ea:
            return r16
        */
        throw new UnsupportedOperationException("Method not decompiled: Z3.v.j(android.widget.FrameLayout, Z3.n, Z3.n):android.animation.Animator");
    }

    public final String[] q() {
        return f12143c0;
    }

    public final boolean s(n nVar, n nVar2) {
        if (nVar == null && nVar2 == null) {
            return false;
        }
        if (nVar != null && nVar2 != null && nVar2.f12130a.containsKey("android:visibility:visibility") != nVar.f12130a.containsKey("android:visibility:visibility")) {
            return false;
        }
        c J5 = J(nVar, nVar2);
        if (!J5.f12156a) {
            return false;
        }
        if (J5.f12158c == 0 || J5.f12159d == 0) {
            return true;
        }
        return false;
    }
}
