package Z4;

public final class a {

    /* renamed from: a  reason: collision with root package name */
    public static final byte[] f12162a = {112, 105, 110, 103};

    /* renamed from: b  reason: collision with root package name */
    public static final byte[] f12163b = {112, 111, 110, 103};
}
