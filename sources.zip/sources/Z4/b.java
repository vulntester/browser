package Z4;

import M.k;
import b5.C1386b;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final int f12164a;

    /* renamed from: b  reason: collision with root package name */
    public final String f12165b;

    /* renamed from: c  reason: collision with root package name */
    public final C1386b f12166c;

    public b(int i10, String str, C1386b bVar) {
        this.f12164a = i10;
        this.f12165b = str;
        this.f12166c = bVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x000a, code lost:
        r5 = (Z4.b) r5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(java.lang.Object r5) {
        /*
            r4 = this;
            r0 = 1
            if (r4 != r5) goto L_0x0004
            return r0
        L_0x0004:
            boolean r1 = r5 instanceof Z4.b
            r2 = 0
            if (r1 != 0) goto L_0x000a
            return r2
        L_0x000a:
            Z4.b r5 = (Z4.b) r5
            int r1 = r5.f12164a
            int r3 = r4.f12164a
            if (r3 == r1) goto L_0x0013
            return r2
        L_0x0013:
            java.lang.String r1 = r4.f12165b
            java.lang.String r3 = r5.f12165b
            boolean r1 = kotlin.jvm.internal.l.a(r1, r3)
            if (r1 != 0) goto L_0x001e
            return r2
        L_0x001e:
            b5.b r1 = r4.f12166c
            b5.b r5 = r5.f12166c
            if (r1 == r5) goto L_0x0025
            return r2
        L_0x0025:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: Z4.b.equals(java.lang.Object):boolean");
    }

    public final int hashCode() {
        return this.f12166c.hashCode() + k.k(this.f12164a * 31, 31, this.f12165b);
    }

    public final String toString() {
        return "ControlModeLayer(id=" + this.f12164a + ", label=" + this.f12165b + ", mode=" + this.f12166c + ')';
    }
}
