package Z4;

import Ba.h;
import C9.k;
import Da.e;
import Da.i;
import Na.p;
import android.util.Log;
import b5.C1386b;
import b5.d;
import com.browser.remote.events.RemoteEvent;
import com.browser.remote.events.TvEvent;
import f7.M;
import ic.A0;
import ic.C4487C;
import ic.C4488D;
import ic.C4500e0;
import ic.G;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kc.C4585c;
import kc.C4586d;
import kotlin.jvm.internal.C4598g;
import kotlin.jvm.internal.l;
import lc.L;
import lc.P;
import lc.S;
import lc.Z;
import lc.a0;
import nc.C4732d;
import xa.C4959D;
import xa.C4976p;
import ya.s;
import za.C5032b;

public final class c {

    /* renamed from: u  reason: collision with root package name */
    public static c f12167u;

    /* renamed from: a  reason: collision with root package name */
    public int f12168a;

    /* renamed from: b  reason: collision with root package name */
    public int f12169b;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayList f12170c = new ArrayList();

    /* renamed from: d  reason: collision with root package name */
    public final Z f12171d = a0.a("");

    /* renamed from: e  reason: collision with root package name */
    public final C4732d f12172e;

    /* renamed from: f  reason: collision with root package name */
    public final C4586d f12173f;

    /* renamed from: g  reason: collision with root package name */
    public final C4586d f12174g;

    /* renamed from: h  reason: collision with root package name */
    public final P f12175h;

    /* renamed from: i  reason: collision with root package name */
    public final L f12176i;

    /* renamed from: j  reason: collision with root package name */
    public final P f12177j;

    /* renamed from: k  reason: collision with root package name */
    public final L f12178k;

    /* renamed from: l  reason: collision with root package name */
    public final Z f12179l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f12180m;

    /* renamed from: n  reason: collision with root package name */
    public Integer f12181n;

    /* renamed from: o  reason: collision with root package name */
    public String f12182o;

    /* renamed from: p  reason: collision with root package name */
    public TvEvent.c f12183p;

    /* renamed from: q  reason: collision with root package name */
    public TvEvent.KeyboardState f12184q;

    /* renamed from: r  reason: collision with root package name */
    public TvEvent.MediaPlaybackState f12185r;

    /* renamed from: s  reason: collision with root package name */
    public long f12186s;

    /* renamed from: t  reason: collision with root package name */
    public A0 f12187t;

    @e(c = "com.browser.remote.RemoteEventsBridge$1", f = "RemoteEventsBridge.kt", l = {127}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public int f12188f;

        /* renamed from: i  reason: collision with root package name */
        public /* synthetic */ Object f12189i;

        /* renamed from: z  reason: collision with root package name */
        public final /* synthetic */ c f12190z;

        @e(c = "com.browser.remote.RemoteEventsBridge$1$1", f = "RemoteEventsBridge.kt", l = {134, 135, 136, 139}, m = "invokeSuspend")
        /* renamed from: Z4.c$a$a  reason: collision with other inner class name */
        public static final class C0119a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

            /* renamed from: E  reason: collision with root package name */
            public final /* synthetic */ c f12191E;

            /* renamed from: f  reason: collision with root package name */
            public RemoteEvent.g f12192f;

            /* renamed from: i  reason: collision with root package name */
            public int f12193i;

            /* renamed from: z  reason: collision with root package name */
            public final /* synthetic */ RemoteEvent f12194z;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C0119a(RemoteEvent remoteEvent, c cVar, Ba.e<? super C0119a> eVar) {
                super(2, eVar);
                this.f12194z = remoteEvent;
                this.f12191E = cVar;
            }

            public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
                return new C0119a(this.f12194z, this.f12191E, eVar);
            }

            public final Object invoke(Object obj, Object obj2) {
                return ((C0119a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
            }

            /* JADX WARNING: Code restructure failed: missing block: B:17:0x005b, code lost:
                if (ic.N.b(75, r7) == r0) goto L_0x0072;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:19:0x0067, code lost:
                if (Z4.c.a(r2, r1, r7) == r0) goto L_0x0072;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:21:0x0070, code lost:
                if (Z4.c.a(r2, r8, r7) == r0) goto L_0x0072;
             */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public final java.lang.Object invokeSuspend(java.lang.Object r8) {
                /*
                    r7 = this;
                    Ca.a r0 = Ca.a.f33640f
                    int r1 = r7.f12193i
                    Z4.c r2 = r7.f12191E
                    r3 = 4
                    r4 = 3
                    r5 = 2
                    r6 = 1
                    if (r1 == 0) goto L_0x002d
                    if (r1 == r6) goto L_0x0027
                    if (r1 == r5) goto L_0x0021
                    if (r1 == r4) goto L_0x001d
                    if (r1 != r3) goto L_0x0015
                    goto L_0x001d
                L_0x0015:
                    java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                    java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                    r8.<init>(r0)
                    throw r8
                L_0x001d:
                    xa.C4976p.b(r8)
                    goto L_0x0073
                L_0x0021:
                    com.browser.remote.events.RemoteEvent$g r1 = r7.f12192f
                    xa.C4976p.b(r8)
                    goto L_0x005e
                L_0x0027:
                    com.browser.remote.events.RemoteEvent$g r1 = r7.f12192f
                    xa.C4976p.b(r8)
                    goto L_0x0051
                L_0x002d:
                    xa.C4976p.b(r8)
                    com.browser.remote.events.RemoteEvent r8 = r7.f12194z
                    boolean r1 = r8 instanceof com.browser.remote.events.RemoteEvent.o
                    if (r1 == 0) goto L_0x006a
                    com.browser.remote.events.RemoteEvent$o r8 = (com.browser.remote.events.RemoteEvent.o) r8
                    com.browser.remote.events.RemoteEvent$g r1 = new com.browser.remote.events.RemoteEvent$g
                    int r8 = r8.f16852a
                    r3 = 0
                    r1.<init>(r8, r3)
                    com.browser.remote.events.RemoteEvent$g r3 = new com.browser.remote.events.RemoteEvent$g
                    r3.<init>(r8, r6)
                    r7.f12192f = r3
                    r7.f12193i = r6
                    java.lang.Object r8 = Z4.c.a(r2, r1, r7)
                    if (r8 != r0) goto L_0x0050
                    goto L_0x0072
                L_0x0050:
                    r1 = r3
                L_0x0051:
                    r7.f12192f = r1
                    r7.f12193i = r5
                    r5 = 75
                    java.lang.Object r8 = ic.N.b(r5, r7)
                    if (r8 != r0) goto L_0x005e
                    goto L_0x0072
                L_0x005e:
                    r8 = 0
                    r7.f12192f = r8
                    r7.f12193i = r4
                    java.lang.Object r8 = Z4.c.a(r2, r1, r7)
                    if (r8 != r0) goto L_0x0073
                    goto L_0x0072
                L_0x006a:
                    r7.f12193i = r3
                    java.lang.Object r8 = Z4.c.a(r2, r8, r7)
                    if (r8 != r0) goto L_0x0073
                L_0x0072:
                    return r0
                L_0x0073:
                    xa.D r8 = xa.C4959D.f44058a
                    return r8
                */
                throw new UnsupportedOperationException("Method not decompiled: Z4.c.a.C0119a.invokeSuspend(java.lang.Object):java.lang.Object");
            }
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(c cVar, Ba.e<? super a> eVar) {
            super(2, eVar);
            this.f12190z = cVar;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            a aVar = new a(this.f12190z, eVar);
            aVar.f12189i = obj;
            return aVar;
        }

        public final Object invoke(Object obj, Object obj2) {
            ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
            return Ca.a.f33640f;
        }

        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
            	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
            */
        /* JADX WARNING: Removed duplicated region for block: B:13:0x0033 A[Catch:{ Exception -> 0x0015 }, RETURN] */
        public final java.lang.Object invokeSuspend(java.lang.Object r9) {
            /*
                r8 = this;
                Ca.a r0 = Ca.a.f33640f
                int r1 = r8.f12188f
                Z4.c r2 = r8.f12190z
                java.lang.String r3 = "RemoteEventsBridge"
                r4 = 1
                if (r1 == 0) goto L_0x001f
                if (r1 != r4) goto L_0x0017
                java.lang.Object r1 = r8.f12189i
                ic.C r1 = (ic.C4487C) r1
                xa.C4976p.b(r9)     // Catch:{ Exception -> 0x0015 }
                goto L_0x0034
            L_0x0015:
                r9 = move-exception
                goto L_0x005b
            L_0x0017:
                java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r9.<init>(r0)
                throw r9
            L_0x001f:
                xa.C4976p.b(r9)
                java.lang.Object r9 = r8.f12189i
                ic.C r9 = (ic.C4487C) r9
                r1 = r9
            L_0x0027:
                kc.d r9 = r2.f12174g     // Catch:{ Exception -> 0x0015 }
                r8.f12189i = r1     // Catch:{ Exception -> 0x0015 }
                r8.f12188f = r4     // Catch:{ Exception -> 0x0015 }
                java.lang.Object r9 = r9.receive(r8)     // Catch:{ Exception -> 0x0015 }
                if (r9 != r0) goto L_0x0034
                return r0
            L_0x0034:
                byte[] r9 = (byte[]) r9     // Catch:{ Exception -> 0x0015 }
                com.browser.remote.events.RemoteEvent$a r5 = com.browser.remote.events.RemoteEvent.Companion     // Catch:{ Exception -> 0x004e }
                r5.getClass()     // Catch:{ Exception -> 0x004e }
                com.browser.remote.events.RemoteEvent r9 = com.browser.remote.events.RemoteEvent.a.a(r9)     // Catch:{ Exception -> 0x004e }
                ic.U r5 = ic.U.f41134a     // Catch:{ Exception -> 0x004e }
                pc.b r5 = pc.b.f43037f     // Catch:{ Exception -> 0x004e }
                Z4.c$a$a r6 = new Z4.c$a$a     // Catch:{ Exception -> 0x004e }
                r7 = 0
                r6.<init>(r9, r2, r7)     // Catch:{ Exception -> 0x004e }
                r9 = 2
                ic.G.y(r1, r5, r6, r9)     // Catch:{ Exception -> 0x004e }
                goto L_0x0027
            L_0x004e:
                r9 = move-exception
                java.lang.String r5 = "Error parsing bytes"
                int r9 = android.util.Log.e(r3, r5, r9)     // Catch:{ Exception -> 0x0015 }
                java.lang.Integer r5 = new java.lang.Integer     // Catch:{ Exception -> 0x0015 }
                r5.<init>(r9)     // Catch:{ Exception -> 0x0015 }
                goto L_0x0027
            L_0x005b:
                java.lang.String r5 = "Error receiving bytes"
                int r9 = android.util.Log.e(r3, r5, r9)
                java.lang.Integer r5 = new java.lang.Integer
                r5.<init>(r9)
                goto L_0x0027
            */
            throw new UnsupportedOperationException("Method not decompiled: Z4.c.a.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @e(c = "com.browser.remote.RemoteEventsBridge$sendEvent$1", f = "RemoteEventsBridge.kt", l = {269, 270}, m = "invokeSuspend")
    public static final class b extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public int f12195f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ c f12196i;

        /* renamed from: z  reason: collision with root package name */
        public final /* synthetic */ TvEvent f12197z;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(c cVar, TvEvent tvEvent, Ba.e<? super b> eVar) {
            super(2, eVar);
            this.f12196i = cVar;
            this.f12197z = tvEvent;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new b(this.f12196i, this.f12197z, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((b) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x0036, code lost:
            if (r6.send(r5.f12197z, r5) == r0) goto L_0x0038;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x0038, code lost:
            return r0;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:9:0x0027, code lost:
            if (ic.N.b(2000, r5) == r0) goto L_0x0038;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object invokeSuspend(java.lang.Object r6) {
            /*
                r5 = this;
                Ca.a r0 = Ca.a.f33640f
                int r1 = r5.f12195f
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L_0x001c
                if (r1 == r3) goto L_0x0018
                if (r1 != r2) goto L_0x0010
                xa.C4976p.b(r6)
                goto L_0x0039
            L_0x0010:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r0)
                throw r6
            L_0x0018:
                xa.C4976p.b(r6)
                goto L_0x002a
            L_0x001c:
                xa.C4976p.b(r6)
                r5.f12195f = r3
                r3 = 2000(0x7d0, double:9.88E-321)
                java.lang.Object r6 = ic.N.b(r3, r5)
                if (r6 != r0) goto L_0x002a
                goto L_0x0038
            L_0x002a:
                Z4.c r6 = r5.f12196i
                kc.d r6 = r6.f12173f
                r5.f12195f = r2
                com.browser.remote.events.TvEvent r1 = r5.f12197z
                java.lang.Object r6 = r6.send(r1, r5)
                if (r6 != r0) goto L_0x0039
            L_0x0038:
                return r0
            L_0x0039:
                xa.D r6 = xa.C4959D.f44058a
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: Z4.c.b.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @e(c = "com.browser.remote.RemoteEventsBridge$sendEvent$2", f = "RemoteEventsBridge.kt", l = {292}, m = "invokeSuspend")
    /* renamed from: Z4.c$c  reason: collision with other inner class name */
    public static final class C0120c extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public int f12198f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ c f12199i;

        /* renamed from: z  reason: collision with root package name */
        public final /* synthetic */ TvEvent f12200z;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0120c(c cVar, TvEvent tvEvent, Ba.e<? super C0120c> eVar) {
            super(2, eVar);
            this.f12199i = cVar;
            this.f12200z = tvEvent;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new C0120c(this.f12199i, this.f12200z, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((C0120c) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            int i10 = this.f12198f;
            if (i10 == 0) {
                C4976p.b(obj);
                C4586d dVar = this.f12199i.f12173f;
                this.f12198f = 1;
                if (dVar.send(this.f12200z, this) == aVar) {
                    return aVar;
                }
            } else if (i10 == 1) {
                C4976p.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return C4959D.f44058a;
        }
    }

    public c() {
        ExecutorService newSingleThreadExecutor = Executors.newSingleThreadExecutor();
        l.e(newSingleThreadExecutor, "newSingleThreadExecutor(...)");
        this.f12172e = C4488D.a(new C4500e0(newSingleThreadExecutor));
        ExecutorService newSingleThreadExecutor2 = Executors.newSingleThreadExecutor();
        l.e(newSingleThreadExecutor2, "newSingleThreadExecutor(...)");
        C4732d a10 = C4488D.a(new C4500e0(newSingleThreadExecutor2));
        this.f12173f = kc.l.a(0, 7, (C4585c) null);
        this.f12174g = kc.l.a(0, 7, (C4585c) null);
        P a11 = S.a(7, (C4585c) null);
        this.f12175h = a11;
        this.f12176i = new L(a11);
        P a12 = S.a(7, (C4585c) null);
        this.f12177j = a12;
        this.f12178k = new L(a12);
        Boolean bool = Boolean.FALSE;
        a0.a(bool);
        this.f12179l = a0.a(bool);
        this.f12180m = true;
        G.y(a10, (h) null, new a(this, (Ba.e<? super a>) null), 3);
        this.f12183p = new TvEvent.c(C1386b.f16522i);
        this.f12184q = new TvEvent.KeyboardState(false, d.f16528f, "", false, false, (String) null, (String) null, (String) null, 0, 504, (C4598g) null);
        this.f12185r = new TvEvent.MediaPlaybackState(false, false, 0.0f, 0.0f, false);
    }

    public static final Object a(c cVar, RemoteEvent remoteEvent, a.C0119a aVar) {
        if ((remoteEvent instanceof RemoteEvent.d) || (remoteEvent instanceof RemoteEvent.c) || (remoteEvent instanceof RemoteEvent.l) || (remoteEvent instanceof RemoteEvent.e) || (remoteEvent instanceof RemoteEvent.b)) {
            Object emit = cVar.f12177j.emit(remoteEvent, aVar);
            if (emit == Ca.a.f33640f) {
                return emit;
            }
            return C4959D.f44058a;
        } else if (remoteEvent instanceof RemoteEvent.p) {
            Log.w("RemoteEventsBridge", "onEventReceived: SyncRequest");
            ListIterator listIterator = cVar.b().listIterator(0);
            while (true) {
                C5032b.C0471b bVar = (C5032b.C0471b) listIterator;
                if (!bVar.hasNext()) {
                    return C4959D.f44058a;
                }
                cVar.d((TvEvent) bVar.next(), "SyncRequest");
            }
        } else {
            if (remoteEvent instanceof RemoteEvent.i) {
                A0 a02 = cVar.f12187t;
                if (a02 != null) {
                    a02.e((CancellationException) null);
                }
                cVar.f12186s = System.currentTimeMillis();
                Log.w("RemoteEventsBridge", "onEventReceived: KeyboardInput: " + ((RemoteEvent.i) remoteEvent).f16834a);
            }
            Object emit2 = cVar.f12175h.emit(remoteEvent, aVar);
            if (emit2 == Ca.a.f33640f) {
                return emit2;
            }
            return C4959D.f44058a;
        }
    }

    public final C5032b b() {
        C5032b r10 = M.r();
        r10.add(this.f12183p);
        r10.add(this.f12184q);
        r10.add(new TvEvent.AppState(this.f12180m));
        r10.add(this.f12185r);
        Integer num = this.f12181n;
        if (num != null) {
            r10.add(new TvEvent.UdpServerInfo(this.f12182o, num.intValue()));
        }
        return M.f(r10);
    }

    public final void c() {
        String a02 = s.a0(this.f12170c, " -> ", (String) null, (String) null, new k(5), 30);
        this.f12171d.setValue(a02);
        Log.d("RemoteEventsBridge", "ControlModeStack: " + a02);
    }

    public final void d(TvEvent tvEvent, String str) {
        l.f(tvEvent, "event");
        boolean z10 = tvEvent instanceof TvEvent.c;
        C4732d dVar = this.f12172e;
        if (z10) {
            StringBuilder sb2 = new StringBuilder("SetControlMode: ");
            TvEvent.c cVar = (TvEvent.c) tvEvent;
            sb2.append(cVar.f16855a.name());
            sb2.append(" (");
            sb2.append(str);
            sb2.append(')');
            Log.w("RemoteEventsBridge", sb2.toString());
            this.f12183p = cVar;
        } else if (tvEvent instanceof TvEvent.KeyboardState) {
            TvEvent.KeyboardState keyboardState = (TvEvent.KeyboardState) tvEvent;
            if (keyboardState.i() != this.f12184q.i() || !l.a(keyboardState.g(), this.f12184q.g())) {
                this.f12184q = keyboardState;
                if (System.currentTimeMillis() - this.f12186s < 2000) {
                    Log.d("RemoteEventsBridge", "sending keyboardState delayed: " + keyboardState.g());
                    A0 a02 = this.f12187t;
                    if (a02 != null) {
                        a02.e((CancellationException) null);
                    }
                    this.f12187t = G.y(dVar, (h) null, new b(this, tvEvent, (Ba.e<? super b>) null), 3);
                    return;
                }
                Log.d("RemoteEventsBridge", "keyboardState: " + keyboardState.g());
            } else {
                return;
            }
        } else if (tvEvent instanceof TvEvent.MediaPlaybackState) {
            this.f12185r = (TvEvent.MediaPlaybackState) tvEvent;
        }
        if (((Boolean) this.f12179l.getValue()).booleanValue()) {
            Log.d("RemoteEventsBridge", "sendEvent: (" + str + ") " + tvEvent);
            G.y(dVar, (h) null, new C0120c(this, tvEvent, (Ba.e<? super C0120c>) null), 3);
        }
    }

    public final void e(boolean z10) {
        Boolean valueOf = Boolean.valueOf(z10);
        Z z11 = this.f12179l;
        z11.getClass();
        z11.h((Object) null, valueOf);
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0046  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x004b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(int r6) {
        /*
            r5 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "setUdpPort: "
            r0.<init>(r1)
            r0.append(r6)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "RemoteEventsBridge"
            android.util.Log.d(r1, r0)
            r0 = 0
            java.util.Enumeration r1 = java.net.NetworkInterface.getNetworkInterfaces()     // Catch:{ Exception -> 0x003f }
        L_0x0018:
            boolean r2 = r1.hasMoreElements()     // Catch:{ Exception -> 0x003f }
            if (r2 == 0) goto L_0x0043
            java.lang.Object r2 = r1.nextElement()     // Catch:{ Exception -> 0x003f }
            java.net.NetworkInterface r2 = (java.net.NetworkInterface) r2     // Catch:{ Exception -> 0x003f }
            java.util.Enumeration r2 = r2.getInetAddresses()     // Catch:{ Exception -> 0x003f }
        L_0x0028:
            boolean r3 = r2.hasMoreElements()     // Catch:{ Exception -> 0x003f }
            if (r3 == 0) goto L_0x0018
            java.lang.Object r3 = r2.nextElement()     // Catch:{ Exception -> 0x003f }
            java.net.InetAddress r3 = (java.net.InetAddress) r3     // Catch:{ Exception -> 0x003f }
            boolean r4 = r3.isLoopbackAddress()     // Catch:{ Exception -> 0x003f }
            if (r4 != 0) goto L_0x0028
            boolean r4 = r3 instanceof java.net.Inet4Address     // Catch:{ Exception -> 0x003f }
            if (r4 == 0) goto L_0x0028
            goto L_0x0044
        L_0x003f:
            r1 = move-exception
            r1.printStackTrace()
        L_0x0043:
            r3 = r0
        L_0x0044:
            if (r3 == 0) goto L_0x004b
            java.lang.String r1 = r3.getHostAddress()
            goto L_0x004c
        L_0x004b:
            r1 = r0
        L_0x004c:
            r5.f12182o = r1
            java.lang.Integer r1 = java.lang.Integer.valueOf(r6)
            r5.f12181n = r1
            com.browser.remote.events.TvEvent$UdpServerInfo r1 = new com.browser.remote.events.TvEvent$UdpServerInfo
            java.lang.String r2 = r5.f12182o
            r1.<init>(r2, r6)
            r5.d(r1, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: Z4.c.f(int):void");
    }
}
