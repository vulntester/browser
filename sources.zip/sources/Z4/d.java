package Z4;

import Da.c;
import Da.e;
import ic.C4488D;
import ic.U;
import io.ktor.websocket.DefaultWebSocketSession;
import kc.C4585c;
import kc.y;
import kotlin.jvm.internal.l;
import lc.C4610c;
import lc.C4613f;
import lc.C4614g;
import mc.C4690j;
import pc.b;
import xa.C4959D;

public final class d extends C7.a {

    /* renamed from: i  reason: collision with root package name */
    public final DefaultWebSocketSession f12201i;

    /* renamed from: z  reason: collision with root package name */
    public final y<byte[]> f12202z;

    public static final class a implements C4613f<byte[]> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C4610c f12203f;

        /* renamed from: Z4.d$a$a  reason: collision with other inner class name */
        public static final class C0121a<T> implements C4614g {

            /* renamed from: f  reason: collision with root package name */
            public final /* synthetic */ C4614g f12204f;

            @e(c = "com.browser.remote.WebSocketConnection$special$$inlined$mapNotNull$1$2", f = "WebSocketConnection.kt", l = {56}, m = "emit")
            /* renamed from: Z4.d$a$a$a  reason: collision with other inner class name */
            public static final class C0122a extends c {

                /* renamed from: f  reason: collision with root package name */
                public /* synthetic */ Object f12205f;

                /* renamed from: i  reason: collision with root package name */
                public int f12206i;

                /* renamed from: z  reason: collision with root package name */
                public final /* synthetic */ C0121a f12207z;

                /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                public C0122a(C0121a aVar, Ba.e eVar) {
                    super(eVar);
                    this.f12207z = aVar;
                }

                public final Object invokeSuspend(Object obj) {
                    this.f12205f = obj;
                    this.f12206i |= Integer.MIN_VALUE;
                    return this.f12207z.emit((Object) null, this);
                }
            }

            public C0121a(C4614g gVar) {
                this.f12204f = gVar;
            }

            /* JADX WARNING: Removed duplicated region for block: B:12:0x002f  */
            /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public final java.lang.Object emit(java.lang.Object r5, Ba.e r6) {
                /*
                    r4 = this;
                    boolean r0 = r6 instanceof Z4.d.a.C0121a.C0122a
                    if (r0 == 0) goto L_0x0013
                    r0 = r6
                    Z4.d$a$a$a r0 = (Z4.d.a.C0121a.C0122a) r0
                    int r1 = r0.f12206i
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L_0x0013
                    int r1 = r1 - r2
                    r0.f12206i = r1
                    goto L_0x0018
                L_0x0013:
                    Z4.d$a$a$a r0 = new Z4.d$a$a$a
                    r0.<init>(r4, r6)
                L_0x0018:
                    java.lang.Object r6 = r0.f12205f
                    Ca.a r1 = Ca.a.f33640f
                    int r2 = r0.f12206i
                    r3 = 1
                    if (r2 == 0) goto L_0x002f
                    if (r2 != r3) goto L_0x0027
                    xa.C4976p.b(r6)
                    goto L_0x004b
                L_0x0027:
                    java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                    java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                    r5.<init>(r6)
                    throw r5
                L_0x002f:
                    xa.C4976p.b(r6)
                    io.ktor.websocket.Frame r5 = (io.ktor.websocket.Frame) r5
                    boolean r6 = r5 instanceof io.ktor.websocket.Frame.Binary
                    if (r6 == 0) goto L_0x003d
                    byte[] r5 = io.ktor.websocket.FrameCommonKt.readBytes(r5)
                    goto L_0x003e
                L_0x003d:
                    r5 = 0
                L_0x003e:
                    if (r5 == 0) goto L_0x004b
                    r0.f12206i = r3
                    lc.g r6 = r4.f12204f
                    java.lang.Object r5 = r6.emit(r5, r0)
                    if (r5 != r1) goto L_0x004b
                    return r1
                L_0x004b:
                    xa.D r5 = xa.C4959D.f44058a
                    return r5
                */
                throw new UnsupportedOperationException("Method not decompiled: Z4.d.a.C0121a.emit(java.lang.Object, Ba.e):java.lang.Object");
            }
        }

        public a(C4610c cVar) {
            this.f12203f = cVar;
        }

        public final Object collect(C4614g gVar, Ba.e eVar) {
            Object collect = this.f12203f.collect(new C0121a(gVar), eVar);
            if (collect == Ca.a.f33640f) {
                return collect;
            }
            return C4959D.f44058a;
        }
    }

    public d(DefaultWebSocketSession defaultWebSocketSession) {
        l.f(defaultWebSocketSession, "session");
        this.f12201i = defaultWebSocketSession;
        a aVar = new a(new C4610c(defaultWebSocketSession.getIncoming(), false));
        U u7 = U.f41134a;
        this.f12202z = new C4690j(aVar, 0, (C4585c) null, 14).f(C4488D.a(b.f43037f));
    }
}
