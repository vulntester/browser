package Z4;

import B4.j;
import C7.a;
import ic.C4488D;
import ic.U;
import io.ktor.client.HttpClientKt;
import io.ktor.client.engine.okhttp.OkHttp;
import kc.C4585c;
import kc.l;
import lc.Z;
import lc.a0;
import pc.b;

public final class e extends a {

    /* renamed from: z  reason: collision with root package name */
    public static e f12208z;

    /* renamed from: i  reason: collision with root package name */
    public final Z f12209i = a0.a("");

    public e() {
        l.a(50, 6, (C4585c) null);
        U u7 = U.f41134a;
        C4488D.a(b.f43037f);
        HttpClientKt.HttpClient(OkHttp.INSTANCE, new j(5));
    }
}
