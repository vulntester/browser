package Z5;

import Pb.C4120j;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;
import com.google.android.gms.internal.measurement.C1572i1;
import com.google.android.gms.internal.measurement.C1626q;
import com.google.android.gms.internal.measurement.C1667w;
import com.google.android.gms.internal.measurement.C1674x;
import com.google.android.gms.internal.measurement.F1;
import com.google.android.gms.internal.measurement.I;
import com.google.android.gms.internal.measurement.J;
import com.google.android.gms.internal.measurement.r;
import f5.c;
import f5.g;
import f5.j;
import i5.u;
import ia.k;
import j5.b;
import ja.N;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import mb.C4649C;
import p5.C2901b;
import p5.C2902c;
import s8.C4821e;

public final class a implements C4649C, j {

    /* renamed from: f  reason: collision with root package name */
    public final Object f12210f;

    /* renamed from: i  reason: collision with root package name */
    public final Object f12211i;

    public /* synthetic */ a(Object obj, Object obj2) {
        this.f12210f = obj;
        this.f12211i = obj2;
    }

    public void a() {
        String str = (String) this.f12210f;
        try {
            C4821e eVar = (C4821e) this.f12211i;
            eVar.getClass();
            new File(eVar.f43417c, str).createNewFile();
        } catch (IOException e10) {
            Log.e("FirebaseCrashlytics", "Error creating marker: ".concat(str), e10);
        }
    }

    public C1626q b(C1572i1 i1Var, C1626q qVar) {
        C1674x xVar;
        F1.c(i1Var);
        if (!(qVar instanceof r)) {
            return qVar;
        }
        r rVar = (r) qVar;
        ArrayList arrayList = rVar.f17902i;
        HashMap hashMap = (HashMap) this.f12210f;
        String str = rVar.f17901f;
        if (hashMap.containsKey(str)) {
            xVar = (C1674x) hashMap.get(str);
        } else {
            xVar = (I) this.f12211i;
        }
        return xVar.a(str, i1Var, arrayList);
    }

    public void c(C1674x xVar) {
        Iterator it = xVar.f17981a.iterator();
        while (it.hasNext()) {
            ((HashMap) this.f12210f).put(Integer.valueOf(((J) it.next()).f17535f).toString(), xVar);
        }
    }

    public c f(g gVar) {
        return c.f21248i;
    }

    public boolean g(Object obj, File file, g gVar) {
        return ((C2901b) this.f12211i).g(new C2902c(((BitmapDrawable) ((u) obj).get()).getBitmap(), (b) this.f12210f), file, gVar);
    }

    public a() {
        this.f12210f = new HashMap();
        this.f12211i = new C1674x();
        c(new C1667w(0));
        C1674x xVar = new C1674x();
        xVar.f17981a.add(J.EQUALS);
        xVar.f17981a.add(J.GREATER_THAN);
        xVar.f17981a.add(J.GREATER_THAN_EQUALS);
        xVar.f17981a.add(J.IDENTITY_EQUALS);
        xVar.f17981a.add(J.IDENTITY_NOT_EQUALS);
        xVar.f17981a.add(J.LESS_THAN);
        xVar.f17981a.add(J.LESS_THAN_EQUALS);
        xVar.f17981a.add(J.NOT_EQUALS);
        c(xVar);
        C1674x xVar2 = new C1674x();
        xVar2.f17981a.add(J.APPLY);
        xVar2.f17981a.add(J.BLOCK);
        xVar2.f17981a.add(J.BREAK);
        xVar2.f17981a.add(J.CASE);
        xVar2.f17981a.add(J.DEFAULT);
        xVar2.f17981a.add(J.CONTINUE);
        xVar2.f17981a.add(J.DEFINE_FUNCTION);
        xVar2.f17981a.add(J.FN);
        xVar2.f17981a.add(J.IF);
        xVar2.f17981a.add(J.QUOTE);
        xVar2.f17981a.add(J.RETURN);
        xVar2.f17981a.add(J.SWITCH);
        xVar2.f17981a.add(J.TERNARY);
        c(xVar2);
        C1674x xVar3 = new C1674x();
        xVar3.f17981a.add(J.AND);
        xVar3.f17981a.add(J.NOT);
        xVar3.f17981a.add(J.OR);
        c(xVar3);
        C1674x xVar4 = new C1674x();
        xVar4.f17981a.add(J.FOR_IN);
        xVar4.f17981a.add(J.FOR_IN_CONST);
        xVar4.f17981a.add(J.FOR_IN_LET);
        xVar4.f17981a.add(J.FOR_LET);
        xVar4.f17981a.add(J.FOR_OF);
        xVar4.f17981a.add(J.FOR_OF_CONST);
        xVar4.f17981a.add(J.FOR_OF_LET);
        xVar4.f17981a.add(J.WHILE);
        c(xVar4);
        C1674x xVar5 = new C1674x();
        xVar5.f17981a.add(J.ADD);
        xVar5.f17981a.add(J.DIVIDE);
        xVar5.f17981a.add(J.MODULUS);
        xVar5.f17981a.add(J.MULTIPLY);
        xVar5.f17981a.add(J.NEGATE);
        xVar5.f17981a.add(J.POST_DECREMENT);
        xVar5.f17981a.add(J.POST_INCREMENT);
        xVar5.f17981a.add(J.PRE_DECREMENT);
        xVar5.f17981a.add(J.PRE_INCREMENT);
        xVar5.f17981a.add(J.SUBTRACT);
        c(xVar5);
        c(new C1667w(1));
    }

    public a(N n10) {
        this.f12210f = n10;
        this.f12211i = n10.f41431b.d((k) null).c((String) null).a(true);
    }

    public a(Map map) {
        this.f12211i = map;
        this.f12210f = new Sb.c("Java nullability annotation states").f(new C4120j(this, 2));
    }
}
