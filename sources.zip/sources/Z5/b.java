package Z5;

import D1.d;
import kotlin.jvm.internal.l;

public abstract class b<T> {

    public static final class a<T> extends b<T> {

        /* renamed from: a  reason: collision with root package name */
        public final T f12212a;

        public a(T t10) {
            this.f12212a = t10;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if ((obj instanceof a) && l.a(this.f12212a, ((a) obj).f12212a)) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            T t10 = this.f12212a;
            if (t10 == null) {
                return 0;
            }
            return t10.hashCode();
        }

        public final String toString() {
            return d.g(new StringBuilder("Some(value="), this.f12212a, ')');
        }
    }

    /* renamed from: Z5.b$b  reason: collision with other inner class name */
    public static final class C0123b extends b {

        /* renamed from: a  reason: collision with root package name */
        public static final C0123b f12213a = new b();

        public final boolean equals(Object obj) {
            if (this != obj && !(obj instanceof C0123b)) {
                return false;
            }
            return true;
        }

        public final int hashCode() {
            return 1961466395;
        }

        public final String toString() {
            return "Undefined";
        }
    }
}
