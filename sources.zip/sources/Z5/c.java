package Z5;

import android.content.SharedPreferences;
import ic.C4488D;
import ic.U;
import java.util.Set;
import kotlin.jvm.internal.l;
import nc.C4732d;
import nc.p;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    public final SharedPreferences f12214a;

    /* renamed from: b  reason: collision with root package name */
    public final C4732d f12215b = C4488D.a(p.f42446a);

    public c(SharedPreferences sharedPreferences) {
        this.f12214a = sharedPreferences;
        U u7 = U.f41134a;
    }

    public final boolean a(a aVar) {
        l.f(aVar, "key");
        return this.f12214a.getBoolean((String) aVar.f12210f, ((Boolean) aVar.f12211i).booleanValue());
    }

    public final int b(a aVar) {
        SharedPreferences sharedPreferences = this.f12214a;
        l.f(aVar, "key");
        String str = (String) aVar.f12210f;
        Object obj = aVar.f12211i;
        try {
            return sharedPreferences.getInt(str, ((Number) obj).intValue());
        } catch (Exception unused) {
            try {
                int i10 = (int) sharedPreferences.getFloat(str, (float) ((Number) obj).intValue());
                g(aVar, i10);
                return i10;
            } catch (Exception e10) {
                e10.printStackTrace();
                return ((Number) obj).intValue();
            }
        }
    }

    public final String c(a aVar) {
        l.f(aVar, "key");
        return this.f12214a.getString((String) aVar.f12210f, (String) aVar.f12211i);
    }

    public final String d(a aVar) {
        l.f(aVar, "key");
        return this.f12214a.getString((String) aVar.f12210f, (String) aVar.f12211i);
    }

    public final Set e(a aVar) {
        l.f(aVar, "key");
        return this.f12214a.getStringSet((String) aVar.f12210f, (Set) aVar.f12211i);
    }

    public final void f(a aVar, boolean z10) {
        l.f(aVar, "key");
        this.f12214a.edit().putBoolean((String) aVar.f12210f, z10).apply();
    }

    public final void g(a aVar, int i10) {
        l.f(aVar, "key");
        this.f12214a.edit().putInt((String) aVar.f12210f, i10).apply();
    }

    public final void h(a aVar, String str) {
        l.f(aVar, "key");
        l.f(str, "value");
        this.f12214a.edit().putString((String) aVar.f12210f, str).apply();
    }
}
