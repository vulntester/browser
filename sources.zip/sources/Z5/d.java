package Z5;

import Da.c;
import Da.e;
import java.util.Iterator;

@e(c = "com.common.components.repository.preferences.RawAppPrefs", f = "RawAppPrefs.kt", l = {233}, m = "migration1")
public final class d extends c {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ e f12216E;

    /* renamed from: F  reason: collision with root package name */
    public int f12217F;

    /* renamed from: f  reason: collision with root package name */
    public g f12218f;

    /* renamed from: i  reason: collision with root package name */
    public Iterator f12219i;

    /* renamed from: z  reason: collision with root package name */
    public /* synthetic */ Object f12220z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(e eVar, c cVar) {
        super(cVar);
        this.f12216E = eVar;
    }

    public final Object invokeSuspend(Object obj) {
        this.f12220z = obj;
        this.f12217F |= Integer.MIN_VALUE;
        return this.f12216E.i((g) null, this);
    }
}
