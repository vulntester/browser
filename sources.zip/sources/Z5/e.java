package Z5;

import N5.i;
import N5.l;
import O8.a;
import Y1.N;
import ya.m;
import ya.w;

public final class e extends c {

    /* renamed from: A0  reason: collision with root package name */
    public static final a f12221A0;

    /* renamed from: B0  reason: collision with root package name */
    public static final a f12222B0;

    /* renamed from: C0  reason: collision with root package name */
    public static final a f12223C0;

    /* renamed from: D0  reason: collision with root package name */
    public static final a f12224D0;

    /* renamed from: E0  reason: collision with root package name */
    public static final a f12225E0 = new a("forward_rewind_seconds_step", 10);

    /* renamed from: F0  reason: collision with root package name */
    public static final a f12226F0 = new a("horizontal_padding", 0);

    /* renamed from: G0  reason: collision with root package name */
    public static final a f12227G0 = new a("vertical_padding", 0);

    /* renamed from: H  reason: collision with root package name */
    public static final a f12228H;

    /* renamed from: H0  reason: collision with root package name */
    public static final a f12229H0 = new a("donations_banner_closed_at", 0L);

    /* renamed from: I  reason: collision with root package name */
    public static final a f12230I = new a("app_start_ctr", 0);

    /* renamed from: I0  reason: collision with root package name */
    public static final a f12231I0;

    /* renamed from: J  reason: collision with root package name */
    public static final a f12232J = new a("video_player_start_ctr", 0);

    /* renamed from: J0  reason: collision with root package name */
    public static final a f12233J0 = new a("app_lock_pin", "");

    /* renamed from: K  reason: collision with root package name */
    public static final a f12234K = new a("enter_fullscreen_ctr", 0);

    /* renamed from: K0  reason: collision with root package name */
    public static final a f12235K0 = new a("last_ima_ad_view_at", 0L);

    /* renamed from: L  reason: collision with root package name */
    public static final a f12236L = new a("pin_code", "");

    /* renamed from: L0  reason: collision with root package name */
    public static final a f12237L0;

    /* renamed from: M  reason: collision with root package name */
    public static final a f12238M = new a("first_installation_version_code", 0);

    /* renamed from: M0  reason: collision with root package name */
    public static final a f12239M0;

    /* renamed from: N  reason: collision with root package name */
    public static final a f12240N = new a("cursor_size", 24);

    /* renamed from: N0  reason: collision with root package name */
    public static final a f12241N0;

    /* renamed from: O  reason: collision with root package name */
    public static final a f12242O = new a("cursor_acceleration", 14);

    /* renamed from: O0  reason: collision with root package name */
    public static final a f12243O0;

    /* renamed from: P  reason: collision with root package name */
    public static final a f12244P = new a("cursor_style", C0.e.p(l.f6457i));

    /* renamed from: P0  reason: collision with root package name */
    public static final a f12245P0;

    /* renamed from: Q  reason: collision with root package name */
    public static final a f12246Q;

    /* renamed from: Q0  reason: collision with root package name */
    public static final a f12247Q0;

    /* renamed from: R  reason: collision with root package name */
    public static final a f12248R = new a("homepage", (Object) null);

    /* renamed from: R0  reason: collision with root package name */
    public static final a f12249R0;

    /* renamed from: S  reason: collision with root package name */
    public static final a f12250S;

    /* renamed from: S0  reason: collision with root package name */
    public static final a f12251S0;

    /* renamed from: T  reason: collision with root package name */
    public static final a f12252T = new a("search_engine", (Object) null);

    /* renamed from: T0  reason: collision with root package name */
    public static final a f12253T0;

    /* renamed from: U  reason: collision with root package name */
    public static final a f12254U;

    /* renamed from: U0  reason: collision with root package name */
    public static final a f12255U0;

    /* renamed from: V  reason: collision with root package name */
    public static final a f12256V;

    /* renamed from: V0  reason: collision with root package name */
    public static final a f12257V0;

    /* renamed from: W  reason: collision with root package name */
    public static final a f12258W;

    /* renamed from: W0  reason: collision with root package name */
    public static final a f12259W0;

    /* renamed from: X  reason: collision with root package name */
    public static final a f12260X;

    /* renamed from: X0  reason: collision with root package name */
    public static final a f12261X0;

    /* renamed from: Y  reason: collision with root package name */
    public static final a f12262Y;

    /* renamed from: Y0  reason: collision with root package name */
    public static final a f12263Y0 = new a("gboard_recommendation_display_ctr", 0);

    /* renamed from: Z  reason: collision with root package name */
    public static final a f12264Z = new a("viewport_mode", "");

    /* renamed from: Z0  reason: collision with root package name */
    public static final a f12265Z0;

    /* renamed from: a0  reason: collision with root package name */
    public static final a f12266a0;

    /* renamed from: a1  reason: collision with root package name */
    public static final a f12267a1;

    /* renamed from: b0  reason: collision with root package name */
    public static final a f12268b0 = new a("application_language", "system");

    /* renamed from: c0  reason: collision with root package name */
    public static final a f12269c0;

    /* renamed from: d0  reason: collision with root package name */
    public static final a f12270d0;
    public static final a e0;

    /* renamed from: f0  reason: collision with root package name */
    public static final a f12271f0;

    /* renamed from: g0  reason: collision with root package name */
    public static final a f12272g0 = new a("app_crashes_ctr", 0);

    /* renamed from: h0  reason: collision with root package name */
    public static final a f12273h0 = new a("user_random_percentage", 0);

    /* renamed from: i0  reason: collision with root package name */
    public static final a f12274i0 = new a("enabled_addons", m.V(new String[]{"ad-blocker", "cookie-banner-blocker", "smart-video-player"}));

    /* renamed from: j0  reason: collision with root package name */
    public static final a f12275j0;

    /* renamed from: k0  reason: collision with root package name */
    public static final a f12276k0 = new a("adblocker_request_blocked_ctr", 0);

    /* renamed from: l0  reason: collision with root package name */
    public static final a f12277l0;

    /* renamed from: m0  reason: collision with root package name */
    public static final a f12278m0 = new a("app_horizontal_padding", 20);

    /* renamed from: n0  reason: collision with root package name */
    public static final a f12279n0 = new a("app_vertical_padding", 20);

    /* renamed from: o0  reason: collision with root package name */
    public static final a f12280o0;

    /* renamed from: p0  reason: collision with root package name */
    public static final a f12281p0 = new a("country_code_from_ip", "");

    /* renamed from: q0  reason: collision with root package name */
    public static final a f12282q0;

    /* renamed from: r0  reason: collision with root package name */
    public static final a f12283r0;

    /* renamed from: s0  reason: collision with root package name */
    public static final a f12284s0;

    /* renamed from: t0  reason: collision with root package name */
    public static final a f12285t0;

    /* renamed from: u0  reason: collision with root package name */
    public static final a f12286u0 = new a("http_server_port", 0);

    /* renamed from: v0  reason: collision with root package name */
    public static final a f12287v0;

    /* renamed from: w0  reason: collision with root package name */
    public static final a f12288w0;

    /* renamed from: x0  reason: collision with root package name */
    public static final a f12289x0;

    /* renamed from: y0  reason: collision with root package name */
    public static final a f12290y0;

    /* renamed from: z0  reason: collision with root package name */
    public static final a f12291z0;

    /* renamed from: A  reason: collision with root package name */
    public final l f12292A;

    /* renamed from: B  reason: collision with root package name */
    public final l f12293B;

    /* renamed from: C  reason: collision with root package name */
    public final l f12294C;

    /* renamed from: D  reason: collision with root package name */
    public final l f12295D;

    /* renamed from: E  reason: collision with root package name */
    public final l f12296E;

    /* renamed from: F  reason: collision with root package name */
    public final l f12297F;

    /* renamed from: G  reason: collision with root package name */
    public final l f12298G;

    /* renamed from: c  reason: collision with root package name */
    public final m f12299c;

    /* renamed from: d  reason: collision with root package name */
    public final m f12300d;

    /* renamed from: e  reason: collision with root package name */
    public final m f12301e;

    /* renamed from: f  reason: collision with root package name */
    public final l f12302f;

    /* renamed from: g  reason: collision with root package name */
    public final l f12303g;

    /* renamed from: h  reason: collision with root package name */
    public final l f12304h;

    /* renamed from: i  reason: collision with root package name */
    public final l f12305i;

    /* renamed from: j  reason: collision with root package name */
    public final m f12306j;

    /* renamed from: k  reason: collision with root package name */
    public final N f12307k;

    /* renamed from: l  reason: collision with root package name */
    public final p f12308l;

    /* renamed from: m  reason: collision with root package name */
    public final o f12309m;

    /* renamed from: n  reason: collision with root package name */
    public final l f12310n;

    /* renamed from: o  reason: collision with root package name */
    public final l f12311o;

    /* renamed from: p  reason: collision with root package name */
    public final l f12312p;

    /* renamed from: q  reason: collision with root package name */
    public final l f12313q;

    /* renamed from: r  reason: collision with root package name */
    public final l f12314r;

    /* renamed from: s  reason: collision with root package name */
    public final q f12315s;

    /* renamed from: t  reason: collision with root package name */
    public final l f12316t;

    /* renamed from: u  reason: collision with root package name */
    public final l f12317u;

    /* renamed from: v  reason: collision with root package name */
    public final N f12318v;

    /* renamed from: w  reason: collision with root package name */
    public final l f12319w;

    /* renamed from: x  reason: collision with root package name */
    public final q f12320x;

    /* renamed from: y  reason: collision with root package name */
    public final a f12321y;

    /* renamed from: z  reason: collision with root package name */
    public final l f12322z;

    static {
        Boolean bool = Boolean.FALSE;
        f12228H = new a("blur_adult_content_media", bool);
        i.a aVar = i.f6445i;
        f12246Q = new a("cursor_hide_automatically", bool);
        Boolean bool2 = Boolean.TRUE;
        f12250S = new a("homepage_launch_at_app_start", bool2);
        f12254U = new a("search_engine_light_mode", bool);
        f12256V = new a("browser_history_on", bool2);
        f12258W = new a("search_history_on", bool2);
        f12260X = new a("dark_mode_on", bool);
        f12262Y = new a("browser_start_fullscreen", bool);
        f12266a0 = new a("close_incognito_tabs_automatically_at_exit", bool2);
        f12269c0 = new a("app_feedback_card_yes_clicked", bool);
        f12270d0 = new a("app_feedback_card_no_clicked", bool);
        e0 = new a("smartphone_browser_card_ad_closed", bool);
        f12271f0 = new a("firebase_config_fetched_once", bool);
        N5.e eVar = N5.e.f6414f;
        N5.e eVar2 = N5.e.f6414f;
        N5.e eVar3 = N5.e.f6414f;
        w wVar = w.f44687f;
        f12275j0 = new a("adblocker_host_whitelist", wVar);
        f12277l0 = new a("http_server_on", bool);
        f12280o0 = new a("has_donated", bool);
        f12282q0 = new a("hide_privacy_protection_addon", bool);
        f12283r0 = new a("vpn_feedback_sent", bool);
        f12284s0 = new a("vpn_location_opened_event_sent", bool);
        f12285t0 = new a("video_finder_host_blacklist", wVar);
        f12287v0 = new a("adblocker_on", bool2);
        f12288w0 = new a("cookie_banner_blocker_on", bool2);
        f12289x0 = new a("smart_video_player_on", bool2);
        f12290y0 = new a("inject_video_player_js", bool2);
        f12291z0 = new a("fullscreen_helper", bool2);
        f12221A0 = new a("webview_fullscreen_native_video_control", bool2);
        f12222B0 = new a("find_video_recommendations", bool2);
        f12223C0 = new a("video_finder_on", bool2);
        f12224D0 = new a("video_finder_found_popup", bool2);
        f12231I0 = new a("app_lock_on", bool);
        f12237L0 = new a("tv_recommendations_on", bool2);
        f12239M0 = new a("home_shortcuts_on", bool2);
        f12241N0 = new a("shortcuts_initialized", bool);
        f12243O0 = new a("browser_tutorial_shown", bool);
        f12245P0 = new a("intro_shown", bool);
        f12247Q0 = new a("show_remote_ad", bool2);
        f12249R0 = new a("debug_mode", bool);
        f12251S0 = new a("show_home_top_sites", bool2);
        f12253T0 = new a("show_home_most_visited", bool2);
        f12255U0 = new a("show_home_favorite_bookmarks", bool2);
        f12257V0 = new a("show_home_last_visited", bool2);
        f12259W0 = new a("show_home_quick_settings", bool2);
        f12261X0 = new a("hide_gboard_recommendation", bool);
        f12265Z0 = new a("migration_1", bool);
        f12267a1 = new a("migration_2", bool);
    }

    /* JADX WARNING: type inference failed for: r2v14, types: [Ta.g, Ta.e] */
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public e(android.content.ContextWrapper r10) {
        /*
            r9 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = r10.getPackageName()
            r0.append(r1)
            java.lang.String r1 = "_preferences"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r1 = 0
            android.content.SharedPreferences r0 = r10.getSharedPreferences(r0, r1)
            java.lang.String r2 = "getSharedPreferences(...)"
            kotlin.jvm.internal.l.e(r0, r2)
            r9.<init>(r0)
            Z5.a r0 = f12238M
            int r2 = r9.b(r0)
            java.lang.String r3 = "RawAppPrefs"
            r4 = 24
            if (r2 != 0) goto L_0x00cd
            android.content.pm.PackageManager r2 = r10.getPackageManager()     // Catch:{ NameNotFoundException -> 0x003d }
            java.lang.String r5 = r10.getPackageName()     // Catch:{ NameNotFoundException -> 0x003d }
            android.content.pm.PackageInfo r2 = r2.getPackageInfo(r5, r1)     // Catch:{ NameNotFoundException -> 0x003d }
            long r5 = r2.firstInstallTime     // Catch:{ NameNotFoundException -> 0x003d }
            goto L_0x0045
        L_0x003d:
            java.util.Calendar r2 = java.util.Calendar.getInstance()
            long r5 = r2.getTimeInMillis()
        L_0x0045:
            r7 = 1696317847843(0x18af46c3923, double:8.380923730466E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 <= 0) goto L_0x0058
            long r5 = s6.m.b(r10)
            int r2 = (int) r5
            r9.g(r0, r2)
            goto L_0x00cd
        L_0x0058:
            r7 = 1677711600000(0x1869f676980, double:8.288996651894E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x0064
            r2 = 9
            goto L_0x00b9
        L_0x0064:
            r7 = 1678834800000(0x186e25a1580, double:8.29454599723E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x0070
            r2 = 17
            goto L_0x00b9
        L_0x0070:
            r7 = 1681164000000(0x1876d2edb00, double:8.30605377425E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x007b
            r2 = r4
            goto L_0x00b9
        L_0x007b:
            r7 = 1685916000000(0x188886c9f00, double:8.32953177374E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x0087
            r2 = 37
            goto L_0x00b9
        L_0x0087:
            r7 = 1687730400000(0x188f4922b00, double:8.33849610082E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x0093
            r2 = 40
            goto L_0x00b9
        L_0x0093:
            r7 = 1689285600000(0x1895144a300, double:8.346179809743E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x009f
            r2 = 41
            goto L_0x00b9
        L_0x009f:
            r7 = 1692655200000(0x18a1a1ca700, double:8.362827845745E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x00ab
            r2 = 42
            goto L_0x00b9
        L_0x00ab:
            r7 = 1694383200000(0x18a811bd700, double:8.371365300106E-312)
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 >= 0) goto L_0x00b7
            r2 = 52
            goto L_0x00b9
        L_0x00b7:
            r2 = 53
        L_0x00b9:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            java.lang.String r6 = "initFirstVersionCode: firstInstallVersionCode="
            r5.<init>(r6)
            r5.append(r2)
            java.lang.String r5 = r5.toString()
            android.util.Log.d(r3, r5)
            r9.g(r0, r2)
        L_0x00cd:
            Z5.a r0 = f12244P
            java.lang.String r2 = "key"
            kotlin.jvm.internal.l.f(r0, r2)
            android.content.SharedPreferences r5 = r9.f12214a
            java.lang.Object r6 = r0.f12210f
            java.lang.String r6 = (java.lang.String) r6
            boolean r5 = r5.contains(r6)
            Z5.a r6 = f12240N
            if (r5 != 0) goto L_0x00fd
            N5.l r5 = N5.l.f6457i
            java.lang.String r5 = C0.e.p(r5)
            r9.h(r0, r5)
            kotlin.jvm.internal.l.f(r6, r2)
            android.content.SharedPreferences r5 = r9.f12214a
            java.lang.Object r7 = r6.f12210f
            java.lang.String r7 = (java.lang.String) r7
            boolean r5 = r5.contains(r7)
            if (r5 != 0) goto L_0x00fd
            r9.g(r6, r4)
        L_0x00fd:
            Z5.a r4 = f12273h0
            kotlin.jvm.internal.l.f(r4, r2)
            android.content.SharedPreferences r2 = r9.f12214a
            java.lang.Object r5 = r4.f12210f
            java.lang.String r5 = (java.lang.String) r5
            boolean r2 = r2.contains(r5)
            if (r2 != 0) goto L_0x0141
            Ta.g r2 = new Ta.g
            r5 = 1
            r7 = 100
            r2.<init>(r5, r7, r5)
            Ra.c$a r5 = Ra.c.f37687f
            java.lang.String r7 = "random"
            kotlin.jvm.internal.l.f(r5, r7)
            int r2 = o2.C2757a.u(r5, r2)     // Catch:{ IllegalArgumentException -> 0x0136 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            java.lang.String r7 = "init: USER_RANDOM_PERCENTAGE="
            r5.<init>(r7)
            r5.append(r2)
            java.lang.String r5 = r5.toString()
            android.util.Log.d(r3, r5)
            r9.g(r4, r2)
            goto L_0x0141
        L_0x0136:
            r10 = move-exception
            java.util.NoSuchElementException r0 = new java.util.NoSuchElementException
            java.lang.String r10 = r10.getMessage()
            r0.<init>(r10)
            throw r0
        L_0x0141:
            Z5.m r2 = new Z5.m
            Z5.a r3 = f12230I
            r2.<init>(r9, r3, r1)
            r9.f12299c = r2
            Z5.m r2 = new Z5.m
            Z5.a r3 = f12232J
            r2.<init>(r9, r3, r1)
            r9.f12300d = r2
            Z5.m r2 = new Z5.m
            Z5.a r3 = f12234K
            r2.<init>(r9, r3, r1)
            r9.f12301e = r2
            Z5.l r2 = new Z5.l
            Z5.a r3 = f12245P0
            r2.<init>(r9, r3)
            r9.f12302f = r2
            Z5.l r2 = new Z5.l
            Z5.a r3 = f12287v0
            r2.<init>(r9, r3)
            r9.f12303g = r2
            Z5.l r2 = new Z5.l
            Z5.a r3 = f12288w0
            r2.<init>(r9, r3)
            r9.f12304h = r2
            Z5.l r2 = new Z5.l
            Z5.a r3 = f12289x0
            r2.<init>(r9, r3)
            r9.f12305i = r2
            Z5.m r2 = new Z5.m
            Z5.a r3 = f12276k0
            r2.<init>(r9, r3, r1)
            r9.f12306j = r2
            Z5.a r1 = f12226F0
            java.lang.String r2 = "pref"
            kotlin.jvm.internal.l.f(r1, r2)
            int r1 = r9.b(r1)
            V.p0 r3 = new V.p0
            r3.<init>(r1)
            Z5.a r1 = f12227G0
            kotlin.jvm.internal.l.f(r1, r2)
            int r1 = r9.b(r1)
            V.p0 r3 = new V.p0
            r3.<init>(r1)
            Z5.a r1 = f12242O
            kotlin.jvm.internal.l.f(r1, r2)
            int r1 = r9.b(r1)
            N5.i$a r3 = N5.i.f6445i
            r3.getClass()
            N5.i r1 = N5.i.a.a(r1)
            R1.a.t(r1)
            kotlin.jvm.internal.l.f(r6, r2)
            int r1 = r9.b(r6)
            V.p0 r3 = new V.p0
            r3.<init>(r1)
            Y1.N r1 = new Y1.N
            Y4.j r3 = new Y4.j
            r4 = 1
            r3.<init>(r9, r4)
            C3.h r4 = new C3.h
            r5 = 3
            r4.<init>(r9, r5)
            r1.<init>(r0, r3, r4)
            r9.f12307k = r1
            Z5.p r0 = new Z5.p
            Z5.a r1 = f12252T
            r0.<init>(r9, r1)
            r9.f12308l = r0
            Z5.o r0 = new Z5.o
            Z5.a r1 = f12248R
            r0.<init>(r9, r1)
            r9.f12309m = r0
            Z5.l r0 = new Z5.l
            Z5.a r1 = f12250S
            r0.<init>(r9, r1)
            r9.f12310n = r0
            Z5.l r0 = new Z5.l
            Z5.a r1 = f12254U
            r0.<init>(r9, r1)
            r9.f12311o = r0
            Z5.l r0 = new Z5.l
            Z5.a r1 = f12256V
            r0.<init>(r9, r1)
            r9.f12312p = r0
            Z5.l r0 = new Z5.l
            Z5.a r1 = f12260X
            r0.<init>(r9, r1)
            r9.f12313q = r0
            Z5.l r0 = new Z5.l
            Z5.a r1 = f12262Y
            r0.<init>(r9, r1)
            r9.f12314r = r0
            Z5.a r0 = f12258W
            kotlin.jvm.internal.l.f(r0, r2)
            boolean r0 = r9.a(r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            R1.a.t(r0)
            Z5.q r0 = new Z5.q
            Z5.a r1 = f12268b0
            r0.<init>(r9, r1)
            r9.f12315s = r0
            Z5.a r0 = f12290y0
            kotlin.jvm.internal.l.f(r0, r2)
            boolean r0 = r9.a(r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            R1.a.t(r0)
            Z5.a r0 = f12291z0
            kotlin.jvm.internal.l.f(r0, r2)
            boolean r0 = r9.a(r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            R1.a.t(r0)
            Z5.a r0 = f12221A0
            kotlin.jvm.internal.l.f(r0, r2)
            boolean r0 = r9.a(r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            R1.a.t(r0)
            Z5.a r0 = f12222B0
            kotlin.jvm.internal.l.f(r0, r2)
            boolean r0 = r9.a(r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            R1.a.t(r0)
            Z5.l r0 = new Z5.l
            Z5.a r1 = f12223C0
            r0.<init>(r9, r1)
            r9.f12316t = r0
            Z5.l r0 = new Z5.l
            Z5.a r1 = f12224D0
            r0.<init>(r9, r1)
            r9.f12317u = r0
            Y1.N r0 = new Y1.N
            A4.j r1 = new A4.j
            r3 = 4
            r1.<init>(r9, r3)
            B9.H r3 = new B9.H
            r4 = 2
            r3.<init>(r9, r4)
            Z5.a r4 = f12225E0
            r0.<init>(r4, r1, r3)
            r9.f12318v = r0
            Z5.a r0 = new Z5.a
            L5.e r1 = L5.e.f5641z
            int r3 = s6.z.g(r10, r1)
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            java.lang.String r4 = "mobile_scale"
            r0.<init>(r4, r3)
            int r0 = r9.b(r0)
            V.p0 r3 = new V.p0
            r3.<init>(r0)
            Z5.a r0 = new Z5.a
            L5.e r3 = L5.e.f5640i
            int r10 = s6.z.g(r10, r3)
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)
            java.lang.String r3 = "desktop_scale"
            r0.<init>(r3, r10)
            int r10 = r9.b(r0)
            V.p0 r0 = new V.p0
            r0.<init>(r10)
            Z5.a r10 = f12264Z
            kotlin.jvm.internal.l.f(r10, r2)
            java.lang.String r10 = r9.d(r10)
            if (r10 != 0) goto L_0x02db
            java.lang.String r10 = "MOBILE"
        L_0x02db:
            L5.e$a r0 = L5.e.f5639f
            r0.getClass()
            L5.e r10 = L5.e.a.a(r10)
            if (r10 != 0) goto L_0x02e7
            goto L_0x02e8
        L_0x02e7:
            r1 = r10
        L_0x02e8:
            R1.a.t(r1)
            Z5.a r10 = f12269c0
            kotlin.jvm.internal.l.f(r10, r2)
            boolean r10 = r9.a(r10)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            R1.a.t(r10)
            Z5.a r10 = f12270d0
            kotlin.jvm.internal.l.f(r10, r2)
            boolean r10 = r9.a(r10)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            R1.a.t(r10)
            Z5.a r10 = f12229H0
            kotlin.jvm.internal.l.f(r10, r2)
            java.lang.Object r0 = r10.f12211i
            java.lang.Number r0 = (java.lang.Number) r0
            long r0 = r0.longValue()
            android.content.SharedPreferences r3 = r9.f12214a
            java.lang.Object r10 = r10.f12210f
            java.lang.String r10 = (java.lang.String) r10
            long r0 = r3.getLong(r10, r0)
            V.q0 r10 = new V.q0
            r10.<init>(r0)
            Z5.a r10 = f12280o0
            kotlin.jvm.internal.l.f(r10, r2)
            boolean r10 = r9.a(r10)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            R1.a.t(r10)
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12231I0
            r10.<init>(r9, r0)
            r9.f12319w = r10
            Z5.q r10 = new Z5.q
            Z5.a r0 = f12233J0
            r10.<init>(r9, r0)
            r9.f12320x = r10
            O8.a r10 = new O8.a
            Z5.a r0 = f12235K0
            r10.<init>(r9, r0)
            r9.f12321y = r10
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12228H
            r10.<init>(r9, r0)
            r9.f12322z = r10
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12237L0
            r10.<init>(r9, r0)
            r9.f12292A = r10
            Z5.a r10 = f12239M0
            kotlin.jvm.internal.l.f(r10, r2)
            boolean r10 = r9.a(r10)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            R1.a.t(r10)
            Z5.a r10 = f12241N0
            kotlin.jvm.internal.l.f(r10, r2)
            boolean r10 = r9.a(r10)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            R1.a.t(r10)
            Z5.a r10 = f12247Q0
            kotlin.jvm.internal.l.f(r10, r2)
            boolean r10 = r9.a(r10)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            R1.a.t(r10)
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12249R0
            r10.<init>(r9, r0)
            r9.f12293B = r10
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12251S0
            r10.<init>(r9, r0)
            r9.f12294C = r10
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12253T0
            r10.<init>(r9, r0)
            r9.f12295D = r10
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12255U0
            r10.<init>(r9, r0)
            r9.f12296E = r10
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12257V0
            r10.<init>(r9, r0)
            r9.f12297F = r10
            Z5.l r10 = new Z5.l
            Z5.a r0 = f12259W0
            r10.<init>(r9, r0)
            r9.f12298G = r10
            Z5.a r10 = f12261X0
            kotlin.jvm.internal.l.f(r10, r2)
            boolean r10 = r9.a(r10)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            R1.a.t(r10)
            Z5.a r10 = f12263Y0
            kotlin.jvm.internal.l.f(r10, r2)
            int r10 = r9.b(r10)
            V.p0 r0 = new V.p0
            r0.<init>(r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: Z5.e.<init>(android.content.ContextWrapper):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0039  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0025  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object i(Z5.g r14, Da.c r15) {
        /*
            r13 = this;
            boolean r0 = r15 instanceof Z5.d
            if (r0 == 0) goto L_0x0013
            r0 = r15
            Z5.d r0 = (Z5.d) r0
            int r1 = r0.f12217F
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L_0x0013
            int r1 = r1 - r2
            r0.f12217F = r1
            goto L_0x0018
        L_0x0013:
            Z5.d r0 = new Z5.d
            r0.<init>(r13, r15)
        L_0x0018:
            java.lang.Object r15 = r0.f12220z
            Ca.a r1 = Ca.a.f33640f
            int r2 = r0.f12217F
            Z5.a r3 = f12265Z0
            java.lang.String r4 = "RawAppPrefs"
            r5 = 1
            if (r2 == 0) goto L_0x0039
            if (r2 != r5) goto L_0x0031
            java.util.Iterator r14 = r0.f12219i
            Z5.g r2 = r0.f12218f
            xa.C4976p.b(r15)
            r11 = r0
            r6 = r2
            goto L_0x0094
        L_0x0031:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r15 = "call to 'resume' before 'invoke' with coroutine"
            r14.<init>(r15)
            throw r14
        L_0x0039:
            xa.C4976p.b(r15)
            boolean r15 = r13.a(r3)
            if (r15 == 0) goto L_0x004a
            java.lang.String r14 = "migration1: already migrated"
            android.util.Log.w(r4, r14)
            xa.D r14 = xa.C4959D.f44058a
            return r14
        L_0x004a:
            java.lang.String r15 = "migration1: start"
            android.util.Log.d(r4, r15)
            Z5.a r15 = f12274i0
            java.util.Set r15 = r13.e(r15)
            ya.w r2 = ya.w.f44687f
            if (r15 != 0) goto L_0x005a
            r15 = r2
        L_0x005a:
            N5.e r6 = N5.e.f6414f
            java.lang.String r6 = "ad-blocker"
            boolean r6 = r15.contains(r6)
            if (r6 == 0) goto L_0x0069
            Z5.a r6 = f12287v0
            r13.f(r6, r5)
        L_0x0069:
            java.lang.String r6 = "cookie-banner-blocker"
            boolean r6 = r15.contains(r6)
            if (r6 == 0) goto L_0x0076
            Z5.a r6 = f12288w0
            r13.f(r6, r5)
        L_0x0076:
            java.lang.String r6 = "smart-video-player"
            boolean r15 = r15.contains(r6)
            if (r15 == 0) goto L_0x0083
            Z5.a r15 = f12289x0
            r13.f(r15, r5)
        L_0x0083:
            Z5.a r15 = f12275j0
            java.util.Set r15 = r13.e(r15)
            if (r15 != 0) goto L_0x008c
            goto L_0x008d
        L_0x008c:
            r2 = r15
        L_0x008d:
            java.util.Iterator r15 = r2.iterator()
            r6 = r14
            r14 = r15
            r11 = r0
        L_0x0094:
            boolean r15 = r14.hasNext()
            if (r15 == 0) goto L_0x00ca
            java.lang.Object r15 = r14.next()
            r7 = r15
            java.lang.String r7 = (java.lang.String) r7
            java.lang.StringBuilder r15 = new java.lang.StringBuilder
            java.lang.String r0 = "migration1: host="
            r15.<init>(r0)
            r15.append(r7)
            java.lang.String r15 = r15.toString()
            android.util.Log.d(r4, r15)
            Z5.b$a r10 = new Z5.b$a
            java.lang.Boolean r15 = java.lang.Boolean.TRUE
            r10.<init>(r15)
            r11.f12218f = r6
            r11.f12219i = r14
            r11.f12217F = r5
            r9 = 0
            r12 = 1014(0x3f6, float:1.421E-42)
            r8 = 0
            java.lang.Object r15 = Z5.g.c(r6, r7, r8, r9, r10, r11, r12)
            if (r15 != r1) goto L_0x0094
            return r1
        L_0x00ca:
            r13.f(r3, r5)
            xa.D r14 = xa.C4959D.f44058a
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: Z5.e.i(Z5.g, Da.c):java.lang.Object");
    }
}
