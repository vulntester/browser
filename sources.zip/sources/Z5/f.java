package Z5;

import V.C1170i0;
import V.C1187r0;

public final class f implements C1170i0<Boolean> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C1187r0 f12323f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ e f12324i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ a f12325z;

    public f(C1187r0 r0Var, e eVar, a aVar) {
        this.f12323f = r0Var;
        this.f12324i = eVar;
        this.f12325z = aVar;
    }

    public final Object getValue() {
        return (Boolean) this.f12323f.getValue();
    }

    public final void setValue(Object obj) {
        Boolean bool = (Boolean) obj;
        this.f12324i.f(this.f12325z, bool.booleanValue());
        this.f12323f.setValue(bool);
    }
}
