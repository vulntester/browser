package Z5;

import Ba.h;
import Da.e;
import Da.i;
import Na.p;
import P5.I;
import Q5.f;
import ic.C4487C;
import ic.C4488D;
import ic.C4528y;
import ic.G;
import ic.U;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import kotlin.jvm.internal.l;
import nc.C4732d;
import pc.b;
import xa.C4959D;
import xa.C4976p;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public final I f12326a;

    /* renamed from: b  reason: collision with root package name */
    public final C4732d f12327b;

    /* renamed from: c  reason: collision with root package name */
    public final LinkedHashMap f12328c = new LinkedHashMap();

    @e(c = "com.common.components.repository.preferences.SiteSettings$1", f = "SiteSettings.kt", l = {}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ g f12329f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(g gVar, Ba.e<? super a> eVar) {
            super(2, eVar);
            this.f12329f = gVar;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new a(this.f12329f, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            C4976p.b(obj);
            g gVar = this.f12329f;
            ArrayList a10 = gVar.f12326a.a();
            l.f("init: " + a10.size(), "string");
            Iterator it = a10.iterator();
            while (it.hasNext()) {
                f fVar = (f) it.next();
                gVar.f12328c.put(k.a(fVar.f7796b), fVar);
            }
            return C4959D.f44058a;
        }
    }

    public g(I i10) {
        l.f(i10, "siteSettingsDao");
        this.f12326a = i10;
        U u7 = U.f41134a;
        C4732d a10 = C4488D.a(C4528y.limitedParallelism$default(b.f43037f, 1, (String) null, 2, (Object) null));
        this.f12327b = a10;
        G.y(a10, (h) null, new a(this, (Ba.e<? super a>) null), 3);
    }

    /* JADX WARNING: type inference failed for: r14v6, types: [Z5.b$b] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ java.lang.Object c(Z5.g r12, java.lang.String r13, Z5.b.a r14, Z5.b.a r15, Z5.b.a r16, Da.c r17, int r18) {
        /*
            r0 = r18 & 2
            if (r0 == 0) goto L_0x0006
            Z5.b$b r14 = Z5.b.C0123b.f12213a
        L_0x0006:
            r2 = r14
            r14 = r18 & 4
            if (r14 == 0) goto L_0x000f
            Z5.b$b r14 = Z5.b.C0123b.f12213a
            r3 = r14
            goto L_0x0010
        L_0x000f:
            r3 = r15
        L_0x0010:
            r14 = r18 & 8
            if (r14 == 0) goto L_0x0018
            Z5.b$b r14 = Z5.b.C0123b.f12213a
            r4 = r14
            goto L_0x001a
        L_0x0018:
            r4 = r16
        L_0x001a:
            Z5.b$b r5 = Z5.b.C0123b.f12213a
            r6 = r5
            r7 = r5
            r8 = r5
            r9 = r5
            r10 = r5
            r0 = r12
            r1 = r13
            r11 = r17
            java.lang.Object r12 = r0.b(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: Z5.g.c(Z5.g, java.lang.String, Z5.b$a, Z5.b$a, Z5.b$a, Da.c, int):java.lang.Object");
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v7, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v7, resolved type: Q5.f} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Q5.f a(java.lang.String r11) {
        /*
            r10 = this;
            java.lang.String r0 = "."
            java.lang.String[] r0 = new java.lang.String[]{r0}
            r1 = 0
            r2 = 6
            java.util.List r0 = fc.C4427q.o0(r11, r0, r1, r2)
            r2 = 2
            java.util.List r3 = ya.s.t0(r2, r0)
            r6 = 0
            r7 = 0
            java.lang.String r4 = "."
            r5 = 0
            r8 = 62
            java.lang.String r2 = ya.s.a0(r3, r4, r5, r6, r7, r8)
            r3 = 3
            java.util.List r4 = ya.s.t0(r3, r0)
            r8 = 0
            java.lang.String r5 = "."
            r9 = 62
            java.lang.String r0 = ya.s.a0(r4, r5, r6, r7, r8, r9)
            java.util.LinkedHashMap r3 = r10.f12328c
            java.lang.String r2 = Z5.k.a(r2)
            java.lang.Object r2 = r3.get(r2)
            Q5.f r2 = (Q5.f) r2
            if (r2 != 0) goto L_0x0043
            java.lang.String r0 = Z5.k.a(r0)
            java.lang.Object r0 = r3.get(r0)
            r2 = r0
            Q5.f r2 = (Q5.f) r2
        L_0x0043:
            java.lang.String r0 = "getSiteSettingCached: "
            java.lang.String r3 = " , found: "
            java.lang.StringBuilder r11 = M.k.o(r0, r11, r3)
            if (r2 == 0) goto L_0x004e
            r1 = 1
        L_0x004e:
            r11.append(r1)
            java.lang.String r11 = r11.toString()
            java.lang.String r0 = "string"
            kotlin.jvm.internal.l.f(r11, r0)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: Z5.g.a(java.lang.String):Q5.f");
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0059  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x00d6  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x014d  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x002b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object b(java.lang.String r24, Z5.b r25, Z5.b r26, Z5.b r27, Z5.b r28, Z5.b r29, Z5.b r30, Z5.b r31, Z5.b r32, Z5.b r33, Da.c r34) {
        /*
            r23 = this;
            r0 = r23
            r1 = r24
            r2 = r34
            boolean r3 = r2 instanceof Z5.j
            if (r3 == 0) goto L_0x0019
            r3 = r2
            Z5.j r3 = (Z5.j) r3
            int r4 = r3.f12347N
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            r6 = r4 & r5
            if (r6 == 0) goto L_0x0019
            int r4 = r4 - r5
            r3.f12347N = r4
            goto L_0x001e
        L_0x0019:
            Z5.j r3 = new Z5.j
            r3.<init>(r0, r2)
        L_0x001e:
            java.lang.Object r2 = r3.f12345L
            Ca.a r4 = Ca.a.f33640f
            int r5 = r3.f12347N
            r6 = 1
            P5.I r7 = r0.f12326a
            java.lang.String r8 = "string"
            if (r5 == 0) goto L_0x0059
            if (r5 != r6) goto L_0x0051
            Z5.b r1 = r3.f12344K
            Z5.b r4 = r3.f12343J
            Z5.b r5 = r3.f12342I
            Z5.b r6 = r3.f12341H
            Z5.b r9 = r3.f12340G
            Z5.b r10 = r3.f12339F
            Z5.b r11 = r3.f12338E
            Z5.b r12 = r3.f12350z
            Z5.b r13 = r3.f12349i
            java.lang.String r3 = r3.f12348f
            xa.C4976p.b(r2)
            r0 = r10
            r10 = r1
            r1 = r0
            r0 = r11
            r11 = r3
            r3 = r9
            r9 = r4
            r4 = r5
            r5 = r12
            r12 = r2
            r2 = r13
            goto L_0x00d2
        L_0x0051:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            r1.<init>(r2)
            throw r1
        L_0x0059:
            xa.C4976p.b(r2)
            r3.f12348f = r1
            r2 = r25
            r3.f12349i = r2
            r5 = r26
            r3.f12350z = r5
            r9 = r27
            r3.f12338E = r9
            r10 = r28
            r3.f12339F = r10
            r11 = r29
            r3.f12340G = r11
            r12 = r30
            r3.f12341H = r12
            r13 = r31
            r3.f12342I = r13
            r14 = r32
            r3.f12343J = r14
            r15 = r33
            r3.f12344K = r15
            r3.f12347N = r6
            java.lang.String r3 = "www."
            r6 = 0
            boolean r3 = fc.C4425o.R(r1, r3, r6)
            java.lang.String r6 = "substring(...)"
            if (r3 == 0) goto L_0x0098
            r3 = 4
            java.lang.String r3 = r1.substring(r3)
            kotlin.jvm.internal.l.e(r3, r6)
            goto L_0x00ab
        L_0x0098:
            java.lang.String r3 = "m."
            r0 = 0
            boolean r0 = fc.C4425o.R(r1, r3, r0)
            if (r0 == 0) goto L_0x00aa
            r0 = 2
            java.lang.String r3 = r1.substring(r0)
            kotlin.jvm.internal.l.e(r3, r6)
            goto L_0x00ab
        L_0x00aa:
            r3 = r1
        L_0x00ab:
            java.lang.String r0 = "%"
            java.lang.String r0 = r0.concat(r3)
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r6 = "getSiteSetting: "
            r3.<init>(r6)
            r3.append(r0)
            java.lang.String r3 = r3.toString()
            kotlin.jvm.internal.l.f(r3, r8)
            Q5.f r0 = r7.e(r0)
            if (r0 != r4) goto L_0x00c9
            return r4
        L_0x00c9:
            r3 = r11
            r6 = r12
            r4 = r13
            r12 = r0
            r11 = r1
            r0 = r9
            r1 = r10
            r9 = r14
            r10 = r15
        L_0x00d2:
            Q5.f r12 = (Q5.f) r12
            if (r12 == 0) goto L_0x014d
            java.lang.Integer r11 = r12.f7797c
            java.lang.Object r2 = Z5.k.b(r2, r11)
            java.lang.Integer r2 = (java.lang.Integer) r2
            r12.f7797c = r2
            java.lang.String r2 = r12.f7798d
            L5.e r2 = L5.f.a(r2)
            java.lang.Object r2 = Z5.k.b(r5, r2)
            L5.e r2 = (L5.e) r2
            java.lang.String r2 = L5.f.b(r2)
            r12.f7798d = r2
            java.lang.Boolean r2 = r12.f7799e
            java.lang.Object r0 = Z5.k.b(r0, r2)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r12.f7799e = r0
            java.lang.Boolean r0 = r12.f7800f
            java.lang.Object r0 = Z5.k.b(r1, r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r12.f7800f = r0
            java.lang.Boolean r0 = r12.f7801g
            java.lang.Object r0 = Z5.k.b(r3, r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r12.f7801g = r0
            java.lang.Boolean r0 = r12.f7802h
            java.lang.Object r0 = Z5.k.b(r6, r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r12.f7802h = r0
            java.lang.Boolean r0 = r12.f7803i
            java.lang.Object r0 = Z5.k.b(r4, r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r12.f7803i = r0
            java.lang.Boolean r0 = r12.f7804j
            java.lang.Object r0 = Z5.k.b(r9, r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r12.f7804j = r0
            java.lang.Boolean r0 = r12.f7805k
            java.lang.Object r0 = Z5.k.b(r10, r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r12.f7805k = r0
            r7.b(r12)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "upsertSiteConfig: update "
            r0.<init>(r1)
            r0.append(r12)
            java.lang.String r0 = r0.toString()
            kotlin.jvm.internal.l.f(r0, r8)
            return r12
        L_0x014d:
            r14 = r9
            Q5.f r9 = new Q5.f
            r19 = 0
            r20 = 0
            r15 = r10
            r10 = 0
            r12 = 0
            r13 = 0
            r16 = r14
            r14 = 0
            r17 = r15
            r15 = 0
            r18 = r16
            r16 = 0
            r21 = r17
            r17 = 0
            r22 = r18
            r18 = 0
            r34 = r21
            r21 = r7
            r7 = r34
            r34 = r8
            r8 = r22
            r9.<init>(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20)
            r10 = 0
            java.lang.Object r2 = Z5.k.b(r2, r10)
            java.lang.Integer r2 = (java.lang.Integer) r2
            r9.f7797c = r2
            java.lang.Object r2 = Z5.k.b(r5, r10)
            L5.e r2 = (L5.e) r2
            java.lang.String r2 = L5.f.b(r2)
            r9.f7798d = r2
            java.lang.Object r0 = Z5.k.b(r0, r10)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r9.f7799e = r0
            java.lang.Object r0 = Z5.k.b(r1, r10)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r9.f7800f = r0
            java.lang.Object r0 = Z5.k.b(r3, r10)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r9.f7801g = r0
            java.lang.Object r0 = Z5.k.b(r6, r10)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r9.f7802h = r0
            java.lang.Object r0 = Z5.k.b(r4, r10)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r9.f7803i = r0
            java.lang.Object r0 = Z5.k.b(r8, r10)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r9.f7804j = r0
            java.lang.Object r0 = Z5.k.b(r7, r10)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            r9.f7805k = r0
            r0 = r21
            long r0 = r0.d(r9)
            int r0 = (int) r0
            r9.f7795a = r0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "upsertSiteConfig: inserted "
            r0.<init>(r1)
            r0.append(r9)
            java.lang.String r0 = r0.toString()
            r1 = r34
            kotlin.jvm.internal.l.f(r0, r1)
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: Z5.g.b(java.lang.String, Z5.b, Z5.b, Z5.b, Z5.b, Z5.b, Z5.b, Z5.b, Z5.b, Z5.b, Da.c):java.lang.Object");
    }
}
