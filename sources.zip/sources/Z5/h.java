package Z5;

import Ca.a;
import Da.e;
import Da.i;
import Na.p;
import Q5.f;
import Z5.b;
import ic.C4487C;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.common.components.repository.preferences.SiteSettings$setViewportModePerHost$1", f = "SiteSettings.kt", l = {69}, m = "invokeSuspend")
public final class h extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ L5.e f12330E;

    /* renamed from: f  reason: collision with root package name */
    public int f12331f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ g f12332i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ String f12333z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public h(g gVar, String str, L5.e eVar, Ba.e<? super h> eVar2) {
        super(2, eVar2);
        this.f12332i = gVar;
        this.f12333z = str;
        this.f12330E = eVar;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new h(this.f12332i, this.f12333z, this.f12330E, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((h) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        h hVar;
        a aVar = a.f33640f;
        int i10 = this.f12331f;
        String str = this.f12333z;
        if (i10 == 0) {
            C4976p.b(obj);
            b.a aVar2 = new b.a(this.f12330E);
            this.f12331f = 1;
            hVar = this;
            obj = g.c(this.f12332i, str, (b.a) null, aVar2, (b.a) null, hVar, 1018);
            if (obj == aVar) {
                return aVar;
            }
        } else if (i10 == 1) {
            C4976p.b(obj);
            hVar = this;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        hVar.f12332i.f12328c.put(k.a(str), (f) obj);
        return C4959D.f44058a;
    }
}
