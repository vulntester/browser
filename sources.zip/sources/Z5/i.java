package Z5;

import Ca.a;
import Da.e;
import Na.p;
import Q5.f;
import Z5.b;
import ic.C4487C;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.common.components.repository.preferences.SiteSettings$setZoomLevelPerHost$1", f = "SiteSettings.kt", l = {62}, m = "invokeSuspend")
public final class i extends Da.i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ int f12334E;

    /* renamed from: f  reason: collision with root package name */
    public int f12335f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ g f12336i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ String f12337z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public i(g gVar, String str, int i10, Ba.e<? super i> eVar) {
        super(2, eVar);
        this.f12336i = gVar;
        this.f12337z = str;
        this.f12334E = i10;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new i(this.f12336i, this.f12337z, this.f12334E, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((i) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        i iVar;
        a aVar = a.f33640f;
        int i10 = this.f12335f;
        if (i10 == 0) {
            C4976p.b(obj);
            b.a aVar2 = new b.a(new Integer(this.f12334E));
            this.f12335f = 1;
            iVar = this;
            obj = g.c(this.f12336i, this.f12337z, aVar2, (b.a) null, (b.a) null, iVar, 1020);
            if (obj == aVar) {
                return aVar;
            }
        } else if (i10 == 1) {
            C4976p.b(obj);
            iVar = this;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        iVar.f12336i.f12328c.put(k.a(iVar.f12337z), (f) obj);
        return C4959D.f44058a;
    }
}
