package Z5;

import Da.c;
import Da.e;

@e(c = "com.common.components.repository.preferences.SiteSettings", f = "SiteSettings.kt", l = {115}, m = "upsertSiteConfig")
public final class j extends c {

    /* renamed from: E  reason: collision with root package name */
    public b f12338E;

    /* renamed from: F  reason: collision with root package name */
    public b f12339F;

    /* renamed from: G  reason: collision with root package name */
    public b f12340G;

    /* renamed from: H  reason: collision with root package name */
    public b f12341H;

    /* renamed from: I  reason: collision with root package name */
    public b f12342I;

    /* renamed from: J  reason: collision with root package name */
    public b f12343J;

    /* renamed from: K  reason: collision with root package name */
    public b f12344K;

    /* renamed from: L  reason: collision with root package name */
    public /* synthetic */ Object f12345L;

    /* renamed from: M  reason: collision with root package name */
    public final /* synthetic */ g f12346M;

    /* renamed from: N  reason: collision with root package name */
    public int f12347N;

    /* renamed from: f  reason: collision with root package name */
    public String f12348f;

    /* renamed from: i  reason: collision with root package name */
    public b f12349i;

    /* renamed from: z  reason: collision with root package name */
    public b f12350z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j(g gVar, c cVar) {
        super(cVar);
        this.f12346M = gVar;
    }

    public final Object invokeSuspend(Object obj) {
        this.f12345L = obj;
        this.f12347N |= Integer.MIN_VALUE;
        return this.f12346M.b((String) null, (b) null, (b) null, (b) null, (b) null, (b) null, (b) null, (b) null, (b) null, (b) null, this);
    }
}
