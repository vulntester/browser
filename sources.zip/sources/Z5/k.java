package Z5;

import Z5.b;
import fc.C4427q;
import kotlin.jvm.internal.l;
import ya.s;

public final class k {
    public static final String a(String str) {
        l.f(str, "host");
        return s.a0(s.t0(3, C4427q.o0(str, new String[]{"."}, 0, 6)), ".", (String) null, (String) null, (Na.l) null, 62);
    }

    public static final <T> T b(b<? extends T> bVar, T t10) {
        l.f(bVar, "<this>");
        if (bVar instanceof b.a) {
            return ((b.a) bVar).f12212a;
        }
        return t10;
    }
}
