package Z5;

import Da.e;
import Da.i;
import Na.p;
import V.C1187r0;
import ic.C4487C;
import ic.G;
import ic.U;
import xa.C4959D;
import xa.C4976p;

public final class l {

    /* renamed from: a  reason: collision with root package name */
    public final e f12351a;

    /* renamed from: b  reason: collision with root package name */
    public final a f12352b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f12353c;

    /* renamed from: d  reason: collision with root package name */
    public final C1187r0 f12354d;

    /* renamed from: e  reason: collision with root package name */
    public final C1187r0 f12355e;

    @e(c = "com.common.components.repository.preferences.StoredBoolState$set$1", f = "MutableStatePrefs.kt", l = {}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ l f12356f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ boolean f12357i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(l lVar, boolean z10, Ba.e<? super a> eVar) {
            super(2, eVar);
            this.f12356f = lVar;
            this.f12357i = z10;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new a(this.f12356f, this.f12357i, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            C4976p.b(obj);
            this.f12356f.f12354d.setValue(Boolean.valueOf(this.f12357i));
            return C4959D.f44058a;
        }
    }

    public l(e eVar, a aVar) {
        kotlin.jvm.internal.l.f(aVar, "pref");
        this.f12351a = eVar;
        this.f12352b = aVar;
        boolean a10 = eVar.a(aVar);
        this.f12353c = a10;
        C1187r0 t10 = R1.a.t(Boolean.valueOf(a10));
        this.f12354d = t10;
        this.f12355e = t10;
    }

    public final void a(boolean z10) {
        this.f12353c = z10;
        e eVar = this.f12351a;
        eVar.f(this.f12352b, z10);
        U u7 = U.f41134a;
        G.y(eVar.f12215b, nc.p.f42446a, new a(this, z10, (Ba.e<? super a>) null), 2);
    }

    public final boolean b() {
        boolean z10 = !((Boolean) this.f12355e.getValue()).booleanValue();
        a(z10);
        return z10;
    }
}
