package Z5;

import Da.e;
import Da.i;
import Na.p;
import V.C1184p0;
import ic.C4487C;
import ic.G;
import ic.U;
import kotlin.jvm.internal.l;
import xa.C4959D;
import xa.C4976p;

public final class m {

    /* renamed from: a  reason: collision with root package name */
    public final e f12358a;

    /* renamed from: b  reason: collision with root package name */
    public final a f12359b;

    /* renamed from: c  reason: collision with root package name */
    public final C1184p0 f12360c;

    /* renamed from: d  reason: collision with root package name */
    public final C1184p0 f12361d;

    @e(c = "com.common.components.repository.preferences.StoredIntState$set$1", f = "MutableStatePrefs.kt", l = {}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ m f12362f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ int f12363i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(m mVar, int i10, Ba.e<? super a> eVar) {
            super(2, eVar);
            this.f12362f = mVar;
            this.f12363i = i10;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new a(this.f12362f, this.f12363i, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            C4976p.b(obj);
            this.f12362f.f12360c.j(this.f12363i);
            return C4959D.f44058a;
        }
    }

    public m(e eVar, a aVar, int i10) {
        l.f(aVar, "pref");
        this.f12358a = eVar;
        this.f12359b = aVar;
        C1184p0 p0Var = new C1184p0(eVar.b(aVar));
        this.f12360c = p0Var;
        this.f12361d = p0Var;
    }

    public final void a(int i10) {
        e eVar = this.f12358a;
        eVar.g(this.f12359b, i10);
        U u7 = U.f41134a;
        G.y(eVar.f12215b, nc.p.f42446a, new a(this, i10, (Ba.e<? super a>) null), 2);
    }
}
