package Z5;

import Da.e;
import Da.i;
import Na.p;
import O8.a;
import V.C1186q0;
import ic.C4487C;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.common.components.repository.preferences.StoredLongState$set$1", f = "MutableStatePrefs.kt", l = {}, m = "invokeSuspend")
public final class n extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ a f12364f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ long f12365i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public n(a aVar, long j10, Ba.e<? super n> eVar) {
        super(2, eVar);
        this.f12364f = aVar;
        this.f12365i = j10;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new n(this.f12364f, this.f12365i, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((n) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        Ca.a aVar = Ca.a.f33640f;
        C4976p.b(obj);
        ((C1186q0) this.f12364f.f37241c).l(this.f12365i);
        return C4959D.f44058a;
    }
}
