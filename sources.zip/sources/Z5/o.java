package Z5;

import Da.e;
import Da.i;
import Na.p;
import V.C1187r0;
import ic.C4487C;
import ic.G;
import ic.U;
import kotlin.jvm.internal.l;
import xa.C4959D;
import xa.C4976p;

public final class o {

    /* renamed from: a  reason: collision with root package name */
    public final e f12366a;

    /* renamed from: b  reason: collision with root package name */
    public final a f12367b;

    /* renamed from: c  reason: collision with root package name */
    public final C1187r0 f12368c;

    /* renamed from: d  reason: collision with root package name */
    public final C1187r0 f12369d;

    @e(c = "com.common.components.repository.preferences.StoredNullableStringState$set$1", f = "MutableStatePrefs.kt", l = {}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ o f12370f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ String f12371i;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(o oVar, String str, Ba.e<? super a> eVar) {
            super(2, eVar);
            this.f12370f = oVar;
            this.f12371i = str;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new a(this.f12370f, this.f12371i, eVar);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            C4976p.b(obj);
            this.f12370f.f12368c.setValue(this.f12371i);
            return C4959D.f44058a;
        }
    }

    public o(e eVar, a aVar) {
        l.f(aVar, "pref");
        this.f12366a = eVar;
        this.f12367b = aVar;
        C1187r0 t10 = R1.a.t(eVar.c(aVar));
        this.f12368c = t10;
        this.f12369d = t10;
    }

    public final void a(String str) {
        e eVar = this.f12366a;
        a aVar = this.f12367b;
        l.f(aVar, "key");
        eVar.f12214a.edit().putString((String) aVar.f12210f, str).apply();
        U u7 = U.f41134a;
        G.y(eVar.f12215b, nc.p.f42446a, new a(this, str, (Ba.e<? super a>) null), 2);
    }
}
