package Z5;

import B9.H0;
import B9.O;
import Y1.N;
import kotlin.jvm.internal.l;

public final class p extends N {

    /* renamed from: e  reason: collision with root package name */
    public final e f12372e;

    /* renamed from: f  reason: collision with root package name */
    public final a f12373f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public p(e eVar, a aVar) {
        super(aVar, new O(3, eVar, aVar), new H0(3, eVar, aVar));
        l.f(eVar, "prefs");
        l.f(aVar, "pref");
        this.f12372e = eVar;
        this.f12373f = aVar;
    }
}
