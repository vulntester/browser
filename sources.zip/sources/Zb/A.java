package Zb;

import Na.l;
import Zb.y;
import ab.k;

public final class A implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final A f38987f = new Object();

    public final Object invoke(Object obj) {
        k kVar = (k) obj;
        y.c cVar = y.c.f39059c;
        kotlin.jvm.internal.l.f(kVar, "<this>");
        return kVar.v();
    }
}
