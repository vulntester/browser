package Zb;

import Zb.f;
import ob.e;

public abstract class B implements f {

    /* renamed from: a  reason: collision with root package name */
    public final String f38988a;

    public static final class a extends B {

        /* renamed from: b  reason: collision with root package name */
        public final int f38989b;

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public a(int r3) {
            /*
                r2 = this;
                java.lang.String r0 = "must have at least "
                java.lang.String r1 = " value parameter"
                java.lang.StringBuilder r0 = D1.b.m(r3, r0, r1)
                r1 = 1
                if (r3 <= r1) goto L_0x000e
                java.lang.String r1 = "s"
                goto L_0x0010
            L_0x000e:
                java.lang.String r1 = ""
            L_0x0010:
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                r2.<init>(r0)
                r2.f38989b = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: Zb.B.a.<init>(int):void");
        }

        public final boolean b(e eVar) {
            if (eVar.g().size() >= this.f38989b) {
                return true;
            }
            return false;
        }
    }

    public static final class b extends B {

        /* renamed from: b  reason: collision with root package name */
        public final int f38990b = 2;

        public b() {
            super("must have exactly 2 value parameters");
        }

        public final boolean b(e eVar) {
            if (eVar.g().size() == this.f38990b) {
                return true;
            }
            return false;
        }
    }

    public static final class c extends B {

        /* renamed from: b  reason: collision with root package name */
        public static final c f38991b = new B("must have no value parameters");

        public final boolean b(e eVar) {
            return eVar.g().isEmpty();
        }
    }

    public static final class d extends B {

        /* renamed from: b  reason: collision with root package name */
        public static final d f38992b = new B("must have a single value parameter");

        public final boolean b(e eVar) {
            if (eVar.g().size() == 1) {
                return true;
            }
            return false;
        }
    }

    public B(String str) {
        this.f38988a = str;
    }

    public final String a(e eVar) {
        return f.a.a(this, eVar);
    }

    public final String getDescription() {
        return this.f38988a;
    }
}
