package Zb;

import Oa.a;
import java.util.Iterator;

/* renamed from: Zb.a  reason: case insensitive filesystem */
public abstract class C4194a<K, V> implements Iterable<V>, a {

    /* renamed from: Zb.a$a  reason: collision with other inner class name */
    public static abstract class C0373a<K, V, T extends V> {

        /* renamed from: f  reason: collision with root package name */
        public final int f38993f;

        public C0373a(int i10) {
            this.f38993f = i10;
        }
    }

    public abstract c<V> a();

    public final boolean isEmpty() {
        if (((e) this).f38998f.a() == 0) {
            return true;
        }
        return false;
    }

    public final Iterator<V> iterator() {
        return a().iterator();
    }
}
