package Zb;

/* renamed from: Zb.b  reason: case insensitive filesystem */
public abstract class C4195b {
}
