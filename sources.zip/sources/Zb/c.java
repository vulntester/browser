package Zb;

import Oa.a;
import Tb.U;
import java.util.Iterator;

public abstract class c<T> implements Iterable<T>, a {
    public abstract int a();

    public abstract void c(int i10, U u7);

    public abstract T get(int i10);

    public abstract Iterator<T> iterator();
}
