package Zb;

import Tb.U;
import java.util.Arrays;
import java.util.Iterator;
import kotlin.jvm.internal.l;
import ya.C5012b;

public final class d<T> extends c<T> {

    /* renamed from: f  reason: collision with root package name */
    public Object[] f38994f;

    /* renamed from: i  reason: collision with root package name */
    public int f38995i;

    public static final class a extends C5012b<T> {

        /* renamed from: E  reason: collision with root package name */
        public final /* synthetic */ d<T> f38996E;

        /* renamed from: z  reason: collision with root package name */
        public int f38997z = -1;

        public a(d<T> dVar) {
            this.f38996E = dVar;
        }
    }

    public final int a() {
        return this.f38995i;
    }

    public final void c(int i10, U u7) {
        l.f(u7, "value");
        Object[] objArr = this.f38994f;
        if (objArr.length <= i10) {
            int length = objArr.length;
            do {
                length *= 2;
            } while (length <= i10);
            Object[] copyOf = Arrays.copyOf(this.f38994f, length);
            l.e(copyOf, "copyOf(...)");
            this.f38994f = copyOf;
        }
        Object[] objArr2 = this.f38994f;
        if (objArr2[i10] == null) {
            this.f38995i++;
        }
        objArr2[i10] = u7;
    }

    public final T get(int i10) {
        T[] tArr = this.f38994f;
        l.f(tArr, "<this>");
        if (i10 < 0 || i10 >= tArr.length) {
            return null;
        }
        return tArr[i10];
    }

    public final Iterator<T> iterator() {
        return new a(this);
    }
}
