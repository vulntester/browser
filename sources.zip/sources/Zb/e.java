package Zb;

public abstract class e<K, T> extends C4194a<K, T> {

    /* renamed from: f  reason: collision with root package name */
    public c<T> f38998f;

    public final c<T> a() {
        return this.f38998f;
    }
}
