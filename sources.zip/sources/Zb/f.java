package Zb;

import ob.e;

public interface f {

    public static final class a {
        public static String a(f fVar, e eVar) {
            if (!fVar.b(eVar)) {
                return fVar.getDescription();
            }
            return null;
        }
    }

    String a(e eVar);

    boolean b(e eVar);

    String getDescription();
}
