package Zb;

public abstract class g {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f38999a;

    public static final class a extends g {

        /* renamed from: b  reason: collision with root package name */
        public static final a f39000b = new g(false);
    }

    public static final class b extends g {
    }

    public static final class c extends g {

        /* renamed from: b  reason: collision with root package name */
        public static final c f39001b = new g(true);
    }

    public g(boolean z10) {
        this.f38999a = z10;
    }
}
