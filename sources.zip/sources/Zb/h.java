package Zb;

import Na.l;
import db.C4333w;

public final class h implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final h f39002f = new Object();

    public final Object invoke(Object obj) {
        kotlin.jvm.internal.l.f((C4333w) obj, "<this>");
        return null;
    }
}
