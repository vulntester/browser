package Zb;

import Na.l;
import db.C4333w;

public final class j implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final j f39004f = new Object();

    public final Object invoke(Object obj) {
        kotlin.jvm.internal.l.f((C4333w) obj, "<this>");
        return null;
    }
}
