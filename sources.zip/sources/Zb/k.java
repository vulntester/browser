package Zb;

import Cb.f;
import Na.l;
import db.C4333w;
import fc.C4419i;
import io.ktor.http.ContentDisposition;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    public final f f39005a;

    /* renamed from: b  reason: collision with root package name */
    public final C4419i f39006b;

    /* renamed from: c  reason: collision with root package name */
    public final Collection<f> f39007c;

    /* renamed from: d  reason: collision with root package name */
    public final l<C4333w, String> f39008d;

    /* renamed from: e  reason: collision with root package name */
    public final f[] f39009e;

    public k() {
        throw null;
    }

    public k(f fVar, C4419i iVar, Collection<f> collection, l<? super C4333w, String> lVar, f... fVarArr) {
        this.f39005a = fVar;
        this.f39006b = iVar;
        this.f39007c = collection;
        this.f39008d = lVar;
        this.f39009e = fVarArr;
    }

    public /* synthetic */ k(f fVar, f[] fVarArr) {
        this(fVar, fVarArr, (l<? super C4333w, String>) h.f39002f);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public k(f fVar, f[] fVarArr, l<? super C4333w, String> lVar) {
        this(fVar, (C4419i) null, (Collection<f>) null, lVar, (f[]) Arrays.copyOf(fVarArr, fVarArr.length));
        kotlin.jvm.internal.l.f(fVar, ContentDisposition.Parameters.Name);
    }

    public /* synthetic */ k(Set set, f[] fVarArr) {
        this((Collection<f>) set, fVarArr, (l<? super C4333w, String>) j.f39004f);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public k(Collection<f> collection, f[] fVarArr, l<? super C4333w, String> lVar) {
        this((f) null, (C4419i) null, collection, lVar, (f[]) Arrays.copyOf(fVarArr, fVarArr.length));
        kotlin.jvm.internal.l.f(collection, "nameList");
    }
}
