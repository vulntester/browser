package Zb;

import Tb.U;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class l extends c {

    /* renamed from: f  reason: collision with root package name */
    public static final l f39010f = new c();

    public static final class a implements Iterator, Oa.a {
        public final boolean hasNext() {
            return false;
        }

        public final Object next() {
            throw new NoSuchElementException();
        }

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public final int a() {
        return 0;
    }

    public final void c(int i10, U u7) {
        Void voidR = (Void) u7;
        throw new IllegalStateException();
    }

    public final /* bridge */ /* synthetic */ Object get(int i10) {
        return null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [java.util.Iterator, java.lang.Object] */
    public final Iterator iterator() {
        return new Object();
    }
}
