package Zb;

import Jb.d;
import Tb.C;
import Tb.C4154z;
import Tb.H;
import Tb.N;
import Tb.W;
import Tb.l0;
import Zb.f;
import ab.n;
import ab.o;
import db.C4291E;
import db.C4315e;
import db.C4332v;
import db.c0;
import db.h0;
import f7.M;
import java.util.List;
import kotlin.jvm.internal.l;
import ob.e;
import ya.s;

public final class m implements f {

    /* renamed from: a  reason: collision with root package name */
    public static final m f39011a = new Object();

    public final String a(e eVar) {
        return f.a.a(this, eVar);
    }

    public final boolean b(e eVar) {
        H h10;
        h0 h0Var = eVar.g().get(1);
        n.b bVar = n.f39157d;
        l.c(h0Var);
        C4291E j10 = d.j(h0Var);
        bVar.getClass();
        C4315e a10 = C4332v.a(j10, o.a.f39196R);
        if (a10 == null) {
            h10 = null;
        } else {
            W.f38074i.getClass();
            W w10 = W.f38075z;
            List<c0> parameters = a10.h().getParameters();
            l.e(parameters, "getParameters(...)");
            Object m02 = s.m0(parameters);
            l.e(m02, "single(...)");
            h10 = C.b(w10, a10, M.s(new N((c0) m02)));
        }
        if (h10 == null) {
            return false;
        }
        C4154z type = h0Var.getType();
        l.e(type, "getType(...)");
        return A.o.S(h10, l0.g(type, false));
    }

    public final String getDescription() {
        return "second parameter must be of type KProperty<*> or its supertype";
    }
}
