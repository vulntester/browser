package Zb;

import Zb.f;
import ob.e;

public abstract class n implements f {

    /* renamed from: a  reason: collision with root package name */
    public final String f39012a;

    public static final class a extends n {

        /* renamed from: b  reason: collision with root package name */
        public static final a f39013b = new n("must be a member function");

        public final boolean b(e eVar) {
            if (eVar.f40916L != null) {
                return true;
            }
            return false;
        }
    }

    public static final class b extends n {

        /* renamed from: b  reason: collision with root package name */
        public static final b f39014b = new n("must be a member or an extension function");

        public final boolean b(e eVar) {
            if (eVar.f40916L == null && eVar.f40915K == null) {
                return false;
            }
            return true;
        }
    }

    public n(String str) {
        this.f39012a = str;
    }

    public final String a(e eVar) {
        return f.a.a(this, eVar);
    }

    public final String getDescription() {
        return this.f39012a;
    }
}
