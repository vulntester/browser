package Zb;

import db.C4321k;
import db.C4325o;
import kotlin.jvm.internal.l;

public interface o {

    public static final class a implements o {

        /* renamed from: a  reason: collision with root package name */
        public static final a f39015a = new Object();

        public final void a(C4325o oVar, C4321k kVar) {
            l.f(kVar, "from");
        }
    }

    void a(C4325o oVar, C4321k kVar);
}
