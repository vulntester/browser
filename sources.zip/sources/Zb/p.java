package Zb;

import Zb.f;
import ob.e;

public final class p implements f {

    /* renamed from: a  reason: collision with root package name */
    public static final p f39016a = new Object();

    public final String a(e eVar) {
        return f.a.a(this, eVar);
    }

    /* JADX WARNING: Removed duplicated region for block: B:5:0x001a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(ob.e r3) {
        /*
            r2 = this;
            java.util.List r3 = r3.g()
            java.lang.String r0 = "getValueParameters(...)"
            kotlin.jvm.internal.l.e(r3, r0)
            boolean r0 = r3.isEmpty()
            if (r0 == 0) goto L_0x0010
            goto L_0x0032
        L_0x0010:
            java.util.Iterator r3 = r3.iterator()
        L_0x0014:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L_0x0032
            java.lang.Object r0 = r3.next()
            db.h0 r0 = (db.h0) r0
            kotlin.jvm.internal.l.c(r0)
            boolean r1 = Jb.d.a(r0)
            if (r1 != 0) goto L_0x0030
            Tb.z r0 = r0.g0()
            if (r0 != 0) goto L_0x0030
            goto L_0x0014
        L_0x0030:
            r3 = 0
            return r3
        L_0x0032:
            r3 = 1
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: Zb.p.b(ob.e):boolean");
    }

    public final String getDescription() {
        return "should not have varargs or parameters with default values";
    }
}
