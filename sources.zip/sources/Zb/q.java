package Zb;

import Qa.b;
import Ua.l;
import Zb.C4194a;

public final class q<K, V, T extends V> extends C4194a.C0373a<K, V, T> implements b<C4194a<K, V>, V> {
    public final Object getValue(Object obj, l lVar) {
        C4194a aVar = (C4194a) obj;
        kotlin.jvm.internal.l.f(aVar, "thisRef");
        kotlin.jvm.internal.l.f(lVar, "property");
        return aVar.a().get(this.f38993f);
    }
}
