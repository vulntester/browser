package Zb;

import Tb.U;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class r<T> extends c<T> {

    /* renamed from: f  reason: collision with root package name */
    public final U f39017f;

    /* renamed from: i  reason: collision with root package name */
    public final int f39018i;

    public static final class a implements Iterator<T>, Oa.a {

        /* renamed from: f  reason: collision with root package name */
        public boolean f39019f = true;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ r<T> f39020i;

        public a(r<T> rVar) {
            this.f39020i = rVar;
        }

        public final boolean hasNext() {
            return this.f39019f;
        }

        public final T next() {
            if (this.f39019f) {
                this.f39019f = false;
                return this.f39020i.f39017f;
            }
            throw new NoSuchElementException();
        }

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public r(int i10, U u7) {
        this.f39017f = u7;
        this.f39018i = i10;
    }

    public final int a() {
        return 1;
    }

    public final void c(int i10, U u7) {
        throw new IllegalStateException();
    }

    public final T get(int i10) {
        if (i10 == this.f39018i) {
            return this.f39017f;
        }
        return null;
    }

    public final Iterator<T> iterator() {
        return new a(this);
    }
}
