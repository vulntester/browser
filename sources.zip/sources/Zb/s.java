package Zb;

import Jb.d;
import Na.l;
import db.C4333w;
import db.h0;
import java.util.List;

public final class s implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final s f39021f = new Object();

    public final Object invoke(Object obj) {
        C4333w wVar = (C4333w) obj;
        v vVar = v.f39024a;
        kotlin.jvm.internal.l.f(wVar, "$this$Checks");
        List<h0> g6 = wVar.g();
        kotlin.jvm.internal.l.e(g6, "getValueParameters(...)");
        h0 h0Var = (h0) ya.s.d0(g6);
        if (h0Var == null || d.a(h0Var) || h0Var.g0() != null) {
            return "last parameter should not have a default value or be a vararg";
        }
        return null;
    }
}
