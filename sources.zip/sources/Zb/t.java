package Zb;

import Na.l;

public final class t implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final t f39022f = new Object();

    /* JADX WARNING: Code restructure failed: missing block: B:46:0x00e4, code lost:
        if (r9.h0() == null) goto L_0x0139;
     */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x002a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invoke(java.lang.Object r9) {
        /*
            r8 = this;
            db.w r9 = (db.C4333w) r9
            Zb.v r0 = Zb.v.f39024a
            java.lang.String r0 = "$this$Checks"
            kotlin.jvm.internal.l.f(r9, r0)
            db.k r0 = r9.d()
            java.lang.String r1 = "getContainingDeclaration(...)"
            kotlin.jvm.internal.l.e(r0, r1)
            boolean r2 = r0 instanceof db.C4315e
            r3 = 0
            r4 = 1
            if (r2 == 0) goto L_0x0026
            db.e r0 = (db.C4315e) r0
            Cb.f r2 = ab.k.f39134e
            Cb.d r2 = ab.o.a.f39205a
            boolean r0 = ab.k.b(r0, r2)
            if (r0 == 0) goto L_0x0026
            r0 = r4
            goto L_0x0027
        L_0x0026:
            r0 = r3
        L_0x0027:
            r2 = 0
            if (r0 != 0) goto L_0x0139
            java.util.Collection r0 = r9.m()
            java.lang.String r5 = "getOverriddenDescriptors(...)"
            kotlin.jvm.internal.l.e(r0, r5)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            r5 = r0
            java.util.Collection r5 = (java.util.Collection) r5
            boolean r5 = r5.isEmpty()
            if (r5 == 0) goto L_0x003f
            goto L_0x0067
        L_0x003f:
            java.util.Iterator r0 = r0.iterator()
        L_0x0043:
            boolean r5 = r0.hasNext()
            if (r5 == 0) goto L_0x0067
            java.lang.Object r5 = r0.next()
            db.w r5 = (db.C4333w) r5
            db.k r5 = r5.d()
            kotlin.jvm.internal.l.e(r5, r1)
            boolean r6 = r5 instanceof db.C4315e
            if (r6 == 0) goto L_0x0043
            db.e r5 = (db.C4315e) r5
            Cb.f r6 = ab.k.f39134e
            Cb.d r6 = ab.o.a.f39205a
            boolean r5 = ab.k.b(r5, r6)
            if (r5 == 0) goto L_0x0043
            return r2
        L_0x0067:
            db.k r0 = r9.d()
            boolean r5 = r0 instanceof db.C4315e
            if (r5 == 0) goto L_0x0072
            db.e r0 = (db.C4315e) r0
            goto L_0x0073
        L_0x0072:
            r0 = r2
        L_0x0073:
            if (r0 == 0) goto L_0x00e7
            boolean r5 = Fb.k.f(r0)
            if (r5 == 0) goto L_0x007c
            goto L_0x007d
        L_0x007c:
            r0 = r2
        L_0x007d:
            if (r0 == 0) goto L_0x00e7
            Tb.H r0 = r0.q()
            if (r0 == 0) goto L_0x00e7
            Tb.n0 r0 = A.o.Y(r0)
            if (r0 != 0) goto L_0x008c
            goto L_0x00e7
        L_0x008c:
            Tb.z r5 = r9.getReturnType()
            if (r5 != 0) goto L_0x0093
            goto L_0x00e7
        L_0x0093:
            Cb.f r6 = r9.getName()
            Cb.f r7 = Zb.w.f39031d
            boolean r6 = kotlin.jvm.internal.l.a(r6, r7)
            if (r6 == 0) goto L_0x00e7
            Cb.f r6 = ab.k.f39134e
            Cb.d r6 = ab.o.a.f39216h
            boolean r6 = ab.k.A(r5, r6)
            if (r6 != 0) goto L_0x00af
            boolean r5 = ab.k.D(r5)
            if (r5 == 0) goto L_0x00e7
        L_0x00af:
            java.util.List r5 = r9.g()
            int r5 = r5.size()
            if (r5 != r4) goto L_0x00e7
            java.util.List r4 = r9.g()
            java.lang.Object r3 = r4.get(r3)
            db.h0 r3 = (db.h0) r3
            Tb.z r3 = r3.getType()
            java.lang.String r4 = "getType(...)"
            kotlin.jvm.internal.l.e(r3, r4)
            Tb.n0 r3 = A.o.Y(r3)
            boolean r0 = kotlin.jvm.internal.l.a(r3, r0)
            if (r0 == 0) goto L_0x00e7
            java.util.List r0 = r9.n0()
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L_0x00e7
            db.U r0 = r9.h0()
            if (r0 != 0) goto L_0x00e7
            goto L_0x0139
        L_0x00e7:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r2 = "must override ''equals()'' in Any"
            r0.<init>(r2)
            db.k r2 = r9.d()
            kotlin.jvm.internal.l.e(r2, r1)
            boolean r1 = Fb.k.f(r2)
            if (r1 == 0) goto L_0x012f
            Eb.r r1 = Eb.n.f34488b
            db.k r9 = r9.d()
            java.lang.String r2 = "null cannot be cast to non-null type org.jetbrains.kotlin.descriptors.ClassDescriptor"
            kotlin.jvm.internal.l.d(r9, r2)
            db.e r9 = (db.C4315e) r9
            Tb.H r9 = r9.q()
            java.lang.String r2 = "getDefaultType(...)"
            kotlin.jvm.internal.l.e(r9, r2)
            Tb.n0 r9 = A.o.Y(r9)
            java.lang.String r9 = r1.X(r9)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = " or define ''equals(other: "
            r1.<init>(r2)
            r1.append(r9)
            java.lang.String r9 = "): Boolean''"
            r1.append(r9)
            java.lang.String r9 = r1.toString()
            r0.append(r9)
        L_0x012f:
            java.lang.String r9 = r0.toString()
            java.lang.String r0 = "toString(...)"
            kotlin.jvm.internal.l.e(r9, r0)
            return r9
        L_0x0139:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: Zb.t.invoke(java.lang.Object):java.lang.Object");
    }
}
