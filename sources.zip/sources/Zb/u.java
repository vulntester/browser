package Zb;

import Na.l;

public final class u implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final u f39023f = new Object();

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0075, code lost:
        if (r7 == false) goto L_0x0078;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invoke(java.lang.Object r7) {
        /*
            r6 = this;
            db.w r7 = (db.C4333w) r7
            Zb.v r0 = Zb.v.f39024a
            java.lang.String r0 = "$this$Checks"
            kotlin.jvm.internal.l.f(r7, r0)
            db.U r0 = r7.Z()
            if (r0 != 0) goto L_0x0013
            db.U r0 = r7.h0()
        L_0x0013:
            r1 = 0
            r2 = 0
            if (r0 == 0) goto L_0x0078
            Tb.z r3 = r7.getReturnType()
            if (r3 == 0) goto L_0x002b
            Tb.z r4 = r0.getType()
            java.lang.String r5 = "getType(...)"
            kotlin.jvm.internal.l.e(r4, r5)
            boolean r3 = A.o.S(r3, r4)
            goto L_0x002c
        L_0x002b:
            r3 = r2
        L_0x002c:
            if (r3 != 0) goto L_0x0077
            Zb.v r3 = Zb.v.f39024a
            r3.getClass()
            Nb.f r0 = r0.getValue()
            java.lang.String r3 = "getValue(...)"
            kotlin.jvm.internal.l.e(r0, r3)
            boolean r3 = r0 instanceof Nb.d
            if (r3 != 0) goto L_0x0042
        L_0x0040:
            r7 = r2
            goto L_0x0075
        L_0x0042:
            Nb.d r0 = (Nb.d) r0
            db.e r0 = r0.f37212a
            boolean r3 = r0.H()
            if (r3 != 0) goto L_0x004d
            goto L_0x0040
        L_0x004d:
            Cb.b r3 = Jb.d.f(r0)
            if (r3 != 0) goto L_0x0054
            goto L_0x0040
        L_0x0054:
            db.E r0 = Jb.d.j(r0)
            db.h r0 = db.C4332v.b(r0, r3)
            boolean r3 = r0 instanceof db.b0
            if (r3 == 0) goto L_0x0063
            db.b0 r0 = (db.b0) r0
            goto L_0x0064
        L_0x0063:
            r0 = r1
        L_0x0064:
            if (r0 != 0) goto L_0x0067
            goto L_0x0040
        L_0x0067:
            Tb.z r7 = r7.getReturnType()
            if (r7 == 0) goto L_0x0040
            Tb.H r0 = r0.R()
            boolean r7 = A.o.S(r7, r0)
        L_0x0075:
            if (r7 == 0) goto L_0x0078
        L_0x0077:
            r2 = 1
        L_0x0078:
            if (r2 != 0) goto L_0x007d
            java.lang.String r7 = "receiver must be a supertype of the return type"
            return r7
        L_0x007d:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: Zb.u.invoke(java.lang.Object):java.lang.Object");
    }
}
