package Zb;

import Cb.f;
import Na.l;
import Zb.B;
import Zb.n;
import Zb.y;
import db.C4333w;
import fc.C4419i;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public final class v extends C4195b {

    /* renamed from: a  reason: collision with root package name */
    public static final v f39024a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public static final List<k> f39025b;

    /* JADX WARNING: type inference failed for: r5v0, types: [java.lang.Object, Zb.v] */
    static {
        f fVar = w.f39036i;
        f fVar2 = n.b.f39014b;
        k kVar = new k(fVar, new f[]{fVar2, new B.a(1)});
        k kVar2 = new k(w.f39037j, new f[]{fVar2, new B.a(2)}, (l<? super C4333w, String>) s.f39021f);
        f fVar3 = w.f39028a;
        f fVar4 = p.f39016a;
        f aVar = new B.a(2);
        f fVar5 = m.f39011a;
        k kVar3 = new k(fVar3, new f[]{fVar2, fVar4, aVar, fVar5});
        k kVar4 = new k(w.f39029b, new f[]{fVar2, fVar4, new B.a(3), fVar5});
        k kVar5 = new k(w.f39030c, new f[]{fVar2, fVar4, new B.b(), fVar5});
        k kVar6 = new k(w.f39034g, new f[]{fVar2});
        f fVar6 = w.f39033f;
        f fVar7 = B.d.f38992b;
        f fVar8 = y.a.f39057c;
        k kVar7 = new k(fVar6, new f[]{fVar2, fVar7, fVar4, fVar8});
        f fVar9 = w.f39035h;
        f fVar10 = B.c.f38991b;
        k kVar8 = new k(fVar9, new f[]{fVar2, fVar10});
        k kVar9 = new k(w.f39038k, new f[]{fVar2, fVar10});
        k kVar10 = new k(w.f39039l, new f[]{fVar2, fVar10, fVar8});
        k kVar11 = kVar9;
        k kVar12 = new k(w.f39043p, new f[]{fVar2, fVar7, fVar4});
        k kVar13 = kVar12;
        k kVar14 = new k(w.f39044q, new f[]{fVar2, fVar7, fVar4});
        k kVar15 = kVar14;
        k kVar16 = new k(w.f39031d, new f[]{n.a.f39013b}, (l<? super C4333w, String>) t.f39022f);
        k kVar17 = kVar16;
        k kVar18 = new k(w.f39032e, new f[]{fVar2, y.b.f39058c, fVar7, fVar4});
        k kVar19 = new k((Set) w.f39047t, new f[]{fVar2, fVar7, fVar4});
        k kVar20 = new k((Set) w.f39046s, new f[]{fVar2, fVar10});
        k kVar21 = kVar20;
        k kVar22 = new k((Collection<f>) ya.n.x(w.f39041n, w.f39042o), new f[]{fVar2}, (l<? super C4333w, String>) u.f39023f);
        k kVar23 = new k((Set) w.f39051x, new f[]{fVar2, y.c.f39059c, fVar7, fVar4});
        C4419i iVar = w.f39040m;
        i iVar2 = i.f39003f;
        kotlin.jvm.internal.l.f(iVar, "regex");
        C4419i iVar3 = iVar;
        f39025b = ya.n.x(kVar, kVar2, kVar3, kVar4, kVar5, kVar6, kVar7, kVar8, kVar11, kVar10, kVar13, kVar15, kVar17, kVar18, kVar19, kVar21, kVar22, kVar23, new k((f) null, iVar3, (Collection<f>) null, iVar2, (f[]) Arrays.copyOf(new f[]{fVar2, fVar10}, 2)));
    }
}
