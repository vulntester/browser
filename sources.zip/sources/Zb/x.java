package Zb;

import Na.l;
import Zb.y;
import ab.k;

public final class x implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final x f39054f = new Object();

    public final Object invoke(Object obj) {
        k kVar = (k) obj;
        y.a aVar = y.a.f39057c;
        kotlin.jvm.internal.l.f(kVar, "<this>");
        return kVar.r(ab.l.BOOLEAN);
    }
}
