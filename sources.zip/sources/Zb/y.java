package Zb;

import Jb.d;
import Na.l;
import Tb.C4154z;
import Zb.f;
import ab.k;
import ob.e;

public abstract class y implements f {

    /* renamed from: a  reason: collision with root package name */
    public final l<k, C4154z> f39055a;

    /* renamed from: b  reason: collision with root package name */
    public final String f39056b;

    public static final class a extends y {

        /* renamed from: c  reason: collision with root package name */
        public static final a f39057c = new y("Boolean", x.f39054f);
    }

    public static final class b extends y {

        /* renamed from: c  reason: collision with root package name */
        public static final b f39058c = new y("Int", z.f39060f);
    }

    public static final class c extends y {

        /* renamed from: c  reason: collision with root package name */
        public static final c f39059c = new y("Unit", A.f38987f);
    }

    public y(String str, l lVar) {
        this.f39055a = lVar;
        this.f39056b = "must return ".concat(str);
    }

    public final String a(e eVar) {
        return f.a.a(this, eVar);
    }

    public final boolean b(e eVar) {
        return kotlin.jvm.internal.l.a(eVar.f40913I, this.f39055a.invoke(d.e(eVar)));
    }

    public final String getDescription() {
        return this.f39056b;
    }
}
