package Zb;

import Na.l;
import Zb.y;
import ab.k;

public final class z implements l {

    /* renamed from: f  reason: collision with root package name */
    public static final z f39060f = new Object();

    public final Object invoke(Object obj) {
        k kVar = (k) obj;
        y.b bVar = y.b.f39058c;
        kotlin.jvm.internal.l.f(kVar, "<this>");
        return kVar.r(ab.l.INT);
    }
}
