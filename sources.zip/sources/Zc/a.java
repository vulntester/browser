package Zc;

public interface a {
    b a(String str);
}
