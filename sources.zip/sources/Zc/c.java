package Zc;

import java.security.PrivilegedAction;
import java.util.ServiceLoader;

public final /* synthetic */ class c implements PrivilegedAction {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ClassLoader f39061a;

    public /* synthetic */ c(ClassLoader classLoader) {
        this.f39061a = classLoader;
    }

    public final Object run() {
        return ServiceLoader.load(cd.c.class, this.f39061a);
    }
}
