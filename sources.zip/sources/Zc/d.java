package Zc;

import androidx.datastore.preferences.protobuf.C1311s;
import bd.e;
import bd.f;
import bd.g;
import bd.h;
import bd.i;
import cd.c;
import io.netty.handler.codec.http.HttpObjectDecoder;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.security.AccessController;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;
import java.util.concurrent.LinkedBlockingQueue;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static volatile int f39062a;

    /* renamed from: b  reason: collision with root package name */
    public static final i f39063b = new i();

    /* renamed from: c  reason: collision with root package name */
    public static final e f39064c = new e();

    /* renamed from: d  reason: collision with root package name */
    public static volatile c f39065d;

    /* renamed from: e  reason: collision with root package name */
    public static final String[] f39066e = {"2.0"};

    static {
        String str;
        try {
            str = System.getProperty("slf4j.detectLoggerNameMismatch");
        } catch (SecurityException unused) {
            str = null;
        }
        if (str != null) {
            str.equalsIgnoreCase("true");
        }
    }

    public static ArrayList a() {
        ServiceLoader<S> serviceLoader;
        ArrayList arrayList = new ArrayList();
        ClassLoader classLoader = d.class.getClassLoader();
        String property = System.getProperty("slf4j.provider");
        c cVar = null;
        if (property != null && !property.isEmpty()) {
            try {
                String str = "Attempting to load provider \"" + property + "\" specified via \"slf4j.provider\" system property";
                f.a aVar = f.f39382a;
                if (C1311s.a(2) >= C1311s.a(f.f39383b)) {
                    f.c().println("SLF4J(I): " + str);
                }
                cVar = (c) classLoader.loadClass(property).getConstructor(new Class[0]).newInstance(new Object[0]);
            } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e10) {
                f.b("Failed to instantiate the specified SLF4JServiceProvider (" + property + ")", e10);
            } catch (ClassCastException e11) {
                f.b("Specified SLF4JServiceProvider (" + property + ") does not implement SLF4JServiceProvider interface", e11);
            }
        }
        if (cVar != null) {
            arrayList.add(cVar);
            return arrayList;
        }
        if (System.getSecurityManager() == null) {
            serviceLoader = ServiceLoader.load(c.class, classLoader);
        } else {
            serviceLoader = (ServiceLoader) AccessController.doPrivileged(new c(classLoader));
        }
        Iterator<S> it = serviceLoader.iterator();
        while (it.hasNext()) {
            try {
                arrayList.add((c) it.next());
            } catch (ServiceConfigurationError e12) {
                f.a("A service provider failed to instantiate:\n" + e12.getMessage());
            }
        }
        return arrayList;
    }

    public static c b() {
        if (f39062a == 0) {
            synchronized (d.class) {
                try {
                    if (f39062a == 0) {
                        f39062a = 1;
                        c();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        int i10 = f39062a;
        if (i10 == 1) {
            return f39063b;
        }
        if (i10 == 2) {
            throw new IllegalStateException("org.slf4j.LoggerFactory in failed state. Original exception was thrown EARLIER. See also https://www.slf4j.org/codes.html#unsuccessfulInit");
        } else if (i10 == 3) {
            return f39065d;
        } else {
            if (i10 == 4) {
                return f39064c;
            }
            throw new IllegalStateException("Unreachable code");
        }
    }

    public static final void c() {
        Enumeration<URL> enumeration;
        try {
            ArrayList a10 = a();
            g(a10);
            if (!a10.isEmpty()) {
                f39065d = (c) a10.get(0);
                f39065d.getClass();
                f39062a = 3;
                e(a10);
            } else {
                f39062a = 4;
                f.d("No SLF4J providers were found.");
                f.d("Defaulting to no-operation (NOP) logger implementation");
                f.d("See https://www.slf4j.org/codes.html#noProviders for further details.");
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                try {
                    ClassLoader classLoader = d.class.getClassLoader();
                    if (classLoader == null) {
                        enumeration = ClassLoader.getSystemResources("org/slf4j/impl/StaticLoggerBinder.class");
                    } else {
                        enumeration = classLoader.getResources("org/slf4j/impl/StaticLoggerBinder.class");
                    }
                    while (enumeration.hasMoreElements()) {
                        linkedHashSet.add(enumeration.nextElement());
                    }
                } catch (IOException e10) {
                    f.b("Error getting resources from path", e10);
                }
                f(linkedHashSet);
            }
            d();
            if (f39062a == 3) {
                try {
                    String c10 = f39065d.c();
                    boolean z10 = false;
                    for (String startsWith : f39066e) {
                        if (c10.startsWith(startsWith)) {
                            z10 = true;
                        }
                    }
                    if (!z10) {
                        f.d("The requested version " + c10 + " by your slf4j provider is not compatible with " + Arrays.asList(f39066e).toString());
                        f.d("See https://www.slf4j.org/codes.html#version_mismatch for further details.");
                    }
                } catch (Throwable th) {
                    f.b("Unexpected problem occurred during version sanity check", th);
                }
            }
        } catch (Exception e11) {
            f39062a = 2;
            f.b("Failed to instantiate SLF4J LoggerFactory", e11);
            throw new IllegalStateException("Unexpected initialization failure", e11);
        }
    }

    public static void d() {
        i iVar = f39063b;
        synchronized (iVar) {
            try {
                iVar.f39397a.f39394a = true;
                h hVar = iVar.f39397a;
                hVar.getClass();
                Iterator it = new ArrayList(hVar.f39395b.values()).iterator();
                while (it.hasNext()) {
                    g gVar = (g) it.next();
                    gVar.f39392i = b().b().a(gVar.f39391f);
                }
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        LinkedBlockingQueue<ad.c> linkedBlockingQueue = f39063b.f39397a.f39396c;
        int size = linkedBlockingQueue.size();
        ArrayList arrayList = new ArrayList(HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
        int i10 = 0;
        while (linkedBlockingQueue.drainTo(arrayList, HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE) != 0) {
            Iterator it2 = arrayList.iterator();
            while (it2.hasNext()) {
                ad.c cVar = (ad.c) it2.next();
                if (cVar != null) {
                    g gVar2 = cVar.f39255b;
                    String str = gVar2.f39391f;
                    if (gVar2.f39392i == null) {
                        throw new IllegalStateException("Delegate logger cannot be null at this state.");
                    } else if (!(gVar2.f39392i instanceof bd.c)) {
                        if (!gVar2.d()) {
                            f.d(str);
                        } else if (gVar2.a(cVar.f39254a) && gVar2.d()) {
                            try {
                                gVar2.f39387E.invoke(gVar2.f39392i, new Object[]{cVar});
                            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException unused) {
                            }
                        }
                    }
                }
                int i11 = i10 + 1;
                if (i10 == 0) {
                    if (cVar.f39255b.d()) {
                        f.d("A number (" + size + ") of logging calls during the initialization phase have been intercepted and are");
                        f.d("now being replayed. These are subject to the filtering rules of the underlying logging system.");
                        f.d("See also https://www.slf4j.org/codes.html#replay");
                    } else if (!(cVar.f39255b.f39392i instanceof bd.c)) {
                        f.d("The following set of substitute loggers may have been accessed");
                        f.d("during the initialization phase. Logging calls during this");
                        f.d("phase were not honored. However, subsequent logging calls to these");
                        f.d("loggers will work as normally expected.");
                        f.d("See also https://www.slf4j.org/codes.html#substituteLogger");
                    }
                }
                i10 = i11;
            }
            arrayList.clear();
        }
        h hVar2 = f39063b.f39397a;
        hVar2.f39395b.clear();
        hVar2.f39396c.clear();
    }

    public static void e(ArrayList arrayList) {
        if (arrayList.isEmpty()) {
            throw new IllegalStateException("No providers were found which is impossible after successful initialization.");
        } else if (arrayList.size() > 1) {
            String str = "Actual provider is of type [" + arrayList.get(0) + "]";
            f.a aVar = f.f39382a;
            if (C1311s.a(2) >= C1311s.a(f.f39383b)) {
                f.c().println("SLF4J(I): " + str);
            }
        } else {
            String str2 = "Connected with provider of type [" + ((c) arrayList.get(0)).getClass().getName() + "]";
            f.a aVar2 = f.f39382a;
            if (C1311s.a(1) >= C1311s.a(f.f39383b)) {
                f.c().println("SLF4J(D): " + str2);
            }
        }
    }

    public static void f(LinkedHashSet linkedHashSet) {
        if (!linkedHashSet.isEmpty()) {
            f.d("Class path contains SLF4J bindings targeting slf4j-api versions 1.7.x or earlier.");
            Iterator it = linkedHashSet.iterator();
            while (it.hasNext()) {
                f.d("Ignoring binding found at [" + ((URL) it.next()) + "]");
            }
            f.d("See https://www.slf4j.org/codes.html#ignoredBindings for an explanation.");
        }
    }

    public static void g(ArrayList arrayList) {
        if (arrayList.size() > 1) {
            f.d("Class path contains multiple SLF4J providers.");
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                f.d("Found provider [" + ((c) it.next()) + "]");
            }
            f.d("See https://www.slf4j.org/codes.html#multiple_bindings for an explanation.");
        }
    }
}
