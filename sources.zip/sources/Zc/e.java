package Zc;

import bd.f;
import cd.b;
import cd.c;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    public static final b f39067a;

    static {
        c b10 = d.b();
        if (b10 != null) {
            f39067a = b10.a();
            return;
        }
        f.a("Failed to find provider.");
        f.a("Defaulting to no-operation MDCAdapter implementation.");
        f39067a = new P8.b(14);
    }
}
