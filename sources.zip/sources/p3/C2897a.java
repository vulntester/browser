package p3;

import Pb.C4126p;
import android.text.Layout;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import n2.C2722a;
import o2.n;
import o2.t;
import o3.C2771m;

/* renamed from: p3.a  reason: case insensitive filesystem */
public final class C2897a extends c {

    /* renamed from: A  reason: collision with root package name */
    public static final int[] f26539A = {0, 4, 8, 12, 16, 20, 24, 28};

    /* renamed from: B  reason: collision with root package name */
    public static final int[] f26540B = {-1, -16711936, -16776961, -16711681, -65536, -256, -65281};

    /* renamed from: C  reason: collision with root package name */
    public static final int[] f26541C = {32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 225, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 233, 93, 237, 243, 250, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 231, 247, 209, 241, 9632};

    /* renamed from: D  reason: collision with root package name */
    public static final int[] f26542D = {174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 232, 226, 234, 238, 244, 251};

    /* renamed from: E  reason: collision with root package name */
    public static final int[] f26543E = {193, 201, 211, 218, 220, 252, 8216, 161, 42, 39, 8212, 169, 8480, 8226, 8220, 8221, 192, 194, 199, 200, 202, 203, 235, 206, 207, 239, 212, 217, 249, 219, 171, 187};

    /* renamed from: F  reason: collision with root package name */
    public static final int[] f26544F = {195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 223, 165, 164, 9474, 197, 229, 216, 248, 9484, 9488, 9492, 9496};

    /* renamed from: G  reason: collision with root package name */
    public static final boolean[] f26545G = {false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false, false, true, true, false, true, false, false, true, false, true, true, false, true, false, false, true, true, false, false, true, false, true, true, false};

    /* renamed from: z  reason: collision with root package name */
    public static final int[] f26546z = {11, 1, 3, 12, 14, 5, 7, 9};

    /* renamed from: h  reason: collision with root package name */
    public final t f26547h = new t();

    /* renamed from: i  reason: collision with root package name */
    public final int f26548i;

    /* renamed from: j  reason: collision with root package name */
    public final int f26549j;

    /* renamed from: k  reason: collision with root package name */
    public final int f26550k;

    /* renamed from: l  reason: collision with root package name */
    public final long f26551l = 16000000;

    /* renamed from: m  reason: collision with root package name */
    public final ArrayList<C0248a> f26552m = new ArrayList<>();

    /* renamed from: n  reason: collision with root package name */
    public C0248a f26553n = new C0248a(0, 4);

    /* renamed from: o  reason: collision with root package name */
    public List<C2722a> f26554o;

    /* renamed from: p  reason: collision with root package name */
    public List<C2722a> f26555p;

    /* renamed from: q  reason: collision with root package name */
    public int f26556q;

    /* renamed from: r  reason: collision with root package name */
    public int f26557r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f26558s;

    /* renamed from: t  reason: collision with root package name */
    public boolean f26559t;

    /* renamed from: u  reason: collision with root package name */
    public byte f26560u;

    /* renamed from: v  reason: collision with root package name */
    public byte f26561v;

    /* renamed from: w  reason: collision with root package name */
    public int f26562w = 0;

    /* renamed from: x  reason: collision with root package name */
    public boolean f26563x;

    /* renamed from: y  reason: collision with root package name */
    public long f26564y;

    /* renamed from: p3.a$a  reason: collision with other inner class name */
    public static final class C0248a {

        /* renamed from: a  reason: collision with root package name */
        public final ArrayList f26565a;

        /* renamed from: b  reason: collision with root package name */
        public final ArrayList f26566b;

        /* renamed from: c  reason: collision with root package name */
        public final StringBuilder f26567c;

        /* renamed from: d  reason: collision with root package name */
        public int f26568d = 15;

        /* renamed from: e  reason: collision with root package name */
        public int f26569e = 0;

        /* renamed from: f  reason: collision with root package name */
        public int f26570f = 0;

        /* renamed from: g  reason: collision with root package name */
        public int f26571g;

        /* renamed from: h  reason: collision with root package name */
        public int f26572h;

        /* renamed from: p3.a$a$a  reason: collision with other inner class name */
        public static class C0249a {

            /* renamed from: a  reason: collision with root package name */
            public final int f26573a;

            /* renamed from: b  reason: collision with root package name */
            public final boolean f26574b;

            /* renamed from: c  reason: collision with root package name */
            public int f26575c;

            public C0249a(int i10, int i11, boolean z10) {
                this.f26573a = i10;
                this.f26574b = z10;
                this.f26575c = i11;
            }
        }

        public C0248a(int i10, int i11) {
            ArrayList arrayList = new ArrayList();
            this.f26565a = arrayList;
            ArrayList arrayList2 = new ArrayList();
            this.f26566b = arrayList2;
            StringBuilder sb2 = new StringBuilder();
            this.f26567c = sb2;
            this.f26571g = i10;
            arrayList.clear();
            arrayList2.clear();
            sb2.setLength(0);
            this.f26572h = i11;
        }

        public final void a(char c10) {
            StringBuilder sb2 = this.f26567c;
            if (sb2.length() < 32) {
                sb2.append(c10);
            }
        }

        public final void b() {
            StringBuilder sb2 = this.f26567c;
            int length = sb2.length();
            if (length > 0) {
                sb2.delete(length - 1, length);
                ArrayList arrayList = this.f26565a;
                int size = arrayList.size() - 1;
                while (size >= 0) {
                    C0249a aVar = (C0249a) arrayList.get(size);
                    int i10 = aVar.f26575c;
                    if (i10 == length) {
                        aVar.f26575c = i10 - 1;
                        size--;
                    } else {
                        return;
                    }
                }
            }
        }

        public final C2722a c(int i10) {
            float f10;
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            int i11 = 0;
            while (true) {
                ArrayList arrayList = this.f26566b;
                if (i11 >= arrayList.size()) {
                    break;
                }
                spannableStringBuilder.append((CharSequence) arrayList.get(i11));
                spannableStringBuilder.append(10);
                i11++;
            }
            spannableStringBuilder.append(d());
            if (spannableStringBuilder.length() == 0) {
                return null;
            }
            int i12 = this.f26569e + this.f26570f;
            int length = (32 - i12) - spannableStringBuilder.length();
            int i13 = i12 - length;
            if (i10 == Integer.MIN_VALUE) {
                if (this.f26571g == 2 && (Math.abs(i13) < 3 || length < 0)) {
                    i10 = 1;
                } else if (this.f26571g != 2 || i13 <= 0) {
                    i10 = 0;
                } else {
                    i10 = 2;
                }
            }
            if (i10 != 1) {
                if (i10 == 2) {
                    i12 = 32 - length;
                }
                f10 = ((((float) i12) / 32.0f) * 0.8f) + 0.1f;
            } else {
                f10 = 0.5f;
            }
            int i14 = this.f26568d;
            if (i14 > 7) {
                i14 -= 17;
            } else if (this.f26571g == 1) {
                i14 -= this.f26572h - 1;
            }
            C2722a.C0239a aVar = new C2722a.C0239a();
            aVar.f25621a = spannableStringBuilder;
            aVar.f25623c = Layout.Alignment.ALIGN_NORMAL;
            aVar.f25625e = (float) i14;
            aVar.f25626f = 1;
            aVar.f25628h = f10;
            aVar.f25629i = i10;
            return aVar.a();
        }

        public final SpannableString d() {
            int i10;
            boolean z10;
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(this.f26567c);
            int length = spannableStringBuilder.length();
            int i11 = -1;
            int i12 = -1;
            int i13 = -1;
            int i14 = -1;
            int i15 = 0;
            int i16 = 0;
            boolean z11 = false;
            while (true) {
                ArrayList arrayList = this.f26565a;
                if (i15 >= arrayList.size()) {
                    break;
                }
                C0249a aVar = (C0249a) arrayList.get(i15);
                boolean z12 = aVar.f26574b;
                int i17 = aVar.f26573a;
                if (i17 != 8) {
                    if (i17 == 7) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    if (i17 != 7) {
                        i14 = C2897a.f26540B[i17];
                    }
                    z11 = z10;
                }
                int i18 = aVar.f26575c;
                i15++;
                if (i15 < arrayList.size()) {
                    i10 = ((C0249a) arrayList.get(i15)).f26575c;
                } else {
                    i10 = length;
                }
                if (i18 != i10) {
                    if (i11 != -1 && !z12) {
                        spannableStringBuilder.setSpan(new UnderlineSpan(), i11, i18, 33);
                        i11 = -1;
                    } else if (i11 == -1 && z12) {
                        i11 = i18;
                    }
                    if (i12 != -1 && !z11) {
                        spannableStringBuilder.setSpan(new StyleSpan(2), i12, i18, 33);
                        i12 = -1;
                    } else if (i12 == -1 && z11) {
                        i12 = i18;
                    }
                    if (i14 != i13) {
                        if (i13 != -1) {
                            spannableStringBuilder.setSpan(new ForegroundColorSpan(i13), i16, i18, 33);
                        }
                        i13 = i14;
                        i16 = i18;
                    }
                }
            }
            if (!(i11 == -1 || i11 == length)) {
                spannableStringBuilder.setSpan(new UnderlineSpan(), i11, length, 33);
            }
            if (!(i12 == -1 || i12 == length)) {
                spannableStringBuilder.setSpan(new StyleSpan(2), i12, length, 33);
            }
            if (!(i16 == length || i13 == -1)) {
                spannableStringBuilder.setSpan(new ForegroundColorSpan(i13), i16, length, 33);
            }
            return new SpannableString(spannableStringBuilder);
        }

        public final boolean e() {
            if (!this.f26565a.isEmpty() || !this.f26566b.isEmpty() || this.f26567c.length() != 0) {
                return false;
            }
            return true;
        }
    }

    public C2897a(String str, int i10) {
        int i11;
        if ("application/x-mp4-cea-608".equals(str)) {
            i11 = 2;
        } else {
            i11 = 3;
        }
        this.f26548i = i11;
        if (i10 == 1) {
            this.f26550k = 0;
            this.f26549j = 0;
        } else if (i10 == 2) {
            this.f26550k = 1;
            this.f26549j = 0;
        } else if (i10 == 3) {
            this.f26550k = 0;
            this.f26549j = 1;
        } else if (i10 != 4) {
            n.f("Cea608Decoder", "Invalid channel. Defaulting to CC1.");
            this.f26550k = 0;
            this.f26549j = 0;
        } else {
            this.f26550k = 1;
            this.f26549j = 1;
        }
        m(0);
        l();
        this.f26563x = true;
        this.f26564y = -9223372036854775807L;
    }

    public final void flush() {
        super.flush();
        this.f26554o = null;
        this.f26555p = null;
        m(0);
        this.f26557r = 4;
        this.f26553n.f26572h = 4;
        l();
        this.f26558s = false;
        this.f26559t = false;
        this.f26560u = 0;
        this.f26561v = 0;
        this.f26562w = 0;
        this.f26563x = true;
        this.f26564y = -9223372036854775807L;
    }

    public final C4126p g() {
        List<C2722a> list = this.f26554o;
        this.f26555p = list;
        list.getClass();
        return new C4126p((Object) list);
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x0064  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x007a  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x007e  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0085  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void h(p3.c.a r15) {
        /*
            r14 = this;
            java.nio.ByteBuffer r15 = r15.f27698E
            r15.getClass()
            byte[] r0 = r15.array()
            int r15 = r15.limit()
            o2.t r1 = r14.f26547h
            r1.E(r15, r0)
            r15 = 0
            r0 = r15
        L_0x0014:
            int r2 = r1.a()
            r3 = 3
            r4 = 1
            int r5 = r14.f26548i
            if (r2 < r5) goto L_0x0268
            r2 = 2
            if (r5 != r2) goto L_0x0023
            r5 = -4
            goto L_0x0027
        L_0x0023:
            int r5 = r1.u()
        L_0x0027:
            int r6 = r1.u()
            int r7 = r1.u()
            r8 = r5 & 2
            if (r8 == 0) goto L_0x0034
            goto L_0x0014
        L_0x0034:
            r8 = r5 & 1
            int r9 = r14.f26549j
            if (r8 == r9) goto L_0x003b
            goto L_0x0014
        L_0x003b:
            r8 = r6 & 127(0x7f, float:1.78E-43)
            byte r8 = (byte) r8
            r9 = r7 & 127(0x7f, float:1.78E-43)
            byte r9 = (byte) r9
            if (r8 != 0) goto L_0x0046
            if (r9 != 0) goto L_0x0046
            goto L_0x0014
        L_0x0046:
            boolean r10 = r14.f26558s
            r5 = r5 & 4
            r11 = 4
            if (r5 != r11) goto L_0x0059
            boolean[] r5 = f26545G
            boolean r6 = r5[r6]
            if (r6 == 0) goto L_0x0059
            boolean r5 = r5[r7]
            if (r5 == 0) goto L_0x0059
            r5 = r4
            goto L_0x005a
        L_0x0059:
            r5 = r15
        L_0x005a:
            r14.f26558s = r5
            r6 = 16
            if (r5 == 0) goto L_0x007a
            r7 = r8 & 240(0xf0, float:3.36E-43)
            if (r7 != r6) goto L_0x007a
            boolean r7 = r14.f26559t
            if (r7 == 0) goto L_0x0073
            byte r7 = r14.f26560u
            if (r7 != r8) goto L_0x0073
            byte r7 = r14.f26561v
            if (r7 != r9) goto L_0x0073
            r14.f26559t = r15
            goto L_0x0014
        L_0x0073:
            r14.f26559t = r4
            r14.f26560u = r8
            r14.f26561v = r9
            goto L_0x007c
        L_0x007a:
            r14.f26559t = r15
        L_0x007c:
            if (r5 != 0) goto L_0x0085
            if (r10 == 0) goto L_0x0014
            r14.l()
        L_0x0083:
            r0 = r4
            goto L_0x0014
        L_0x0085:
            r5 = 32
            r7 = 20
            if (r4 > r8) goto L_0x0092
            r10 = 15
            if (r8 > r10) goto L_0x0092
            r14.f26563x = r15
            goto L_0x00a8
        L_0x0092:
            r10 = r8 & 246(0xf6, float:3.45E-43)
            if (r10 != r7) goto L_0x00a8
            if (r9 == r5) goto L_0x00a6
            r10 = 47
            if (r9 == r10) goto L_0x00a6
            switch(r9) {
                case 37: goto L_0x00a6;
                case 38: goto L_0x00a6;
                case 39: goto L_0x00a6;
                default: goto L_0x009f;
            }
        L_0x009f:
            switch(r9) {
                case 41: goto L_0x00a6;
                case 42: goto L_0x00a3;
                case 43: goto L_0x00a3;
                default: goto L_0x00a2;
            }
        L_0x00a2:
            goto L_0x00a8
        L_0x00a3:
            r14.f26563x = r15
            goto L_0x00a8
        L_0x00a6:
            r14.f26563x = r4
        L_0x00a8:
            boolean r10 = r14.f26563x
            if (r10 != 0) goto L_0x00ae
            goto L_0x0014
        L_0x00ae:
            r10 = r8 & 224(0xe0, float:3.14E-43)
            if (r10 != 0) goto L_0x00b7
            int r12 = r8 >> 3
            r12 = r12 & r4
            r14.f26562w = r12
        L_0x00b7:
            int r12 = r14.f26562w
            int r13 = r14.f26550k
            if (r12 != r13) goto L_0x0014
            if (r10 != 0) goto L_0x024a
            r0 = r8 & 247(0xf7, float:3.46E-43)
            r10 = 17
            if (r0 != r10) goto L_0x00d8
            r12 = r9 & 240(0xf0, float:3.36E-43)
            r13 = 48
            if (r12 != r13) goto L_0x00d8
            p3.a$a r0 = r14.f26553n
            r2 = r9 & 15
            int[] r3 = f26542D
            r2 = r3[r2]
            char r2 = (char) r2
            r0.a(r2)
            goto L_0x0083
        L_0x00d8:
            r12 = r8 & 246(0xf6, float:3.45E-43)
            r13 = 18
            if (r12 != r13) goto L_0x0100
            r13 = r9 & 224(0xe0, float:3.14E-43)
            if (r13 != r5) goto L_0x0100
            p3.a$a r0 = r14.f26553n
            r0.b()
            p3.a$a r0 = r14.f26553n
            r2 = r8 & 1
            if (r2 != 0) goto L_0x00f5
            r2 = r9 & 31
            int[] r3 = f26543E
            r2 = r3[r2]
        L_0x00f3:
            char r2 = (char) r2
            goto L_0x00fc
        L_0x00f5:
            r2 = r9 & 31
            int[] r3 = f26544F
            r2 = r3[r2]
            goto L_0x00f3
        L_0x00fc:
            r0.a(r2)
            goto L_0x0083
        L_0x0100:
            if (r0 != r10) goto L_0x012a
            r10 = r9 & 240(0xf0, float:3.36E-43)
            if (r10 != r5) goto L_0x012a
            p3.a$a r0 = r14.f26553n
            r0.a(r5)
            r0 = r9 & 1
            if (r0 != r4) goto L_0x0111
            r0 = r4
            goto L_0x0112
        L_0x0111:
            r0 = r15
        L_0x0112:
            int r2 = r9 >> 1
            r2 = r2 & 7
            p3.a$a r3 = r14.f26553n
            java.util.ArrayList r5 = r3.f26565a
            p3.a$a$a r6 = new p3.a$a$a
            java.lang.StringBuilder r3 = r3.f26567c
            int r3 = r3.length()
            r6.<init>(r2, r3, r0)
            r5.add(r6)
            goto L_0x0083
        L_0x012a:
            r10 = r8 & 240(0xf0, float:3.36E-43)
            if (r10 != r6) goto L_0x019a
            r10 = r9 & 192(0xc0, float:2.69E-43)
            r13 = 64
            if (r10 != r13) goto L_0x019a
            int[] r0 = f26546z
            r2 = r8 & 7
            r0 = r0[r2]
            r2 = r9 & 32
            if (r2 == 0) goto L_0x0140
            int r0 = r0 + 1
        L_0x0140:
            p3.a$a r2 = r14.f26553n
            int r3 = r2.f26568d
            if (r0 == r3) goto L_0x0164
            int r3 = r14.f26556q
            if (r3 == r4) goto L_0x0160
            boolean r2 = r2.e()
            if (r2 != 0) goto L_0x0160
            p3.a$a r2 = new p3.a$a
            int r3 = r14.f26556q
            int r5 = r14.f26557r
            r2.<init>(r3, r5)
            r14.f26553n = r2
            java.util.ArrayList<p3.a$a> r3 = r14.f26552m
            r3.add(r2)
        L_0x0160:
            p3.a$a r2 = r14.f26553n
            r2.f26568d = r0
        L_0x0164:
            r0 = r9 & 16
            if (r0 != r6) goto L_0x016a
            r0 = r4
            goto L_0x016b
        L_0x016a:
            r0 = r15
        L_0x016b:
            r2 = r9 & 1
            if (r2 != r4) goto L_0x0171
            r2 = r4
            goto L_0x0172
        L_0x0171:
            r2 = r15
        L_0x0172:
            int r3 = r9 >> 1
            r3 = r3 & 7
            p3.a$a r5 = r14.f26553n
            if (r0 == 0) goto L_0x017d
            r6 = 8
            goto L_0x017e
        L_0x017d:
            r6 = r3
        L_0x017e:
            java.util.ArrayList r7 = r5.f26565a
            p3.a$a$a r8 = new p3.a$a$a
            java.lang.StringBuilder r5 = r5.f26567c
            int r5 = r5.length()
            r8.<init>(r6, r5, r2)
            r7.add(r8)
            if (r0 == 0) goto L_0x0083
            p3.a$a r0 = r14.f26553n
            int[] r2 = f26539A
            r2 = r2[r3]
            r0.f26569e = r2
            goto L_0x0083
        L_0x019a:
            r6 = 23
            r8 = 33
            if (r0 != r6) goto L_0x01ae
            if (r9 < r8) goto L_0x01ae
            r0 = 35
            if (r9 > r0) goto L_0x01ae
            p3.a$a r0 = r14.f26553n
            int r9 = r9 + -32
            r0.f26570f = r9
            goto L_0x0083
        L_0x01ae:
            if (r12 != r7) goto L_0x0083
            r0 = r9 & 240(0xf0, float:3.36E-43)
            if (r0 != r5) goto L_0x0083
            if (r9 == r5) goto L_0x0245
            r0 = 41
            if (r9 == r0) goto L_0x0240
            switch(r9) {
                case 37: goto L_0x0235;
                case 38: goto L_0x022a;
                case 39: goto L_0x021f;
                default: goto L_0x01bd;
            }
        L_0x01bd:
            int r0 = r14.f26556q
            if (r0 != 0) goto L_0x01c3
            goto L_0x0083
        L_0x01c3:
            if (r9 == r8) goto L_0x0218
            switch(r9) {
                case 44: goto L_0x020b;
                case 45: goto L_0x01da;
                case 46: goto L_0x01d5;
                case 47: goto L_0x01ca;
                default: goto L_0x01c8;
            }
        L_0x01c8:
            goto L_0x0083
        L_0x01ca:
            java.util.ArrayList r0 = r14.k()
            r14.f26554o = r0
            r14.l()
            goto L_0x0083
        L_0x01d5:
            r14.l()
            goto L_0x0083
        L_0x01da:
            if (r0 != r4) goto L_0x0083
            p3.a$a r0 = r14.f26553n
            boolean r0 = r0.e()
            if (r0 != 0) goto L_0x0083
            p3.a$a r0 = r14.f26553n
            java.util.ArrayList r2 = r0.f26566b
            android.text.SpannableString r3 = r0.d()
            r2.add(r3)
            java.lang.StringBuilder r3 = r0.f26567c
            r3.setLength(r15)
            java.util.ArrayList r3 = r0.f26565a
            r3.clear()
            int r3 = r0.f26572h
            int r0 = r0.f26568d
            int r0 = java.lang.Math.min(r3, r0)
        L_0x0201:
            int r3 = r2.size()
            if (r3 < r0) goto L_0x0083
            r2.remove(r15)
            goto L_0x0201
        L_0x020b:
            java.util.List r2 = java.util.Collections.EMPTY_LIST
            r14.f26554o = r2
            if (r0 == r4) goto L_0x0213
            if (r0 != r3) goto L_0x0083
        L_0x0213:
            r14.l()
            goto L_0x0083
        L_0x0218:
            p3.a$a r0 = r14.f26553n
            r0.b()
            goto L_0x0083
        L_0x021f:
            r14.m(r4)
            r14.f26557r = r11
            p3.a$a r0 = r14.f26553n
            r0.f26572h = r11
            goto L_0x0083
        L_0x022a:
            r14.m(r4)
            r14.f26557r = r3
            p3.a$a r0 = r14.f26553n
            r0.f26572h = r3
            goto L_0x0083
        L_0x0235:
            r14.m(r4)
            r14.f26557r = r2
            p3.a$a r0 = r14.f26553n
            r0.f26572h = r2
            goto L_0x0083
        L_0x0240:
            r14.m(r3)
            goto L_0x0083
        L_0x0245:
            r14.m(r2)
            goto L_0x0083
        L_0x024a:
            p3.a$a r0 = r14.f26553n
            r2 = r8 & 127(0x7f, float:1.78E-43)
            int r2 = r2 - r5
            int[] r3 = f26541C
            r2 = r3[r2]
            char r2 = (char) r2
            r0.a(r2)
            r0 = r9 & 224(0xe0, float:3.14E-43)
            if (r0 == 0) goto L_0x0083
            p3.a$a r0 = r14.f26553n
            r2 = r9 & 127(0x7f, float:1.78E-43)
            int r2 = r2 - r5
            r2 = r3[r2]
            char r2 = (char) r2
            r0.a(r2)
            goto L_0x0083
        L_0x0268:
            if (r0 == 0) goto L_0x027a
            int r15 = r14.f26556q
            if (r15 == r4) goto L_0x0270
            if (r15 != r3) goto L_0x027a
        L_0x0270:
            java.util.ArrayList r15 = r14.k()
            r14.f26554o = r15
            long r0 = r14.f26628e
            r14.f26564y = r0
        L_0x027a:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p3.C2897a.h(p3.c$a):void");
    }

    /* renamed from: i */
    public final C2771m d() {
        C2771m pollFirst;
        C2771m i10 = super.d();
        if (i10 != null) {
            return i10;
        }
        long j10 = this.f26551l;
        if (j10 == -9223372036854775807L) {
            return null;
        }
        long j11 = this.f26564y;
        if (j11 == -9223372036854775807L || this.f26628e - j11 < j10 || (pollFirst = this.f26625b.pollFirst()) == null) {
            return null;
        }
        this.f26554o = Collections.EMPTY_LIST;
        this.f26564y = -9223372036854775807L;
        C4126p g6 = g();
        long j12 = this.f26628e;
        pollFirst.f27705i = j12;
        pollFirst.f25923E = g6;
        pollFirst.f25924F = j12;
        return pollFirst;
    }

    public final boolean j() {
        if (this.f26554o != this.f26555p) {
            return true;
        }
        return false;
    }

    public final ArrayList k() {
        ArrayList<C0248a> arrayList = this.f26552m;
        int size = arrayList.size();
        ArrayList arrayList2 = new ArrayList(size);
        int i10 = 2;
        for (int i11 = 0; i11 < size; i11++) {
            C2722a c10 = arrayList.get(i11).c(Integer.MIN_VALUE);
            arrayList2.add(c10);
            if (c10 != null) {
                i10 = Math.min(i10, c10.f25612i);
            }
        }
        ArrayList arrayList3 = new ArrayList(size);
        for (int i12 = 0; i12 < size; i12++) {
            C2722a aVar = (C2722a) arrayList2.get(i12);
            if (aVar != null) {
                if (aVar.f25612i != i10) {
                    aVar = arrayList.get(i12).c(i10);
                    aVar.getClass();
                }
                arrayList3.add(aVar);
            }
        }
        return arrayList3;
    }

    public final void l() {
        C0248a aVar = this.f26553n;
        aVar.f26571g = this.f26556q;
        aVar.f26565a.clear();
        aVar.f26566b.clear();
        aVar.f26567c.setLength(0);
        aVar.f26568d = 15;
        aVar.f26569e = 0;
        aVar.f26570f = 0;
        ArrayList<C0248a> arrayList = this.f26552m;
        arrayList.clear();
        arrayList.add(this.f26553n);
    }

    public final void m(int i10) {
        int i11 = this.f26556q;
        if (i11 != i10) {
            this.f26556q = i10;
            if (i10 == 3) {
                int i12 = 0;
                while (true) {
                    ArrayList<C0248a> arrayList = this.f26552m;
                    if (i12 < arrayList.size()) {
                        arrayList.get(i12).f26571g = i10;
                        i12++;
                    } else {
                        return;
                    }
                }
            } else {
                l();
                if (i11 == 3 || i10 == 1 || i10 == 0) {
                    this.f26554o = Collections.EMPTY_LIST;
                }
            }
        }
    }

    public final void release() {
    }
}
