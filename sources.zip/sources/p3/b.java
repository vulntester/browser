package p3;

import Pb.C4126p;
import android.text.Layout;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import f7.M;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import m8.F;
import n2.C2722a;
import o2.d;
import o2.n;
import o2.t;
import p3.c;

public final class b extends c {

    /* renamed from: h  reason: collision with root package name */
    public final t f26576h = new t();

    /* renamed from: i  reason: collision with root package name */
    public final U1.c f26577i = new U1.c(1);

    /* renamed from: j  reason: collision with root package name */
    public int f26578j = -1;

    /* renamed from: k  reason: collision with root package name */
    public final int f26579k;

    /* renamed from: l  reason: collision with root package name */
    public final C0250b[] f26580l;

    /* renamed from: m  reason: collision with root package name */
    public C0250b f26581m;

    /* renamed from: n  reason: collision with root package name */
    public List<C2722a> f26582n;

    /* renamed from: o  reason: collision with root package name */
    public List<C2722a> f26583o;

    /* renamed from: p  reason: collision with root package name */
    public c f26584p;

    /* renamed from: q  reason: collision with root package name */
    public int f26585q;

    public static final class a {

        /* renamed from: c  reason: collision with root package name */
        public static final F f26586c = new F(1);

        /* renamed from: a  reason: collision with root package name */
        public final C2722a f26587a;

        /* renamed from: b  reason: collision with root package name */
        public final int f26588b;

        public a(SpannableStringBuilder spannableStringBuilder, Layout.Alignment alignment, float f10, int i10, float f11, int i11, boolean z10, int i12, int i13) {
            C2722a.C0239a aVar = new C2722a.C0239a();
            aVar.f25621a = spannableStringBuilder;
            aVar.f25623c = alignment;
            aVar.f25625e = f10;
            aVar.f25626f = 0;
            aVar.f25627g = i10;
            aVar.f25628h = f11;
            aVar.f25629i = i11;
            aVar.f25632l = -3.4028235E38f;
            if (z10) {
                aVar.f25635o = i12;
                aVar.f25634n = true;
            }
            this.f26587a = aVar.a();
            this.f26588b = i13;
        }
    }

    /* renamed from: p3.b$b  reason: collision with other inner class name */
    public static final class C0250b {

        /* renamed from: A  reason: collision with root package name */
        public static final boolean[] f26589A = {false, false, false, true, true, true, false};

        /* renamed from: B  reason: collision with root package name */
        public static final int[] f26590B;

        /* renamed from: C  reason: collision with root package name */
        public static final int[] f26591C = {0, 1, 2, 3, 4, 3, 4};

        /* renamed from: D  reason: collision with root package name */
        public static final int[] f26592D = {0, 0, 0, 0, 0, 3, 3};

        /* renamed from: E  reason: collision with root package name */
        public static final int[] f26593E;

        /* renamed from: v  reason: collision with root package name */
        public static final int f26594v = c(2, 2, 2, 0);

        /* renamed from: w  reason: collision with root package name */
        public static final int f26595w;

        /* renamed from: x  reason: collision with root package name */
        public static final int[] f26596x = {0, 0, 0, 0, 0, 2, 0};

        /* renamed from: y  reason: collision with root package name */
        public static final int[] f26597y = {0, 0, 0, 0, 0, 0, 2};

        /* renamed from: z  reason: collision with root package name */
        public static final int[] f26598z = {3, 3, 3, 3, 3, 3, 1};

        /* renamed from: a  reason: collision with root package name */
        public final ArrayList f26599a = new ArrayList();

        /* renamed from: b  reason: collision with root package name */
        public final SpannableStringBuilder f26600b = new SpannableStringBuilder();

        /* renamed from: c  reason: collision with root package name */
        public boolean f26601c;

        /* renamed from: d  reason: collision with root package name */
        public boolean f26602d;

        /* renamed from: e  reason: collision with root package name */
        public int f26603e;

        /* renamed from: f  reason: collision with root package name */
        public boolean f26604f;

        /* renamed from: g  reason: collision with root package name */
        public int f26605g;

        /* renamed from: h  reason: collision with root package name */
        public int f26606h;

        /* renamed from: i  reason: collision with root package name */
        public int f26607i;

        /* renamed from: j  reason: collision with root package name */
        public int f26608j;

        /* renamed from: k  reason: collision with root package name */
        public int f26609k;

        /* renamed from: l  reason: collision with root package name */
        public int f26610l;

        /* renamed from: m  reason: collision with root package name */
        public int f26611m;

        /* renamed from: n  reason: collision with root package name */
        public int f26612n;

        /* renamed from: o  reason: collision with root package name */
        public int f26613o;

        /* renamed from: p  reason: collision with root package name */
        public int f26614p;

        /* renamed from: q  reason: collision with root package name */
        public int f26615q;

        /* renamed from: r  reason: collision with root package name */
        public int f26616r;

        /* renamed from: s  reason: collision with root package name */
        public int f26617s;

        /* renamed from: t  reason: collision with root package name */
        public int f26618t;

        /* renamed from: u  reason: collision with root package name */
        public int f26619u;

        static {
            int c10 = c(0, 0, 0, 0);
            f26595w = c10;
            int c11 = c(0, 0, 0, 3);
            int i10 = c10;
            int i11 = c10;
            f26590B = new int[]{c10, c11, i10, i11, c11, c10, c10};
            int i12 = c11;
            f26593E = new int[]{c10, c10, i10, i11, c10, i12, i12};
        }

        public C0250b() {
            d();
        }

        /* JADX WARNING: Removed duplicated region for block: B:11:0x0023  */
        /* JADX WARNING: Removed duplicated region for block: B:12:0x0025  */
        /* JADX WARNING: Removed duplicated region for block: B:14:0x0028  */
        /* JADX WARNING: Removed duplicated region for block: B:15:0x002a  */
        /* JADX WARNING: Removed duplicated region for block: B:17:0x002d  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public static int c(int r4, int r5, int r6, int r7) {
            /*
                r0 = 4
                f7.M.i(r4, r0)
                f7.M.i(r5, r0)
                f7.M.i(r6, r0)
                f7.M.i(r7, r0)
                r0 = 0
                r1 = 1
                r2 = 255(0xff, float:3.57E-43)
                if (r7 == 0) goto L_0x001b
                if (r7 == r1) goto L_0x001b
                r3 = 2
                if (r7 == r3) goto L_0x001f
                r3 = 3
                if (r7 == r3) goto L_0x001d
            L_0x001b:
                r7 = r2
                goto L_0x0021
            L_0x001d:
                r7 = r0
                goto L_0x0021
            L_0x001f:
                r7 = 127(0x7f, float:1.78E-43)
            L_0x0021:
                if (r4 <= r1) goto L_0x0025
                r4 = r2
                goto L_0x0026
            L_0x0025:
                r4 = r0
            L_0x0026:
                if (r5 <= r1) goto L_0x002a
                r5 = r2
                goto L_0x002b
            L_0x002a:
                r5 = r0
            L_0x002b:
                if (r6 <= r1) goto L_0x002e
                r0 = r2
            L_0x002e:
                int r4 = android.graphics.Color.argb(r7, r4, r5, r0)
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: p3.b.C0250b.c(int, int, int, int):int");
        }

        public final void a(char c10) {
            SpannableStringBuilder spannableStringBuilder = this.f26600b;
            if (c10 == 10) {
                ArrayList arrayList = this.f26599a;
                arrayList.add(b());
                spannableStringBuilder.clear();
                if (this.f26613o != -1) {
                    this.f26613o = 0;
                }
                if (this.f26614p != -1) {
                    this.f26614p = 0;
                }
                if (this.f26615q != -1) {
                    this.f26615q = 0;
                }
                if (this.f26617s != -1) {
                    this.f26617s = 0;
                }
                while (true) {
                    if (arrayList.size() >= this.f26608j || arrayList.size() >= 15) {
                        arrayList.remove(0);
                    } else {
                        this.f26619u = arrayList.size();
                        return;
                    }
                }
            } else {
                spannableStringBuilder.append(c10);
            }
        }

        public final SpannableString b() {
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(this.f26600b);
            int length = spannableStringBuilder.length();
            if (length > 0) {
                if (this.f26613o != -1) {
                    spannableStringBuilder.setSpan(new StyleSpan(2), this.f26613o, length, 33);
                }
                if (this.f26614p != -1) {
                    spannableStringBuilder.setSpan(new UnderlineSpan(), this.f26614p, length, 33);
                }
                if (this.f26615q != -1) {
                    spannableStringBuilder.setSpan(new ForegroundColorSpan(this.f26616r), this.f26615q, length, 33);
                }
                if (this.f26617s != -1) {
                    spannableStringBuilder.setSpan(new BackgroundColorSpan(this.f26618t), this.f26617s, length, 33);
                }
            }
            return new SpannableString(spannableStringBuilder);
        }

        public final void d() {
            this.f26599a.clear();
            this.f26600b.clear();
            this.f26613o = -1;
            this.f26614p = -1;
            this.f26615q = -1;
            this.f26617s = -1;
            this.f26619u = 0;
            this.f26601c = false;
            this.f26602d = false;
            this.f26603e = 4;
            this.f26604f = false;
            this.f26605g = 0;
            this.f26606h = 0;
            this.f26607i = 0;
            this.f26608j = 15;
            this.f26609k = 0;
            this.f26610l = 0;
            this.f26611m = 0;
            int i10 = f26595w;
            this.f26612n = i10;
            this.f26616r = f26594v;
            this.f26618t = i10;
        }

        public final void e(boolean z10, boolean z11) {
            int i10 = this.f26613o;
            SpannableStringBuilder spannableStringBuilder = this.f26600b;
            if (i10 != -1) {
                if (!z10) {
                    spannableStringBuilder.setSpan(new StyleSpan(2), this.f26613o, spannableStringBuilder.length(), 33);
                    this.f26613o = -1;
                }
            } else if (z10) {
                this.f26613o = spannableStringBuilder.length();
            }
            if (this.f26614p != -1) {
                if (!z11) {
                    spannableStringBuilder.setSpan(new UnderlineSpan(), this.f26614p, spannableStringBuilder.length(), 33);
                    this.f26614p = -1;
                }
            } else if (z11) {
                this.f26614p = spannableStringBuilder.length();
            }
        }

        public final void f(int i10, int i11) {
            int i12 = this.f26615q;
            SpannableStringBuilder spannableStringBuilder = this.f26600b;
            if (!(i12 == -1 || this.f26616r == i10)) {
                spannableStringBuilder.setSpan(new ForegroundColorSpan(this.f26616r), this.f26615q, spannableStringBuilder.length(), 33);
            }
            if (i10 != f26594v) {
                this.f26615q = spannableStringBuilder.length();
                this.f26616r = i10;
            }
            if (!(this.f26617s == -1 || this.f26618t == i11)) {
                spannableStringBuilder.setSpan(new BackgroundColorSpan(this.f26618t), this.f26617s, spannableStringBuilder.length(), 33);
            }
            if (i11 != f26595w) {
                this.f26617s = spannableStringBuilder.length();
                this.f26618t = i11;
            }
        }
    }

    public static final class c {

        /* renamed from: a  reason: collision with root package name */
        public final int f26620a;

        /* renamed from: b  reason: collision with root package name */
        public final int f26621b;

        /* renamed from: c  reason: collision with root package name */
        public final byte[] f26622c;

        /* renamed from: d  reason: collision with root package name */
        public int f26623d = 0;

        public c(int i10, int i11) {
            this.f26620a = i10;
            this.f26621b = i11;
            this.f26622c = new byte[((i11 * 2) - 1)];
        }
    }

    public b(int i10, List<byte[]> list) {
        this.f26579k = i10 == -1 ? 1 : i10;
        if (list != null) {
            byte[] bArr = d.f25832a;
            if (list.size() == 1 && list.get(0).length == 1) {
                byte b10 = list.get(0)[0];
            }
        }
        this.f26580l = new C0250b[8];
        for (int i11 = 0; i11 < 8; i11++) {
            this.f26580l[i11] = new C0250b();
        }
        this.f26581m = this.f26580l[0];
    }

    public final void flush() {
        super.flush();
        this.f26582n = null;
        this.f26583o = null;
        this.f26585q = 0;
        this.f26581m = this.f26580l[0];
        m();
        this.f26584p = null;
    }

    public final C4126p g() {
        List<C2722a> list = this.f26582n;
        this.f26583o = list;
        list.getClass();
        return new C4126p((Object) list);
    }

    public final void h(c.a aVar) {
        boolean z10;
        ByteBuffer byteBuffer = aVar.f27698E;
        byteBuffer.getClass();
        byte[] array = byteBuffer.array();
        int limit = byteBuffer.limit();
        t tVar = this.f26576h;
        tVar.E(limit, array);
        while (tVar.a() >= 3) {
            int u7 = tVar.u();
            int i10 = u7 & 3;
            boolean z11 = false;
            if ((u7 & 4) == 4) {
                z10 = true;
            } else {
                z10 = false;
            }
            byte u10 = (byte) tVar.u();
            byte u11 = (byte) tVar.u();
            if ((i10 == 2 || i10 == 3) && z10) {
                if (i10 == 3) {
                    k();
                    int i11 = (u10 & 192) >> 6;
                    int i12 = this.f26578j;
                    if (!(i12 == -1 || i11 == (i12 + 1) % 4)) {
                        m();
                        n.f("Cea708Decoder", "Sequence number discontinuity. previous=" + this.f26578j + " current=" + i11);
                    }
                    this.f26578j = i11;
                    byte b10 = u10 & 63;
                    if (b10 == 0) {
                        b10 = 64;
                    }
                    c cVar = new c(i11, b10);
                    this.f26584p = cVar;
                    cVar.f26623d = 1;
                    cVar.f26622c[0] = u11;
                } else {
                    if (i10 == 2) {
                        z11 = true;
                    }
                    M.h(z11);
                    c cVar2 = this.f26584p;
                    if (cVar2 == null) {
                        n.c("Cea708Decoder", "Encountered DTVCC_PACKET_DATA before DTVCC_PACKET_START");
                    } else {
                        byte[] bArr = cVar2.f26622c;
                        int i13 = cVar2.f26623d;
                        int i14 = i13 + 1;
                        cVar2.f26623d = i14;
                        bArr[i13] = u10;
                        cVar2.f26623d = i13 + 2;
                        bArr[i14] = u11;
                    }
                }
                c cVar3 = this.f26584p;
                if (cVar3.f26623d == (cVar3.f26621b * 2) - 1) {
                    k();
                }
            }
        }
    }

    public final boolean j() {
        if (this.f26582n != this.f26583o) {
            return true;
        }
        return false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:125:0x0354, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x014d, code lost:
        r4 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:0x014e, code lost:
        r11 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0206, code lost:
        r4 = false;
        r7 = 3;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void k() {
        /*
            r19 = this;
            r0 = r19
            p3.b$c r1 = r0.f26584p
            if (r1 != 0) goto L_0x0007
            return
        L_0x0007:
            int r2 = r1.f26623d
            int r1 = r1.f26621b
            r3 = 2
            int r1 = r1 * r3
            r4 = 1
            int r1 = r1 - r4
            java.lang.String r5 = "Cea708Decoder"
            if (r2 == r1) goto L_0x0047
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "DtvCcPacket ended prematurely; size is "
            r1.<init>(r2)
            p3.b$c r2 = r0.f26584p
            int r2 = r2.f26621b
            int r2 = r2 * r3
            int r2 = r2 - r4
            r1.append(r2)
            java.lang.String r2 = ", but current index is "
            r1.append(r2)
            p3.b$c r2 = r0.f26584p
            int r2 = r2.f26623d
            r1.append(r2)
            java.lang.String r2 = " (sequence number "
            r1.append(r2)
            p3.b$c r2 = r0.f26584p
            int r2 = r2.f26620a
            r1.append(r2)
            java.lang.String r2 = ");"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            o2.n.b(r5, r1)
        L_0x0047:
            p3.b$c r1 = r0.f26584p
            byte[] r2 = r1.f26622c
            int r1 = r1.f26623d
            U1.c r6 = r0.f26577i
            r6.l(r1, r2)
            r2 = 0
        L_0x0053:
            int r7 = r6.c()
            if (r7 <= 0) goto L_0x0537
            r7 = 3
            int r8 = r6.h(r7)
            r9 = 5
            int r9 = r6.h(r9)
            r10 = 6
            r11 = 7
            if (r8 != r11) goto L_0x0075
            r6.p(r3)
            int r8 = r6.h(r10)
            if (r8 >= r11) goto L_0x0075
            java.lang.String r12 = "Invalid extended service number: "
            A6.u.r(r8, r12, r5)
        L_0x0075:
            if (r9 != 0) goto L_0x0091
            if (r8 == 0) goto L_0x0537
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r3 = "serviceNumber is non-zero ("
            r1.<init>(r3)
            r1.append(r8)
            java.lang.String r3 = ") when blockSize is 0"
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            o2.n.f(r5, r1)
            goto L_0x0537
        L_0x0091:
            int r12 = r0.f26579k
            if (r8 == r12) goto L_0x0099
            r6.q(r9)
            goto L_0x0053
        L_0x0099:
            int r8 = r6.f()
            int r9 = r9 * 8
            int r9 = r9 + r8
        L_0x00a0:
            int r8 = r6.f()
            if (r8 >= r9) goto L_0x0053
            r8 = 8
            int r12 = r6.h(r8)
            r15 = 23
            r13 = 159(0x9f, float:2.23E-43)
            r1 = 127(0x7f, float:1.78E-43)
            r14 = 24
            r4 = 31
            r10 = 16
            if (r12 == r10) goto L_0x03ac
            r11 = 10
            if (r12 > r4) goto L_0x0123
            if (r12 == 0) goto L_0x0121
            if (r12 == r7) goto L_0x011b
            if (r12 == r8) goto L_0x010b
            switch(r12) {
                case 12: goto L_0x0107;
                case 13: goto L_0x0101;
                case 14: goto L_0x0121;
                default: goto L_0x00c7;
            }
        L_0x00c7:
            r1 = 17
            if (r12 < r1) goto L_0x00e2
            if (r12 > r15) goto L_0x00e2
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r4 = "Currently unsupported COMMAND_EXT1 Command: "
            r1.<init>(r4)
            r1.append(r12)
            java.lang.String r1 = r1.toString()
            o2.n.f(r5, r1)
            r6.p(r8)
            goto L_0x0121
        L_0x00e2:
            if (r12 < r14) goto L_0x00fb
            if (r12 > r4) goto L_0x00fb
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r4 = "Currently unsupported COMMAND_P16 Command: "
            r1.<init>(r4)
            r1.append(r12)
            java.lang.String r1 = r1.toString()
            o2.n.f(r5, r1)
            r6.p(r10)
            goto L_0x0121
        L_0x00fb:
            java.lang.String r1 = "Invalid C0 command: "
            A6.u.r(r12, r1, r5)
            goto L_0x0121
        L_0x0101:
            p3.b$b r1 = r0.f26581m
            r1.a(r11)
            goto L_0x0121
        L_0x0107:
            r0.m()
            goto L_0x0121
        L_0x010b:
            p3.b$b r1 = r0.f26581m
            android.text.SpannableStringBuilder r1 = r1.f26600b
            int r4 = r1.length()
            if (r4 <= 0) goto L_0x0121
            int r8 = r4 + -1
            r1.delete(r8, r4)
            goto L_0x0121
        L_0x011b:
            java.util.List r1 = r0.l()
            r0.f26582n = r1
        L_0x0121:
            r1 = r3
            goto L_0x0139
        L_0x0123:
            if (r12 > r1) goto L_0x0140
            if (r12 != r1) goto L_0x012f
            p3.b$b r1 = r0.f26581m
            r2 = 9835(0x266b, float:1.3782E-41)
            r1.a(r2)
            goto L_0x0137
        L_0x012f:
            p3.b$b r1 = r0.f26581m
            r2 = r12 & 255(0xff, float:3.57E-43)
            char r2 = (char) r2
            r1.a(r2)
        L_0x0137:
            r1 = r3
            r2 = 1
        L_0x0139:
            r10 = 6
            r11 = 1
            r12 = 7
            r17 = 0
            goto L_0x0532
        L_0x0140:
            if (r12 > r13) goto L_0x0395
            r1 = 4
            p3.b$b[] r2 = r0.f26580l
            switch(r12) {
                case 128: goto L_0x037f;
                case 129: goto L_0x037f;
                case 130: goto L_0x037f;
                case 131: goto L_0x037f;
                case 132: goto L_0x037f;
                case 133: goto L_0x037f;
                case 134: goto L_0x037f;
                case 135: goto L_0x037f;
                case 136: goto L_0x0356;
                case 137: goto L_0x033e;
                case 138: goto L_0x032b;
                case 139: goto L_0x0313;
                case 140: goto L_0x0300;
                case 141: goto L_0x02fb;
                case 142: goto L_0x014d;
                case 143: goto L_0x02f6;
                case 144: goto L_0x02cb;
                case 145: goto L_0x027d;
                case 146: goto L_0x0258;
                case 147: goto L_0x0148;
                case 148: goto L_0x0148;
                case 149: goto L_0x0148;
                case 150: goto L_0x0148;
                case 151: goto L_0x020a;
                case 152: goto L_0x0151;
                case 153: goto L_0x0151;
                case 154: goto L_0x0151;
                case 155: goto L_0x0151;
                case 156: goto L_0x0151;
                case 157: goto L_0x0151;
                case 158: goto L_0x0151;
                case 159: goto L_0x0151;
                default: goto L_0x0148;
            }
        L_0x0148:
            java.lang.String r1 = "Invalid C1 command: "
            A6.u.r(r12, r1, r5)
        L_0x014d:
            r4 = 0
        L_0x014e:
            r11 = 1
            goto L_0x038d
        L_0x0151:
            int r12 = r12 + -152
            r4 = r2[r12]
            r6.p(r3)
            boolean r10 = r6.g()
            r6.p(r3)
            int r11 = r6.h(r7)
            boolean r13 = r6.g()
            r14 = 7
            int r15 = r6.h(r14)
            int r8 = r6.h(r8)
            int r14 = r6.h(r1)
            int r1 = r6.h(r1)
            r6.p(r3)
            r7 = 6
            r6.p(r7)
            r6.p(r3)
            r7 = 3
            int r3 = r6.h(r7)
            r16 = r1
            int r1 = r6.h(r7)
            r7 = 1
            r4.f26601c = r7
            r4.f26602d = r10
            r4.f26603e = r11
            r4.f26604f = r13
            r4.f26605g = r15
            r4.f26606h = r8
            r4.f26607i = r14
            int r8 = r4.f26608j
            int r10 = r16 + 1
            if (r8 == r10) goto L_0x01bb
            r4.f26608j = r10
        L_0x01a4:
            java.util.ArrayList r7 = r4.f26599a
            int r8 = r7.size()
            int r10 = r4.f26608j
            if (r8 >= r10) goto L_0x01b6
            int r8 = r7.size()
            r10 = 15
            if (r8 < r10) goto L_0x01bb
        L_0x01b6:
            r8 = 0
            r7.remove(r8)
            goto L_0x01a4
        L_0x01bb:
            if (r3 == 0) goto L_0x01dd
            int r7 = r4.f26610l
            if (r7 == r3) goto L_0x01dd
            r4.f26610l = r3
            int r3 = r3 + -1
            int[] r7 = p3.b.C0250b.f26590B
            r7 = r7[r3]
            boolean[] r8 = p3.b.C0250b.f26589A
            boolean r8 = r8[r3]
            int[] r8 = p3.b.C0250b.f26597y
            r8 = r8[r3]
            int[] r8 = p3.b.C0250b.f26598z
            r8 = r8[r3]
            int[] r8 = p3.b.C0250b.f26596x
            r3 = r8[r3]
            r4.f26612n = r7
            r4.f26609k = r3
        L_0x01dd:
            if (r1 == 0) goto L_0x01fc
            int r3 = r4.f26611m
            if (r3 == r1) goto L_0x01fc
            r4.f26611m = r1
            int r1 = r1 + -1
            int[] r3 = p3.b.C0250b.f26592D
            r3 = r3[r1]
            int[] r3 = p3.b.C0250b.f26591C
            r3 = r3[r1]
            r8 = 0
            r4.e(r8, r8)
            int[] r3 = p3.b.C0250b.f26593E
            r1 = r3[r1]
            int r3 = p3.b.C0250b.f26594v
            r4.f(r3, r1)
        L_0x01fc:
            int r1 = r0.f26585q
            if (r1 == r12) goto L_0x0206
            r0.f26585q = r12
            r1 = r2[r12]
            r0.f26581m = r1
        L_0x0206:
            r4 = 0
            r7 = 3
            goto L_0x014e
        L_0x020a:
            p3.b$b r1 = r0.f26581m
            boolean r1 = r1.f26601c
            if (r1 != 0) goto L_0x0216
            r1 = 32
            r6.p(r1)
            goto L_0x0206
        L_0x0216:
            r1 = 2
            int r2 = r6.h(r1)
            int r3 = r6.h(r1)
            int r4 = r6.h(r1)
            int r7 = r6.h(r1)
            int r2 = p3.b.C0250b.c(r3, r4, r7, r2)
            r6.h(r1)
            int r3 = r6.h(r1)
            int r4 = r6.h(r1)
            int r7 = r6.h(r1)
            r10 = 0
            p3.b.C0250b.c(r3, r4, r7, r10)
            r6.g()
            r6.g()
            r6.h(r1)
            r6.h(r1)
            int r3 = r6.h(r1)
            r6.p(r8)
            p3.b$b r1 = r0.f26581m
            r1.f26612n = r2
            r1.f26609k = r3
            goto L_0x0206
        L_0x0258:
            p3.b$b r2 = r0.f26581m
            boolean r2 = r2.f26601c
            if (r2 != 0) goto L_0x0262
            r6.p(r10)
            goto L_0x0206
        L_0x0262:
            r6.p(r1)
            int r1 = r6.h(r1)
            r2 = 2
            r6.p(r2)
            r7 = 6
            r6.h(r7)
            p3.b$b r2 = r0.f26581m
            int r3 = r2.f26619u
            if (r3 == r1) goto L_0x027a
            r2.a(r11)
        L_0x027a:
            r2.f26619u = r1
            goto L_0x0206
        L_0x027d:
            p3.b$b r1 = r0.f26581m
            boolean r1 = r1.f26601c
            if (r1 != 0) goto L_0x0288
            r6.p(r14)
            goto L_0x0206
        L_0x0288:
            r1 = 2
            int r2 = r6.h(r1)
            int r3 = r6.h(r1)
            int r4 = r6.h(r1)
            int r7 = r6.h(r1)
            int r2 = p3.b.C0250b.c(r3, r4, r7, r2)
            int r3 = r6.h(r1)
            int r4 = r6.h(r1)
            int r7 = r6.h(r1)
            int r8 = r6.h(r1)
            int r3 = p3.b.C0250b.c(r4, r7, r8, r3)
            r6.p(r1)
            int r4 = r6.h(r1)
            int r7 = r6.h(r1)
            int r8 = r6.h(r1)
            r10 = 0
            p3.b.C0250b.c(r4, r7, r8, r10)
            p3.b$b r1 = r0.f26581m
            r1.f(r2, r3)
            goto L_0x0206
        L_0x02cb:
            p3.b$b r2 = r0.f26581m
            boolean r2 = r2.f26601c
            if (r2 != 0) goto L_0x02d6
            r6.p(r10)
            goto L_0x0206
        L_0x02d6:
            r6.h(r1)
            r1 = 2
            r6.h(r1)
            r6.h(r1)
            boolean r1 = r6.g()
            boolean r2 = r6.g()
            r7 = 3
            r6.h(r7)
            r6.h(r7)
            p3.b$b r3 = r0.f26581m
            r3.e(r1, r2)
            goto L_0x014d
        L_0x02f6:
            r0.m()
            goto L_0x014d
        L_0x02fb:
            r6.p(r8)
            goto L_0x014d
        L_0x0300:
            r1 = 1
        L_0x0301:
            if (r1 > r8) goto L_0x014d
            boolean r3 = r6.g()
            if (r3 == 0) goto L_0x0310
            int r3 = 8 - r1
            r3 = r2[r3]
            r3.d()
        L_0x0310:
            int r1 = r1 + 1
            goto L_0x0301
        L_0x0313:
            r1 = 1
        L_0x0314:
            if (r1 > r8) goto L_0x014d
            boolean r3 = r6.g()
            if (r3 == 0) goto L_0x0328
            int r3 = 8 - r1
            r3 = r2[r3]
            boolean r4 = r3.f26602d
            r18 = 1
            r4 = r4 ^ 1
            r3.f26602d = r4
        L_0x0328:
            int r1 = r1 + 1
            goto L_0x0314
        L_0x032b:
            r1 = 1
        L_0x032c:
            if (r1 > r8) goto L_0x014d
            boolean r3 = r6.g()
            if (r3 == 0) goto L_0x033b
            int r3 = 8 - r1
            r3 = r2[r3]
            r10 = 0
            r3.f26602d = r10
        L_0x033b:
            int r1 = r1 + 1
            goto L_0x032c
        L_0x033e:
            r1 = 1
        L_0x033f:
            if (r1 > r8) goto L_0x0353
            boolean r3 = r6.g()
            if (r3 == 0) goto L_0x034f
            int r3 = 8 - r1
            r3 = r2[r3]
            r11 = 1
            r3.f26602d = r11
            goto L_0x0350
        L_0x034f:
            r11 = 1
        L_0x0350:
            int r1 = r1 + 1
            goto L_0x033f
        L_0x0353:
            r11 = 1
        L_0x0354:
            r4 = 0
            goto L_0x038d
        L_0x0356:
            r11 = 1
            r1 = r11
        L_0x0358:
            if (r1 > r8) goto L_0x0354
            boolean r3 = r6.g()
            if (r3 == 0) goto L_0x037b
            int r3 = 8 - r1
            r3 = r2[r3]
            java.util.ArrayList r4 = r3.f26599a
            r4.clear()
            android.text.SpannableStringBuilder r4 = r3.f26600b
            r4.clear()
            r4 = -1
            r3.f26613o = r4
            r3.f26614p = r4
            r3.f26615q = r4
            r3.f26617s = r4
            r4 = 0
            r3.f26619u = r4
            goto L_0x037c
        L_0x037b:
            r4 = 0
        L_0x037c:
            int r1 = r1 + 1
            goto L_0x0358
        L_0x037f:
            r4 = 0
            r11 = 1
            int r12 = r12 + -128
            int r1 = r0.f26585q
            if (r1 == r12) goto L_0x038d
            r0.f26585q = r12
            r1 = r2[r12]
            r0.f26581m = r1
        L_0x038d:
            r17 = r4
            r2 = r11
        L_0x0390:
            r1 = 2
            r10 = 6
            r12 = 7
            goto L_0x0532
        L_0x0395:
            r1 = 255(0xff, float:3.57E-43)
            r4 = 0
            r11 = 1
            if (r12 > r1) goto L_0x03a4
            p3.b$b r1 = r0.f26581m
            r2 = r12 & 255(0xff, float:3.57E-43)
            char r2 = (char) r2
            r1.a(r2)
            goto L_0x038d
        L_0x03a4:
            java.lang.String r1 = "Invalid base command: "
            A6.u.r(r12, r1, r5)
            r17 = r4
            goto L_0x0390
        L_0x03ac:
            r11 = 1
            r17 = 0
            int r3 = r6.h(r8)
            if (r3 > r4) goto L_0x03d1
            r12 = 7
            if (r3 > r12) goto L_0x03ba
            goto L_0x04e6
        L_0x03ba:
            r1 = 15
            if (r3 > r1) goto L_0x03c3
            r6.p(r8)
            goto L_0x04e6
        L_0x03c3:
            if (r3 > r15) goto L_0x03ca
            r6.p(r10)
            goto L_0x04e6
        L_0x03ca:
            if (r3 > r4) goto L_0x04e6
            r6.p(r14)
            goto L_0x04e6
        L_0x03d1:
            r12 = 7
            r4 = 160(0xa0, float:2.24E-43)
            if (r3 > r1) goto L_0x04e9
            r1 = 32
            if (r3 == r1) goto L_0x04de
            r1 = 33
            if (r3 == r1) goto L_0x04d8
            r1 = 37
            if (r3 == r1) goto L_0x04d0
            r1 = 42
            if (r3 == r1) goto L_0x04c8
            r1 = 44
            if (r3 == r1) goto L_0x04c0
            r1 = 63
            if (r3 == r1) goto L_0x04b8
            r1 = 57
            if (r3 == r1) goto L_0x04b0
            r1 = 58
            if (r3 == r1) goto L_0x04a8
            r1 = 60
            if (r3 == r1) goto L_0x04a0
            r1 = 61
            if (r3 == r1) goto L_0x0498
            switch(r3) {
                case 48: goto L_0x0490;
                case 49: goto L_0x0488;
                case 50: goto L_0x0480;
                case 51: goto L_0x0477;
                case 52: goto L_0x046e;
                case 53: goto L_0x0465;
                default: goto L_0x0401;
            }
        L_0x0401:
            switch(r3) {
                case 118: goto L_0x045c;
                case 119: goto L_0x0453;
                case 120: goto L_0x044a;
                case 121: goto L_0x0441;
                case 122: goto L_0x0438;
                case 123: goto L_0x042f;
                case 124: goto L_0x0426;
                case 125: goto L_0x041d;
                case 126: goto L_0x0414;
                case 127: goto L_0x040b;
                default: goto L_0x0404;
            }
        L_0x0404:
            java.lang.String r1 = "Invalid G2 character: "
            A6.u.r(r3, r1, r5)
            goto L_0x04e5
        L_0x040b:
            p3.b$b r1 = r0.f26581m
            r2 = 9484(0x250c, float:1.329E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0414:
            p3.b$b r1 = r0.f26581m
            r2 = 9496(0x2518, float:1.3307E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x041d:
            p3.b$b r1 = r0.f26581m
            r2 = 9472(0x2500, float:1.3273E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0426:
            p3.b$b r1 = r0.f26581m
            r2 = 9492(0x2514, float:1.3301E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x042f:
            p3.b$b r1 = r0.f26581m
            r2 = 9488(0x2510, float:1.3296E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0438:
            p3.b$b r1 = r0.f26581m
            r2 = 9474(0x2502, float:1.3276E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0441:
            p3.b$b r1 = r0.f26581m
            r2 = 8542(0x215e, float:1.197E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x044a:
            p3.b$b r1 = r0.f26581m
            r2 = 8541(0x215d, float:1.1968E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0453:
            p3.b$b r1 = r0.f26581m
            r2 = 8540(0x215c, float:1.1967E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x045c:
            p3.b$b r1 = r0.f26581m
            r2 = 8539(0x215b, float:1.1966E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0465:
            p3.b$b r1 = r0.f26581m
            r2 = 8226(0x2022, float:1.1527E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x046e:
            p3.b$b r1 = r0.f26581m
            r2 = 8221(0x201d, float:1.152E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0477:
            p3.b$b r1 = r0.f26581m
            r2 = 8220(0x201c, float:1.1519E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0480:
            p3.b$b r1 = r0.f26581m
            r2 = 8217(0x2019, float:1.1514E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0488:
            p3.b$b r1 = r0.f26581m
            r2 = 8216(0x2018, float:1.1513E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0490:
            p3.b$b r1 = r0.f26581m
            r2 = 9608(0x2588, float:1.3464E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x0498:
            p3.b$b r1 = r0.f26581m
            r2 = 8480(0x2120, float:1.1883E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x04a0:
            p3.b$b r1 = r0.f26581m
            r2 = 339(0x153, float:4.75E-43)
            r1.a(r2)
            goto L_0x04e5
        L_0x04a8:
            p3.b$b r1 = r0.f26581m
            r2 = 353(0x161, float:4.95E-43)
            r1.a(r2)
            goto L_0x04e5
        L_0x04b0:
            p3.b$b r1 = r0.f26581m
            r2 = 8482(0x2122, float:1.1886E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x04b8:
            p3.b$b r1 = r0.f26581m
            r2 = 376(0x178, float:5.27E-43)
            r1.a(r2)
            goto L_0x04e5
        L_0x04c0:
            p3.b$b r1 = r0.f26581m
            r2 = 338(0x152, float:4.74E-43)
            r1.a(r2)
            goto L_0x04e5
        L_0x04c8:
            p3.b$b r1 = r0.f26581m
            r2 = 352(0x160, float:4.93E-43)
            r1.a(r2)
            goto L_0x04e5
        L_0x04d0:
            p3.b$b r1 = r0.f26581m
            r2 = 8230(0x2026, float:1.1533E-41)
            r1.a(r2)
            goto L_0x04e5
        L_0x04d8:
            p3.b$b r1 = r0.f26581m
            r1.a(r4)
            goto L_0x04e5
        L_0x04de:
            p3.b$b r1 = r0.f26581m
            r10 = 32
            r1.a(r10)
        L_0x04e5:
            r2 = r11
        L_0x04e6:
            r1 = 2
            r10 = 6
            goto L_0x0532
        L_0x04e9:
            r10 = 32
            if (r3 > r13) goto L_0x050f
            r1 = 135(0x87, float:1.89E-43)
            if (r3 > r1) goto L_0x04f5
            r6.p(r10)
            goto L_0x04e6
        L_0x04f5:
            r1 = 143(0x8f, float:2.0E-43)
            if (r3 > r1) goto L_0x04ff
            r1 = 40
            r6.p(r1)
            goto L_0x04e6
        L_0x04ff:
            if (r3 > r13) goto L_0x04e6
            r1 = 2
            r6.p(r1)
            r10 = 6
            int r3 = r6.h(r10)
            int r3 = r3 * r8
            r6.p(r3)
            goto L_0x0532
        L_0x050f:
            r1 = 2
            r8 = 255(0xff, float:3.57E-43)
            r10 = 6
            if (r3 > r8) goto L_0x052d
            if (r3 != r4) goto L_0x051f
            p3.b$b r2 = r0.f26581m
            r3 = 13252(0x33c4, float:1.857E-41)
            r2.a(r3)
            goto L_0x052b
        L_0x051f:
            java.lang.String r2 = "Invalid G3 character: "
            A6.u.r(r3, r2, r5)
            p3.b$b r2 = r0.f26581m
            r3 = 95
            r2.a(r3)
        L_0x052b:
            r2 = r11
            goto L_0x0532
        L_0x052d:
            java.lang.String r4 = "Invalid extended command: "
            A6.u.r(r3, r4, r5)
        L_0x0532:
            r3 = r1
            r4 = r11
            r11 = r12
            goto L_0x00a0
        L_0x0537:
            if (r2 == 0) goto L_0x053f
            java.util.List r1 = r0.l()
            r0.f26582n = r1
        L_0x053f:
            r1 = 0
            r0.f26584p = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p3.b.k():void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:35:0x0099  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00a4  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00c2  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00c5  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00d0  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00d2  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00dd  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x00df  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x00ee  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x00f1 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.util.List<n2.C2722a> l() {
        /*
            r17 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r1 = 0
            r2 = r1
        L_0x0007:
            r3 = 8
            if (r2 >= r3) goto L_0x00f5
            r3 = r17
            p3.b$b[] r4 = r3.f26580l
            r5 = r4[r2]
            boolean r6 = r5.f26601c
            if (r6 == 0) goto L_0x00f1
            java.util.ArrayList r6 = r5.f26599a
            boolean r6 = r6.isEmpty()
            if (r6 == 0) goto L_0x0027
            android.text.SpannableStringBuilder r5 = r5.f26600b
            int r5 = r5.length()
            if (r5 != 0) goto L_0x0027
            goto L_0x00f1
        L_0x0027:
            r4 = r4[r2]
            boolean r5 = r4.f26602d
            if (r5 == 0) goto L_0x00f1
            boolean r5 = r4.f26601c
            if (r5 == 0) goto L_0x00eb
            java.util.ArrayList r5 = r4.f26599a
            boolean r6 = r5.isEmpty()
            if (r6 == 0) goto L_0x0043
            android.text.SpannableStringBuilder r6 = r4.f26600b
            int r6 = r6.length()
            if (r6 != 0) goto L_0x0043
            goto L_0x00eb
        L_0x0043:
            android.text.SpannableStringBuilder r8 = new android.text.SpannableStringBuilder
            r8.<init>()
            r6 = r1
        L_0x0049:
            int r7 = r5.size()
            if (r6 >= r7) goto L_0x0060
            java.lang.Object r7 = r5.get(r6)
            java.lang.CharSequence r7 = (java.lang.CharSequence) r7
            r8.append(r7)
            r7 = 10
            r8.append(r7)
            int r6 = r6 + 1
            goto L_0x0049
        L_0x0060:
            android.text.SpannableString r5 = r4.b()
            r8.append(r5)
            int r5 = r4.f26609k
            r6 = 1
            r7 = 2
            if (r5 == 0) goto L_0x0092
            if (r5 == r6) goto L_0x008f
            if (r5 == r7) goto L_0x008b
            r9 = 3
            if (r5 != r9) goto L_0x0075
            goto L_0x0092
        L_0x0075:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Unexpected justification value: "
            r1.<init>(r2)
            int r2 = r4.f26609k
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x008b:
            android.text.Layout$Alignment r5 = android.text.Layout.Alignment.ALIGN_CENTER
        L_0x008d:
            r9 = r5
            goto L_0x0095
        L_0x008f:
            android.text.Layout$Alignment r5 = android.text.Layout.Alignment.ALIGN_OPPOSITE
            goto L_0x008d
        L_0x0092:
            android.text.Layout$Alignment r5 = android.text.Layout.Alignment.ALIGN_NORMAL
            goto L_0x008d
        L_0x0095:
            boolean r5 = r4.f26604f
            if (r5 == 0) goto L_0x00a4
            int r5 = r4.f26606h
            float r5 = (float) r5
            r10 = 1120272384(0x42c60000, float:99.0)
            float r5 = r5 / r10
            int r11 = r4.f26605g
            float r11 = (float) r11
            float r11 = r11 / r10
            goto L_0x00b1
        L_0x00a4:
            int r5 = r4.f26606h
            float r5 = (float) r5
            r10 = 1129381888(0x43510000, float:209.0)
            float r5 = r5 / r10
            int r10 = r4.f26605g
            float r10 = (float) r10
            r11 = 1116995584(0x42940000, float:74.0)
            float r11 = r10 / r11
        L_0x00b1:
            r10 = 1063675494(0x3f666666, float:0.9)
            float r5 = r5 * r10
            r12 = 1028443341(0x3d4ccccd, float:0.05)
            float r5 = r5 + r12
            float r11 = r11 * r10
            float r10 = r11 + r12
            int r11 = r4.f26607i
            int r12 = r11 / 3
            if (r12 != 0) goto L_0x00c5
            r12 = r11
            r11 = r1
            goto L_0x00cc
        L_0x00c5:
            if (r12 != r6) goto L_0x00ca
            r12 = r11
            r11 = r6
            goto L_0x00cc
        L_0x00ca:
            r12 = r11
            r11 = r7
        L_0x00cc:
            int r12 = r12 % 3
            if (r12 != 0) goto L_0x00d2
            r13 = r1
            goto L_0x00d7
        L_0x00d2:
            if (r12 != r6) goto L_0x00d6
            r13 = r6
            goto L_0x00d7
        L_0x00d6:
            r13 = r7
        L_0x00d7:
            int r15 = r4.f26612n
            int r7 = p3.b.C0250b.f26595w
            if (r15 == r7) goto L_0x00df
            r14 = r6
            goto L_0x00e0
        L_0x00df:
            r14 = r1
        L_0x00e0:
            p3.b$a r7 = new p3.b$a
            int r4 = r4.f26603e
            r16 = r4
            r12 = r5
            r7.<init>(r8, r9, r10, r11, r12, r13, r14, r15, r16)
            goto L_0x00ec
        L_0x00eb:
            r7 = 0
        L_0x00ec:
            if (r7 == 0) goto L_0x00f1
            r0.add(r7)
        L_0x00f1:
            int r2 = r2 + 1
            goto L_0x0007
        L_0x00f5:
            r3 = r17
            m8.F r2 = p3.b.a.f26586c
            java.util.Collections.sort(r0, r2)
            java.util.ArrayList r2 = new java.util.ArrayList
            int r4 = r0.size()
            r2.<init>(r4)
        L_0x0105:
            int r4 = r0.size()
            if (r1 >= r4) goto L_0x0119
            java.lang.Object r4 = r0.get(r1)
            p3.b$a r4 = (p3.b.a) r4
            n2.a r4 = r4.f26587a
            r2.add(r4)
            int r1 = r1 + 1
            goto L_0x0105
        L_0x0119:
            java.util.List r0 = java.util.Collections.unmodifiableList(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p3.b.l():java.util.List");
    }

    public final void m() {
        for (int i10 = 0; i10 < 8; i10++) {
            this.f26580l[i10].d();
        }
    }
}
