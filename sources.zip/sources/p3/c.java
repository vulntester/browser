package p3;

import Pb.C4126p;
import f7.M;
import java.util.ArrayDeque;
import o2.C2756B;
import o3.C2767i;
import o3.C2770l;
import o3.C2771m;

public abstract class c implements C2767i {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayDeque<a> f26624a = new ArrayDeque<>();

    /* renamed from: b  reason: collision with root package name */
    public final ArrayDeque<C2771m> f26625b;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayDeque<a> f26626c;

    /* renamed from: d  reason: collision with root package name */
    public a f26627d;

    /* renamed from: e  reason: collision with root package name */
    public long f26628e;

    /* renamed from: f  reason: collision with root package name */
    public long f26629f;

    /* renamed from: g  reason: collision with root package name */
    public long f26630g;

    public static final class a extends C2770l implements Comparable<a> {

        /* renamed from: K  reason: collision with root package name */
        public long f26631K;

        public final int compareTo(Object obj) {
            a aVar = (a) obj;
            if (i(4) == aVar.i(4)) {
                long j10 = this.f27700G - aVar.f27700G;
                if (j10 == 0) {
                    j10 = this.f26631K - aVar.f26631K;
                    if (j10 == 0) {
                        return 0;
                    }
                }
                if (j10 > 0) {
                    return 1;
                }
                return -1;
            } else if (i(4)) {
                return 1;
            } else {
                return -1;
            }
        }
    }

    public static final class b extends C2771m {

        /* renamed from: G  reason: collision with root package name */
        public Gc.a f26632G;

        public final void k() {
            c cVar = (c) this.f26632G.f35367i;
            cVar.getClass();
            j();
            cVar.f26625b.add(this);
        }
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [o3.m, p3.c$b, java.lang.Object] */
    public c() {
        for (int i10 = 0; i10 < 10; i10++) {
            this.f26624a.add(new a());
        }
        this.f26625b = new ArrayDeque<>();
        for (int i11 = 0; i11 < 2; i11++) {
            ArrayDeque<C2771m> arrayDeque = this.f26625b;
            Gc.a aVar = new Gc.a(this, 5);
            ? mVar = new C2771m();
            mVar.f26632G = aVar;
            arrayDeque.add(mVar);
        }
        this.f26626c = new ArrayDeque<>();
        this.f26630g = -9223372036854775807L;
    }

    public final void a(long j10) {
        this.f26630g = j10;
    }

    public final void c(long j10) {
        this.f26628e = j10;
    }

    public final Object e() {
        boolean z10;
        if (this.f26627d == null) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.m(z10);
        ArrayDeque<a> arrayDeque = this.f26624a;
        if (arrayDeque.isEmpty()) {
            return null;
        }
        a pollFirst = arrayDeque.pollFirst();
        this.f26627d = pollFirst;
        return pollFirst;
    }

    public final void f(C2770l lVar) {
        boolean z10;
        if (lVar == this.f26627d) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.h(z10);
        a aVar = (a) lVar;
        if (!aVar.i(4)) {
            long j10 = aVar.f27700G;
            if (j10 != Long.MIN_VALUE) {
                long j11 = this.f26630g;
                if (j11 != -9223372036854775807L && j10 < j11) {
                    aVar.j();
                    this.f26624a.add(aVar);
                    this.f26627d = null;
                }
            }
        }
        long j12 = this.f26629f;
        this.f26629f = 1 + j12;
        aVar.f26631K = j12;
        this.f26626c.add(aVar);
        this.f26627d = null;
    }

    public void flush() {
        ArrayDeque<a> arrayDeque;
        this.f26629f = 0;
        this.f26628e = 0;
        while (true) {
            ArrayDeque<a> arrayDeque2 = this.f26626c;
            boolean isEmpty = arrayDeque2.isEmpty();
            arrayDeque = this.f26624a;
            if (isEmpty) {
                break;
            }
            a poll = arrayDeque2.poll();
            int i10 = C2756B.f25811a;
            poll.j();
            arrayDeque.add(poll);
        }
        a aVar = this.f26627d;
        if (aVar != null) {
            aVar.j();
            arrayDeque.add(aVar);
            this.f26627d = null;
        }
    }

    public abstract C4126p g();

    public abstract void h(a aVar);

    /* renamed from: i */
    public C2771m d() {
        ArrayDeque<C2771m> arrayDeque = this.f26625b;
        if (arrayDeque.isEmpty()) {
            return null;
        }
        while (true) {
            ArrayDeque<a> arrayDeque2 = this.f26626c;
            if (arrayDeque2.isEmpty()) {
                return null;
            }
            int i10 = C2756B.f25811a;
            if (arrayDeque2.peek().f27700G > this.f26628e) {
                return null;
            }
            a poll = arrayDeque2.poll();
            boolean i11 = poll.i(4);
            ArrayDeque<a> arrayDeque3 = this.f26624a;
            if (i11) {
                C2771m pollFirst = arrayDeque.pollFirst();
                pollFirst.g(4);
                poll.j();
                arrayDeque3.add(poll);
                return pollFirst;
            }
            h(poll);
            if (j()) {
                C4126p g6 = g();
                C2771m pollFirst2 = arrayDeque.pollFirst();
                long j10 = poll.f27700G;
                pollFirst2.f27705i = j10;
                pollFirst2.f25923E = g6;
                pollFirst2.f25924F = j10;
                poll.j();
                arrayDeque3.add(poll);
                return pollFirst2;
            }
            poll.j();
            arrayDeque3.add(poll);
        }
    }

    public abstract boolean j();

    public void release() {
    }
}
