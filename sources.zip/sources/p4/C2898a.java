package p4;

import C0.e;
import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import androidx.work.impl.background.systemjob.SystemJobService;
import l4.C2640i;

@SuppressLint({"ClassVerificationFailure"})
/* renamed from: p4.a  reason: case insensitive filesystem */
public final class C2898a {

    /* renamed from: c  reason: collision with root package name */
    public static final String f26633c = C2640i.f("SystemJobInfoConverter");

    /* renamed from: a  reason: collision with root package name */
    public final ComponentName f26634a;

    /* renamed from: b  reason: collision with root package name */
    public final e f26635b;

    public C2898a(Context context, e eVar) {
        this.f26635b = eVar;
        this.f26634a = new ComponentName(context.getApplicationContext(), SystemJobService.class);
    }
}
