package p4;

import S6.b;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.PersistableBundle;
import androidx.work.a;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemjob.SystemJobService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.internal.l;
import l4.C2640i;
import l4.C2646o;
import m4.s;
import u4.C3218h;
import u4.C3223m;
import u4.v;
import v4.C3329h;

/* renamed from: p4.b  reason: case insensitive filesystem */
public final class C2899b implements s {

    /* renamed from: G  reason: collision with root package name */
    public static final String f26636G = C2640i.f("SystemJobScheduler");

    /* renamed from: E  reason: collision with root package name */
    public final WorkDatabase f26637E;

    /* renamed from: F  reason: collision with root package name */
    public final a f26638F;

    /* renamed from: f  reason: collision with root package name */
    public final Context f26639f;

    /* renamed from: i  reason: collision with root package name */
    public final JobScheduler f26640i;

    /* renamed from: z  reason: collision with root package name */
    public final C2898a f26641z;

    public C2899b(Context context, WorkDatabase workDatabase, a aVar) {
        C2898a aVar2 = new C2898a(context, aVar.f16254c);
        this.f26639f = context;
        this.f26640i = (JobScheduler) context.getSystemService("jobscheduler");
        this.f26641z = aVar2;
        this.f26637E = workDatabase;
        this.f26638F = aVar;
    }

    public static void b(JobScheduler jobScheduler, int i10) {
        try {
            jobScheduler.cancel(i10);
        } catch (Throwable th) {
            C2640i.d().c(f26636G, String.format(Locale.getDefault(), "Exception while trying to cancel job (%d)", new Object[]{Integer.valueOf(i10)}), th);
        }
    }

    public static ArrayList d(Context context, JobScheduler jobScheduler, String str) {
        ArrayList f10 = f(context, jobScheduler);
        if (f10 == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(2);
        Iterator it = f10.iterator();
        while (it.hasNext()) {
            JobInfo jobInfo = (JobInfo) it.next();
            C3223m g6 = g(jobInfo);
            if (g6 != null && str.equals(g6.f28651a)) {
                arrayList.add(Integer.valueOf(jobInfo.getId()));
            }
        }
        return arrayList;
    }

    public static ArrayList f(Context context, JobScheduler jobScheduler) {
        List<JobInfo> list;
        try {
            list = jobScheduler.getAllPendingJobs();
        } catch (Throwable th) {
            C2640i.d().c(f26636G, "getAllPendingJobs() is not reliable on this device.", th);
            list = null;
        }
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        ComponentName componentName = new ComponentName(context, SystemJobService.class);
        for (JobInfo next : list) {
            if (componentName.equals(next.getService())) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public static C3223m g(JobInfo jobInfo) {
        PersistableBundle extras = jobInfo.getExtras();
        if (extras == null) {
            return null;
        }
        try {
            if (!extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return null;
            }
            return new C3223m(extras.getString("EXTRA_WORK_SPEC_ID"), extras.getInt("EXTRA_WORK_SPEC_GENERATION", 0));
        } catch (NullPointerException unused) {
            return null;
        }
    }

    public final void a(v... vVarArr) {
        int i10;
        ArrayList d10;
        int i11;
        WorkDatabase workDatabase = this.f26637E;
        b bVar = new b(workDatabase);
        int length = vVarArr.length;
        int i12 = 0;
        while (i12 < length) {
            v vVar = vVarArr[i12];
            workDatabase.c();
            try {
                v t10 = workDatabase.u().t(vVar.f28657a);
                String str = f26636G;
                String str2 = vVar.f28657a;
                if (t10 == null) {
                    C2640i.d().g(str, "Skipping scheduling " + str2 + " because it's no longer in the DB");
                    workDatabase.n();
                } else if (t10.f28658b != C2646o.f24698f) {
                    C2640i.d().g(str, "Skipping scheduling " + str2 + " because it is no longer enqueued");
                    workDatabase.n();
                } else {
                    C3223m j10 = k5.b.j(vVar);
                    C3218h a10 = workDatabase.r().a(j10);
                    WorkDatabase workDatabase2 = (WorkDatabase) bVar.f9685f;
                    a aVar = this.f26638F;
                    if (a10 != null) {
                        i10 = a10.f28647c;
                    } else {
                        aVar.getClass();
                        Object m10 = workDatabase2.m(new C3329h(bVar, aVar.f16259h));
                        l.e(m10, "workDatabase.runInTransa…            id\n        })");
                        i10 = ((Number) m10).intValue();
                    }
                    if (a10 == null) {
                        workDatabase.r().d(new C3218h(j10.f28651a, j10.f28652b, i10));
                    }
                    h(vVar, i10);
                    if (Build.VERSION.SDK_INT == 23 && (d10 = d(this.f26639f, this.f26640i, str2)) != null) {
                        int indexOf = d10.indexOf(Integer.valueOf(i10));
                        if (indexOf >= 0) {
                            d10.remove(indexOf);
                        }
                        if (!d10.isEmpty()) {
                            i11 = ((Integer) d10.get(0)).intValue();
                        } else {
                            aVar.getClass();
                            Object m11 = workDatabase2.m(new C3329h(bVar, aVar.f16259h));
                            l.e(m11, "workDatabase.runInTransa…            id\n        })");
                            i11 = ((Number) m11).intValue();
                        }
                        h(vVar, i11);
                    }
                    workDatabase.n();
                }
                i12++;
            } finally {
                workDatabase.j();
            }
        }
    }

    public final boolean c() {
        return true;
    }

    public final void e(String str) {
        Context context = this.f26639f;
        JobScheduler jobScheduler = this.f26640i;
        ArrayList d10 = d(context, jobScheduler, str);
        if (d10 != null && !d10.isEmpty()) {
            Iterator it = d10.iterator();
            while (it.hasNext()) {
                b(jobScheduler, ((Integer) it.next()).intValue());
            }
            this.f26637E.r().e(str);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x007c, code lost:
        if (r11 < 26) goto L_0x0089;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void h(u4.v r22, int r23) {
        /*
            r21 = this;
            r1 = r21
            r2 = r22
            r0 = r23
            r3 = 3
            r4 = 2
            r5 = 1
            android.app.job.JobScheduler r7 = r1.f26640i
            p4.a r8 = r1.f26641z
            r8.getClass()
            l4.c r9 = r2.f28666j
            android.os.PersistableBundle r10 = new android.os.PersistableBundle
            r10.<init>()
            java.lang.String r11 = "EXTRA_WORK_SPEC_ID"
            java.lang.String r12 = r2.f28657a
            r10.putString(r11, r12)
            java.lang.String r11 = "EXTRA_WORK_SPEC_GENERATION"
            int r13 = r2.f28676t
            r10.putInt(r11, r13)
            java.lang.String r11 = "EXTRA_IS_PERIODIC"
            boolean r13 = r2.c()
            r10.putBoolean(r11, r13)
            android.app.job.JobInfo$Builder r11 = new android.app.job.JobInfo$Builder
            android.content.ComponentName r13 = r8.f26634a
            r11.<init>(r0, r13)
            boolean r13 = r9.f24659b
            android.app.job.JobInfo$Builder r11 = r11.setRequiresCharging(r13)
            boolean r13 = r9.f24660c
            android.app.job.JobInfo$Builder r11 = r11.setRequiresDeviceIdle(r13)
            android.app.job.JobInfo$Builder r10 = r11.setExtras(r10)
            int r11 = android.os.Build.VERSION.SDK_INT
            r14 = 30
            r6 = 26
            l4.j r15 = r9.f24658a
            if (r11 < r14) goto L_0x006a
            l4.j r14 = l4.C2641j.f24682G
            if (r15 != r14) goto L_0x006a
            android.net.NetworkRequest$Builder r14 = new android.net.NetworkRequest$Builder
            r14.<init>()
            r15 = 25
            android.net.NetworkRequest$Builder r14 = r14.addCapability(r15)
            android.net.NetworkRequest r14 = r14.build()
            r10.setRequiredNetwork(r14)
            r17 = r4
            r18 = r5
            goto L_0x00b5
        L_0x006a:
            int r14 = r15.ordinal()
            if (r14 == 0) goto L_0x00ad
            if (r14 == r5) goto L_0x00a8
            if (r14 == r4) goto L_0x00a5
            if (r14 == r3) goto L_0x0081
            r17 = r4
            r4 = 4
            if (r14 == r4) goto L_0x007c
            goto L_0x0089
        L_0x007c:
            if (r11 < r6) goto L_0x0089
        L_0x007e:
            r18 = r5
            goto L_0x00b2
        L_0x0081:
            r17 = r4
            r4 = 24
            if (r11 < r4) goto L_0x0089
            r4 = r3
            goto L_0x007e
        L_0x0089:
            l4.i r4 = l4.C2640i.d()
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r18 = r5
            java.lang.String r5 = "API version too low. Cannot convert network type value "
            r14.<init>(r5)
            r14.append(r15)
            java.lang.String r5 = r14.toString()
            java.lang.String r14 = p4.C2898a.f26633c
            r4.a(r14, r5)
        L_0x00a2:
            r4 = r18
            goto L_0x00b2
        L_0x00a5:
            r17 = r4
            goto L_0x007e
        L_0x00a8:
            r17 = r4
            r18 = r5
            goto L_0x00a2
        L_0x00ad:
            r17 = r4
            r18 = r5
            r4 = 0
        L_0x00b2:
            r10.setRequiredNetworkType(r4)
        L_0x00b5:
            if (r13 != 0) goto L_0x00c6
            l4.a r4 = l4.C2632a.f24653i
            l4.a r5 = r2.f28668l
            if (r5 != r4) goto L_0x00bf
            r4 = 0
            goto L_0x00c1
        L_0x00bf:
            r4 = r18
        L_0x00c1:
            long r13 = r2.f28669m
            r10.setBackoffCriteria(r13, r4)
        L_0x00c6:
            long r4 = r2.a()
            C0.e r8 = r8.f26635b
            r8.getClass()
            long r13 = java.lang.System.currentTimeMillis()
            long r4 = r4 - r13
            r13 = 0
            long r4 = java.lang.Math.max(r4, r13)
            r8 = 28
            if (r11 > r8) goto L_0x00e4
            r10.setMinimumLatency(r4)
        L_0x00e1:
            r8 = 24
            goto L_0x00f4
        L_0x00e4:
            int r8 = (r4 > r13 ? 1 : (r4 == r13 ? 0 : -1))
            if (r8 <= 0) goto L_0x00ec
            r10.setMinimumLatency(r4)
            goto L_0x00e1
        L_0x00ec:
            boolean r8 = r2.f28673q
            if (r8 != 0) goto L_0x00e1
            r10.setImportantWhileForeground(true)
            goto L_0x00e1
        L_0x00f4:
            if (r11 < r8) goto L_0x012b
            boolean r8 = r9.a()
            if (r8 == 0) goto L_0x012b
            java.util.Set<l4.c$a> r8 = r9.f24665h
            java.util.Iterator r8 = r8.iterator()
        L_0x0102:
            boolean r11 = r8.hasNext()
            if (r11 == 0) goto L_0x011d
            java.lang.Object r11 = r8.next()
            l4.c$a r11 = (l4.C2634c.a) r11
            boolean r15 = r11.f24667b
            f7.R1.e()
            android.net.Uri r11 = r11.f24666a
            android.app.job.JobInfo$TriggerContentUri r11 = X0.t.b(r11, r15)
            r10.addTriggerContentUri(r11)
            goto L_0x0102
        L_0x011d:
            r19 = r13
            long r13 = r9.f24663f
            r10.setTriggerContentUpdateDelay(r13)
            long r13 = r9.f24664g
            r10.setTriggerContentMaxDelay(r13)
        L_0x0129:
            r8 = 0
            goto L_0x012e
        L_0x012b:
            r19 = r13
            goto L_0x0129
        L_0x012e:
            r10.setPersisted(r8)
            int r8 = android.os.Build.VERSION.SDK_INT
            if (r8 < r6) goto L_0x013f
            boolean r6 = r9.f24661d
            r10.setRequiresBatteryNotLow(r6)
            boolean r6 = r9.f24662e
            r10.setRequiresStorageNotLow(r6)
        L_0x013f:
            int r6 = r2.f28667k
            if (r6 <= 0) goto L_0x0146
            r6 = r18
            goto L_0x0147
        L_0x0146:
            r6 = 0
        L_0x0147:
            int r4 = (r4 > r19 ? 1 : (r4 == r19 ? 0 : -1))
            if (r4 <= 0) goto L_0x014e
            r4 = r18
            goto L_0x014f
        L_0x014e:
            r4 = 0
        L_0x014f:
            r5 = 31
            if (r8 < r5) goto L_0x015e
            boolean r5 = r2.f28673q
            if (r5 == 0) goto L_0x015e
            if (r6 != 0) goto L_0x015e
            if (r4 != 0) goto L_0x015e
            r10.setExpedited(true)
        L_0x015e:
            android.app.job.JobInfo r4 = r10.build()
            l4.i r5 = l4.C2640i.d()
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String r8 = "Scheduling work ID "
            r6.<init>(r8)
            r6.append(r12)
            java.lang.String r8 = "Job ID "
            r6.append(r8)
            r6.append(r0)
            java.lang.String r6 = r6.toString()
            java.lang.String r8 = f26636G
            r5.a(r8, r6)
            int r4 = r7.schedule(r4)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            if (r4 != 0) goto L_0x01e6
            l4.i r4 = l4.C2640i.d()     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            r5.<init>()     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            java.lang.String r6 = "Unable to schedule work ID "
            r5.append(r6)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            r5.append(r12)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            java.lang.String r5 = r5.toString()     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            r4.g(r8, r5)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            boolean r4 = r2.f28673q     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            if (r4 == 0) goto L_0x01e6
            l4.n r4 = r2.f28674r     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            l4.n r5 = l4.C2645n.f24691f     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            if (r4 != r5) goto L_0x01e6
            r4 = 0
            r2.f28673q = r4     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            r4.<init>()     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            java.lang.String r5 = "Scheduling a non-expedited job (work ID "
            r4.append(r5)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            r4.append(r12)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            java.lang.String r5 = ")"
            r4.append(r5)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            java.lang.String r4 = r4.toString()     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            l4.i r5 = l4.C2640i.d()     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            r5.a(r8, r4)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            r21.h(r22, r23)     // Catch:{ IllegalStateException -> 0x01cf, all -> 0x01cd }
            return
        L_0x01cd:
            r0 = move-exception
            goto L_0x01d1
        L_0x01cf:
            r0 = move-exception
            goto L_0x01e7
        L_0x01d1:
            l4.i r3 = l4.C2640i.d()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "Unable to schedule "
            r4.<init>(r5)
            r4.append(r2)
            java.lang.String r2 = r4.toString()
            r3.c(r8, r2, r0)
        L_0x01e6:
            return
        L_0x01e7:
            android.content.Context r2 = r1.f26639f
            java.util.ArrayList r2 = f(r2, r7)
            if (r2 == 0) goto L_0x01f4
            int r2 = r2.size()
            goto L_0x01f5
        L_0x01f4:
            r2 = 0
        L_0x01f5:
            java.util.Locale r4 = java.util.Locale.getDefault()
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            androidx.work.impl.WorkDatabase r5 = r1.f26637E
            u4.w r5 = r5.u()
            java.util.ArrayList r5 = r5.l()
            int r5 = r5.size()
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            androidx.work.a r6 = r1.f26638F
            int r6 = r6.f16261j
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r16 = 0
            r3[r16] = r2
            r3[r18] = r5
            r3[r17] = r6
            java.lang.String r2 = "JobScheduler 100 job limit exceeded.  We count %d WorkManager jobs in JobScheduler; we have %d tracked jobs in our DB; our Configuration limit is %d."
            java.lang.String r2 = java.lang.String.format(r4, r2, r3)
            l4.i r3 = l4.C2640i.d()
            r3.b(r8, r2)
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            r3.<init>(r2, r0)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: p4.C2899b.h(u4.v, int):void");
    }
}
