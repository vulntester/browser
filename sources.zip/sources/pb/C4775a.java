package pb;

import A6.k;
import Kb.c;
import Sb.c;
import Z7.b;
import ab.n;
import db.a0;
import gb.C4432B;
import ib.e;
import ib.g;
import ib.i;
import mb.C4659c;
import mb.C4672p;
import mb.C4679w;
import nb.C4726h;
import nb.C4727i;
import nb.l;
import ub.C4881E;
import vb.C4925l;
import vb.w;

/* renamed from: pb.a  reason: case insensitive filesystem */
public final class C4775a {

    /* renamed from: a  reason: collision with root package name */
    public final c f42969a;

    /* renamed from: b  reason: collision with root package name */
    public final k f42970b;

    /* renamed from: c  reason: collision with root package name */
    public final e f42971c;

    /* renamed from: d  reason: collision with root package name */
    public final C4925l f42972d;

    /* renamed from: e  reason: collision with root package name */
    public final l.a f42973e;

    /* renamed from: f  reason: collision with root package name */
    public final g f42974f;

    /* renamed from: g  reason: collision with root package name */
    public final C4727i.a f42975g;

    /* renamed from: h  reason: collision with root package name */
    public final C4726h f42976h;

    /* renamed from: i  reason: collision with root package name */
    public final b f42977i;

    /* renamed from: j  reason: collision with root package name */
    public final i f42978j;

    /* renamed from: k  reason: collision with root package name */
    public final A7.b f42979k;

    /* renamed from: l  reason: collision with root package name */
    public final w f42980l;

    /* renamed from: m  reason: collision with root package name */
    public final a0.a f42981m;

    /* renamed from: n  reason: collision with root package name */
    public final lb.b f42982n;

    /* renamed from: o  reason: collision with root package name */
    public final C4432B f42983o;

    /* renamed from: p  reason: collision with root package name */
    public final n f42984p;

    /* renamed from: q  reason: collision with root package name */
    public final C4659c f42985q;

    /* renamed from: r  reason: collision with root package name */
    public final C4881E f42986r;

    /* renamed from: s  reason: collision with root package name */
    public final C4672p f42987s;

    /* renamed from: t  reason: collision with root package name */
    public final C4776b f42988t;

    /* renamed from: u  reason: collision with root package name */
    public final Ub.l f42989u;

    /* renamed from: v  reason: collision with root package name */
    public final C4679w f42990v;

    /* renamed from: w  reason: collision with root package name */
    public final k5.b f42991w;

    /* renamed from: x  reason: collision with root package name */
    public final Kb.c f42992x;

    public C4775a(c cVar, k kVar, e eVar, C4925l lVar, l.a aVar, g gVar, C4726h hVar, b bVar, i iVar, A7.b bVar2, w wVar, a0.a aVar2, lb.b bVar3, C4432B b10, n nVar, C4659c cVar2, C4881E e10, C4672p pVar, C4776b bVar4, Ub.l lVar2, C4679w wVar2, k5.b bVar5) {
        c cVar3 = cVar;
        k kVar2 = kVar;
        e eVar2 = eVar;
        C4925l lVar3 = lVar;
        l.a aVar3 = aVar;
        g gVar2 = gVar;
        C4726h hVar2 = hVar;
        b bVar6 = bVar;
        i iVar2 = iVar;
        A7.b bVar7 = bVar2;
        w wVar3 = wVar;
        a0.a aVar4 = aVar2;
        lb.b bVar8 = bVar3;
        C4432B b11 = b10;
        C4727i.a aVar5 = C4727i.f42400a;
        Kb.c.f36584e.getClass();
        C4727i.a aVar6 = aVar5;
        kotlin.jvm.internal.l.f(cVar3, "storageManager");
        kotlin.jvm.internal.l.f(kVar2, "finder");
        kotlin.jvm.internal.l.f(eVar2, "kotlinClassFinder");
        kotlin.jvm.internal.l.f(lVar3, "deserializedDescriptorResolver");
        kotlin.jvm.internal.l.f(aVar3, "signaturePropagator");
        kotlin.jvm.internal.l.f(gVar2, "errorReporter");
        kotlin.jvm.internal.l.f(hVar2, "javaPropertyInitializerEvaluator");
        kotlin.jvm.internal.l.f(bVar6, "samConversionResolver");
        kotlin.jvm.internal.l.f(iVar2, "sourceElementFactory");
        kotlin.jvm.internal.l.f(bVar7, "moduleClassResolver");
        kotlin.jvm.internal.l.f(wVar3, "packagePartProvider");
        kotlin.jvm.internal.l.f(aVar4, "supertypeLoopChecker");
        kotlin.jvm.internal.l.f(bVar8, "lookupTracker");
        kotlin.jvm.internal.l.f(b11, "module");
        kotlin.jvm.internal.l.f(nVar, "reflectionTypes");
        kotlin.jvm.internal.l.f(cVar2, "annotationTypeQualifierResolver");
        kotlin.jvm.internal.l.f(e10, "signatureEnhancement");
        kotlin.jvm.internal.l.f(pVar, "javaClassesTracker");
        kotlin.jvm.internal.l.f(bVar4, "settings");
        kotlin.jvm.internal.l.f(lVar2, "kotlinTypeChecker");
        kotlin.jvm.internal.l.f(wVar2, "javaTypeEnhancementState");
        kotlin.jvm.internal.l.f(bVar5, "javaModuleResolver");
        P8.b bVar9 = c.a.f36586b;
        kotlin.jvm.internal.l.f(bVar9, "syntheticPartsProvider");
        this.f42969a = cVar3;
        this.f42970b = kVar2;
        this.f42971c = eVar2;
        this.f42972d = lVar3;
        this.f42973e = aVar3;
        this.f42974f = gVar2;
        this.f42975g = aVar6;
        this.f42976h = hVar2;
        this.f42977i = bVar6;
        this.f42978j = iVar2;
        this.f42979k = bVar7;
        this.f42980l = wVar3;
        this.f42981m = aVar4;
        this.f42982n = bVar8;
        this.f42983o = b11;
        this.f42984p = nVar;
        this.f42985q = cVar2;
        this.f42986r = e10;
        this.f42987s = pVar;
        this.f42988t = bVar4;
        this.f42989u = lVar2;
        this.f42990v = wVar2;
        this.f42991w = bVar5;
        this.f42992x = bVar9;
    }
}
