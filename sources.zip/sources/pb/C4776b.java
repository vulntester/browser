package pb;

/* renamed from: pb.b  reason: case insensitive filesystem */
public final class C4776b {

    /* renamed from: a  reason: collision with root package name */
    public static final C4776b f42993a = new Object();
}
