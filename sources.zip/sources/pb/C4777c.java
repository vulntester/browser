package pb;

import C9.k;
import Cb.c;
import Cb.f;
import Sb.h;
import ab.o;
import db.C4293G;
import eb.C4373b;
import eb.C4377f;
import ec.C4389e;
import ec.C4392h;
import ec.C4398n;
import ec.C4400p;
import ec.C4402r;
import java.util.Iterator;
import kotlin.jvm.internal.l;
import nb.C4721c;
import tb.C4841a;
import tb.C4844d;
import ya.m;
import ya.s;

/* renamed from: pb.c  reason: case insensitive filesystem */
public final class C4777c implements C4377f {

    /* renamed from: E  reason: collision with root package name */
    public final h<C4841a, C4373b> f42994E;

    /* renamed from: f  reason: collision with root package name */
    public final C4779e f42995f;

    /* renamed from: i  reason: collision with root package name */
    public final C4844d f42996i;

    /* renamed from: z  reason: collision with root package name */
    public final boolean f42997z;

    public C4777c(C4779e eVar, C4844d dVar, boolean z10) {
        l.f(eVar, "c");
        l.f(dVar, "annotationOwner");
        this.f42995f = eVar;
        this.f42996i = dVar;
        this.f42997z = z10;
        this.f42994E = eVar.f43000a.f42969a.f(new C4293G(this, 2));
    }

    public final C4373b f(c cVar) {
        C4373b invoke;
        l.f(cVar, "fqName");
        C4844d dVar = this.f42996i;
        C4841a f10 = dVar.f(cVar);
        if (f10 != null && (invoke = this.f42994E.invoke(f10)) != null) {
            return invoke;
        }
        f fVar = C4721c.f42389a;
        return C4721c.a(cVar, dVar, this.f42995f);
    }

    public final boolean isEmpty() {
        if (this.f42996i.getAnnotations().isEmpty()) {
            return true;
        }
        return false;
    }

    public final Iterator<C4373b> iterator() {
        C4844d dVar = this.f42996i;
        C4402r I10 = C4400p.I(s.M(dVar.getAnnotations()), this.f42994E);
        f fVar = C4721c.f42389a;
        return new C4389e.a(C4400p.G(C4398n.B(m.A(new C4392h[]{I10, m.A(new Object[]{C4721c.a(o.a.f39221m, dVar, this.f42995f)})})), new k(6)));
    }

    public final boolean y(c cVar) {
        return C4377f.b.b(this, cVar);
    }
}
