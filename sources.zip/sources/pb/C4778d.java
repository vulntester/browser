package pb;

import Cb.c;
import Sb.a;
import Sb.c;
import db.C4299M;
import f7.M;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import jb.C4561D;
import kotlin.jvm.internal.l;
import pb.C4781g;
import qb.m;
import xa.C4961a;
import ya.u;

/* renamed from: pb.d  reason: case insensitive filesystem */
public final class C4778d implements C4299M {

    /* renamed from: a  reason: collision with root package name */
    public final C4779e f42998a;

    /* renamed from: b  reason: collision with root package name */
    public final a<c, m> f42999b;

    /* JADX WARNING: type inference failed for: r2v0, types: [xa.h, java.lang.Object] */
    public C4778d(C4775a aVar) {
        this.f42998a = new C4779e(aVar, C4781g.a.f43010a, new Object());
        this.f42999b = aVar.f42969a.d();
    }

    @C4961a
    public final List<m> a(c cVar) {
        l.f(cVar, "fqName");
        return M.s(d(cVar));
    }

    public final boolean b(c cVar) {
        l.f(cVar, "fqName");
        this.f42998a.f43000a.f42970b.getClass();
        new C4561D(cVar);
        return false;
    }

    public final void c(c cVar, ArrayList arrayList) {
        l.f(cVar, "fqName");
        arrayList.add(d(cVar));
    }

    public final m d(c cVar) {
        this.f42998a.f43000a.f42970b.getClass();
        l.f(cVar, "fqName");
        Xa.M m10 = new Xa.M(1, this, new C4561D(cVar));
        c.b bVar = (c.b) this.f42999b;
        bVar.getClass();
        Object invoke = bVar.invoke(new c.e(cVar, m10));
        if (invoke != null) {
            return (m) invoke;
        }
        c.b.a(3);
        throw null;
    }

    public final Collection r(Cb.c cVar, Na.l lVar) {
        l.f(cVar, "fqName");
        List list = (List) d(cVar).f43297M.invoke();
        if (list == null) {
            return u.f44685f;
        }
        return list;
    }

    public final String toString() {
        return "LazyJavaPackageFragmentProvider of module " + this.f42998a.f43000a.f42983o;
    }
}
