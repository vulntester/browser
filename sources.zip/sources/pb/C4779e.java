package pb;

import kotlin.jvm.internal.l;
import mb.C4680x;
import rb.C4811d;
import xa.C4968h;

/* renamed from: pb.e  reason: case insensitive filesystem */
public final class C4779e {

    /* renamed from: a  reason: collision with root package name */
    public final C4775a f43000a;

    /* renamed from: b  reason: collision with root package name */
    public final C4781g f43001b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f43002c;

    /* renamed from: d  reason: collision with root package name */
    public final Object f43003d;

    /* renamed from: e  reason: collision with root package name */
    public final C4811d f43004e;

    public C4779e(C4775a aVar, C4781g gVar, C4968h<C4680x> hVar) {
        l.f(gVar, "typeParameterResolver");
        this.f43000a = aVar;
        this.f43001b = gVar;
        this.f43002c = hVar;
        this.f43003d = hVar;
        this.f43004e = new C4811d(this, gVar);
    }
}
