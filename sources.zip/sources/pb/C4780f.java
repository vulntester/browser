package pb;

import Pb.C4120j;
import Sb.h;
import db.C4322l;
import db.c0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import kotlin.jvm.internal.l;
import qb.C4798A;
import tb.C4864x;
import tb.C4865y;

/* renamed from: pb.f  reason: case insensitive filesystem */
public final class C4780f implements C4781g {

    /* renamed from: a  reason: collision with root package name */
    public final C4779e f43005a;

    /* renamed from: b  reason: collision with root package name */
    public final C4322l f43006b;

    /* renamed from: c  reason: collision with root package name */
    public final int f43007c;

    /* renamed from: d  reason: collision with root package name */
    public final LinkedHashMap f43008d;

    /* renamed from: e  reason: collision with root package name */
    public final h<C4864x, C4798A> f43009e;

    public C4780f(C4779e eVar, C4322l lVar, C4865y yVar, int i10) {
        l.f(eVar, "c");
        l.f(yVar, "typeParameterOwner");
        this.f43005a = eVar;
        this.f43006b = lVar;
        this.f43007c = i10;
        ArrayList typeParameters = yVar.getTypeParameters();
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Iterator it = typeParameters.iterator();
        int i11 = 0;
        while (it.hasNext()) {
            linkedHashMap.put(it.next(), Integer.valueOf(i11));
            i11++;
        }
        this.f43008d = linkedHashMap;
        this.f43009e = this.f43005a.f43000a.f42969a.f(new C4120j(this, 3));
    }

    public final c0 a(C4864x xVar) {
        l.f(xVar, "javaTypeParameter");
        C4798A invoke = this.f43009e.invoke(xVar);
        if (invoke != null) {
            return invoke;
        }
        return this.f43005a.f43001b.a(xVar);
    }
}
