package pb;

import db.c0;
import kotlin.jvm.internal.l;
import tb.C4864x;

/* renamed from: pb.g  reason: case insensitive filesystem */
public interface C4781g {

    /* renamed from: pb.g$a */
    public static final class a implements C4781g {

        /* renamed from: a  reason: collision with root package name */
        public static final a f43010a = new Object();

        public final c0 a(C4864x xVar) {
            l.f(xVar, "javaTypeParameter");
            return null;
        }
    }

    c0 a(C4864x xVar);
}
