package pc;

import A6.u;
import B0.C0493u;
import db.C4290D;
import ic.G;
import io.ktor.util.date.GMTDateParser;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import kotlin.jvm.internal.D;
import kotlin.jvm.internal.l;
import nc.m;
import nc.s;
import x.i0;
import xa.C4959D;

/* renamed from: pc.a  reason: case insensitive filesystem */
public final class C4782a implements Executor, Closeable {

    /* renamed from: I  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f43011I;

    /* renamed from: J  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f43012J;

    /* renamed from: K  reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f43013K;

    /* renamed from: L  reason: collision with root package name */
    public static final C4290D f43014L = new C4290D("NOT_IN_STACK", 1);

    /* renamed from: E  reason: collision with root package name */
    public final String f43015E;

    /* renamed from: F  reason: collision with root package name */
    public final d f43016F;

    /* renamed from: G  reason: collision with root package name */
    public final d f43017G;

    /* renamed from: H  reason: collision with root package name */
    public final s<C0431a> f43018H;
    private volatile /* synthetic */ int _isTerminated$volatile;
    private volatile /* synthetic */ long controlState$volatile;

    /* renamed from: f  reason: collision with root package name */
    public final int f43019f;

    /* renamed from: i  reason: collision with root package name */
    public final int f43020i;
    private volatile /* synthetic */ long parkedWorkersStack$volatile;

    /* renamed from: z  reason: collision with root package name */
    public final long f43021z;

    /* renamed from: pc.a$a  reason: collision with other inner class name */
    public final class C0431a extends Thread {

        /* renamed from: J  reason: collision with root package name */
        public static final /* synthetic */ AtomicIntegerFieldUpdater f43022J = AtomicIntegerFieldUpdater.newUpdater(C0431a.class, "workerCtl$volatile");

        /* renamed from: E  reason: collision with root package name */
        public long f43023E;

        /* renamed from: F  reason: collision with root package name */
        public long f43024F;

        /* renamed from: G  reason: collision with root package name */
        public int f43025G;

        /* renamed from: H  reason: collision with root package name */
        public boolean f43026H;

        /* renamed from: f  reason: collision with root package name */
        public final l f43028f;

        /* renamed from: i  reason: collision with root package name */
        public final D<h> f43029i;
        private volatile int indexInArray;
        private volatile Object nextParkedWorker;
        private volatile /* synthetic */ int workerCtl$volatile;

        /* renamed from: z  reason: collision with root package name */
        public b f43030z;

        public C0431a() {
            throw null;
        }

        public C0431a(int i10) {
            setDaemon(true);
            setContextClassLoader(C4782a.this.getClass().getClassLoader());
            this.f43028f = new l();
            this.f43029i = new D<>();
            this.f43030z = b.f43031E;
            this.nextParkedWorker = C4782a.f43014L;
            int nanoTime = (int) System.nanoTime();
            this.f43025G = nanoTime == 0 ? 42 : nanoTime;
            f(i10);
        }

        public final h a(boolean z10) {
            h e10;
            h e11;
            C4782a aVar;
            long j10;
            b bVar = this.f43030z;
            b bVar2 = b.f43034f;
            h hVar = null;
            l lVar = this.f43028f;
            boolean z11 = true;
            C4782a aVar2 = C4782a.this;
            if (bVar != bVar2) {
                AtomicLongFieldUpdater atomicLongFieldUpdater = C4782a.f43012J;
                do {
                    aVar = C4782a.this;
                    j10 = atomicLongFieldUpdater.get(aVar);
                    if (((int) ((9223367638808264704L & j10) >> 42)) == 0) {
                        lVar.getClass();
                        loop1:
                        while (true) {
                            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = l.f43052b;
                            h hVar2 = (h) atomicReferenceFieldUpdater.get(lVar);
                            if (hVar2 != null && hVar2.f43043i) {
                                while (true) {
                                    if (atomicReferenceFieldUpdater.compareAndSet(lVar, hVar2, (Object) null)) {
                                        hVar = hVar2;
                                        break loop1;
                                    } else if (atomicReferenceFieldUpdater.get(lVar) != hVar2) {
                                    }
                                }
                            }
                        }
                        int i10 = l.f43054d.get(lVar);
                        int i11 = l.f43053c.get(lVar);
                        while (true) {
                            if (i10 != i11 && l.f43055e.get(lVar) != 0) {
                                i11--;
                                h c10 = lVar.c(i11, true);
                                if (c10 != null) {
                                    hVar = c10;
                                    break;
                                }
                            } else {
                                break;
                            }
                        }
                        if (hVar != null) {
                            return hVar;
                        }
                        h hVar3 = (h) aVar2.f43017G.d();
                        if (hVar3 == null) {
                            return i(1);
                        }
                        return hVar3;
                    }
                } while (!C4782a.f43012J.compareAndSet(aVar, j10, j10 - 4398046511104L));
                this.f43030z = b.f43034f;
            }
            if (z10) {
                if (d(aVar2.f43019f * 2) != 0) {
                    z11 = false;
                }
                if (z11 && (e11 = e()) != null) {
                    return e11;
                }
                lVar.getClass();
                h hVar4 = (h) l.f43052b.getAndSet(lVar, (Object) null);
                if (hVar4 == null) {
                    hVar4 = lVar.b();
                }
                if (hVar4 != null) {
                    return hVar4;
                }
                if (!z11 && (e10 = e()) != null) {
                    return e10;
                }
            } else {
                h e12 = e();
                if (e12 != null) {
                    return e12;
                }
            }
            return i(3);
        }

        public final int b() {
            return this.indexInArray;
        }

        public final Object c() {
            return this.nextParkedWorker;
        }

        public final int d(int i10) {
            int i11 = this.f43025G;
            int i12 = i11 ^ (i11 << 13);
            int i13 = i12 ^ (i12 >> 17);
            int i14 = i13 ^ (i13 << 5);
            this.f43025G = i14;
            int i15 = i10 - 1;
            if ((i15 & i10) == 0) {
                return i14 & i15;
            }
            return (i14 & Integer.MAX_VALUE) % i10;
        }

        public final h e() {
            int d10 = d(2);
            C4782a aVar = C4782a.this;
            if (d10 == 0) {
                h hVar = (h) aVar.f43016F.d();
                if (hVar != null) {
                    return hVar;
                }
                return (h) aVar.f43017G.d();
            }
            h hVar2 = (h) aVar.f43017G.d();
            if (hVar2 != null) {
                return hVar2;
            }
            return (h) aVar.f43016F.d();
        }

        public final void f(int i10) {
            String str;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(C4782a.this.f43015E);
            sb2.append("-worker-");
            if (i10 == 0) {
                str = "TERMINATED";
            } else {
                str = String.valueOf(i10);
            }
            sb2.append(str);
            setName(sb2.toString());
            this.indexInArray = i10;
        }

        public final void g(Object obj) {
            this.nextParkedWorker = obj;
        }

        public final boolean h(b bVar) {
            boolean z10;
            b bVar2 = this.f43030z;
            if (bVar2 == b.f43034f) {
                z10 = true;
            } else {
                z10 = false;
            }
            if (z10) {
                C4782a.f43012J.addAndGet(C4782a.this, 4398046511104L);
            }
            if (bVar2 != bVar) {
                this.f43030z = bVar;
            }
            return z10;
        }

        public final h i(int i10) {
            int i11;
            long j10;
            T t10;
            long j11;
            long j12;
            int i12;
            boolean z10;
            int i13 = i10;
            AtomicLongFieldUpdater atomicLongFieldUpdater = C4782a.f43012J;
            C4782a aVar = C4782a.this;
            int i14 = (int) (atomicLongFieldUpdater.get(aVar) & 2097151);
            T t11 = null;
            if (i14 < 2) {
                return null;
            }
            int d10 = d(i14);
            int i15 = 0;
            long j13 = Long.MAX_VALUE;
            while (i15 < i14) {
                int i16 = d10 + 1;
                if (i16 > i14) {
                    i16 = 1;
                }
                C0431a b10 = aVar.f43018H.b(i16);
                if (b10 == null || b10 == this) {
                    i11 = i16;
                } else {
                    l lVar = b10.f43028f;
                    if (i13 == 3) {
                        t10 = lVar.b();
                        j10 = 0;
                    } else {
                        lVar.getClass();
                        int i17 = l.f43054d.get(lVar);
                        int i18 = l.f43053c.get(lVar);
                        if (i13 == 1) {
                            z10 = true;
                        } else {
                            z10 = false;
                        }
                        while (true) {
                            if (i17 == i18) {
                                j10 = 0;
                                break;
                            }
                            j10 = 0;
                            if (z10 && l.f43055e.get(lVar) == 0) {
                                break;
                            }
                            int i19 = i17 + 1;
                            t10 = lVar.c(i17, z10);
                            if (t10 != null) {
                                break;
                            }
                            i17 = i19;
                        }
                        t10 = t11;
                    }
                    D<h> d11 = this.f43029i;
                    if (t10 != null) {
                        d11.f41743f = t10;
                        i11 = i16;
                        j12 = -1;
                        j11 = -1;
                    } else {
                        while (true) {
                            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = l.f43052b;
                            T t12 = (h) atomicReferenceFieldUpdater.get(lVar);
                            if (t12 == null) {
                                j11 = -1;
                                break;
                            }
                            j11 = -1;
                            if (t12.f43043i) {
                                i12 = 1;
                            } else {
                                i12 = 2;
                            }
                            if ((i12 & i13) == 0) {
                                break;
                            }
                            j.f43050f.getClass();
                            i11 = i16;
                            long nanoTime = System.nanoTime() - t12.f43042f;
                            long j14 = j.f43046b;
                            if (nanoTime < j14) {
                                j12 = j14 - nanoTime;
                                t11 = null;
                                break;
                            }
                            do {
                                t11 = null;
                                if (atomicReferenceFieldUpdater.compareAndSet(lVar, t12, (Object) null)) {
                                    d11.f41743f = t12;
                                    j12 = -1;
                                    break;
                                }
                            } while (atomicReferenceFieldUpdater.get(lVar) == t12);
                            i16 = i11;
                            t11 = null;
                        }
                        j12 = -2;
                        i11 = i16;
                    }
                    if (j12 == j11) {
                        h hVar = (h) d11.f41743f;
                        d11.f41743f = t11;
                        return hVar;
                    } else if (j12 > j10) {
                        j13 = Math.min(j13, j12);
                    }
                }
                i15++;
                d10 = i11;
                t11 = null;
            }
            if (j13 == Long.MAX_VALUE) {
                j13 = 0;
            }
            this.f43024F = j13;
            return null;
        }

        public final void run() {
            b bVar;
            boolean z10;
            b bVar2;
            long j10;
            boolean z11;
            AtomicLongFieldUpdater atomicLongFieldUpdater;
            long j11;
            int i10;
            loop0:
            while (true) {
                boolean z12 = false;
                while (true) {
                    C4782a aVar = C4782a.this;
                    aVar.getClass();
                    if (!(C4782a.f43013K.get(aVar) == 1 || this.f43030z == (bVar = b.f43032F))) {
                        h a10 = a(this.f43026H);
                        if (a10 == null) {
                            this.f43026H = false;
                            if (this.f43024F != 0) {
                                if (z12) {
                                    h(b.f43036z);
                                    Thread.interrupted();
                                    LockSupport.parkNanos(this.f43024F);
                                    this.f43024F = 0;
                                    break;
                                }
                                z12 = true;
                            } else {
                                Object obj = this.nextParkedWorker;
                                C4290D d10 = C4782a.f43014L;
                                if (obj != d10) {
                                    z10 = true;
                                } else {
                                    z10 = false;
                                }
                                long j12 = 2097151;
                                if (z10) {
                                    f43022J.set(this, -1);
                                    while (this.nextParkedWorker != C4782a.f43014L) {
                                        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f43022J;
                                        if (atomicIntegerFieldUpdater.get(this) != -1) {
                                            break;
                                        }
                                        C4782a aVar2 = C4782a.this;
                                        aVar2.getClass();
                                        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater2 = C4782a.f43013K;
                                        if (atomicIntegerFieldUpdater2.get(aVar2) == 1 || this.f43030z == (bVar2 = b.f43032F)) {
                                            break;
                                        }
                                        h(b.f43036z);
                                        Thread.interrupted();
                                        if (this.f43023E == 0) {
                                            j10 = j12;
                                            this.f43023E = System.nanoTime() + C4782a.this.f43021z;
                                        } else {
                                            j10 = j12;
                                        }
                                        LockSupport.parkNanos(C4782a.this.f43021z);
                                        if (System.nanoTime() - this.f43023E >= 0) {
                                            this.f43023E = 0;
                                            C4782a aVar3 = C4782a.this;
                                            synchronized (aVar3.f43018H) {
                                                try {
                                                    if (atomicIntegerFieldUpdater2.get(aVar3) == 1) {
                                                        z11 = true;
                                                    } else {
                                                        z11 = false;
                                                    }
                                                    if (!z11) {
                                                        AtomicLongFieldUpdater atomicLongFieldUpdater2 = C4782a.f43012J;
                                                        if (((int) (atomicLongFieldUpdater2.get(aVar3) & j10)) > aVar3.f43019f) {
                                                            if (atomicIntegerFieldUpdater.compareAndSet(this, -1, 1)) {
                                                                int i11 = this.indexInArray;
                                                                f(0);
                                                                aVar3.f(this, i11, 0);
                                                                int andDecrement = (int) (atomicLongFieldUpdater2.getAndDecrement(aVar3) & j10);
                                                                if (andDecrement != i11) {
                                                                    C0431a b10 = aVar3.f43018H.b(andDecrement);
                                                                    l.c(b10);
                                                                    C0431a aVar4 = b10;
                                                                    aVar3.f43018H.c(i11, aVar4);
                                                                    aVar4.f(i11);
                                                                    aVar3.f(aVar4, andDecrement, i11);
                                                                }
                                                                aVar3.f43018H.c(andDecrement, (C0431a) null);
                                                                C4959D d11 = C4959D.f44058a;
                                                                this.f43030z = bVar2;
                                                            }
                                                        }
                                                    }
                                                } catch (Throwable th) {
                                                    throw th;
                                                }
                                            }
                                        }
                                        j12 = j10;
                                    }
                                } else {
                                    C4782a aVar5 = C4782a.this;
                                    aVar5.getClass();
                                    if (this.nextParkedWorker == d10) {
                                        do {
                                            atomicLongFieldUpdater = C4782a.f43011I;
                                            j11 = atomicLongFieldUpdater.get(aVar5);
                                            i10 = this.indexInArray;
                                            this.nextParkedWorker = aVar5.f43018H.b((int) (j11 & 2097151));
                                        } while (!atomicLongFieldUpdater.compareAndSet(aVar5, j11, ((2097152 + j11) & -2097152) | ((long) i10)));
                                    }
                                }
                            }
                        } else {
                            this.f43024F = 0;
                            this.f43023E = 0;
                            if (this.f43030z == b.f43036z) {
                                this.f43030z = b.f43035i;
                            }
                            boolean z13 = a10.f43043i;
                            C4782a aVar6 = C4782a.this;
                            if (z13) {
                                if (h(b.f43035i) && !aVar6.k() && !aVar6.j(C4782a.f43012J.get(aVar6))) {
                                    aVar6.k();
                                }
                                aVar6.getClass();
                                try {
                                    a10.run();
                                } catch (Throwable th2) {
                                    Thread currentThread = Thread.currentThread();
                                    currentThread.getUncaughtExceptionHandler().uncaughtException(currentThread, th2);
                                }
                                C4782a.f43012J.addAndGet(aVar6, -2097152);
                                if (this.f43030z != bVar) {
                                    this.f43030z = b.f43031E;
                                }
                            } else {
                                aVar6.getClass();
                                try {
                                    a10.run();
                                } catch (Throwable th3) {
                                    Thread currentThread2 = Thread.currentThread();
                                    currentThread2.getUncaughtExceptionHandler().uncaughtException(currentThread2, th3);
                                }
                            }
                        }
                    }
                }
            }
            h(b.f43032F);
        }
    }

    /* renamed from: pc.a$b */
    public enum b {
        ;

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r10v2, resolved type: pc.a$b[]} */
        /* JADX WARNING: type inference failed for: r5v0, types: [java.lang.Enum, pc.a$b] */
        /* JADX WARNING: type inference failed for: r6v1, types: [java.lang.Enum, pc.a$b] */
        /* JADX WARNING: type inference failed for: r7v1, types: [java.lang.Enum, pc.a$b] */
        /* JADX WARNING: type inference failed for: r8v1, types: [java.lang.Enum, pc.a$b] */
        /* JADX WARNING: type inference failed for: r9v1, types: [java.lang.Enum, pc.a$b] */
        /* JADX WARNING: Multi-variable type inference failed */
        static {
            /*
                r0 = 4
                r1 = 3
                r2 = 2
                r3 = 1
                r4 = 0
                pc.a$b r5 = new pc.a$b
                java.lang.String r6 = "CPU_ACQUIRED"
                r5.<init>(r6, r4)
                f43034f = r5
                pc.a$b r6 = new pc.a$b
                java.lang.String r7 = "BLOCKING"
                r6.<init>(r7, r3)
                f43035i = r6
                pc.a$b r7 = new pc.a$b
                java.lang.String r8 = "PARKING"
                r7.<init>(r8, r2)
                f43036z = r7
                pc.a$b r8 = new pc.a$b
                java.lang.String r9 = "DORMANT"
                r8.<init>(r9, r1)
                f43031E = r8
                pc.a$b r9 = new pc.a$b
                java.lang.String r10 = "TERMINATED"
                r9.<init>(r10, r0)
                f43032F = r9
                r10 = 5
                pc.a$b[] r10 = new pc.C4782a.b[r10]
                r10[r4] = r5
                r10[r3] = r6
                r10[r2] = r7
                r10[r1] = r8
                r10[r0] = r9
                f43033G = r10
                A1.a.r(r10)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: pc.C4782a.b.<clinit>():void");
        }

        /* access modifiers changed from: public */
        b() {
            throw null;
        }
    }

    static {
        Class<C4782a> cls = C4782a.class;
        f43011I = AtomicLongFieldUpdater.newUpdater(cls, "parkedWorkersStack$volatile");
        f43012J = AtomicLongFieldUpdater.newUpdater(cls, "controlState$volatile");
        f43013K = AtomicIntegerFieldUpdater.newUpdater(cls, "_isTerminated$volatile");
    }

    /* JADX WARNING: type inference failed for: r4v8, types: [nc.m, pc.d] */
    /* JADX WARNING: type inference failed for: r4v9, types: [nc.m, pc.d] */
    public C4782a(int i10, int i11, long j10, String str) {
        this.f43019f = i10;
        this.f43020i = i11;
        this.f43021z = j10;
        this.f43015E = str;
        if (i10 < 1) {
            throw new IllegalArgumentException(u.n(i10, "Core pool size ", " should be at least 1").toString());
        } else if (i11 < i10) {
            throw new IllegalArgumentException(D1.b.i(i11, i10, "Max pool size ", " should be greater than or equals to core pool size ").toString());
        } else if (i11 > 2097150) {
            throw new IllegalArgumentException(u.n(i11, "Max pool size ", " should not exceed maximal supported number of threads 2097150").toString());
        } else if (j10 > 0) {
            this.f43016F = new m();
            this.f43017G = new m();
            this.f43018H = new s<>((i10 + 1) * 2);
            this.controlState$volatile = ((long) i10) << 42;
        } else {
            throw new IllegalArgumentException(C0493u.f("Idle worker keep alive time ", j10, " must be positive").toString());
        }
    }

    public static /* synthetic */ void e(C4782a aVar, Runnable runnable, int i10) {
        boolean z10;
        if ((i10 & 4) != 0) {
            z10 = false;
        } else {
            z10 = true;
        }
        aVar.d(runnable, false, z10);
    }

    public final int b() {
        boolean z10;
        synchronized (this.f43018H) {
            try {
                if (f43013K.get(this) == 1) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                if (z10) {
                    return -1;
                }
                AtomicLongFieldUpdater atomicLongFieldUpdater = f43012J;
                long j10 = atomicLongFieldUpdater.get(this);
                int i10 = (int) (j10 & 2097151);
                int i11 = i10 - ((int) ((j10 & 4398044413952L) >> 21));
                if (i11 < 0) {
                    i11 = 0;
                }
                if (i11 >= this.f43019f) {
                    return 0;
                }
                if (i10 >= this.f43020i) {
                    return 0;
                }
                int i12 = ((int) (atomicLongFieldUpdater.get(this) & 2097151)) + 1;
                if (i12 <= 0 || this.f43018H.b(i12) != null) {
                    throw new IllegalArgumentException("Failed requirement.");
                }
                C0431a aVar = new C0431a(i12);
                this.f43018H.c(i12, aVar);
                if (i12 == ((int) (2097151 & atomicLongFieldUpdater.incrementAndGet(this)))) {
                    int i13 = i11 + 1;
                    aVar.start();
                    return i13;
                }
                throw new IllegalArgumentException("Failed requirement.");
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0088, code lost:
        if (r1 == null) goto L_0x008a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void close() {
        /*
            r8 = this;
            java.util.concurrent.atomic.AtomicIntegerFieldUpdater r0 = f43013K
            r1 = 0
            r2 = 1
            boolean r0 = r0.compareAndSet(r8, r1, r2)
            if (r0 != 0) goto L_0x000b
            return
        L_0x000b:
            java.lang.Thread r0 = java.lang.Thread.currentThread()
            boolean r1 = r0 instanceof pc.C4782a.C0431a
            r3 = 0
            if (r1 == 0) goto L_0x0017
            pc.a$a r0 = (pc.C4782a.C0431a) r0
            goto L_0x0018
        L_0x0017:
            r0 = r3
        L_0x0018:
            if (r0 == 0) goto L_0x0023
            pc.a r1 = pc.C4782a.this
            boolean r1 = kotlin.jvm.internal.l.a(r1, r8)
            if (r1 == 0) goto L_0x0023
            goto L_0x0024
        L_0x0023:
            r0 = r3
        L_0x0024:
            nc.s<pc.a$a> r1 = r8.f43018H
            monitor-enter(r1)
            java.util.concurrent.atomic.AtomicLongFieldUpdater r4 = f43012J     // Catch:{ all -> 0x00c3 }
            long r4 = r4.get(r8)     // Catch:{ all -> 0x00c3 }
            r6 = 2097151(0x1fffff, double:1.0361303E-317)
            long r4 = r4 & r6
            int r4 = (int) r4
            monitor-exit(r1)
            if (r2 > r4) goto L_0x0078
            r1 = r2
        L_0x0036:
            nc.s<pc.a$a> r5 = r8.f43018H
            java.lang.Object r5 = r5.b(r1)
            kotlin.jvm.internal.l.c(r5)
            pc.a$a r5 = (pc.C4782a.C0431a) r5
            if (r5 == r0) goto L_0x0073
        L_0x0043:
            java.lang.Thread$State r6 = r5.getState()
            java.lang.Thread$State r7 = java.lang.Thread.State.TERMINATED
            if (r6 == r7) goto L_0x0054
            java.util.concurrent.locks.LockSupport.unpark(r5)
            r6 = 10000(0x2710, double:4.9407E-320)
            r5.join(r6)
            goto L_0x0043
        L_0x0054:
            pc.l r5 = r5.f43028f
            pc.d r6 = r8.f43017G
            r5.getClass()
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = pc.l.f43052b
            java.lang.Object r7 = r7.getAndSet(r5, r3)
            pc.h r7 = (pc.h) r7
            if (r7 == 0) goto L_0x0068
            r6.a(r7)
        L_0x0068:
            pc.h r7 = r5.b()
            if (r7 != 0) goto L_0x006f
            goto L_0x0073
        L_0x006f:
            r6.a(r7)
            goto L_0x0068
        L_0x0073:
            if (r1 == r4) goto L_0x0078
            int r1 = r1 + 1
            goto L_0x0036
        L_0x0078:
            pc.d r1 = r8.f43017G
            r1.b()
            pc.d r1 = r8.f43016F
            r1.b()
        L_0x0082:
            if (r0 == 0) goto L_0x008a
            pc.h r1 = r0.a(r2)
            if (r1 != 0) goto L_0x00b2
        L_0x008a:
            pc.d r1 = r8.f43016F
            java.lang.Object r1 = r1.d()
            pc.h r1 = (pc.h) r1
            if (r1 != 0) goto L_0x00b2
            pc.d r1 = r8.f43017G
            java.lang.Object r1 = r1.d()
            pc.h r1 = (pc.h) r1
            if (r1 != 0) goto L_0x00b2
            if (r0 == 0) goto L_0x00a5
            pc.a$b r1 = pc.C4782a.b.f43032F
            r0.h(r1)
        L_0x00a5:
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f43011I
            r1 = 0
            r0.set(r8, r1)
            java.util.concurrent.atomic.AtomicLongFieldUpdater r0 = f43012J
            r0.set(r8, r1)
            return
        L_0x00b2:
            r1.run()     // Catch:{ all -> 0x00b6 }
            goto L_0x0082
        L_0x00b6:
            r1 = move-exception
            java.lang.Thread r3 = java.lang.Thread.currentThread()
            java.lang.Thread$UncaughtExceptionHandler r4 = r3.getUncaughtExceptionHandler()
            r4.uncaughtException(r3, r1)
            goto L_0x0082
        L_0x00c3:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: pc.C4782a.close():void");
    }

    public final void d(Runnable runnable, boolean z10, boolean z11) {
        h hVar;
        long j10;
        C0431a aVar;
        boolean z12;
        b bVar;
        j.f43050f.getClass();
        long nanoTime = System.nanoTime();
        if (runnable instanceof h) {
            hVar = (h) runnable;
            hVar.f43042f = nanoTime;
            hVar.f43043i = z10;
        } else {
            hVar = new i(runnable, nanoTime, z10);
        }
        boolean z13 = hVar.f43043i;
        AtomicLongFieldUpdater atomicLongFieldUpdater = f43012J;
        if (z13) {
            j10 = atomicLongFieldUpdater.addAndGet(this, 2097152);
        } else {
            j10 = 0;
        }
        Thread currentThread = Thread.currentThread();
        if (currentThread instanceof C0431a) {
            aVar = (C0431a) currentThread;
        } else {
            aVar = null;
        }
        if (aVar == null || !l.a(C4782a.this, this)) {
            aVar = null;
        }
        if (!(aVar == null || (bVar = aVar.f43030z) == b.f43032F || (!hVar.f43043i && bVar == b.f43035i))) {
            aVar.f43026H = true;
            l lVar = aVar.f43028f;
            if (z11) {
                hVar = lVar.a(hVar);
            } else {
                lVar.getClass();
                h hVar2 = (h) l.f43052b.getAndSet(lVar, hVar);
                if (hVar2 == null) {
                    hVar = null;
                } else {
                    hVar = lVar.a(hVar2);
                }
            }
        }
        if (hVar != null) {
            if (hVar.f43043i) {
                z12 = this.f43017G.a(hVar);
            } else {
                z12 = this.f43016F.a(hVar);
            }
            if (!z12) {
                throw new RejectedExecutionException(i0.c(new StringBuilder(), this.f43015E, " was terminated"));
            }
        }
        if (z13) {
            if (!k() && !j(j10)) {
                k();
            }
        } else if (!k() && !j(atomicLongFieldUpdater.get(this))) {
            k();
        }
    }

    public final void execute(Runnable runnable) {
        e(this, runnable, 6);
    }

    public final void f(C0431a aVar, int i10, int i11) {
        while (true) {
            long j10 = f43011I.get(this);
            int i12 = (int) (2097151 & j10);
            long j11 = (2097152 + j10) & -2097152;
            if (i12 == i10) {
                if (i11 == 0) {
                    Object c10 = aVar.c();
                    while (true) {
                        if (c10 == f43014L) {
                            i12 = -1;
                            break;
                        } else if (c10 == null) {
                            i12 = 0;
                            break;
                        } else {
                            C0431a aVar2 = (C0431a) c10;
                            int b10 = aVar2.b();
                            if (b10 != 0) {
                                i12 = b10;
                                break;
                            }
                            c10 = aVar2.c();
                        }
                    }
                } else {
                    i12 = i11;
                }
            }
            if (i12 >= 0) {
                if (f43011I.compareAndSet(this, j10, ((long) i12) | j11)) {
                    return;
                }
            }
        }
    }

    public final boolean j(long j10) {
        int i10 = ((int) (2097151 & j10)) - ((int) ((j10 & 4398044413952L) >> 21));
        if (i10 < 0) {
            i10 = 0;
        }
        int i11 = this.f43019f;
        if (i10 < i11) {
            int b10 = b();
            if (b10 == 1 && i11 > 1) {
                b();
            }
            if (b10 > 0) {
                return true;
            }
        }
        return false;
    }

    public final boolean k() {
        C4290D d10;
        int i10;
        while (true) {
            AtomicLongFieldUpdater atomicLongFieldUpdater = f43011I;
            long j10 = atomicLongFieldUpdater.get(this);
            C0431a b10 = this.f43018H.b((int) (2097151 & j10));
            if (b10 == null) {
                b10 = null;
            } else {
                long j11 = (2097152 + j10) & -2097152;
                Object c10 = b10.c();
                while (true) {
                    d10 = f43014L;
                    if (c10 == d10) {
                        i10 = -1;
                        break;
                    } else if (c10 == null) {
                        i10 = 0;
                        break;
                    } else {
                        C0431a aVar = (C0431a) c10;
                        i10 = aVar.b();
                        if (i10 != 0) {
                            break;
                        }
                        c10 = aVar.c();
                    }
                }
                if (i10 >= 0) {
                    if (atomicLongFieldUpdater.compareAndSet(this, j10, j11 | ((long) i10))) {
                        b10.g(d10);
                    } else {
                        continue;
                    }
                } else {
                    continue;
                }
            }
            if (b10 == null) {
                return false;
            }
            if (C0431a.f43022J.compareAndSet(b10, -1, 0)) {
                LockSupport.unpark(b10);
                return true;
            }
        }
    }

    public final String toString() {
        int i10;
        ArrayList arrayList = new ArrayList();
        s<C0431a> sVar = this.f43018H;
        int a10 = sVar.a();
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        int i15 = 0;
        for (int i16 = 1; i16 < a10; i16++) {
            C0431a b10 = sVar.b(i16);
            if (b10 != null) {
                l lVar = b10.f43028f;
                lVar.getClass();
                if (l.f43052b.get(lVar) != null) {
                    i10 = (l.f43053c.get(lVar) - l.f43054d.get(lVar)) + 1;
                } else {
                    i10 = l.f43053c.get(lVar) - l.f43054d.get(lVar);
                }
                int ordinal = b10.f43030z.ordinal();
                if (ordinal == 0) {
                    i11++;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(i10);
                    sb2.append('c');
                    arrayList.add(sb2.toString());
                } else if (ordinal == 1) {
                    i12++;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(i10);
                    sb3.append('b');
                    arrayList.add(sb3.toString());
                } else if (ordinal == 2) {
                    i13++;
                } else if (ordinal == 3) {
                    i14++;
                    if (i10 > 0) {
                        StringBuilder sb4 = new StringBuilder();
                        sb4.append(i10);
                        sb4.append(GMTDateParser.DAY_OF_MONTH);
                        arrayList.add(sb4.toString());
                    }
                } else if (ordinal == 4) {
                    i15++;
                } else {
                    throw new RuntimeException();
                }
            }
        }
        long j10 = f43012J.get(this);
        StringBuilder sb5 = new StringBuilder();
        sb5.append(this.f43015E);
        sb5.append('@');
        sb5.append(G.n(this));
        sb5.append("[Pool Size {core = ");
        int i17 = this.f43019f;
        sb5.append(i17);
        sb5.append(", max = ");
        sb5.append(this.f43020i);
        sb5.append("}, Worker States {CPU = ");
        sb5.append(i11);
        sb5.append(", blocking = ");
        sb5.append(i12);
        sb5.append(", parked = ");
        sb5.append(i13);
        sb5.append(", dormant = ");
        sb5.append(i14);
        sb5.append(", terminated = ");
        sb5.append(i15);
        sb5.append("}, running workers queues = ");
        sb5.append(arrayList);
        sb5.append(", global CPU queue size = ");
        sb5.append(this.f43016F.c());
        sb5.append(", global blocking queue size = ");
        sb5.append(this.f43017G.c());
        sb5.append(", Control State {created workers= ");
        sb5.append((int) (2097151 & j10));
        sb5.append(", blocking tasks = ");
        sb5.append((int) ((4398044413952L & j10) >> 21));
        sb5.append(", CPUs acquired = ");
        sb5.append(i17 - ((int) ((j10 & 9223367638808264704L) >> 42)));
        sb5.append("}]");
        return sb5.toString();
    }
}
