package pc;

import A.o;
import Ba.h;
import Ba.i;
import ic.C4498d0;
import ic.C4528y;
import java.util.concurrent.Executor;
import nc.w;

public final class b extends C4498d0 implements Executor {

    /* renamed from: f  reason: collision with root package name */
    public static final b f43037f = new C4498d0();

    /* renamed from: i  reason: collision with root package name */
    public static final C4528y f43038i;

    /* JADX WARNING: type inference failed for: r0v0, types: [pc.b, ic.d0] */
    static {
        k kVar = k.f43051f;
        int i10 = w.f42455a;
        if (64 >= i10) {
            i10 = 64;
        }
        f43038i = C4528y.limitedParallelism$default(kVar, o.d0(i10, 12, "kotlinx.coroutines.io.parallelism"), (String) null, 2, (Object) null);
    }

    public final void close() {
        throw new IllegalStateException("Cannot be invoked on Dispatchers.IO");
    }

    public final void dispatch(h hVar, Runnable runnable) {
        f43038i.dispatch(hVar, runnable);
    }

    public final void dispatchYield(h hVar, Runnable runnable) {
        f43038i.dispatchYield(hVar, runnable);
    }

    public final void execute(Runnable runnable) {
        dispatch(i.f33491f, runnable);
    }

    public final C4528y limitedParallelism(int i10, String str) {
        return k.f43051f.limitedParallelism(i10, str);
    }

    public final String toString() {
        return "Dispatchers.IO";
    }
}
