package pc;

import ic.C4498d0;
import ic.C4528y;
import k5.b;
import nc.q;

public final class c extends f {

    /* renamed from: i  reason: collision with root package name */
    public static final c f43039i;

    /* JADX WARNING: type inference failed for: r0v0, types: [ic.d0, pc.c, pc.f] */
    static {
        int i10 = j.f43047c;
        int i11 = j.f43048d;
        long j10 = j.f43049e;
        String str = j.f43045a;
        ? d0Var = new C4498d0();
        d0Var.f43041f = new C4782a(i10, i11, j10, str);
        f43039i = d0Var;
    }

    public final void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    public final C4528y limitedParallelism(int i10, String str) {
        b.h(i10);
        if (i10 < j.f43047c) {
            return super.limitedParallelism(i10, str);
        }
        if (str != null) {
            return new q(this, str);
        }
        return this;
    }

    public final String toString() {
        return "Dispatchers.Default";
    }
}
