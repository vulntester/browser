package pc;

import nc.m;

public final class d extends m<h> {
}
