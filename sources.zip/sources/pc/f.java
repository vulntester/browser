package pc;

import Ba.h;
import ic.C4498d0;

public class f extends C4498d0 {

    /* renamed from: f  reason: collision with root package name */
    public C4782a f43041f;

    public final void dispatch(h hVar, Runnable runnable) {
        C4782a.e(this.f43041f, runnable, 6);
    }

    public final void dispatchYield(h hVar, Runnable runnable) {
        C4782a.e(this.f43041f, runnable, 2);
    }
}
