package pc;

import com.common.videofinder.VideoInfo;

public abstract class g {
    public abstract void a();

    public abstract boolean b();

    public abstract VideoInfo c();

    public abstract boolean d();
}
