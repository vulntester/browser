package pc;

public abstract class h implements Runnable {

    /* renamed from: f  reason: collision with root package name */
    public long f43042f;

    /* renamed from: i  reason: collision with root package name */
    public boolean f43043i;

    public h(long j10, boolean z10) {
        this.f43042f = j10;
        this.f43043i = z10;
    }

    public h() {
        this(0, false);
    }
}
