package pc;

import D2.E;
import ic.G;

public final class i extends h {

    /* renamed from: z  reason: collision with root package name */
    public final Runnable f43044z;

    public i(Runnable runnable, long j10, boolean z10) {
        super(j10, z10);
        this.f43044z = runnable;
    }

    public final void run() {
        this.f43044z.run();
    }

    public final String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder("Task[");
        Runnable runnable = this.f43044z;
        sb2.append(runnable.getClass().getSimpleName());
        sb2.append('@');
        sb2.append(G.n(runnable));
        sb2.append(", ");
        sb2.append(this.f43042f);
        sb2.append(", ");
        if (this.f43043i) {
            str = "Blocking";
        } else {
            str = "Non-blocking";
        }
        return E.p(sb2, str, ']');
    }
}
