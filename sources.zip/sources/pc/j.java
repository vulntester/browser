package pc;

import A.o;
import java.util.concurrent.TimeUnit;
import nc.w;

public final class j {

    /* renamed from: a  reason: collision with root package name */
    public static final String f43045a;

    /* renamed from: b  reason: collision with root package name */
    public static final long f43046b = o.c0(100000, 1, Long.MAX_VALUE, "kotlinx.coroutines.scheduler.resolution.ns");

    /* renamed from: c  reason: collision with root package name */
    public static final int f43047c;

    /* renamed from: d  reason: collision with root package name */
    public static final int f43048d = o.d0(2097150, 4, "kotlinx.coroutines.scheduler.max.pool.size");

    /* renamed from: e  reason: collision with root package name */
    public static final long f43049e = TimeUnit.SECONDS.toNanos(o.c0(60, 1, Long.MAX_VALUE, "kotlinx.coroutines.scheduler.keep.alive.sec"));

    /* renamed from: f  reason: collision with root package name */
    public static final e f43050f = e.f43040a;

    static {
        String str;
        int i10 = w.f42455a;
        try {
            str = System.getProperty("kotlinx.coroutines.scheduler.default.name");
        } catch (SecurityException unused) {
            str = null;
        }
        if (str == null) {
            str = "DefaultDispatcher";
        }
        f43045a = str;
        int i11 = w.f42455a;
        if (i11 < 2) {
            i11 = 2;
        }
        f43047c = o.d0(i11, 8, "kotlinx.coroutines.scheduler.core.pool.size");
    }
}
