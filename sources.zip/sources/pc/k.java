package pc;

import Ba.h;
import ic.C4528y;
import k5.b;
import nc.q;

public final class k extends C4528y {

    /* renamed from: f  reason: collision with root package name */
    public static final k f43051f = new C4528y();

    public final void dispatch(h hVar, Runnable runnable) {
        c.f43039i.f43041f.d(runnable, true, false);
    }

    public final void dispatchYield(h hVar, Runnable runnable) {
        c.f43039i.f43041f.d(runnable, true, true);
    }

    public final C4528y limitedParallelism(int i10, String str) {
        b.h(i10);
        if (i10 < j.f43048d) {
            return super.limitedParallelism(i10, str);
        }
        if (str != null) {
            return new q(this, str);
        }
        return this;
    }

    public final String toString() {
        return "Dispatchers.IO";
    }
}
