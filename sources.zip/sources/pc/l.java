package pc;

import io.netty.handler.codec.http.HttpObjectDecoder;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class l {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f43052b;

    /* renamed from: c  reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f43053c;

    /* renamed from: d  reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f43054d;

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f43055e;

    /* renamed from: a  reason: collision with root package name */
    public final AtomicReferenceArray<h> f43056a = new AtomicReferenceArray<>(HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
    private volatile /* synthetic */ int blockingTasksInBuffer$volatile;
    private volatile /* synthetic */ int consumerIndex$volatile;
    private volatile /* synthetic */ Object lastScheduledTask$volatile;
    private volatile /* synthetic */ int producerIndex$volatile;

    static {
        Class<l> cls = l.class;
        f43052b = AtomicReferenceFieldUpdater.newUpdater(cls, Object.class, "lastScheduledTask$volatile");
        f43053c = AtomicIntegerFieldUpdater.newUpdater(cls, "producerIndex$volatile");
        f43054d = AtomicIntegerFieldUpdater.newUpdater(cls, "consumerIndex$volatile");
        f43055e = AtomicIntegerFieldUpdater.newUpdater(cls, "blockingTasksInBuffer$volatile");
    }

    public final h a(h hVar) {
        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f43053c;
        if (atomicIntegerFieldUpdater.get(this) - f43054d.get(this) == 127) {
            return hVar;
        }
        if (hVar.f43043i) {
            f43055e.incrementAndGet(this);
        }
        int i10 = atomicIntegerFieldUpdater.get(this) & 127;
        while (true) {
            AtomicReferenceArray<h> atomicReferenceArray = this.f43056a;
            if (atomicReferenceArray.get(i10) != null) {
                Thread.yield();
            } else {
                atomicReferenceArray.lazySet(i10, hVar);
                atomicIntegerFieldUpdater.incrementAndGet(this);
                return null;
            }
        }
    }

    public final h b() {
        h andSet;
        while (true) {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f43054d;
            int i10 = atomicIntegerFieldUpdater.get(this);
            if (i10 - f43053c.get(this) == 0) {
                return null;
            }
            int i11 = i10 & 127;
            if (atomicIntegerFieldUpdater.compareAndSet(this, i10, i10 + 1) && (andSet = this.f43056a.getAndSet(i11, (Object) null)) != null) {
                if (andSet.f43043i) {
                    f43055e.decrementAndGet(this);
                }
                return andSet;
            }
        }
    }

    public final h c(int i10, boolean z10) {
        int i11 = i10 & 127;
        AtomicReferenceArray<h> atomicReferenceArray = this.f43056a;
        h hVar = atomicReferenceArray.get(i11);
        if (hVar == null || hVar.f43043i != z10) {
            return null;
        }
        while (!atomicReferenceArray.compareAndSet(i11, hVar, (Object) null)) {
            if (atomicReferenceArray.get(i11) != hVar) {
                return null;
            }
        }
        if (z10) {
            f43055e.decrementAndGet(this);
        }
        return hVar;
    }
}
