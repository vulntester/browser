package s2;

/* renamed from: s2.a  reason: case insensitive filesystem */
public abstract class C3070a {

    /* renamed from: f  reason: collision with root package name */
    public int f27685f;

    public final void g(int i10) {
        this.f27685f = i10 | this.f27685f;
    }

    public final boolean i(int i10) {
        if ((this.f27685f & i10) == i10) {
            return true;
        }
        return false;
    }
}
