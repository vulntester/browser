package s2;

public interface b {
}
