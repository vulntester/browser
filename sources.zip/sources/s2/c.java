package s2;

import X0.t;
import android.media.MediaCodec;
import o2.C2756B;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public byte[] f27686a;

    /* renamed from: b  reason: collision with root package name */
    public byte[] f27687b;

    /* renamed from: c  reason: collision with root package name */
    public int f27688c;

    /* renamed from: d  reason: collision with root package name */
    public int[] f27689d;

    /* renamed from: e  reason: collision with root package name */
    public int[] f27690e;

    /* renamed from: f  reason: collision with root package name */
    public int f27691f;

    /* renamed from: g  reason: collision with root package name */
    public int f27692g;

    /* renamed from: h  reason: collision with root package name */
    public int f27693h;

    /* renamed from: i  reason: collision with root package name */
    public final MediaCodec.CryptoInfo f27694i;

    /* renamed from: j  reason: collision with root package name */
    public final a f27695j;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final MediaCodec.CryptoInfo f27696a;

        /* renamed from: b  reason: collision with root package name */
        public final MediaCodec.CryptoInfo.Pattern f27697b = t.c();

        public a(MediaCodec.CryptoInfo cryptoInfo) {
            this.f27696a = cryptoInfo;
        }
    }

    public c() {
        a aVar;
        MediaCodec.CryptoInfo cryptoInfo = new MediaCodec.CryptoInfo();
        this.f27694i = cryptoInfo;
        if (C2756B.f25811a >= 24) {
            aVar = new a(cryptoInfo);
        } else {
            aVar = null;
        }
        this.f27695j = aVar;
    }
}
