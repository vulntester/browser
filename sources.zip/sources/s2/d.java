package s2;

import o3.C2770l;
import s2.e;

public interface d<I, O, E extends e> {
    void a(long j10);

    O d();

    I e();

    void f(C2770l lVar);

    void flush();

    void release();
}
