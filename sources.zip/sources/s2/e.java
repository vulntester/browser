package s2;

public class e extends Exception {
}
