package s2;

import L.C0866g;
import java.nio.ByteBuffer;
import l2.n;
import l2.r;

public class f extends C3070a {

    /* renamed from: E  reason: collision with root package name */
    public ByteBuffer f27698E;

    /* renamed from: F  reason: collision with root package name */
    public boolean f27699F;

    /* renamed from: G  reason: collision with root package name */
    public long f27700G;

    /* renamed from: H  reason: collision with root package name */
    public ByteBuffer f27701H;

    /* renamed from: I  reason: collision with root package name */
    public final int f27702I;

    /* renamed from: i  reason: collision with root package name */
    public n f27703i;

    /* renamed from: z  reason: collision with root package name */
    public final c f27704z = new c();

    public static final class a extends IllegalStateException {
    }

    static {
        r.a("media3.decoder");
    }

    public f(int i10) {
        this.f27702I = i10;
    }

    public void j() {
        this.f27685f = 0;
        ByteBuffer byteBuffer = this.f27698E;
        if (byteBuffer != null) {
            byteBuffer.clear();
        }
        ByteBuffer byteBuffer2 = this.f27701H;
        if (byteBuffer2 != null) {
            byteBuffer2.clear();
        }
        this.f27699F = false;
    }

    public final ByteBuffer k(int i10) {
        int i11;
        int i12 = this.f27702I;
        if (i12 == 1) {
            return ByteBuffer.allocate(i10);
        }
        if (i12 == 2) {
            return ByteBuffer.allocateDirect(i10);
        }
        ByteBuffer byteBuffer = this.f27698E;
        if (byteBuffer == null) {
            i11 = 0;
        } else {
            i11 = byteBuffer.capacity();
        }
        throw new IllegalStateException(C0866g.g(i11, i10, "Buffer too small (", " < ", ")"));
    }

    public final void m(int i10) {
        ByteBuffer byteBuffer = this.f27698E;
        if (byteBuffer == null) {
            this.f27698E = k(i10);
            return;
        }
        int capacity = byteBuffer.capacity();
        int position = byteBuffer.position();
        int i11 = i10 + position;
        if (capacity >= i11) {
            this.f27698E = byteBuffer;
            return;
        }
        ByteBuffer k10 = k(i11);
        k10.order(byteBuffer.order());
        if (position > 0) {
            byteBuffer.flip();
            k10.put(byteBuffer);
        }
        this.f27698E = k10;
    }

    public final void p() {
        ByteBuffer byteBuffer = this.f27698E;
        if (byteBuffer != null) {
            byteBuffer.flip();
        }
        ByteBuffer byteBuffer2 = this.f27701H;
        if (byteBuffer2 != null) {
            byteBuffer2.flip();
        }
    }
}
