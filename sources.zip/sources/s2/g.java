package s2;

public abstract class g extends C3070a {

    /* renamed from: i  reason: collision with root package name */
    public long f27705i;

    /* renamed from: z  reason: collision with root package name */
    public boolean f27706z;

    public void j() {
        this.f27685f = 0;
        this.f27705i = 0;
        this.f27706z = false;
    }

    public abstract void k();
}
