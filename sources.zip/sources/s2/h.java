package s2;

import f7.M;
import java.util.ArrayDeque;
import s2.e;
import s2.f;
import s2.g;

public abstract class h<I extends f, O extends g, E extends e> implements d<I, O, E> {

    /* renamed from: a  reason: collision with root package name */
    public final a f27707a;

    /* renamed from: b  reason: collision with root package name */
    public final Object f27708b = new Object();

    /* renamed from: c  reason: collision with root package name */
    public final ArrayDeque<I> f27709c = new ArrayDeque<>();

    /* renamed from: d  reason: collision with root package name */
    public final ArrayDeque<O> f27710d = new ArrayDeque<>();

    /* renamed from: e  reason: collision with root package name */
    public final I[] f27711e;

    /* renamed from: f  reason: collision with root package name */
    public final O[] f27712f;

    /* renamed from: g  reason: collision with root package name */
    public int f27713g;

    /* renamed from: h  reason: collision with root package name */
    public int f27714h;

    /* renamed from: i  reason: collision with root package name */
    public I f27715i;

    /* renamed from: j  reason: collision with root package name */
    public E f27716j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f27717k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f27718l;

    /* renamed from: m  reason: collision with root package name */
    public long f27719m = -9223372036854775807L;

    public class a extends Thread {
        public a() {
            super("ExoPlayer:SimpleDecoder");
        }

        public final void run() {
            do {
                try {
                } catch (InterruptedException e10) {
                    throw new IllegalStateException(e10);
                }
            } while (h.this.k());
        }
    }

    public h(I[] iArr, O[] oArr) {
        this.f27711e = iArr;
        this.f27713g = iArr.length;
        for (int i10 = 0; i10 < this.f27713g; i10++) {
            this.f27711e[i10] = g();
        }
        this.f27712f = oArr;
        this.f27714h = oArr.length;
        for (int i11 = 0; i11 < this.f27714h; i11++) {
            this.f27712f[i11] = h();
        }
        a aVar = new a();
        this.f27707a = aVar;
        aVar.start();
    }

    public final void a(long j10) {
        boolean z10;
        synchronized (this.f27708b) {
            try {
                if (this.f27713g != this.f27711e.length) {
                    if (!this.f27717k) {
                        z10 = false;
                        M.m(z10);
                        this.f27719m = j10;
                    }
                }
                z10 = true;
                M.m(z10);
                this.f27719m = j10;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* renamed from: b */
    public final void f(I i10) {
        boolean z10;
        synchronized (this.f27708b) {
            try {
                E e10 = this.f27716j;
                if (e10 == null) {
                    if (i10 == this.f27715i) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    M.h(z10);
                    this.f27709c.addLast(i10);
                    if (!this.f27709c.isEmpty() && this.f27714h > 0) {
                        this.f27708b.notify();
                    }
                    this.f27715i = null;
                } else {
                    throw e10;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final Object e() {
        boolean z10;
        I i10;
        synchronized (this.f27708b) {
            try {
                E e10 = this.f27716j;
                if (e10 == null) {
                    if (this.f27715i == null) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    M.m(z10);
                    int i11 = this.f27713g;
                    if (i11 == 0) {
                        i10 = null;
                    } else {
                        I[] iArr = this.f27711e;
                        int i12 = i11 - 1;
                        this.f27713g = i12;
                        i10 = iArr[i12];
                    }
                    this.f27715i = i10;
                } else {
                    throw e10;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return i10;
    }

    public final void flush() {
        synchronized (this.f27708b) {
            try {
                this.f27717k = true;
                I i10 = this.f27715i;
                if (i10 != null) {
                    i10.j();
                    int i11 = this.f27713g;
                    this.f27713g = i11 + 1;
                    this.f27711e[i11] = i10;
                    this.f27715i = null;
                }
                while (!this.f27709c.isEmpty()) {
                    I i12 = (f) this.f27709c.removeFirst();
                    i12.j();
                    int i13 = this.f27713g;
                    this.f27713g = i13 + 1;
                    this.f27711e[i13] = i12;
                }
                while (!this.f27710d.isEmpty()) {
                    ((g) this.f27710d.removeFirst()).k();
                }
            } finally {
            }
        }
    }

    public abstract I g();

    public abstract O h();

    public abstract E i(Throwable th);

    public abstract E j(I i10, O o10, boolean z10);

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0044, code lost:
        if (r1.i(4) == false) goto L_0x004a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0046, code lost:
        r4.g(4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x004a, code lost:
        r4.f27705i = r1.f27700G;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0054, code lost:
        if (r1.i(134217728) == false) goto L_0x0059;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0056, code lost:
        r4.g(134217728);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x005f, code lost:
        if (m(r1.f27700G) != false) goto L_0x0063;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0061, code lost:
        r4.f27706z = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:?, code lost:
        r0 = j(r1, r4, r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0068, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0069, code lost:
        r0 = i(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x006e, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x006f, code lost:
        r0 = i(r0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean k() {
        /*
            r8 = this;
            java.lang.Object r0 = r8.f27708b
            monitor-enter(r0)
        L_0x0003:
            boolean r1 = r8.f27718l     // Catch:{ all -> 0x0020 }
            r2 = 0
            r3 = 1
            if (r1 != 0) goto L_0x0023
            java.util.ArrayDeque<I> r1 = r8.f27709c     // Catch:{ all -> 0x0020 }
            boolean r1 = r1.isEmpty()     // Catch:{ all -> 0x0020 }
            if (r1 != 0) goto L_0x0017
            int r1 = r8.f27714h     // Catch:{ all -> 0x0020 }
            if (r1 <= 0) goto L_0x0017
            r1 = r3
            goto L_0x0018
        L_0x0017:
            r1 = r2
        L_0x0018:
            if (r1 != 0) goto L_0x0023
            java.lang.Object r1 = r8.f27708b     // Catch:{ all -> 0x0020 }
            r1.wait()     // Catch:{ all -> 0x0020 }
            goto L_0x0003
        L_0x0020:
            r1 = move-exception
            goto L_0x00aa
        L_0x0023:
            boolean r1 = r8.f27718l     // Catch:{ all -> 0x0020 }
            if (r1 == 0) goto L_0x0029
            monitor-exit(r0)     // Catch:{ all -> 0x0020 }
            return r2
        L_0x0029:
            java.util.ArrayDeque<I> r1 = r8.f27709c     // Catch:{ all -> 0x0020 }
            java.lang.Object r1 = r1.removeFirst()     // Catch:{ all -> 0x0020 }
            s2.f r1 = (s2.f) r1     // Catch:{ all -> 0x0020 }
            O[] r4 = r8.f27712f     // Catch:{ all -> 0x0020 }
            int r5 = r8.f27714h     // Catch:{ all -> 0x0020 }
            int r5 = r5 - r3
            r8.f27714h = r5     // Catch:{ all -> 0x0020 }
            r4 = r4[r5]     // Catch:{ all -> 0x0020 }
            boolean r5 = r8.f27717k     // Catch:{ all -> 0x0020 }
            r8.f27717k = r2     // Catch:{ all -> 0x0020 }
            monitor-exit(r0)     // Catch:{ all -> 0x0020 }
            r0 = 4
            boolean r6 = r1.i(r0)
            if (r6 == 0) goto L_0x004a
            r4.g(r0)
            goto L_0x007f
        L_0x004a:
            long r6 = r1.f27700G
            r4.f27705i = r6
            r0 = 134217728(0x8000000, float:3.85186E-34)
            boolean r6 = r1.i(r0)
            if (r6 == 0) goto L_0x0059
            r4.g(r0)
        L_0x0059:
            long r6 = r1.f27700G
            boolean r0 = r8.m(r6)
            if (r0 != 0) goto L_0x0063
            r4.f27706z = r3
        L_0x0063:
            s2.e r0 = r8.j(r1, r4, r5)     // Catch:{ RuntimeException -> 0x006e, OutOfMemoryError -> 0x0068 }
            goto L_0x0073
        L_0x0068:
            r0 = move-exception
            s2.e r0 = r8.i(r0)
            goto L_0x0073
        L_0x006e:
            r0 = move-exception
            s2.e r0 = r8.i(r0)
        L_0x0073:
            if (r0 == 0) goto L_0x007f
            java.lang.Object r5 = r8.f27708b
            monitor-enter(r5)
            r8.f27716j = r0     // Catch:{ all -> 0x007c }
            monitor-exit(r5)     // Catch:{ all -> 0x007c }
            return r2
        L_0x007c:
            r0 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x007c }
            throw r0
        L_0x007f:
            java.lang.Object r2 = r8.f27708b
            monitor-enter(r2)
            boolean r0 = r8.f27717k     // Catch:{ all -> 0x008a }
            if (r0 == 0) goto L_0x008c
            r4.k()     // Catch:{ all -> 0x008a }
            goto L_0x0099
        L_0x008a:
            r0 = move-exception
            goto L_0x00a8
        L_0x008c:
            boolean r0 = r4.f27706z     // Catch:{ all -> 0x008a }
            if (r0 == 0) goto L_0x0094
            r4.k()     // Catch:{ all -> 0x008a }
            goto L_0x0099
        L_0x0094:
            java.util.ArrayDeque<O> r0 = r8.f27710d     // Catch:{ all -> 0x008a }
            r0.addLast(r4)     // Catch:{ all -> 0x008a }
        L_0x0099:
            r1.j()     // Catch:{ all -> 0x008a }
            int r0 = r8.f27713g     // Catch:{ all -> 0x008a }
            int r4 = r0 + 1
            r8.f27713g = r4     // Catch:{ all -> 0x008a }
            I[] r4 = r8.f27711e     // Catch:{ all -> 0x008a }
            r4[r0] = r1     // Catch:{ all -> 0x008a }
            monitor-exit(r2)     // Catch:{ all -> 0x008a }
            return r3
        L_0x00a8:
            monitor-exit(r2)     // Catch:{ all -> 0x008a }
            throw r0
        L_0x00aa:
            monitor-exit(r0)     // Catch:{ all -> 0x0020 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: s2.h.k():boolean");
    }

    /* renamed from: l */
    public final O d() {
        synchronized (this.f27708b) {
            try {
                E e10 = this.f27716j;
                if (e10 != null) {
                    throw e10;
                } else if (this.f27710d.isEmpty()) {
                    return null;
                } else {
                    O o10 = (g) this.f27710d.removeFirst();
                    return o10;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean m(long j10) {
        boolean z10;
        synchronized (this.f27708b) {
            long j11 = this.f27719m;
            if (j11 != -9223372036854775807L) {
                if (j10 < j11) {
                    z10 = false;
                }
            }
            z10 = true;
        }
        return z10;
    }

    public final void n(O o10) {
        synchronized (this.f27708b) {
            o10.j();
            int i10 = this.f27714h;
            this.f27714h = i10 + 1;
            this.f27712f[i10] = o10;
            if (!this.f27709c.isEmpty() && this.f27714h > 0) {
                this.f27708b.notify();
            }
        }
    }

    public final void release() {
        synchronized (this.f27708b) {
            this.f27718l = true;
            this.f27708b.notify();
        }
        try {
            this.f27707a.join();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }
}
