package s3;

/* renamed from: s3.a  reason: case insensitive filesystem */
public final class C3071a {

    /* renamed from: a  reason: collision with root package name */
    public final int f27721a;

    /* renamed from: b  reason: collision with root package name */
    public final int f27722b;

    /* renamed from: c  reason: collision with root package name */
    public final int f27723c;

    /* renamed from: d  reason: collision with root package name */
    public final int f27724d;

    /* renamed from: e  reason: collision with root package name */
    public final int f27725e;

    public C3071a(int i10, int i11, int i12, int i13, int i14) {
        this.f27721a = i10;
        this.f27722b = i11;
        this.f27723c = i12;
        this.f27724d = i13;
        this.f27725e = i14;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static s3.C3071a a(java.lang.String r10) {
        /*
            r0 = 1
            java.lang.String r1 = "Format:"
            boolean r1 = r10.startsWith(r1)
            f7.M.h(r1)
            r1 = 7
            java.lang.String r10 = r10.substring(r1)
            java.lang.String r1 = ","
            java.lang.String[] r10 = android.text.TextUtils.split(r10, r1)
            r1 = -1
            r2 = 0
            r5 = r1
            r6 = r5
            r7 = r6
            r8 = r7
            r3 = r2
        L_0x001c:
            int r4 = r10.length
            if (r3 >= r4) goto L_0x006d
            r4 = r10[r3]
            java.lang.String r4 = r4.trim()
            java.lang.String r4 = A1.a.N(r4)
            r4.getClass()
            int r9 = r4.hashCode()
            switch(r9) {
                case 100571: goto L_0x0056;
                case 3556653: goto L_0x004b;
                case 109757538: goto L_0x0040;
                case 109780401: goto L_0x0035;
                default: goto L_0x0033;
            }
        L_0x0033:
            r4 = r1
            goto L_0x0060
        L_0x0035:
            java.lang.String r9 = "style"
            boolean r4 = r4.equals(r9)
            if (r4 != 0) goto L_0x003e
            goto L_0x0033
        L_0x003e:
            r4 = 3
            goto L_0x0060
        L_0x0040:
            java.lang.String r9 = "start"
            boolean r4 = r4.equals(r9)
            if (r4 != 0) goto L_0x0049
            goto L_0x0033
        L_0x0049:
            r4 = 2
            goto L_0x0060
        L_0x004b:
            java.lang.String r9 = "text"
            boolean r4 = r4.equals(r9)
            if (r4 != 0) goto L_0x0054
            goto L_0x0033
        L_0x0054:
            r4 = r0
            goto L_0x0060
        L_0x0056:
            java.lang.String r9 = "end"
            boolean r4 = r4.equals(r9)
            if (r4 != 0) goto L_0x005f
            goto L_0x0033
        L_0x005f:
            r4 = r2
        L_0x0060:
            switch(r4) {
                case 0: goto L_0x006a;
                case 1: goto L_0x0068;
                case 2: goto L_0x0066;
                case 3: goto L_0x0064;
                default: goto L_0x0063;
            }
        L_0x0063:
            goto L_0x006b
        L_0x0064:
            r7 = r3
            goto L_0x006b
        L_0x0066:
            r5 = r3
            goto L_0x006b
        L_0x0068:
            r8 = r3
            goto L_0x006b
        L_0x006a:
            r6 = r3
        L_0x006b:
            int r3 = r3 + r0
            goto L_0x001c
        L_0x006d:
            if (r5 == r1) goto L_0x007a
            if (r6 == r1) goto L_0x007a
            if (r8 == r1) goto L_0x007a
            s3.a r4 = new s3.a
            int r9 = r10.length
            r4.<init>(r5, r6, r7, r8, r9)
            return r4
        L_0x007a:
            r10 = 0
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: s3.C3071a.a(java.lang.String):s3.a");
    }
}
