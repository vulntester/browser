package s3;

import D1.c;
import f7.M;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import o2.C2756B;
import o2.t;
import o3.C2766h;
import o3.C2772n;

public final class b implements C2772n {

    /* renamed from: g  reason: collision with root package name */
    public static final Pattern f27726g = Pattern.compile("(?:(\\d+):)?(\\d+):(\\d+)[:.](\\d+)");

    /* renamed from: a  reason: collision with root package name */
    public final boolean f27727a;

    /* renamed from: b  reason: collision with root package name */
    public final C3071a f27728b;

    /* renamed from: c  reason: collision with root package name */
    public final t f27729c = new t();

    /* renamed from: d  reason: collision with root package name */
    public LinkedHashMap f27730d;

    /* renamed from: e  reason: collision with root package name */
    public float f27731e = -3.4028235E38f;

    /* renamed from: f  reason: collision with root package name */
    public float f27732f = -3.4028235E38f;

    public b(List<byte[]> list) {
        if (list == null || list.isEmpty()) {
            this.f27727a = false;
            this.f27728b = null;
            return;
        }
        this.f27727a = true;
        String o10 = C2756B.o(list.get(0));
        M.h(o10.startsWith("Format:"));
        C3071a a10 = C3071a.a(o10);
        a10.getClass();
        this.f27728b = a10;
        e(new t(list.get(1)), StandardCharsets.UTF_8);
    }

    public static int d(long j10, ArrayList arrayList, ArrayList arrayList2) {
        int i10;
        ArrayList arrayList3;
        int size = arrayList.size() - 1;
        while (true) {
            if (size < 0) {
                i10 = 0;
                break;
            } else if (((Long) arrayList.get(size)).longValue() == j10) {
                return size;
            } else {
                if (((Long) arrayList.get(size)).longValue() < j10) {
                    i10 = size + 1;
                    break;
                }
                size--;
            }
        }
        arrayList.add(i10, Long.valueOf(j10));
        if (i10 != 0) {
            arrayList3 = new ArrayList((Collection) arrayList2.get(i10 - 1));
        }
        arrayList2.add(i10, arrayList3);
        return i10;
    }

    public static long f(String str) {
        Matcher matcher = f27726g.matcher(str.trim());
        if (!matcher.matches()) {
            return -9223372036854775807L;
        }
        String group = matcher.group(1);
        int i10 = C2756B.f25811a;
        return (Long.parseLong(matcher.group(4)) * 10000) + (Long.parseLong(matcher.group(3)) * 1000000) + (Long.parseLong(matcher.group(2)) * 60000000) + (Long.parseLong(group) * 3600000000L);
    }

    public final /* synthetic */ C2766h a(int i10, byte[] bArr, int i11) {
        return c.b(this, bArr, i11);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:100:0x0232, code lost:
        switch(r14) {
            case -1: goto L_0x0238;
            case 0: goto L_0x0235;
            case 1: goto L_0x023e;
            case 2: goto L_0x023c;
            case 3: goto L_0x023a;
            case 4: goto L_0x023e;
            case 5: goto L_0x023c;
            case 6: goto L_0x023a;
            case 7: goto L_0x023e;
            case 8: goto L_0x023c;
            case 9: goto L_0x023a;
            default: goto L_0x0235;
        };
     */
    /* JADX WARNING: Code restructure failed: missing block: B:101:0x0235, code lost:
        A6.u.r(r14, "Unknown alignment: ", "SsaParser");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x0238, code lost:
        r7 = Integer.MIN_VALUE;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x023a, code lost:
        r7 = 2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x023c, code lost:
        r7 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x023e, code lost:
        r7 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:0x023f, code lost:
        r6.f25629i = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:107:0x0241, code lost:
        switch(r14) {
            case -1: goto L_0x024d;
            case 0: goto L_0x0244;
            case 1: goto L_0x024c;
            case 2: goto L_0x024c;
            case 3: goto L_0x024c;
            case 4: goto L_0x024a;
            case 5: goto L_0x024a;
            case 6: goto L_0x024a;
            case 7: goto L_0x0248;
            case 8: goto L_0x0248;
            case 9: goto L_0x0248;
            default: goto L_0x0244;
        };
     */
    /* JADX WARNING: Code restructure failed: missing block: B:108:0x0244, code lost:
        A6.u.r(r14, "Unknown alignment: ", "SsaParser");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:0x0248, code lost:
        r1 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x024a, code lost:
        r1 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x024c, code lost:
        r1 = 2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x024d, code lost:
        r6.f25627g = r1;
        r0 = r20;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:113:0x0251, code lost:
        if (r0 == null) goto L_0x026b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x0255, code lost:
        if (r25 == -3.4028235E38f) goto L_0x026b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0259, code lost:
        if (r23 == -3.4028235E38f) goto L_0x026b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:118:0x025b, code lost:
        r6.f25628h = r0.x / r23;
        r6.f25625e = r0.y / r25;
        r6.f25626f = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:119:0x026b, code lost:
        r0 = r6.f25629i;
        r7 = 0.05f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:120:0x0275, code lost:
        if (r0 == 0) goto L_0x0285;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x0277, code lost:
        r14 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x0278, code lost:
        if (r0 == 1) goto L_0x0282;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:123:0x027a, code lost:
        r15 = 2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:124:0x027b, code lost:
        if (r0 == 2) goto L_0x0280;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:125:0x027d, code lost:
        r0 = -3.4028235E38f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x0280, code lost:
        r0 = 0.95f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x0282, code lost:
        r15 = 2;
        r0 = 0.5f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:128:0x0285, code lost:
        r14 = 1;
        r15 = 2;
        r0 = 0.05f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x0288, code lost:
        r6.f25628h = r0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:130:0x028a, code lost:
        if (r1 == 0) goto L_0x0296;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:131:0x028c, code lost:
        if (r1 == r14) goto L_0x0295;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:132:0x028e, code lost:
        if (r1 == r15) goto L_0x0293;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x0290, code lost:
        r7 = -3.4028235E38f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:134:0x0293, code lost:
        r7 = 0.95f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x0295, code lost:
        r7 = 0.5f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:136:0x0296, code lost:
        r6.f25625e = r7;
        r6.f25626f = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:137:0x029b, code lost:
        r0 = r6.a();
        r1 = d(r12, r5, r4);
        r6 = d(r10, r5, r4);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:138:0x02a7, code lost:
        if (r1 >= r6) goto L_0x02bc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:139:0x02a9, code lost:
        ((java.util.List) r4.get(r1)).add(r0);
        r1 = r1 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:95:0x0224, code lost:
        r1 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:99:0x022e, code lost:
        r6.f25623c = r1;
        r1 = Integer.MIN_VALUE;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:45:0x00fc */
    /* JADX WARNING: Removed duplicated region for block: B:179:0x011c A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0108 A[Catch:{ RuntimeException -> 0x011c }] */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0116  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x011a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void b(byte[] r27, int r28, int r29, o3.C2772n.b r30, o2.g<o3.C2761c> r31) {
        /*
            r26 = this;
            r0 = r26
            r1 = r28
            r2 = r30
            r3 = r31
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            int r6 = r1 + r29
            o2.t r7 = r0.f27729c
            r8 = r27
            r7.E(r6, r8)
            r7.G(r1)
            java.nio.charset.Charset r1 = r7.C()
            if (r1 == 0) goto L_0x0025
            goto L_0x0027
        L_0x0025:
            java.nio.charset.Charset r1 = java.nio.charset.StandardCharsets.UTF_8
        L_0x0027:
            boolean r6 = r0.f27727a
            if (r6 != 0) goto L_0x002e
            r0.e(r7, r1)
        L_0x002e:
            if (r6 == 0) goto L_0x0033
            s3.a r6 = r0.f27728b
            goto L_0x0034
        L_0x0033:
            r6 = 0
        L_0x0034:
            java.lang.String r9 = r7.i(r1)
            if (r9 == 0) goto L_0x02c6
            java.lang.String r14 = "Format:"
            boolean r14 = r9.startsWith(r14)
            if (r14 == 0) goto L_0x0047
            s3.a r6 = s3.C3071a.a(r9)
            goto L_0x0034
        L_0x0047:
            java.lang.String r14 = "Dialogue:"
            boolean r15 = r9.startsWith(r14)
            if (r15 == 0) goto L_0x005c
            java.lang.String r15 = "SsaParser"
            if (r6 != 0) goto L_0x0064
            java.lang.String r10 = "Skipping dialogue line before complete format: "
            java.lang.String r9 = r10.concat(r9)
            o2.n.f(r15, r9)
        L_0x005c:
            r18 = r1
            r21 = r6
            r24 = r7
            goto L_0x02bc
        L_0x0064:
            boolean r14 = r9.startsWith(r14)
            f7.M.h(r14)
            r14 = 9
            java.lang.String r14 = r9.substring(r14)
            java.lang.String r8 = ","
            r28 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r12 = r6.f27725e
            java.lang.String[] r8 = r14.split(r8, r12)
            int r13 = r8.length
            if (r13 == r12) goto L_0x008b
            java.lang.String r8 = "Skipping dialogue line with fewer columns than format: "
            java.lang.String r8 = r8.concat(r9)
            o2.n.f(r15, r8)
            goto L_0x005c
        L_0x008b:
            int r12 = r6.f27721a
            r12 = r8[r12]
            long r12 = f(r12)
            int r14 = (r12 > r28 ? 1 : (r12 == r28 ? 0 : -1))
            java.lang.String r11 = "Skipping invalid timing: "
            if (r14 != 0) goto L_0x00a1
            java.lang.String r8 = r11.concat(r9)
            o2.n.f(r15, r8)
            goto L_0x005c
        L_0x00a1:
            int r14 = r6.f27722b
            r14 = r8[r14]
            r17 = r11
            long r10 = f(r14)
            int r14 = (r10 > r28 ? 1 : (r10 == r28 ? 0 : -1))
            if (r14 == 0) goto L_0x00b3
            int r14 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r14 > 0) goto L_0x00bd
        L_0x00b3:
            r18 = r1
            r21 = r6
            r24 = r7
            r0 = r17
            goto L_0x02b5
        L_0x00bd:
            java.util.LinkedHashMap r9 = r0.f27730d
            r14 = -1
            r18 = r1
            if (r9 == 0) goto L_0x00d5
            int r1 = r6.f27723c
            if (r1 == r14) goto L_0x00d5
            r1 = r8[r1]
            java.lang.String r1 = r1.trim()
            java.lang.Object r1 = r9.get(r1)
            s3.c r1 = (s3.c) r1
            goto L_0x00d6
        L_0x00d5:
            r1 = 0
        L_0x00d6:
            int r9 = r6.f27724d
            r8 = r8[r9]
            java.util.regex.Pattern r9 = s3.c.b.f27754a
            java.util.regex.Matcher r9 = r9.matcher(r8)
            r19 = r14
            r20 = 0
        L_0x00e4:
            boolean r17 = r9.find()
            if (r17 == 0) goto L_0x0120
            r21 = r6
            r14 = 1
            java.lang.String r6 = r9.group(r14)
            r6.getClass()
            android.graphics.PointF r14 = s3.c.b.a(r6)     // Catch:{ RuntimeException -> 0x00fc }
            if (r14 == 0) goto L_0x00fc
            r20 = r14
        L_0x00fc:
            java.util.regex.Pattern r14 = s3.c.b.f27757d     // Catch:{ RuntimeException -> 0x011c }
            java.util.regex.Matcher r6 = r14.matcher(r6)     // Catch:{ RuntimeException -> 0x011c }
            boolean r14 = r6.find()     // Catch:{ RuntimeException -> 0x011c }
            if (r14 == 0) goto L_0x0116
            r14 = 1
            java.lang.String r6 = r6.group(r14)     // Catch:{ RuntimeException -> 0x011c }
            r6.getClass()     // Catch:{ RuntimeException -> 0x011c }
            int r6 = s3.c.a(r6)     // Catch:{ RuntimeException -> 0x011c }
        L_0x0114:
            r14 = -1
            goto L_0x0118
        L_0x0116:
            r6 = -1
            goto L_0x0114
        L_0x0118:
            if (r6 == r14) goto L_0x011c
            r19 = r6
        L_0x011c:
            r6 = r21
            r14 = -1
            goto L_0x00e4
        L_0x0120:
            r21 = r6
            s3.c$b r6 = new s3.c$b
            java.util.regex.Pattern r6 = s3.c.b.f27754a
            java.util.regex.Matcher r6 = r6.matcher(r8)
            java.lang.String r8 = ""
            java.lang.String r6 = r6.replaceAll(r8)
            java.lang.String r8 = "\\N"
            java.lang.String r9 = "\n"
            java.lang.String r6 = r6.replace(r8, r9)
            java.lang.String r8 = "\\n"
            java.lang.String r6 = r6.replace(r8, r9)
            java.lang.String r8 = "\\h"
            java.lang.String r9 = " "
            java.lang.String r6 = r6.replace(r8, r9)
            float r8 = r0.f27731e
            float r9 = r0.f27732f
            android.text.SpannableString r14 = new android.text.SpannableString
            r14.<init>(r6)
            n2.a$a r6 = new n2.a$a
            r6.<init>()
            r6.f25621a = r14
            r17 = -8388609(0xffffffffff7fffff, float:-3.4028235E38)
            if (r1 == 0) goto L_0x020d
            java.lang.Integer r0 = r1.f27735c
            if (r0 == 0) goto L_0x017b
            r23 = r0
            android.text.style.ForegroundColorSpan r0 = new android.text.style.ForegroundColorSpan
            r24 = r7
            int r7 = r23.intValue()
            r0.<init>(r7)
            int r7 = r14.length()
            r23 = r8
            r25 = r9
            r8 = 0
            r9 = 33
            r14.setSpan(r0, r8, r7, r9)
            goto L_0x0181
        L_0x017b:
            r24 = r7
            r23 = r8
            r25 = r9
        L_0x0181:
            int r0 = r1.f27742j
            r7 = 3
            if (r0 != r7) goto L_0x019d
            java.lang.Integer r0 = r1.f27736d
            if (r0 == 0) goto L_0x019d
            android.text.style.BackgroundColorSpan r8 = new android.text.style.BackgroundColorSpan
            int r0 = r0.intValue()
            r8.<init>(r0)
            int r0 = r14.length()
            r7 = 33
            r9 = 0
            r14.setSpan(r8, r9, r0, r7)
        L_0x019d:
            float r0 = r1.f27737e
            int r7 = (r0 > r17 ? 1 : (r0 == r17 ? 0 : -1))
            if (r7 == 0) goto L_0x01ae
            int r7 = (r25 > r17 ? 1 : (r25 == r17 ? 0 : -1))
            if (r7 == 0) goto L_0x01ae
            float r0 = r0 / r25
            r6.f25631k = r0
            r0 = 1
            r6.f25630j = r0
        L_0x01ae:
            boolean r0 = r1.f27739g
            boolean r7 = r1.f27738f
            if (r7 == 0) goto L_0x01c7
            if (r0 == 0) goto L_0x01c7
            android.text.style.StyleSpan r0 = new android.text.style.StyleSpan
            r7 = 3
            r0.<init>(r7)
            int r7 = r14.length()
            r8 = 0
            r9 = 33
            r14.setSpan(r0, r8, r7, r9)
            goto L_0x01e9
        L_0x01c7:
            r8 = 0
            r9 = 33
            if (r7 == 0) goto L_0x01da
            android.text.style.StyleSpan r0 = new android.text.style.StyleSpan
            r7 = 1
            r0.<init>(r7)
            int r7 = r14.length()
            r14.setSpan(r0, r8, r7, r9)
            goto L_0x01e9
        L_0x01da:
            if (r0 == 0) goto L_0x01e9
            android.text.style.StyleSpan r0 = new android.text.style.StyleSpan
            r7 = 2
            r0.<init>(r7)
            int r7 = r14.length()
            r14.setSpan(r0, r8, r7, r9)
        L_0x01e9:
            boolean r0 = r1.f27740h
            if (r0 == 0) goto L_0x01f9
            android.text.style.UnderlineSpan r0 = new android.text.style.UnderlineSpan
            r0.<init>()
            int r7 = r14.length()
            r14.setSpan(r0, r8, r7, r9)
        L_0x01f9:
            boolean r0 = r1.f27741i
            if (r0 == 0) goto L_0x0209
            android.text.style.StrikethroughSpan r0 = new android.text.style.StrikethroughSpan
            r0.<init>()
            int r7 = r14.length()
            r14.setSpan(r0, r8, r7, r9)
        L_0x0209:
            r0 = r19
            r14 = -1
            goto L_0x0214
        L_0x020d:
            r24 = r7
            r23 = r8
            r25 = r9
            goto L_0x0209
        L_0x0214:
            if (r0 == r14) goto L_0x0218
            r14 = r0
            goto L_0x021c
        L_0x0218:
            if (r1 == 0) goto L_0x021c
            int r14 = r1.f27734b
        L_0x021c:
            java.lang.String r0 = "Unknown alignment: "
            switch(r14) {
                case -1: goto L_0x0224;
                case 0: goto L_0x0221;
                case 1: goto L_0x022c;
                case 2: goto L_0x0229;
                case 3: goto L_0x0226;
                case 4: goto L_0x022c;
                case 5: goto L_0x0229;
                case 6: goto L_0x0226;
                case 7: goto L_0x022c;
                case 8: goto L_0x0229;
                case 9: goto L_0x0226;
                default: goto L_0x0221;
            }
        L_0x0221:
            A6.u.r(r14, r0, r15)
        L_0x0224:
            r1 = 0
            goto L_0x022e
        L_0x0226:
            android.text.Layout$Alignment r1 = android.text.Layout.Alignment.ALIGN_OPPOSITE
            goto L_0x022e
        L_0x0229:
            android.text.Layout$Alignment r1 = android.text.Layout.Alignment.ALIGN_CENTER
            goto L_0x022e
        L_0x022c:
            android.text.Layout$Alignment r1 = android.text.Layout.Alignment.ALIGN_NORMAL
        L_0x022e:
            r6.f25623c = r1
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            switch(r14) {
                case -1: goto L_0x0238;
                case 0: goto L_0x0235;
                case 1: goto L_0x023e;
                case 2: goto L_0x023c;
                case 3: goto L_0x023a;
                case 4: goto L_0x023e;
                case 5: goto L_0x023c;
                case 6: goto L_0x023a;
                case 7: goto L_0x023e;
                case 8: goto L_0x023c;
                case 9: goto L_0x023a;
                default: goto L_0x0235;
            }
        L_0x0235:
            A6.u.r(r14, r0, r15)
        L_0x0238:
            r7 = r1
            goto L_0x023f
        L_0x023a:
            r7 = 2
            goto L_0x023f
        L_0x023c:
            r7 = 1
            goto L_0x023f
        L_0x023e:
            r7 = 0
        L_0x023f:
            r6.f25629i = r7
            switch(r14) {
                case -1: goto L_0x024d;
                case 0: goto L_0x0244;
                case 1: goto L_0x024c;
                case 2: goto L_0x024c;
                case 3: goto L_0x024c;
                case 4: goto L_0x024a;
                case 5: goto L_0x024a;
                case 6: goto L_0x024a;
                case 7: goto L_0x0248;
                case 8: goto L_0x0248;
                case 9: goto L_0x0248;
                default: goto L_0x0244;
            }
        L_0x0244:
            A6.u.r(r14, r0, r15)
            goto L_0x024d
        L_0x0248:
            r1 = 0
            goto L_0x024d
        L_0x024a:
            r1 = 1
            goto L_0x024d
        L_0x024c:
            r1 = 2
        L_0x024d:
            r6.f25627g = r1
            r0 = r20
            if (r0 == 0) goto L_0x026b
            int r7 = (r25 > r17 ? 1 : (r25 == r17 ? 0 : -1))
            if (r7 == 0) goto L_0x026b
            int r7 = (r23 > r17 ? 1 : (r23 == r17 ? 0 : -1))
            if (r7 == 0) goto L_0x026b
            float r1 = r0.x
            float r1 = r1 / r23
            r6.f25628h = r1
            float r0 = r0.y
            float r0 = r0 / r25
            r6.f25625e = r0
            r8 = 0
            r6.f25626f = r8
            goto L_0x029b
        L_0x026b:
            int r0 = r6.f25629i
            r7 = 1028443341(0x3d4ccccd, float:0.05)
            r8 = 1056964608(0x3f000000, float:0.5)
            r9 = 1064514355(0x3f733333, float:0.95)
            if (r0 == 0) goto L_0x0285
            r14 = 1
            if (r0 == r14) goto L_0x0282
            r15 = 2
            if (r0 == r15) goto L_0x0280
            r0 = r17
            goto L_0x0288
        L_0x0280:
            r0 = r9
            goto L_0x0288
        L_0x0282:
            r15 = 2
            r0 = r8
            goto L_0x0288
        L_0x0285:
            r14 = 1
            r15 = 2
            r0 = r7
        L_0x0288:
            r6.f25628h = r0
            if (r1 == 0) goto L_0x0296
            if (r1 == r14) goto L_0x0295
            if (r1 == r15) goto L_0x0293
            r7 = r17
            goto L_0x0296
        L_0x0293:
            r7 = r9
            goto L_0x0296
        L_0x0295:
            r7 = r8
        L_0x0296:
            r6.f25625e = r7
            r8 = 0
            r6.f25626f = r8
        L_0x029b:
            n2.a r0 = r6.a()
            int r1 = d(r12, r5, r4)
            int r6 = d(r10, r5, r4)
        L_0x02a7:
            if (r1 >= r6) goto L_0x02bc
            java.lang.Object r7 = r4.get(r1)
            java.util.List r7 = (java.util.List) r7
            r7.add(r0)
            int r1 = r1 + 1
            goto L_0x02a7
        L_0x02b5:
            java.lang.String r0 = r0.concat(r9)
            o2.n.f(r15, r0)
        L_0x02bc:
            r0 = r26
            r1 = r18
            r6 = r21
            r7 = r24
            goto L_0x0034
        L_0x02c6:
            r28 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r8 = 0
            long r0 = r2.f25927a
            int r6 = (r0 > r28 ? 1 : (r0 == r28 ? 0 : -1))
            if (r6 == 0) goto L_0x02dc
            boolean r2 = r2.f25928b
            if (r2 == 0) goto L_0x02dc
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            goto L_0x02dd
        L_0x02dc:
            r2 = 0
        L_0x02dd:
            r11 = r8
        L_0x02de:
            int r6 = r4.size()
            if (r11 >= r6) goto L_0x034c
            java.lang.Object r6 = r4.get(r11)
            r22 = r6
            java.util.List r22 = (java.util.List) r22
            boolean r6 = r22.isEmpty()
            if (r6 == 0) goto L_0x02f7
            if (r11 == 0) goto L_0x02f7
            r16 = 1
            goto L_0x0343
        L_0x02f7:
            int r6 = r4.size()
            r16 = 1
            int r6 = r6 + -1
            if (r11 == r6) goto L_0x0346
            java.lang.Object r6 = r5.get(r11)
            java.lang.Long r6 = (java.lang.Long) r6
            long r18 = r6.longValue()
            int r6 = r11 + 1
            java.lang.Object r6 = r5.get(r6)
            java.lang.Long r6 = (java.lang.Long) r6
            long r6 = r6.longValue()
            java.lang.Object r8 = r5.get(r11)
            java.lang.Long r8 = (java.lang.Long) r8
            long r8 = r8.longValue()
            long r20 = r6 - r8
            int r6 = (r0 > r28 ? 1 : (r0 == r28 ? 0 : -1))
            if (r6 == 0) goto L_0x0339
            int r6 = (r18 > r0 ? 1 : (r18 == r0 ? 0 : -1))
            if (r6 < 0) goto L_0x032c
            goto L_0x0339
        L_0x032c:
            if (r2 == 0) goto L_0x0343
            o3.c r17 = new o3.c
            r17.<init>(r18, r20, r22)
            r6 = r17
            r2.add(r6)
            goto L_0x0343
        L_0x0339:
            o3.c r17 = new o3.c
            r17.<init>(r18, r20, r22)
            r6 = r17
            r3.accept(r6)
        L_0x0343:
            int r11 = r11 + 1
            goto L_0x02de
        L_0x0346:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            r0.<init>()
            throw r0
        L_0x034c:
            if (r2 == 0) goto L_0x0362
            java.util.Iterator r0 = r2.iterator()
        L_0x0352:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0362
            java.lang.Object r1 = r0.next()
            o3.c r1 = (o3.C2761c) r1
            r3.accept(r1)
            goto L_0x0352
        L_0x0362:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: s3.b.b(byte[], int, int, o3.n$b, o2.g):void");
    }

    public final int c() {
        return 1;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Can't wrap try/catch for region: R(2:148|149) */
    /* JADX WARNING: Code restructure failed: missing block: B:147:0x029c, code lost:
        if (r4 != 3) goto L_0x029e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:149:?, code lost:
        o2.n.f("SsaStyle", "Ignoring unknown BorderStyle: " + r0);
        r4 = -1;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:148:0x029e */
    /* JADX WARNING: Removed duplicated region for block: B:156:0x02d3  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void e(o2.t r38, java.nio.charset.Charset r39) {
        /*
            r37 = this;
            r1 = r37
            r2 = 6
            r3 = 3
            r4 = 7
            r5 = -1
            r6 = 2
            r7 = 0
            r8 = 1
        L_0x0009:
            java.lang.String r0 = r38.i(r39)
            if (r0 == 0) goto L_0x02fe
            java.lang.String r9 = "[Script Info]"
            boolean r9 = r9.equalsIgnoreCase(r0)
            r10 = 91
            if (r9 == 0) goto L_0x006d
        L_0x0019:
            java.lang.String r0 = r38.i(r39)
            if (r0 == 0) goto L_0x0009
            int r9 = r38.a()
            if (r9 == 0) goto L_0x002b
            char r9 = r38.c(r39)
            if (r9 == r10) goto L_0x0009
        L_0x002b:
            java.lang.String r9 = ":"
            java.lang.String[] r0 = r0.split(r9)
            int r9 = r0.length
            if (r9 == r6) goto L_0x0035
            goto L_0x0019
        L_0x0035:
            r9 = r0[r7]
            java.lang.String r9 = r9.trim()
            java.lang.String r9 = A1.a.N(r9)
            r9.getClass()
            java.lang.String r11 = "playresx"
            boolean r11 = r9.equals(r11)
            if (r11 != 0) goto L_0x0060
            java.lang.String r11 = "playresy"
            boolean r9 = r9.equals(r11)
            if (r9 != 0) goto L_0x0053
            goto L_0x0019
        L_0x0053:
            r0 = r0[r8]     // Catch:{ NumberFormatException -> 0x0019 }
            java.lang.String r0 = r0.trim()     // Catch:{ NumberFormatException -> 0x0019 }
            float r0 = java.lang.Float.parseFloat(r0)     // Catch:{ NumberFormatException -> 0x0019 }
            r1.f27732f = r0     // Catch:{ NumberFormatException -> 0x0019 }
            goto L_0x0019
        L_0x0060:
            r0 = r0[r8]     // Catch:{ NumberFormatException -> 0x0019 }
            java.lang.String r0 = r0.trim()     // Catch:{ NumberFormatException -> 0x0019 }
            float r0 = java.lang.Float.parseFloat(r0)     // Catch:{ NumberFormatException -> 0x0019 }
            r1.f27731e = r0     // Catch:{ NumberFormatException -> 0x0019 }
            goto L_0x0019
        L_0x006d:
            java.lang.String r9 = "[V4+ Styles]"
            boolean r9 = r9.equalsIgnoreCase(r0)
            java.lang.String r11 = "SsaParser"
            if (r9 == 0) goto L_0x02e8
            java.util.LinkedHashMap r9 = new java.util.LinkedHashMap
            r9.<init>()
            r12 = 0
            r13 = r12
        L_0x007e:
            java.lang.String r14 = r38.i(r39)
            if (r14 == 0) goto L_0x02e0
            int r0 = r38.a()
            if (r0 == 0) goto L_0x0090
            char r0 = r38.c(r39)
            if (r0 == r10) goto L_0x02e0
        L_0x0090:
            java.lang.String r0 = "Format:"
            boolean r0 = r14.startsWith(r0)
            java.lang.String r15 = ","
            if (r0 == 0) goto L_0x0175
            java.lang.String r0 = r14.substring(r4)
            java.lang.String[] r0 = android.text.TextUtils.split(r0, r15)
            r15 = r5
            r16 = r15
            r17 = r16
            r18 = r17
            r19 = r18
            r20 = r19
            r21 = r20
            r22 = r21
            r23 = r22
            r24 = r23
            r13 = r7
        L_0x00b6:
            int r14 = r0.length
            if (r13 >= r14) goto L_0x0165
            r14 = r0[r13]
            java.lang.String r14 = r14.trim()
            java.lang.String r14 = A1.a.N(r14)
            r14.getClass()
            int r25 = r14.hashCode()
            switch(r25) {
                case -1178781136: goto L_0x0137;
                case -1026963764: goto L_0x012c;
                case -192095652: goto L_0x0121;
                case -70925746: goto L_0x0116;
                case 3029637: goto L_0x010b;
                case 3373707: goto L_0x0100;
                case 366554320: goto L_0x00f5;
                case 767321349: goto L_0x00ea;
                case 1767875043: goto L_0x00dd;
                case 1988365454: goto L_0x00d0;
                default: goto L_0x00cd;
            }
        L_0x00cd:
            r4 = r5
            goto L_0x0141
        L_0x00d0:
            java.lang.String r4 = "outlinecolour"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x00d9
            goto L_0x00cd
        L_0x00d9:
            r4 = 9
            goto L_0x0141
        L_0x00dd:
            java.lang.String r4 = "alignment"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x00e6
            goto L_0x00cd
        L_0x00e6:
            r4 = 8
            goto L_0x0141
        L_0x00ea:
            java.lang.String r4 = "borderstyle"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x00f3
            goto L_0x00cd
        L_0x00f3:
            r4 = 7
            goto L_0x0141
        L_0x00f5:
            java.lang.String r4 = "fontsize"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x00fe
            goto L_0x00cd
        L_0x00fe:
            r4 = r2
            goto L_0x0141
        L_0x0100:
            java.lang.String r4 = "name"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x0109
            goto L_0x00cd
        L_0x0109:
            r4 = 5
            goto L_0x0141
        L_0x010b:
            java.lang.String r4 = "bold"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x0114
            goto L_0x00cd
        L_0x0114:
            r4 = 4
            goto L_0x0141
        L_0x0116:
            java.lang.String r4 = "primarycolour"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x011f
            goto L_0x00cd
        L_0x011f:
            r4 = r3
            goto L_0x0141
        L_0x0121:
            java.lang.String r4 = "strikeout"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x012a
            goto L_0x00cd
        L_0x012a:
            r4 = r6
            goto L_0x0141
        L_0x012c:
            java.lang.String r4 = "underline"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x0135
            goto L_0x00cd
        L_0x0135:
            r4 = r8
            goto L_0x0141
        L_0x0137:
            java.lang.String r4 = "italic"
            boolean r4 = r14.equals(r4)
            if (r4 != 0) goto L_0x0140
            goto L_0x00cd
        L_0x0140:
            r4 = r7
        L_0x0141:
            switch(r4) {
                case 0: goto L_0x015f;
                case 1: goto L_0x015c;
                case 2: goto L_0x0159;
                case 3: goto L_0x0156;
                case 4: goto L_0x0153;
                case 5: goto L_0x0151;
                case 6: goto L_0x014e;
                case 7: goto L_0x014b;
                case 8: goto L_0x0148;
                case 9: goto L_0x0145;
                default: goto L_0x0144;
            }
        L_0x0144:
            goto L_0x0161
        L_0x0145:
            r18 = r13
            goto L_0x0161
        L_0x0148:
            r16 = r13
            goto L_0x0161
        L_0x014b:
            r24 = r13
            goto L_0x0161
        L_0x014e:
            r19 = r13
            goto L_0x0161
        L_0x0151:
            r15 = r13
            goto L_0x0161
        L_0x0153:
            r20 = r13
            goto L_0x0161
        L_0x0156:
            r17 = r13
            goto L_0x0161
        L_0x0159:
            r23 = r13
            goto L_0x0161
        L_0x015c:
            r22 = r13
            goto L_0x0161
        L_0x015f:
            r21 = r13
        L_0x0161:
            int r13 = r13 + r8
            r4 = 7
            goto L_0x00b6
        L_0x0165:
            if (r15 == r5) goto L_0x0171
            s3.c$a r14 = new s3.c$a
            int r0 = r0.length
            r25 = r0
            r14.<init>(r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25)
            r13 = r14
            goto L_0x0172
        L_0x0171:
            r13 = r12
        L_0x0172:
            r4 = 7
            goto L_0x007e
        L_0x0175:
            java.lang.String r0 = "Style:"
            boolean r4 = r14.startsWith(r0)
            if (r4 == 0) goto L_0x02d8
            if (r13 != 0) goto L_0x018a
            java.lang.String r0 = "Skipping 'Style:' line before 'Format:' line: "
            java.lang.String r0 = r0.concat(r14)
            o2.n.f(r11, r0)
            goto L_0x02d8
        L_0x018a:
            boolean r0 = r14.startsWith(r0)
            f7.M.h(r0)
            java.lang.String r0 = r14.substring(r2)
            java.lang.String[] r4 = android.text.TextUtils.split(r0, r15)
            int r0 = r4.length
            int r15 = r13.f27753k
            java.lang.String r2 = "'"
            java.lang.String r6 = "SsaStyle"
            if (r0 == r15) goto L_0x01c1
            int r0 = r4.length
            int r4 = o2.C2756B.f25811a
            java.util.Locale r4 = java.util.Locale.US
            java.lang.String r4 = "Skipping malformed 'Style:' line (expected "
            java.lang.String r7 = " values, found "
            java.lang.String r10 = "): '"
            java.lang.StringBuilder r0 = H0.C0708z.m(r15, r0, r4, r7, r10)
            r0.append(r14)
            r0.append(r2)
            java.lang.String r0 = r0.toString()
            o2.n.f(r6, r0)
        L_0x01be:
            r0 = r12
            goto L_0x02d1
        L_0x01c1:
            s3.c r26 = new s3.c     // Catch:{ RuntimeException -> 0x01dc }
            int r0 = r13.f27743a     // Catch:{ RuntimeException -> 0x01dc }
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r27 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            int r0 = r13.f27744b     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x01df
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            int r0 = s3.c.a(r0)     // Catch:{ RuntimeException -> 0x01dc }
            r28 = r0
            goto L_0x01e1
        L_0x01dc:
            r0 = move-exception
            goto L_0x02bb
        L_0x01df:
            r28 = r5
        L_0x01e1:
            int r0 = r13.f27745c     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x01f2
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.Integer r0 = s3.c.c(r0)     // Catch:{ RuntimeException -> 0x01dc }
            r29 = r0
            goto L_0x01f4
        L_0x01f2:
            r29 = r12
        L_0x01f4:
            int r0 = r13.f27746d     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x0205
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.Integer r0 = s3.c.c(r0)     // Catch:{ RuntimeException -> 0x01dc }
            r30 = r0
            goto L_0x0207
        L_0x0205:
            r30 = r12
        L_0x0207:
            int r0 = r13.f27747e     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x0231
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r10 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            float r7 = java.lang.Float.parseFloat(r10)     // Catch:{ NumberFormatException -> 0x0216 }
            goto L_0x022e
        L_0x0216:
            r0 = move-exception
            java.lang.StringBuilder r15 = new java.lang.StringBuilder     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r7 = "Failed to parse font size: '"
            r15.<init>(r7)     // Catch:{ RuntimeException -> 0x01dc }
            r15.append(r10)     // Catch:{ RuntimeException -> 0x01dc }
            r15.append(r2)     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r7 = r15.toString()     // Catch:{ RuntimeException -> 0x01dc }
            o2.n.g(r6, r7, r0)     // Catch:{ RuntimeException -> 0x01dc }
            r7 = -8388609(0xffffffffff7fffff, float:-3.4028235E38)
        L_0x022e:
            r31 = r7
            goto L_0x0234
        L_0x0231:
            r31 = -8388609(0xffffffffff7fffff, float:-3.4028235E38)
        L_0x0234:
            int r0 = r13.f27748f     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x0247
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            boolean r0 = s3.c.b(r0)     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == 0) goto L_0x0247
            r32 = r8
            goto L_0x0249
        L_0x0247:
            r32 = 0
        L_0x0249:
            int r0 = r13.f27749g     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x025c
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            boolean r0 = s3.c.b(r0)     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == 0) goto L_0x025c
            r33 = r8
            goto L_0x025e
        L_0x025c:
            r33 = 0
        L_0x025e:
            int r0 = r13.f27750h     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x0271
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            boolean r0 = s3.c.b(r0)     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == 0) goto L_0x0271
            r34 = r8
            goto L_0x0273
        L_0x0271:
            r34 = 0
        L_0x0273:
            int r0 = r13.f27751i     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x0286
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            boolean r0 = s3.c.b(r0)     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == 0) goto L_0x0286
            r35 = r8
            goto L_0x0288
        L_0x0286:
            r35 = 0
        L_0x0288:
            int r0 = r13.f27752j     // Catch:{ RuntimeException -> 0x01dc }
            if (r0 == r5) goto L_0x02b3
            r0 = r4[r0]     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r0.trim()     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r4 = r0.trim()     // Catch:{ NumberFormatException -> 0x029e }
            int r4 = java.lang.Integer.parseInt(r4)     // Catch:{ NumberFormatException -> 0x029e }
            if (r4 == r8) goto L_0x02b0
            if (r4 == r3) goto L_0x02b0
        L_0x029e:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r7 = "Ignoring unknown BorderStyle: "
            r4.<init>(r7)     // Catch:{ RuntimeException -> 0x01dc }
            r4.append(r0)     // Catch:{ RuntimeException -> 0x01dc }
            java.lang.String r0 = r4.toString()     // Catch:{ RuntimeException -> 0x01dc }
            o2.n.f(r6, r0)     // Catch:{ RuntimeException -> 0x01dc }
            r4 = r5
        L_0x02b0:
            r36 = r4
            goto L_0x02b5
        L_0x02b3:
            r36 = r5
        L_0x02b5:
            r26.<init>(r27, r28, r29, r30, r31, r32, r33, r34, r35, r36)     // Catch:{ RuntimeException -> 0x01dc }
            r0 = r26
            goto L_0x02d1
        L_0x02bb:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r7 = "Skipping malformed 'Style:' line: '"
            r4.<init>(r7)
            r4.append(r14)
            r4.append(r2)
            java.lang.String r2 = r4.toString()
            o2.n.g(r6, r2, r0)
            goto L_0x01be
        L_0x02d1:
            if (r0 == 0) goto L_0x02d8
            java.lang.String r2 = r0.f27733a
            r9.put(r2, r0)
        L_0x02d8:
            r2 = 6
            r4 = 7
            r6 = 2
            r7 = 0
            r10 = 91
            goto L_0x007e
        L_0x02e0:
            r1.f27730d = r9
        L_0x02e2:
            r2 = 6
            r4 = 7
            r6 = 2
            r7 = 0
            goto L_0x0009
        L_0x02e8:
            java.lang.String r2 = "[V4 Styles]"
            boolean r2 = r2.equalsIgnoreCase(r0)
            if (r2 == 0) goto L_0x02f6
            java.lang.String r0 = "[V4 Styles] are not supported"
            o2.n.e(r11, r0)
            goto L_0x02e2
        L_0x02f6:
            java.lang.String r2 = "[Events]"
            boolean r0 = r2.equalsIgnoreCase(r0)
            if (r0 == 0) goto L_0x02e2
        L_0x02fe:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: s3.b.e(o2.t, java.nio.charset.Charset):void");
    }

    public final /* synthetic */ void reset() {
    }
}
