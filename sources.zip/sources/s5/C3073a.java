package s5;

import f5.g;
import f5.i;
import i5.u;
import java.io.File;
import q5.C2964b;

/* renamed from: s5.a  reason: case insensitive filesystem */
public final class C3073a implements i<File, File> {
    public final u a(Object obj, int i10, int i11, g gVar) {
        return new C2964b((File) obj);
    }

    public final /* bridge */ /* synthetic */ boolean b(Object obj, g gVar) {
        File file = (File) obj;
        return true;
    }
}
