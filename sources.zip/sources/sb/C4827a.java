package sb;

import db.C4309X;
import jb.x;

/* renamed from: sb.a  reason: case insensitive filesystem */
public interface C4827a extends C4309X {
    x b();
}
