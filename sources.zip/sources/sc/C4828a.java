package sc;

import Da.c;

/* renamed from: sc.a  reason: case insensitive filesystem */
public interface C4828a {
    void a(Object obj);

    Object b(c cVar);

    boolean tryLock();
}
