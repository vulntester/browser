package sc;

import Ba.h;
import Na.q;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import sc.C4830c;
import xa.C4959D;

/* renamed from: sc.b  reason: case insensitive filesystem */
public final /* synthetic */ class C4829b implements q {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C4830c f43467f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ C4830c.a f43468i;

    public /* synthetic */ C4829b(C4830c cVar, C4830c.a aVar) {
        this.f43467f = cVar;
        this.f43468i = aVar;
    }

    public final Object invoke(Object obj, Object obj2, Object obj3) {
        Throwable th = (Throwable) obj;
        C4959D d10 = (C4959D) obj2;
        h hVar = (h) obj3;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = C4830c.f43469h;
        this.f43468i.getClass();
        C4830c cVar = this.f43467f;
        atomicReferenceFieldUpdater.set(cVar, (Object) null);
        cVar.a((Object) null);
        return C4959D.f44058a;
    }
}
