package sc;

import A.o;
import Ba.h;
import Da.c;
import Na.l;
import Na.q;
import Z7.b;
import db.C4290D;
import ic.C4505h;
import ic.C4507i;
import ic.C4509j;
import ic.G;
import ic.M0;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import nc.u;
import xa.C4959D;

/* renamed from: sc.c  reason: case insensitive filesystem */
public final class C4830c extends C4833f implements C4828a {

    /* renamed from: h  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f43469h = AtomicReferenceFieldUpdater.newUpdater(C4830c.class, Object.class, "owner$volatile");
    private volatile /* synthetic */ Object owner$volatile;

    /* renamed from: sc.c$a */
    public final class a implements C4505h<C4959D>, M0 {

        /* renamed from: f  reason: collision with root package name */
        public final C4509j<C4959D> f43470f;

        public a(C4509j jVar) {
            this.f43470f = jVar;
        }

        public final void b(u<?> uVar, int i10) {
            this.f43470f.b(uVar, i10);
        }

        public final boolean cancel(Throwable th) {
            return this.f43470f.cancel(th);
        }

        public final h getContext() {
            return this.f43470f.f41178F;
        }

        public final boolean isCancelled() {
            return this.f43470f.isCancelled();
        }

        public final void m(Object obj, q qVar) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = C4830c.f43469h;
            C4830c cVar = C4830c.this;
            atomicReferenceFieldUpdater.set(cVar, (Object) null);
            G9.a aVar = new G9.a(8, cVar, this);
            C4509j<C4959D> jVar = this.f43470f;
            jVar.z((C4959D) obj, jVar.f41133z, new C4507i(aVar));
        }

        public final void n(l<? super Throwable, C4959D> lVar) {
            this.f43470f.n(lVar);
        }

        public final C4290D r(Object obj, q qVar) {
            C4830c cVar = C4830c.this;
            C4829b bVar = new C4829b(cVar, this);
            C4290D C10 = this.f43470f.C((C4959D) obj, bVar);
            if (C10 != null) {
                C4830c.f43469h.set(cVar, (Object) null);
            }
            return C10;
        }

        public final void resumeWith(Object obj) {
            this.f43470f.resumeWith(obj);
        }

        public final void u(Object obj) {
            this.f43470f.u(obj);
        }
    }

    public C4830c(boolean z10) {
        super(1, z10 ? 1 : 0);
        C4290D d10;
        if (z10) {
            d10 = null;
        } else {
            d10 = C4831d.f43472a;
        }
        this.owner$volatile = d10;
    }

    public final void a(Object obj) {
        while (e()) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f43469h;
            Object obj2 = atomicReferenceFieldUpdater.get(this);
            C4290D d10 = C4831d.f43472a;
            if (obj2 != d10) {
                if (obj2 == obj || obj == null) {
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, obj2, d10)) {
                        if (atomicReferenceFieldUpdater.get(this) != obj2) {
                        }
                    }
                    release();
                    return;
                }
                throw new IllegalStateException(("This mutex is locked by " + obj2 + ", but " + obj + " is expected").toString());
            }
        }
        throw new IllegalStateException("This mutex is not locked");
    }

    public final Object b(c cVar) {
        if (tryLock()) {
            return C4959D.f44058a;
        }
        C4509j p10 = b.p(o.L(cVar));
        try {
            a aVar = new a(p10);
            while (true) {
                int andDecrement = C4833f.f43477g.getAndDecrement(this);
                if (andDecrement <= this.f43478a) {
                    if (andDecrement > 0) {
                        aVar.m(C4959D.f44058a, this.f43479b);
                        break;
                    } else if (d(aVar)) {
                        break;
                    }
                }
            }
            Object p11 = p10.p();
            Ca.a aVar2 = Ca.a.f33640f;
            if (p11 != aVar2) {
                p11 = C4959D.f44058a;
            }
            if (p11 == aVar2) {
                return p11;
            }
            return C4959D.f44058a;
        } catch (Throwable th) {
            p10.y();
            throw th;
        }
    }

    public final boolean e() {
        if (Math.max(C4833f.f43477g.get(this), 0) == 0) {
            return true;
        }
        return false;
    }

    public final String toString() {
        return "Mutex@" + G.n(this) + "[isLocked=" + e() + ",owner=" + f43469h.get(this) + ']';
    }

    public final boolean tryLock() {
        boolean z10;
        int i10;
        while (true) {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = C4833f.f43477g;
            int i11 = atomicIntegerFieldUpdater.get(this);
            int i12 = this.f43478a;
            if (i11 > i12) {
                do {
                    i10 = atomicIntegerFieldUpdater.get(this);
                    if (i10 <= i12) {
                        break;
                    }
                } while (atomicIntegerFieldUpdater.compareAndSet(this, i10, i12));
            } else if (i11 <= 0) {
                z10 = true;
                break;
            } else if (atomicIntegerFieldUpdater.compareAndSet(this, i11, i11 - 1)) {
                f43469h.set(this, (Object) null);
                z10 = false;
                break;
            }
        }
        if (!z10) {
            return true;
        }
        if (z10) {
            return false;
        }
        if (!z10) {
            throw new IllegalStateException("unexpected");
        }
        throw new IllegalStateException("This mutex is already locked by the specified owner: null".toString());
    }
}
