package sc;

import db.C4290D;

/* renamed from: sc.d  reason: case insensitive filesystem */
public final class C4831d {

    /* renamed from: a  reason: collision with root package name */
    public static final C4290D f43472a = new C4290D("NO_OWNER", 1);

    public static C4830c a() {
        return new C4830c(false);
    }
}
