package sc;

/* renamed from: sc.e  reason: case insensitive filesystem */
public interface C4832e {
    void release();
}
