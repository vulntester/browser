package sc;

import A.o;
import D1.b;
import Da.c;
import Na.p;
import db.C4290D;
import ic.C4505h;
import ic.C4509j;
import ic.M0;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import k.C2573a;
import kotlin.jvm.internal.k;
import nc.C4730b;
import nc.u;
import q9.C4797i;
import xa.C4959D;

/* renamed from: sc.f  reason: case insensitive filesystem */
public class C4833f {

    /* renamed from: c  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f43473c;

    /* renamed from: d  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f43474d;

    /* renamed from: e  reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f43475e;

    /* renamed from: f  reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f43476f;

    /* renamed from: g  reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f43477g;
    private volatile /* synthetic */ int _availablePermits$volatile;

    /* renamed from: a  reason: collision with root package name */
    public final int f43478a;

    /* renamed from: b  reason: collision with root package name */
    public final C4797i f43479b;
    private volatile /* synthetic */ long deqIdx$volatile;
    private volatile /* synthetic */ long enqIdx$volatile;
    private volatile /* synthetic */ Object head$volatile;
    private volatile /* synthetic */ Object tail$volatile;

    /* renamed from: sc.f$a */
    public /* synthetic */ class a extends k implements p<Long, j, j> {

        /* renamed from: f  reason: collision with root package name */
        public static final a f43480f = new k(2, i.class, "createSegment", "createSegment(JLkotlinx/coroutines/sync/SemaphoreSegment;)Lkotlinx/coroutines/sync/SemaphoreSegment;", 1);

        public final Object invoke(Object obj, Object obj2) {
            int i10 = i.f43482a;
            return new j(((Number) obj).longValue(), (j) obj2, 0);
        }
    }

    static {
        Class<C4833f> cls = C4833f.class;
        Class<Object> cls2 = Object.class;
        f43473c = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "head$volatile");
        f43474d = AtomicLongFieldUpdater.newUpdater(cls, "deqIdx$volatile");
        f43475e = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "tail$volatile");
        f43476f = AtomicLongFieldUpdater.newUpdater(cls, "enqIdx$volatile");
        f43477g = AtomicIntegerFieldUpdater.newUpdater(cls, "_availablePermits$volatile");
    }

    public C4833f(int i10, int i11) {
        this.f43478a = i10;
        if (i10 <= 0) {
            throw new IllegalArgumentException(b.j(i10, "Semaphore should have at least 1 permit, but had ").toString());
        } else if (i11 < 0 || i11 > i10) {
            throw new IllegalArgumentException(b.j(i10, "The number of acquired permits should be in 0..").toString());
        } else {
            j jVar = new j(0, (j) null, 2);
            this.head$volatile = jVar;
            this.tail$volatile = jVar;
            this._availablePermits$volatile = i10 - i11;
            this.f43479b = new C4797i(this, 1);
        }
    }

    public final Object c(c cVar) {
        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater;
        int andDecrement;
        int i10;
        do {
            atomicIntegerFieldUpdater = f43477g;
            andDecrement = atomicIntegerFieldUpdater.getAndDecrement(this);
            i10 = this.f43478a;
        } while (andDecrement > i10);
        if (andDecrement > 0) {
            return C4959D.f44058a;
        }
        C4509j p10 = Z7.b.p(o.L(cVar));
        try {
            if (!d(p10)) {
                while (true) {
                    int andDecrement2 = atomicIntegerFieldUpdater.getAndDecrement(this);
                    if (andDecrement2 <= i10) {
                        if (andDecrement2 > 0) {
                            p10.m(C4959D.f44058a, this.f43479b);
                            break;
                        } else if (d(p10)) {
                            break;
                        }
                    }
                }
            }
            Object p11 = p10.p();
            Ca.a aVar = Ca.a.f33640f;
            if (p11 != aVar) {
                p11 = C4959D.f44058a;
            }
            if (p11 == aVar) {
                return p11;
            }
            return C4959D.f44058a;
        } catch (Throwable th) {
            p10.y();
            throw th;
        }
    }

    public final boolean d(M0 m02) {
        Object a10;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f43475e;
        j jVar = (j) atomicReferenceFieldUpdater.get(this);
        long andIncrement = f43476f.getAndIncrement(this);
        a aVar = a.f43480f;
        long j10 = andIncrement / ((long) i.f43487f);
        loop0:
        while (true) {
            a10 = C4730b.a(jVar, j10, aVar);
            if (C2573a.j(a10)) {
                break;
            }
            u i10 = C2573a.i(a10);
            while (true) {
                u uVar = (u) atomicReferenceFieldUpdater.get(this);
                if (uVar.f42453z >= i10.f42453z) {
                    break loop0;
                } else if (i10.j()) {
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, uVar, i10)) {
                        if (atomicReferenceFieldUpdater.get(this) != uVar) {
                            if (i10.f()) {
                                i10.e();
                            }
                        }
                    }
                    if (uVar.f()) {
                        uVar.e();
                    }
                }
            }
        }
        j jVar2 = (j) C2573a.i(a10);
        int i11 = (int) (andIncrement % ((long) i.f43487f));
        AtomicReferenceArray atomicReferenceArray = jVar2.f43488F;
        while (!atomicReferenceArray.compareAndSet(i11, (Object) null, m02)) {
            if (atomicReferenceArray.get(i11) != null) {
                C4290D d10 = i.f43483b;
                C4290D d11 = i.f43484c;
                while (!atomicReferenceArray.compareAndSet(i11, d10, d11)) {
                    if (atomicReferenceArray.get(i11) != d10) {
                        return false;
                    }
                }
                if (m02 instanceof C4505h) {
                    ((C4505h) m02).m(C4959D.f44058a, this.f43479b);
                    return true;
                } else if (m02 instanceof qc.c) {
                    ((qc.c) m02).d(C4959D.f44058a);
                    return true;
                } else {
                    throw new IllegalStateException(("unexpected: " + m02).toString());
                }
            }
        }
        m02.b(jVar2, i11);
        return true;
    }

    public final void release() {
        int i10;
        Object a10;
        boolean z10;
        do {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f43477g;
            int andIncrement = atomicIntegerFieldUpdater.getAndIncrement(this);
            int i11 = this.f43478a;
            if (andIncrement >= i11) {
                do {
                    i10 = atomicIntegerFieldUpdater.get(this);
                    if (i10 <= i11 || atomicIntegerFieldUpdater.compareAndSet(this, i10, i11)) {
                    }
                    i10 = atomicIntegerFieldUpdater.get(this);
                    break;
                } while (atomicIntegerFieldUpdater.compareAndSet(this, i10, i11));
                throw new IllegalStateException(("The number of released permits cannot be greater than " + i11).toString());
            } else if (andIncrement < 0) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f43473c;
                j jVar = (j) atomicReferenceFieldUpdater.get(this);
                long andIncrement2 = f43474d.getAndIncrement(this);
                long j10 = andIncrement2 / ((long) i.f43487f);
                C4834g gVar = C4834g.f43481f;
                while (true) {
                    a10 = C4730b.a(jVar, j10, gVar);
                    if (C2573a.j(a10)) {
                        break;
                    }
                    u i12 = C2573a.i(a10);
                    while (true) {
                        u uVar = (u) atomicReferenceFieldUpdater.get(this);
                        if (uVar.f42453z >= i12.f42453z) {
                            break;
                        } else if (i12.j()) {
                            while (!atomicReferenceFieldUpdater.compareAndSet(this, uVar, i12)) {
                                if (atomicReferenceFieldUpdater.get(this) != uVar) {
                                    if (i12.f()) {
                                        i12.e();
                                    }
                                }
                            }
                            if (uVar.f()) {
                                uVar.e();
                            }
                        }
                    }
                }
                j jVar2 = (j) C2573a.i(a10);
                jVar2.a();
                int i13 = (jVar2.f42453z > j10 ? 1 : (jVar2.f42453z == j10 ? 0 : -1));
                z10 = false;
                if (i13 <= 0) {
                    int i14 = (int) (andIncrement2 % ((long) i.f43487f));
                    C4290D d10 = i.f43483b;
                    AtomicReferenceArray atomicReferenceArray = jVar2.f43488F;
                    Object andSet = atomicReferenceArray.getAndSet(i14, d10);
                    if (andSet == null) {
                        int i15 = i.f43482a;
                        int i16 = 0;
                        while (true) {
                            if (i16 >= i15) {
                                C4290D d11 = i.f43483b;
                                C4290D d12 = i.f43485d;
                                while (true) {
                                    if (!atomicReferenceArray.compareAndSet(i14, d11, d12)) {
                                        if (atomicReferenceArray.get(i14) != d11) {
                                            break;
                                        }
                                    } else {
                                        z10 = true;
                                        break;
                                    }
                                }
                                z10 = !z10;
                                continue;
                            } else if (atomicReferenceArray.get(i14) == i.f43484c) {
                                break;
                            } else {
                                i16++;
                            }
                        }
                    } else if (andSet == i.f43486e) {
                        continue;
                    } else if (andSet instanceof C4505h) {
                        C4505h hVar = (C4505h) andSet;
                        C4290D r10 = hVar.r(C4959D.f44058a, this.f43479b);
                        if (r10 != null) {
                            hVar.u(r10);
                        } else {
                            continue;
                        }
                    } else if (andSet instanceof qc.c) {
                        z10 = ((qc.c) andSet).a(this, C4959D.f44058a);
                        continue;
                    } else {
                        throw new IllegalStateException(("unexpected: " + andSet).toString());
                    }
                    z10 = true;
                    continue;
                }
            } else {
                return;
            }
        } while (!z10);
    }
}
