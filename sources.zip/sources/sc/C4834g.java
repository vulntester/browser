package sc;

import Na.p;
import kotlin.jvm.internal.k;

/* renamed from: sc.g  reason: case insensitive filesystem */
public final /* synthetic */ class C4834g extends k implements p<Long, j, j> {

    /* renamed from: f  reason: collision with root package name */
    public static final C4834g f43481f = new k(2, i.class, "createSegment", "createSegment(JLkotlinx/coroutines/sync/SemaphoreSegment;)Lkotlinx/coroutines/sync/SemaphoreSegment;", 1);

    public final Object invoke(Object obj, Object obj2) {
        int i10 = i.f43482a;
        return new j(((Number) obj).longValue(), (j) obj2, 0);
    }
}
