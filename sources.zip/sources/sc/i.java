package sc;

import A.o;
import db.C4290D;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public static final int f43482a = o.d0(100, 12, "kotlinx.coroutines.semaphore.maxSpinCycles");

    /* renamed from: b  reason: collision with root package name */
    public static final C4290D f43483b = new C4290D("PERMIT", 1);

    /* renamed from: c  reason: collision with root package name */
    public static final C4290D f43484c = new C4290D("TAKEN", 1);

    /* renamed from: d  reason: collision with root package name */
    public static final C4290D f43485d = new C4290D("BROKEN", 1);

    /* renamed from: e  reason: collision with root package name */
    public static final C4290D f43486e = new C4290D("CANCELLED", 1);

    /* renamed from: f  reason: collision with root package name */
    public static final int f43487f = o.d0(16, 12, "kotlinx.coroutines.semaphore.segmentSize");
}
