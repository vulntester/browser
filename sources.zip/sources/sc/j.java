package sc;

import Ba.h;
import java.util.concurrent.atomic.AtomicReferenceArray;
import nc.u;

public final class j extends u<j> {

    /* renamed from: F  reason: collision with root package name */
    public final /* synthetic */ AtomicReferenceArray f43488F = new AtomicReferenceArray(i.f43487f);

    public j(long j10, j jVar, int i10) {
        super(j10, jVar, i10);
    }

    public final int g() {
        return i.f43487f;
    }

    public final void h(int i10, h hVar) {
        this.f43488F.set(i10, i.f43486e);
        i();
    }

    public final String toString() {
        return "SemaphoreSegment[id=" + this.f42453z + ", hashCode=" + hashCode() + ']';
    }
}
