package u0;

import D2.B;
import V6.b;
import e1.j;
import kotlin.jvm.internal.l;
import p0.C2844C;
import p0.C2880t;
import r0.d;

/* renamed from: u0.a  reason: case insensitive filesystem */
public final class C3192a extends C3194c {

    /* renamed from: G  reason: collision with root package name */
    public final C2844C f28461G;

    /* renamed from: H  reason: collision with root package name */
    public final long f28462H;

    /* renamed from: I  reason: collision with root package name */
    public int f28463I = 1;

    /* renamed from: J  reason: collision with root package name */
    public final long f28464J;

    /* renamed from: K  reason: collision with root package name */
    public float f28465K;

    /* renamed from: L  reason: collision with root package name */
    public C2880t f28466L;

    public C3192a(C2844C c10, long j10) {
        int i10;
        int i11;
        this.f28461G = c10;
        this.f28462H = j10;
        if (((int) 0) < 0 || ((int) 0) < 0 || (i10 = (int) (j10 >> 32)) < 0 || (i11 = (int) (4294967295L & j10)) < 0 || i10 > c10.getWidth() || i11 > c10.getHeight()) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        this.f28464J = j10;
        this.f28465K = 1.0f;
    }

    public final boolean a(float f10) {
        this.f28465K = f10;
        return true;
    }

    public final boolean e(C2880t tVar) {
        this.f28466L = tVar;
        return true;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3192a)) {
            return false;
        }
        C3192a aVar = (C3192a) obj;
        if (l.a(this.f28461G, aVar.f28461G) && j.b(0, 0) && e1.l.b(this.f28462H, aVar.f28462H) && this.f28463I == aVar.f28463I) {
            return true;
        }
        return false;
    }

    public final long h() {
        return b.u(this.f28464J);
    }

    public final int hashCode() {
        int i10 = (int) 0;
        long j10 = this.f28462H;
        return ((((int) (j10 ^ (j10 >>> 32))) + ((i10 + (this.f28461G.hashCode() * 31)) * 31)) * 31) + this.f28463I;
    }

    public final void i(d dVar) {
        int round = Math.round(Float.intBitsToFloat((int) (dVar.v() >> 32)));
        float f10 = this.f28465K;
        C2880t tVar = this.f28466L;
        int i10 = this.f28463I;
        d dVar2 = dVar;
        B.l(dVar2, this.f28461G, this.f28462H, (((long) round) << 32) | (((long) Math.round(Float.intBitsToFloat((int) (dVar.v() & 4294967295L)))) & 4294967295L), f10, tVar, i10, 328);
    }

    public final String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder("BitmapPainter(image=");
        sb2.append(this.f28461G);
        sb2.append(", srcOffset=");
        sb2.append(j.e(0));
        sb2.append(", srcSize=");
        sb2.append(e1.l.c(this.f28462H));
        sb2.append(", filterQuality=");
        int i10 = this.f28463I;
        if (i10 == 0) {
            str = "None";
        } else if (i10 == 1) {
            str = "Low";
        } else if (i10 == 2) {
            str = "Medium";
        } else if (i10 == 3) {
            str = "High";
        } else {
            str = "Unknown";
        }
        sb2.append(str);
        sb2.append(')');
        return sb2.toString();
    }
}
