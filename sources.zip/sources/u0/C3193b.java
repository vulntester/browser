package u0;

import A.o;
import C.N;
import D1.b;
import com.google.android.gms.internal.measurement.C1684y2;
import io.netty.handler.codec.http.HttpObjectDecoder;
import kotlin.jvm.internal.B;
import kotlin.jvm.internal.l;
import lc.C4622o;
import p0.C2844C;
import wc.C4941a;
import wc.g;
import wc.i;
import wc.j;
import wc.m;

/* renamed from: u0.b  reason: case insensitive filesystem */
public final class C3193b {
    public static C3192a a(C2844C c10, int i10) {
        int width = c10.getWidth();
        C3192a aVar = new C3192a(c10, (((long) c10.getHeight()) & 4294967295L) | (((long) width) << 32));
        aVar.f28463I = i10;
        return aVar;
    }

    public static final String b(C4941a aVar, long j10) {
        if (j10 == 0) {
            return "";
        }
        g gVar = aVar.f43849f;
        if (gVar == null) {
            throw new IllegalStateException("Unreacheable");
        } else if (((long) gVar.b()) >= j10) {
            int i10 = gVar.f43865b;
            String f10 = C4622o.f(i10, gVar.f43864a, Math.min(gVar.f43866c, ((int) j10) + i10));
            aVar.skip(j10);
            return f10;
        } else {
            byte[] f11 = C1684y2.f(aVar, (int) j10);
            return C4622o.f(0, f11, f11.length);
        }
    }

    public static final String c(j jVar) {
        l.f(jVar, "<this>");
        jVar.h(Long.MAX_VALUE);
        return b(jVar.a(), jVar.a().f43851z);
    }

    public static final String d(j jVar, long j10) {
        l.f(jVar, "<this>");
        jVar.y0(j10);
        return b(jVar.a(), j10);
    }

    public static final double e(long j10) {
        return (((double) (j10 >>> 11)) * ((double) 2048)) + ((double) (j10 & 2047));
    }

    public static final String f(int i10, long j10) {
        if (j10 >= 0) {
            o.j(i10);
            String l10 = Long.toString(j10, i10);
            l.e(l10, "toString(...)");
            return l10;
        }
        long j11 = (long) i10;
        long j12 = ((j10 >>> 1) / j11) << 1;
        long j13 = j10 - (j12 * j11);
        if (j13 >= j11) {
            j13 -= j11;
            j12++;
        }
        o.j(i10);
        String l11 = Long.toString(j12, i10);
        l.e(l11, "toString(...)");
        o.j(i10);
        String l12 = Long.toString(j13, i10);
        l.e(l12, "toString(...)");
        return l11.concat(l12);
    }

    public static final void g(i iVar, String str, int i10, int i11) {
        int i12;
        long j10;
        char c10;
        l.f(str, "string");
        m.a((long) str.length(), (long) i10, (long) i11);
        C4941a a10 = iVar.a();
        while (i10 < i11) {
            B b10 = new B();
            char charAt = str.charAt(i10);
            b10.f41741f = charAt;
            if (charAt < 128) {
                g f10 = a10.f(1);
                int i13 = -i10;
                int min = Math.min(i11, f10.a() + i10);
                int i14 = i10 + 1;
                int i15 = f10.f43866c + i10 + i13;
                byte[] bArr = f10.f43864a;
                bArr[i15] = (byte) b10.f41741f;
                while (i14 < min) {
                    char charAt2 = str.charAt(i14);
                    b10.f41741f = charAt2;
                    if (charAt2 >= 128) {
                        break;
                    }
                    bArr[f10.f43866c + i14 + i13] = (byte) charAt2;
                    i14++;
                }
                int i16 = i13 + i14;
                if (i16 == 1) {
                    f10.f43866c += i16;
                    a10.f43851z += (long) i16;
                } else if (i16 < 0 || i16 > f10.a()) {
                    StringBuilder m10 = b.m(i16, "Invalid number of bytes written: ", ". Should be in 0..");
                    m10.append(f10.a());
                    throw new IllegalStateException(m10.toString().toString());
                } else if (i16 != 0) {
                    f10.f43866c += i16;
                    a10.f43851z += (long) i16;
                } else if (N.D(f10)) {
                    a10.d();
                }
                i10 = i14;
            } else {
                if (charAt < 2048) {
                    i12 = 2;
                    g f11 = a10.f(2);
                    int i17 = b10.f41741f;
                    int i18 = f11.f43866c;
                    byte[] bArr2 = f11.f43864a;
                    bArr2[i18] = (byte) ((i17 >> 6) | 192);
                    bArr2[i18 + 1] = (byte) ((i17 & 63) | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
                    f11.f43866c = i18 + 2;
                    j10 = a10.f43851z;
                } else if (charAt < 55296 || charAt > 57343) {
                    i12 = 3;
                    g f12 = a10.f(3);
                    int i19 = b10.f41741f;
                    int i20 = f12.f43866c;
                    byte[] bArr3 = f12.f43864a;
                    bArr3[i20] = (byte) ((i19 >> 12) | 224);
                    bArr3[i20 + 1] = (byte) (((i19 >> 6) & 63) | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
                    bArr3[i20 + 2] = (byte) ((i19 & 63) | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
                    f12.f43866c = i20 + 3;
                    j10 = a10.f43851z;
                } else {
                    int i21 = i10 + 1;
                    if (i21 < i11) {
                        c10 = str.charAt(i21);
                    } else {
                        c10 = 0;
                    }
                    int i22 = b10.f41741f;
                    if (i22 > 56319 || 56320 > c10 || c10 >= 57344) {
                        a10.I((byte) 63);
                        i10 = i21;
                    } else {
                        int i23 = (((i22 & 1023) << 10) | (c10 & 1023)) + 0;
                        g f13 = a10.f(4);
                        int i24 = f13.f43866c;
                        byte[] bArr4 = f13.f43864a;
                        bArr4[i24] = (byte) ((i23 >> 18) | 240);
                        bArr4[i24 + 1] = (byte) (((i23 >> 12) & 63) | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
                        bArr4[i24 + 2] = (byte) (((i23 >> 6) & 63) | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
                        bArr4[i24 + 3] = (byte) ((i23 & 63) | HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
                        f13.f43866c = i24 + 4;
                        a10.f43851z += (long) 4;
                        i10 += 2;
                    }
                }
                a10.f43851z = j10 + ((long) i12);
                i10++;
            }
        }
    }
}
