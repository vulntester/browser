package u0;

import C.N;
import Na.l;
import e1.m;
import kotlin.jvm.internal.n;
import o0.C2747c;
import p0.C2867g;
import p0.C2868h;
import p0.C2876p;
import p0.C2880t;
import r0.d;
import xa.C4959D;

/* renamed from: u0.c  reason: case insensitive filesystem */
public abstract class C3194c {

    /* renamed from: E  reason: collision with root package name */
    public float f28467E = 1.0f;

    /* renamed from: F  reason: collision with root package name */
    public m f28468F = m.f20656f;

    /* renamed from: f  reason: collision with root package name */
    public C2867g f28469f;

    /* renamed from: i  reason: collision with root package name */
    public boolean f28470i;

    /* renamed from: z  reason: collision with root package name */
    public C2880t f28471z;

    /* renamed from: u0.c$a */
    public static final class a extends n implements l<d, C4959D> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3194c f28472f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(C3194c cVar) {
            super(1);
            this.f28472f = cVar;
        }

        public final Object invoke(Object obj) {
            this.f28472f.i((d) obj);
            return C4959D.f44058a;
        }
    }

    public C3194c() {
        new a(this);
    }

    public boolean a(float f10) {
        return false;
    }

    public boolean e(C2880t tVar) {
        return false;
    }

    public final void g(d dVar, long j10, float f10, C2880t tVar) {
        C2876p a10;
        if (this.f28467E != f10) {
            if (!a(f10)) {
                if (f10 == 1.0f) {
                    C2867g gVar = this.f28469f;
                    if (gVar != null) {
                        gVar.g(f10);
                    }
                    this.f28470i = false;
                } else {
                    C2867g gVar2 = this.f28469f;
                    if (gVar2 == null) {
                        gVar2 = C2868h.a();
                        this.f28469f = gVar2;
                    }
                    gVar2.g(f10);
                    this.f28470i = true;
                }
            }
            this.f28467E = f10;
        }
        if (!kotlin.jvm.internal.l.a(this.f28471z, tVar)) {
            if (!e(tVar)) {
                if (tVar == null) {
                    C2867g gVar3 = this.f28469f;
                    if (gVar3 != null) {
                        gVar3.j((C2880t) null);
                    }
                    this.f28470i = false;
                } else {
                    C2867g gVar4 = this.f28469f;
                    if (gVar4 == null) {
                        gVar4 = C2868h.a();
                        this.f28469f = gVar4;
                    }
                    gVar4.j(tVar);
                    this.f28470i = true;
                }
            }
            this.f28471z = tVar;
        }
        m layoutDirection = dVar.getLayoutDirection();
        if (this.f28468F != layoutDirection) {
            f(layoutDirection);
            this.f28468F = layoutDirection;
        }
        int i10 = (int) (j10 >> 32);
        float intBitsToFloat = Float.intBitsToFloat((int) (dVar.v() >> 32)) - Float.intBitsToFloat(i10);
        int i11 = (int) (j10 & 4294967295L);
        float intBitsToFloat2 = Float.intBitsToFloat((int) (dVar.v() & 4294967295L)) - Float.intBitsToFloat(i11);
        dVar.I0().f27309a.e(0.0f, 0.0f, intBitsToFloat, intBitsToFloat2);
        if (f10 > 0.0f) {
            try {
                if (Float.intBitsToFloat(i10) > 0.0f && Float.intBitsToFloat(i11) > 0.0f) {
                    if (this.f28470i) {
                        float intBitsToFloat3 = Float.intBitsToFloat(i10);
                        C2747c e10 = N.e(0, (((long) Float.floatToRawIntBits(Float.intBitsToFloat(i11))) & 4294967295L) | (((long) Float.floatToRawIntBits(intBitsToFloat3)) << 32));
                        a10 = dVar.I0().a();
                        C2867g gVar5 = this.f28469f;
                        if (gVar5 == null) {
                            gVar5 = C2868h.a();
                            this.f28469f = gVar5;
                        }
                        a10.k(e10, gVar5);
                        i(dVar);
                        a10.t();
                    } else {
                        i(dVar);
                    }
                }
            } catch (Throwable th) {
                dVar.I0().f27309a.e(-0.0f, -0.0f, -intBitsToFloat, -intBitsToFloat2);
                throw th;
            }
        }
        dVar.I0().f27309a.e(-0.0f, -0.0f, -intBitsToFloat, -intBitsToFloat2);
    }

    public abstract long h();

    public abstract void i(d dVar);

    public void f(m mVar) {
    }
}
