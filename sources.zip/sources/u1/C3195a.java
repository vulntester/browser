package u1;

import B1.f;
import android.annotation.SuppressLint;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Process;
import android.text.TextUtils;
import f7.y3;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Executor;
import t1.p;

@SuppressLint({"PrivateConstructorForUtilityClass"})
/* renamed from: u1.a  reason: case insensitive filesystem */
public class C3195a {

    /* renamed from: u1.a$a  reason: collision with other inner class name */
    public static class C0274a {
        public static Context a(Context context) {
            return context.createDeviceProtectedStorageContext();
        }
    }

    /* renamed from: u1.a$b */
    public static class b {
        public static Intent a(Context context, y3 y3Var, IntentFilter intentFilter) {
            return context.registerReceiver(y3Var, intentFilter, (String) null, (Handler) null, 0);
        }

        public static void b(Context context, Intent intent) {
            context.startForegroundService(intent);
        }
    }

    /* renamed from: u1.a$c */
    public static class c {
        public static Executor a(Context context) {
            return context.getMainExecutor();
        }
    }

    /* renamed from: u1.a$d */
    public static class d {
        public static Intent a(Context context, y3 y3Var, IntentFilter intentFilter) {
            return context.registerReceiver(y3Var, intentFilter, (String) null, (Handler) null, 2);
        }
    }

    public static int a(Context context, String str) {
        boolean z10 = true;
        if (str != null) {
            int i10 = Build.VERSION.SDK_INT;
            if (i10 >= 33 || !TextUtils.equals("android.permission.POST_NOTIFICATIONS", str)) {
                return context.checkPermission(str, Process.myPid(), Process.myUid());
            }
            p pVar = new p(context);
            if (i10 >= 24) {
                z10 = p.a.a(pVar.f28165a);
            } else {
                AppOpsManager appOpsManager = (AppOpsManager) context.getSystemService("appops");
                ApplicationInfo applicationInfo = context.getApplicationInfo();
                String packageName = context.getApplicationContext().getPackageName();
                int i11 = applicationInfo.uid;
                try {
                    Class<?> cls = Class.forName(AppOpsManager.class.getName());
                    Class cls2 = Integer.TYPE;
                    Method method = cls.getMethod("checkOpNoThrow", new Class[]{cls2, cls2, String.class});
                    Integer num = (Integer) cls.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class);
                    num.getClass();
                    if (((Integer) method.invoke(appOpsManager, new Object[]{num, Integer.valueOf(i11), packageName})).intValue() != 0) {
                        z10 = false;
                    }
                } catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException | NoSuchMethodException | RuntimeException | InvocationTargetException unused) {
                }
            }
            if (z10) {
                return 0;
            }
            return -1;
        }
        throw new NullPointerException("permission must be non-null");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0046, code lost:
        if (r5.f29952c == r8.hashCode()) goto L_0x0048;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.content.res.ColorStateList b(android.content.Context r8, int r9) {
        /*
            android.content.res.Resources r0 = r8.getResources()
            android.content.res.Resources$Theme r8 = r8.getTheme()
            w1.f$b r1 = new w1.f$b
            r1.<init>(r0, r8)
            java.lang.Object r2 = w1.f.f29949c
            monitor-enter(r2)
            java.util.WeakHashMap<w1.f$b, android.util.SparseArray<w1.f$a>> r3 = w1.f.f29948b     // Catch:{ all -> 0x003c }
            java.lang.Object r3 = r3.get(r1)     // Catch:{ all -> 0x003c }
            android.util.SparseArray r3 = (android.util.SparseArray) r3     // Catch:{ all -> 0x003c }
            r4 = 0
            if (r3 == 0) goto L_0x004f
            int r5 = r3.size()     // Catch:{ all -> 0x003c }
            if (r5 <= 0) goto L_0x004f
            java.lang.Object r5 = r3.get(r9)     // Catch:{ all -> 0x003c }
            w1.f$a r5 = (w1.f.a) r5     // Catch:{ all -> 0x003c }
            if (r5 == 0) goto L_0x004f
            android.content.res.Configuration r6 = r5.f29951b     // Catch:{ all -> 0x003c }
            android.content.res.Configuration r7 = r0.getConfiguration()     // Catch:{ all -> 0x003c }
            boolean r6 = r6.equals(r7)     // Catch:{ all -> 0x003c }
            if (r6 == 0) goto L_0x004c
            if (r8 != 0) goto L_0x003e
            int r6 = r5.f29952c     // Catch:{ all -> 0x003c }
            if (r6 == 0) goto L_0x0048
            goto L_0x003e
        L_0x003c:
            r8 = move-exception
            goto L_0x0091
        L_0x003e:
            if (r8 == 0) goto L_0x004c
            int r6 = r5.f29952c     // Catch:{ all -> 0x003c }
            int r7 = r8.hashCode()     // Catch:{ all -> 0x003c }
            if (r6 != r7) goto L_0x004c
        L_0x0048:
            android.content.res.ColorStateList r3 = r5.f29950a     // Catch:{ all -> 0x003c }
            monitor-exit(r2)     // Catch:{ all -> 0x003c }
            goto L_0x0051
        L_0x004c:
            r3.remove(r9)     // Catch:{ all -> 0x003c }
        L_0x004f:
            monitor-exit(r2)     // Catch:{ all -> 0x003c }
            r3 = r4
        L_0x0051:
            if (r3 == 0) goto L_0x0054
            return r3
        L_0x0054:
            java.lang.ThreadLocal<android.util.TypedValue> r2 = w1.f.f29947a
            java.lang.Object r3 = r2.get()
            android.util.TypedValue r3 = (android.util.TypedValue) r3
            if (r3 != 0) goto L_0x0066
            android.util.TypedValue r3 = new android.util.TypedValue
            r3.<init>()
            r2.set(r3)
        L_0x0066:
            r2 = 1
            r0.getValue(r9, r3, r2)
            int r2 = r3.type
            r3 = 28
            if (r2 < r3) goto L_0x0075
            r3 = 31
            if (r2 > r3) goto L_0x0075
            goto L_0x0086
        L_0x0075:
            android.content.res.XmlResourceParser r2 = r0.getXml(r9)
            android.content.res.ColorStateList r4 = w1.c.a(r0, r2, r8)     // Catch:{ Exception -> 0x007e }
            goto L_0x0086
        L_0x007e:
            r2 = move-exception
            java.lang.String r3 = "ResourcesCompat"
            java.lang.String r5 = "Failed to inflate ColorStateList, leaving it to the framework"
            android.util.Log.w(r3, r5, r2)
        L_0x0086:
            if (r4 == 0) goto L_0x008c
            w1.f.a(r1, r9, r4, r8)
            goto L_0x0090
        L_0x008c:
            android.content.res.ColorStateList r4 = r0.getColorStateList(r9, r8)
        L_0x0090:
            return r4
        L_0x0091:
            monitor-exit(r2)     // Catch:{ all -> 0x003c }
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: u1.C3195a.b(android.content.Context, int):android.content.res.ColorStateList");
    }

    public static Executor c(Context context) {
        if (Build.VERSION.SDK_INT >= 28) {
            return c.a(context);
        }
        return new f(new Handler(context.getMainLooper()));
    }
}
