package u1;

import E1.a;
import Y1.x;
import android.content.res.Configuration;

/* renamed from: u1.b  reason: case insensitive filesystem */
public interface C3196b {
    void N(a<Configuration> aVar);

    void R(x xVar);
}
