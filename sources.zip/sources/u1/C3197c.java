package u1;

import Y1.y;

/* renamed from: u1.c  reason: case insensitive filesystem */
public interface C3197c {
    void T(y yVar);

    void U(y yVar);
}
