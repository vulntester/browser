package u6;

import C3.n;
import C4.H;
import R1.a;
import Ta.k;
import V.C1187r0;
import V.M0;
import android.graphics.ColorFilter;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import e1.m;
import kotlin.jvm.internal.l;
import lc.C4622o;
import o0.C2749e;
import p0.C2863c;
import p0.C2876p;
import p0.C2880t;
import r0.d;
import u0.C3194c;
import xa.C4969i;
import xa.C4978r;

/* renamed from: u6.a  reason: case insensitive filesystem */
public final class C3233a extends C3194c implements M0 {

    /* renamed from: G  reason: collision with root package name */
    public final Drawable f28690G;

    /* renamed from: H  reason: collision with root package name */
    public final C1187r0 f28691H = a.t(0);

    /* renamed from: I  reason: collision with root package name */
    public final C1187r0 f28692I;

    /* renamed from: J  reason: collision with root package name */
    public final C4978r f28693J;

    /* renamed from: u6.a$a  reason: collision with other inner class name */
    public static final class C0276a implements Drawable.Callback {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3233a f28694f;

        public C0276a(C3233a aVar) {
            this.f28694f = aVar;
        }

        public final void invalidateDrawable(Drawable drawable) {
            long j10;
            l.f(drawable, "d");
            C3233a aVar = this.f28694f;
            aVar.f28691H.setValue(Integer.valueOf(((Number) aVar.f28691H.getValue()).intValue() + 1));
            Object obj = C3234b.f28695a;
            Drawable drawable2 = aVar.f28690G;
            if (drawable2.getIntrinsicWidth() < 0 || drawable2.getIntrinsicHeight() < 0) {
                j10 = 9205357640488583168L;
            } else {
                j10 = C4622o.a((float) drawable2.getIntrinsicWidth(), (float) drawable2.getIntrinsicHeight());
            }
            aVar.f28692I.setValue(new C2749e(j10));
        }

        /* JADX WARNING: type inference failed for: r2v2, types: [xa.h, java.lang.Object] */
        public final void scheduleDrawable(Drawable drawable, Runnable runnable, long j10) {
            l.f(drawable, "d");
            l.f(runnable, "what");
            ((Handler) C3234b.f28695a.getValue()).postAtTime(runnable, j10);
        }

        /* JADX WARNING: type inference failed for: r2v2, types: [xa.h, java.lang.Object] */
        public final void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            l.f(drawable, "d");
            l.f(runnable, "what");
            ((Handler) C3234b.f28695a.getValue()).removeCallbacks(runnable);
        }
    }

    public C3233a(Drawable drawable) {
        long j10;
        l.f(drawable, "drawable");
        this.f28690G = drawable;
        Object obj = C3234b.f28695a;
        if (drawable.getIntrinsicWidth() < 0 || drawable.getIntrinsicHeight() < 0) {
            j10 = 9205357640488583168L;
        } else {
            j10 = C4622o.a((float) drawable.getIntrinsicWidth(), (float) drawable.getIntrinsicHeight());
        }
        this.f28692I = a.t(new C2749e(j10));
        this.f28693J = C4969i.e(new n(this, 16));
        if (drawable.getIntrinsicWidth() >= 0 && drawable.getIntrinsicHeight() >= 0) {
            drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        }
    }

    public final boolean a(float f10) {
        this.f28690G.setAlpha(k.R(Pa.a.b(f10 * ((float) 255)), 0, 255));
        return true;
    }

    public final void b() {
        c();
    }

    public final void c() {
        Drawable drawable = this.f28690G;
        if (drawable instanceof Animatable) {
            ((Animatable) drawable).stop();
        }
        drawable.setVisible(false, false);
        drawable.setCallback((Drawable.Callback) null);
    }

    public final void d() {
        Drawable drawable = this.f28690G;
        drawable.setCallback((Drawable.Callback) this.f28693J.getValue());
        drawable.setVisible(true, true);
        if (drawable instanceof Animatable) {
            ((Animatable) drawable).start();
        }
    }

    public final boolean e(C2880t tVar) {
        ColorFilter colorFilter;
        if (tVar != null) {
            colorFilter = tVar.f26410a;
        } else {
            colorFilter = null;
        }
        this.f28690G.setColorFilter(colorFilter);
        return true;
    }

    public final void f(m mVar) {
        int i10;
        l.f(mVar, "layoutDirection");
        int ordinal = mVar.ordinal();
        if (ordinal != 0) {
            i10 = 1;
            if (ordinal != 1) {
                throw new RuntimeException();
            }
        } else {
            i10 = 0;
        }
        this.f28690G.setLayoutDirection(i10);
    }

    public final long h() {
        return ((C2749e) this.f28692I.getValue()).f25781a;
    }

    public final void i(d dVar) {
        l.f(dVar, "<this>");
        C2876p a10 = dVar.I0().a();
        ((Number) this.f28691H.getValue()).intValue();
        try {
            a10.f();
            int i10 = Build.VERSION.SDK_INT;
            Drawable drawable = this.f28690G;
            if (i10 >= 28 && i10 < 31) {
                if (H.d(drawable)) {
                    a10.c(C2749e.d(dVar.v()) / C2749e.d(h()), C2749e.b(dVar.v()) / C2749e.b(h()));
                    drawable.draw(C2863c.a(a10));
                    a10.t();
                }
            }
            drawable.setBounds(0, 0, Pa.a.b(C2749e.d(dVar.v())), Pa.a.b(C2749e.b(dVar.v())));
            drawable.draw(C2863c.a(a10));
            a10.t();
        } catch (Throwable th) {
            a10.t();
            throw th;
        }
    }
}
