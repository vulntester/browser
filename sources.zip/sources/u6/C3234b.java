package u6;

import F3.b;
import xa.C4969i;
import xa.C4970j;

/* renamed from: u6.b  reason: case insensitive filesystem */
public final class C3234b {

    /* renamed from: a  reason: collision with root package name */
    public static final Object f28695a = C4969i.d(C4970j.f44069i, new b(8));
}
