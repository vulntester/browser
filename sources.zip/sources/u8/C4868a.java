package u8;

import C0.e;
import org.json.JSONObject;
import u8.C4869b;

/* renamed from: u8.a  reason: case insensitive filesystem */
public final class C4868a implements C4874g {
    public static C4869b b(e eVar) {
        return new C4869b(System.currentTimeMillis() + ((long) 3600000), new C4869b.C0443b(8), new C4869b.a(true, false, false), 10.0d, 1.2d, 60);
    }

    public final C4869b a(e eVar, JSONObject jSONObject) {
        return b(eVar);
    }
}
