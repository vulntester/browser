package u8;

/* renamed from: u8.b  reason: case insensitive filesystem */
public final class C4869b {

    /* renamed from: a  reason: collision with root package name */
    public final C0443b f43514a;

    /* renamed from: b  reason: collision with root package name */
    public final a f43515b;

    /* renamed from: c  reason: collision with root package name */
    public final long f43516c;

    /* renamed from: d  reason: collision with root package name */
    public final double f43517d;

    /* renamed from: e  reason: collision with root package name */
    public final double f43518e;

    /* renamed from: f  reason: collision with root package name */
    public final int f43519f;

    /* renamed from: u8.b$a */
    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public final boolean f43520a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f43521b;

        /* renamed from: c  reason: collision with root package name */
        public final boolean f43522c;

        public a(boolean z10, boolean z11, boolean z12) {
            this.f43520a = z10;
            this.f43521b = z11;
            this.f43522c = z12;
        }
    }

    /* renamed from: u8.b$b  reason: collision with other inner class name */
    public static class C0443b {

        /* renamed from: a  reason: collision with root package name */
        public final int f43523a;

        public C0443b(int i10) {
            this.f43523a = i10;
        }
    }

    public C4869b(long j10, C0443b bVar, a aVar, double d10, double d11, int i10) {
        this.f43516c = j10;
        this.f43514a = bVar;
        this.f43515b = aVar;
        this.f43517d = d10;
        this.f43518e = d11;
        this.f43519f = i10;
    }
}
