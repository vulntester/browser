package u8;

/* renamed from: u8.c  reason: case insensitive filesystem */
public enum C4870c {
    ;

    /* access modifiers changed from: public */
    C4870c() {
        throw null;
    }
}
