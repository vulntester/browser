package u8;

import R2.l;
import android.util.Log;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.Callable;
import kotlin.jvm.internal.k;
import n8.C4709g;
import n8.C4712j;
import r8.C4806a;

/* renamed from: u8.d  reason: case insensitive filesystem */
public final /* synthetic */ class C4871d implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C4872e f43528a;

    public /* synthetic */ C4871d(C4872e eVar) {
        this.f43528a = eVar;
    }

    /* JADX WARNING: type inference failed for: r6v0, types: [Na.a, kotlin.jvm.internal.k] */
    public final Object call() {
        C4873f fVar = this.f43528a.f43530i;
        C4875h hVar = fVar.f43532b;
        l lVar = fVar.f43536f;
        String str = lVar.f8184a;
        C4712j.a aVar = C4712j.f42348d;
        aVar.getClass();
        C4712j.a.a(new k(0, aVar, C4712j.a.class, "isBlockingThread", "isBlockingThread()Z", 0), C4709g.f42346f);
        try {
            HashMap b10 = l.b(hVar);
            C4806a aVar2 = new C4806a(str, b10);
            aVar2.c("User-Agent", "Crashlytics Android SDK/19.4.3");
            aVar2.c("X-CRASHLYTICS-DEVELOPER-TOKEN", "470fa2b4ae81cd56ecbcda9735803434cec591fa");
            l.a(aVar2, hVar);
            String str2 = "Requesting settings from " + str;
            if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                Log.d("FirebaseCrashlytics", str2, (Throwable) null);
            }
            String str3 = "Settings query params were: " + b10;
            if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                Log.v("FirebaseCrashlytics", str3, (Throwable) null);
            }
            return lVar.c(aVar2.b());
        } catch (IOException e10) {
            Log.e("FirebaseCrashlytics", "Settings request failed.", e10);
            return null;
        }
    }
}
