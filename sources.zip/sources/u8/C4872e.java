package u8;

import j7.i;
import n8.C4712j;

/* renamed from: u8.e  reason: case insensitive filesystem */
public final class C4872e implements i<Void, Void> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C4712j f43529f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ C4873f f43530i;

    public C4872e(C4873f fVar, C4712j jVar) {
        this.f43530i = fVar;
        this.f43529f = jVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x005a, code lost:
        r10 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x005f, code lost:
        r3 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0060, code lost:
        r4 = r3;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005a A[ExcHandler: all (th java.lang.Throwable), Splitter:B:6:0x003b] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final j7.j b(java.lang.Object r10) {
        /*
            r9 = this;
            java.lang.Void r10 = (java.lang.Void) r10
            n8.j r10 = r9.f43529f
            n8.c r10 = r10.f42351c
            java.util.concurrent.ExecutorService r10 = r10.f42342f
            u8.d r0 = new u8.d
            r0.<init>(r9)
            java.util.concurrent.Future r10 = r10.submit(r0)
            java.lang.Object r10 = r10.get()
            org.json.JSONObject r10 = (org.json.JSONObject) r10
            r0 = 0
            if (r10 == 0) goto L_0x009b
            u8.f r1 = r9.f43530i
            S6.b r2 = r1.f43533c
            u8.b r2 = r2.f(r10)
            long r3 = r2.f43516c
            A7.b r5 = r1.f43535e
            r5.getClass()
            java.lang.String r6 = "Failed to close settings writer."
            r7 = 2
            java.lang.String r8 = "FirebaseCrashlytics"
            boolean r7 = android.util.Log.isLoggable(r8, r7)
            if (r7 == 0) goto L_0x0039
            java.lang.String r7 = "Writing settings to cache file..."
            android.util.Log.v(r8, r7, r0)
        L_0x0039:
            java.lang.String r7 = "expires_at"
            r10.put(r7, r3)     // Catch:{ Exception -> 0x005c, all -> 0x005a }
            java.io.FileWriter r3 = new java.io.FileWriter     // Catch:{ Exception -> 0x005c, all -> 0x005a }
            java.lang.Object r4 = r5.f408i     // Catch:{ Exception -> 0x005f, all -> 0x005a }
            java.io.File r4 = (java.io.File) r4     // Catch:{ Exception -> 0x005f, all -> 0x005a }
            r3.<init>(r4)     // Catch:{ Exception -> 0x005c, all -> 0x005a }
            java.lang.String r4 = r10.toString()     // Catch:{ Exception -> 0x0058 }
            r3.write(r4)     // Catch:{ Exception -> 0x0058 }
            r3.flush()     // Catch:{ Exception -> 0x0058 }
        L_0x0051:
            m8.C4643g.b(r3, r6)
            goto L_0x0068
        L_0x0055:
            r10 = move-exception
            r0 = r3
            goto L_0x0097
        L_0x0058:
            r4 = move-exception
            goto L_0x0062
        L_0x005a:
            r10 = move-exception
            goto L_0x0097
        L_0x005c:
            r4 = move-exception
        L_0x005d:
            r3 = r0
            goto L_0x0062
        L_0x005f:
            r3 = move-exception
            r4 = r3
            goto L_0x005d
        L_0x0062:
            java.lang.String r5 = "Failed to cache settings"
            android.util.Log.e(r8, r5, r4)     // Catch:{ all -> 0x0055 }
            goto L_0x0051
        L_0x0068:
            java.lang.String r3 = "Loaded settings: "
            u8.C4873f.c(r10, r3)
            u8.h r10 = r1.f43532b
            java.lang.String r10 = r10.f43545f
            java.lang.String r3 = "com.google.firebase.crashlytics"
            r4 = 0
            android.content.Context r5 = r1.f43531a
            android.content.SharedPreferences r3 = r5.getSharedPreferences(r3, r4)
            android.content.SharedPreferences$Editor r3 = r3.edit()
            java.lang.String r4 = "existing_instance_identifier"
            r3.putString(r4, r10)
            r3.apply()
            java.util.concurrent.atomic.AtomicReference<u8.b> r10 = r1.f43538h
            r10.set(r2)
            java.util.concurrent.atomic.AtomicReference<j7.k<u8.b>> r10 = r1.f43539i
            java.lang.Object r10 = r10.get()
            j7.k r10 = (j7.k) r10
            r10.d(r2)
            goto L_0x009b
        L_0x0097:
            m8.C4643g.b(r0, r6)
            throw r10
        L_0x009b:
            j7.y r10 = j7.m.e(r0)
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: u8.C4872e.b(java.lang.Object):j7.j");
    }
}
