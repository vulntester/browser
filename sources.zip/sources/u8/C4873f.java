package u8;

import C0.e;
import D1.c;
import R2.l;
import S6.b;
import android.content.Context;
import android.util.Log;
import j7.k;
import java.util.concurrent.atomic.AtomicReference;
import m8.y;
import org.json.JSONObject;

/* renamed from: u8.f  reason: case insensitive filesystem */
public final class C4873f {

    /* renamed from: a  reason: collision with root package name */
    public final Context f43531a;

    /* renamed from: b  reason: collision with root package name */
    public final C4875h f43532b;

    /* renamed from: c  reason: collision with root package name */
    public final b f43533c;

    /* renamed from: d  reason: collision with root package name */
    public final e f43534d;

    /* renamed from: e  reason: collision with root package name */
    public final A7.b f43535e;

    /* renamed from: f  reason: collision with root package name */
    public final l f43536f;

    /* renamed from: g  reason: collision with root package name */
    public final y f43537g;

    /* renamed from: h  reason: collision with root package name */
    public final AtomicReference<C4869b> f43538h;

    /* renamed from: i  reason: collision with root package name */
    public final AtomicReference<k<C4869b>> f43539i = new AtomicReference<>(new k());

    public C4873f(Context context, C4875h hVar, e eVar, b bVar, A7.b bVar2, l lVar, y yVar) {
        AtomicReference<C4869b> atomicReference = new AtomicReference<>();
        this.f43538h = atomicReference;
        this.f43531a = context;
        this.f43532b = hVar;
        this.f43534d = eVar;
        this.f43533c = bVar;
        this.f43535e = bVar2;
        this.f43536f = lVar;
        this.f43537g = yVar;
        atomicReference.set(C4868a.b(eVar));
    }

    public static void c(JSONObject jSONObject, String str) {
        StringBuilder i10 = c.i(str);
        i10.append(jSONObject.toString());
        String sb2 = i10.toString();
        if (Log.isLoggable("FirebaseCrashlytics", 3)) {
            Log.d("FirebaseCrashlytics", sb2, (Throwable) null);
        }
    }

    public final C4869b a(C4870c cVar) {
        C4869b bVar = null;
        try {
            if (!C4870c.f43526i.equals(cVar)) {
                JSONObject c10 = this.f43535e.c();
                if (c10 != null) {
                    C4869b f10 = this.f43533c.f(c10);
                    c(c10, "Loaded cached settings: ");
                    this.f43534d.getClass();
                    long currentTimeMillis = System.currentTimeMillis();
                    if (C4870c.f43527z.equals(cVar) || f10.f43516c >= currentTimeMillis) {
                        try {
                            if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                                Log.v("FirebaseCrashlytics", "Returning cached settings.", (Throwable) null);
                            }
                            return f10;
                        } catch (Exception e10) {
                            e = e10;
                            bVar = f10;
                            Log.e("FirebaseCrashlytics", "Failed to get cached settings", e);
                            return bVar;
                        }
                    } else if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", "Cached settings have expired.", (Throwable) null);
                        return null;
                    }
                } else if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                    Log.d("FirebaseCrashlytics", "No cached settings data found.", (Throwable) null);
                }
            }
            return null;
        } catch (Exception e11) {
            e = e11;
            Log.e("FirebaseCrashlytics", "Failed to get cached settings", e);
            return bVar;
        }
    }

    public final C4869b b() {
        return this.f43538h.get();
    }
}
