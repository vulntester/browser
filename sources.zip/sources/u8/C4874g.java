package u8;

import C0.e;
import org.json.JSONObject;

/* renamed from: u8.g  reason: case insensitive filesystem */
public interface C4874g {
    C4869b a(e eVar, JSONObject jSONObject);
}
