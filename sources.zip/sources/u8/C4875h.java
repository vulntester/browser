package u8;

import m8.C4635C;

/* renamed from: u8.h  reason: case insensitive filesystem */
public final class C4875h {

    /* renamed from: a  reason: collision with root package name */
    public final String f43540a;

    /* renamed from: b  reason: collision with root package name */
    public final String f43541b;

    /* renamed from: c  reason: collision with root package name */
    public final String f43542c;

    /* renamed from: d  reason: collision with root package name */
    public final String f43543d;

    /* renamed from: e  reason: collision with root package name */
    public final C4635C f43544e;

    /* renamed from: f  reason: collision with root package name */
    public final String f43545f;

    /* renamed from: g  reason: collision with root package name */
    public final String f43546g;

    /* renamed from: h  reason: collision with root package name */
    public final String f43547h;

    /* renamed from: i  reason: collision with root package name */
    public final int f43548i;

    public C4875h(String str, String str2, String str3, String str4, C4635C c10, String str5, String str6, String str7, int i10) {
        this.f43540a = str;
        this.f43541b = str2;
        this.f43542c = str3;
        this.f43543d = str4;
        this.f43544e = c10;
        this.f43545f = str5;
        this.f43546g = str6;
        this.f43547h = str7;
        this.f43548i = i10;
    }
}
