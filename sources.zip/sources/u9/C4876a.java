package u9;

/* renamed from: u9.a  reason: case insensitive filesystem */
public enum C4876a {
    ;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v2, resolved type: u9.a[]} */
    /* JADX WARNING: type inference failed for: r4v0, types: [u9.a, java.lang.Enum] */
    /* JADX WARNING: type inference failed for: r6v1, types: [u9.a, java.lang.Enum] */
    /* JADX WARNING: type inference failed for: r7v1, types: [u9.a, java.lang.Enum] */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            r0 = 3
            r1 = 2
            r2 = 1
            r3 = 0
            u9.a r4 = new u9.a
            java.lang.String r5 = "BROWSER"
            r4.<init>(r5, r3)
            f43550f = r4
            u9.a r5 = new u9.a
            java.lang.String r6 = "SEARCH"
            r5.<init>(r6, r2)
            u9.a r6 = new u9.a
            java.lang.String r7 = "MAIN"
            r6.<init>(r7, r1)
            f43551i = r6
            u9.a r7 = new u9.a
            java.lang.String r8 = "VIDEO"
            r7.<init>(r8, r0)
            f43552z = r7
            r8 = 4
            u9.a[] r8 = new u9.C4876a[r8]
            r8[r3] = r4
            r8[r2] = r5
            r8[r1] = r6
            r8[r0] = r7
            f43549E = r8
            A1.a.r(r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: u9.C4876a.<clinit>():void");
    }

    /* access modifiers changed from: public */
    C4876a() {
        throw null;
    }

    public final String toString() {
        int ordinal = ordinal();
        if (ordinal == 0) {
            return "BrowserActivity";
        }
        if (ordinal == 1) {
            return "SearchActivity";
        }
        if (ordinal == 2) {
            return "MainActivity";
        }
        if (ordinal == 3) {
            return "VideoPlayerActivity";
        }
        throw new RuntimeException();
    }
}
