package u9;

import io.ktor.websocket.DefaultWebSocketSession;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.jvm.internal.l;

public final class b {

    /* renamed from: b  reason: collision with root package name */
    public static final AtomicInteger f43553b = new AtomicInteger(0);

    /* renamed from: a  reason: collision with root package name */
    public final DefaultWebSocketSession f43554a;

    public b(DefaultWebSocketSession defaultWebSocketSession) {
        l.f(defaultWebSocketSession, "session");
        this.f43554a = defaultWebSocketSession;
        f43553b.getAndIncrement();
    }
}
