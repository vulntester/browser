package u9;

public enum c {
    ;

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v2, resolved type: u9.c[]} */
    /* JADX WARNING: type inference failed for: r2v0, types: [java.lang.Enum, u9.c] */
    /* JADX WARNING: type inference failed for: r3v1, types: [java.lang.Enum, u9.c] */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            r0 = 1
            r1 = 0
            u9.c r2 = new u9.c
            java.lang.String r3 = "CONNECTED"
            r2.<init>(r3, r1)
            f43555f = r2
            u9.c r3 = new u9.c
            java.lang.String r4 = "DISCONNECTED"
            r3.<init>(r4, r0)
            f43556i = r3
            r4 = 2
            u9.c[] r4 = new u9.c[r4]
            r4[r1] = r2
            r4[r0] = r3
            f43557z = r4
            A1.a.r(r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: u9.c.<clinit>():void");
    }

    /* access modifiers changed from: public */
    c() {
        throw null;
    }
}
