package u9;

import Da.e;
import Da.i;
import Na.p;
import com.internet.tvbrowser.services.server.HttpServerService;
import ic.C4487C;
import xa.C4959D;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService$deleteBookmark$1", f = "HttpServerService.kt", l = {734}, m = "invokeSuspend")
public final class d extends i implements p<C4487C, Ba.e<? super C4959D>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ int f43558E;

    /* renamed from: f  reason: collision with root package name */
    public int f43559f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ String f43560i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43561z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(String str, HttpServerService httpServerService, int i10, Ba.e<? super d> eVar) {
        super(2, eVar);
        this.f43560i = str;
        this.f43561z = httpServerService;
        this.f43558E = i10;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new d(this.f43560i, this.f43561z, this.f43558E, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((d) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v3, resolved type: Q5.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v4, resolved type: Q5.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v0, resolved type: Q5.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: Q5.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v12, resolved type: Q5.c} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r10) {
        /*
            r9 = this;
            java.lang.String r0 = "Invalid type "
            Ca.a r1 = Ca.a.f33640f
            int r2 = r9.f43559f
            java.lang.String r3 = r9.f43560i
            r4 = 1
            java.lang.String r5 = "string"
            int r6 = r9.f43558E
            if (r2 == 0) goto L_0x0021
            if (r2 != r4) goto L_0x0019
            xa.C4976p.b(r10)     // Catch:{ Exception -> 0x0016 }
            goto L_0x015f
        L_0x0016:
            r10 = move-exception
            goto L_0x013e
        L_0x0019:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r10.<init>(r0)
            throw r10
        L_0x0021:
            xa.C4976p.b(r10)
            java.lang.String r10 = "link"
            boolean r10 = kotlin.jvm.internal.l.a(r3, r10)     // Catch:{ Exception -> 0x0016 }
            if (r10 == 0) goto L_0x00a9
            W5.a r10 = com.internet.tvbrowser.services.server.HttpServerService.d()     // Catch:{ Exception -> 0x0016 }
            P5.f r10 = r10.f11385a     // Catch:{ Exception -> 0x0016 }
            java.util.ArrayList r10 = r10.p()     // Catch:{ Exception -> 0x0016 }
            java.util.Iterator r10 = r10.iterator()     // Catch:{ Exception -> 0x0016 }
        L_0x003a:
            boolean r0 = r10.hasNext()     // Catch:{ Exception -> 0x0016 }
            if (r0 == 0) goto L_0x015f
            java.lang.Object r0 = r10.next()     // Catch:{ Exception -> 0x0016 }
            Q5.c r0 = (Q5.c) r0     // Catch:{ Exception -> 0x0016 }
            java.util.ArrayList r0 = r0.f7784b     // Catch:{ Exception -> 0x0016 }
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch:{ Exception -> 0x0016 }
            r1.<init>()     // Catch:{ Exception -> 0x0016 }
            java.util.Iterator r0 = r0.iterator()     // Catch:{ Exception -> 0x0016 }
        L_0x0051:
            boolean r2 = r0.hasNext()     // Catch:{ Exception -> 0x0016 }
            if (r2 == 0) goto L_0x0066
            java.lang.Object r2 = r0.next()     // Catch:{ Exception -> 0x0016 }
            r4 = r2
            Q5.a r4 = (Q5.a) r4     // Catch:{ Exception -> 0x0016 }
            int r4 = r4.f7768a     // Catch:{ Exception -> 0x0016 }
            if (r4 != r6) goto L_0x0051
            r1.add(r2)     // Catch:{ Exception -> 0x0016 }
            goto L_0x0051
        L_0x0066:
            java.util.Iterator r0 = r1.iterator()     // Catch:{ Exception -> 0x0016 }
        L_0x006a:
            boolean r1 = r0.hasNext()     // Catch:{ Exception -> 0x0016 }
            if (r1 == 0) goto L_0x003a
            java.lang.Object r1 = r0.next()     // Catch:{ Exception -> 0x0016 }
            Q5.a r1 = (Q5.a) r1     // Catch:{ Exception -> 0x0016 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0016 }
            r2.<init>()     // Catch:{ Exception -> 0x0016 }
            java.lang.String r4 = "Deleting bookmark ID="
            r2.append(r4)     // Catch:{ Exception -> 0x0016 }
            r2.append(r6)     // Catch:{ Exception -> 0x0016 }
            java.lang.String r4 = ": found bookmark "
            r2.append(r4)     // Catch:{ Exception -> 0x0016 }
            r2.append(r1)     // Catch:{ Exception -> 0x0016 }
            r4 = 46
            r2.append(r4)     // Catch:{ Exception -> 0x0016 }
            java.lang.String r2 = r2.toString()     // Catch:{ Exception -> 0x0016 }
            kotlin.jvm.internal.l.f(r2, r5)     // Catch:{ Exception -> 0x0016 }
            W5.a r2 = com.internet.tvbrowser.services.server.HttpServerService.d()     // Catch:{ Exception -> 0x0016 }
            r2.getClass()     // Catch:{ Exception -> 0x0016 }
            java.lang.String r4 = "bookmark"
            kotlin.jvm.internal.l.f(r1, r4)     // Catch:{ Exception -> 0x0016 }
            P5.f r2 = r2.f11385a     // Catch:{ Exception -> 0x0016 }
            r2.l(r1)     // Catch:{ Exception -> 0x0016 }
            goto L_0x006a
        L_0x00a9:
            java.lang.String r10 = "folder"
            boolean r10 = kotlin.jvm.internal.l.a(r3, r10)     // Catch:{ Exception -> 0x0016 }
            if (r10 == 0) goto L_0x0121
            W5.a r10 = com.internet.tvbrowser.services.server.HttpServerService.d()     // Catch:{ Exception -> 0x0016 }
            P5.f r10 = r10.f11385a     // Catch:{ Exception -> 0x0016 }
            java.util.ArrayList r10 = r10.p()     // Catch:{ Exception -> 0x0016 }
            java.util.Iterator r10 = r10.iterator()     // Catch:{ Exception -> 0x0016 }
            r0 = 0
            r2 = 0
        L_0x00c1:
            boolean r7 = r10.hasNext()     // Catch:{ Exception -> 0x0016 }
            if (r7 == 0) goto L_0x00e1
            java.lang.Object r7 = r10.next()     // Catch:{ Exception -> 0x0016 }
            r8 = r7
            Q5.c r8 = (Q5.c) r8     // Catch:{ Exception -> 0x0016 }
            Q5.b r8 = r8.f7783a     // Catch:{ Exception -> 0x0016 }
            int r8 = r8.f7777a     // Catch:{ Exception -> 0x0016 }
            if (r8 != r6) goto L_0x00c1
            if (r2 != 0) goto L_0x00d9
            r2 = r4
            r0 = r7
            goto L_0x00c1
        L_0x00d9:
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException     // Catch:{ Exception -> 0x0016 }
            java.lang.String r0 = "Collection contains more than one matching element."
            r10.<init>(r0)     // Catch:{ Exception -> 0x0016 }
            throw r10     // Catch:{ Exception -> 0x0016 }
        L_0x00e1:
            if (r2 == 0) goto L_0x0119
            Q5.c r0 = (Q5.c) r0     // Catch:{ Exception -> 0x0016 }
            Q5.b r10 = r0.f7783a     // Catch:{ Exception -> 0x0016 }
            boolean r10 = B0.C0491s.r(r10)     // Catch:{ Exception -> 0x0016 }
            if (r10 == 0) goto L_0x0107
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0016 }
            r10.<init>()     // Catch:{ Exception -> 0x0016 }
            java.lang.String r0 = "Tried to delete favorites folder (ID: "
            r10.append(r0)     // Catch:{ Exception -> 0x0016 }
            r10.append(r6)     // Catch:{ Exception -> 0x0016 }
            java.lang.String r0 = "). Ignoring"
            r10.append(r0)     // Catch:{ Exception -> 0x0016 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x0016 }
            kotlin.jvm.internal.l.f(r10, r5)     // Catch:{ Exception -> 0x0016 }
            goto L_0x015f
        L_0x0107:
            W5.a r10 = com.internet.tvbrowser.services.server.HttpServerService.d()     // Catch:{ Exception -> 0x0016 }
            Q5.b r0 = r0.f7783a     // Catch:{ Exception -> 0x0016 }
            r9.f43559f = r4     // Catch:{ Exception -> 0x0016 }
            P5.f r10 = r10.f11385a     // Catch:{ Exception -> 0x0016 }
            r10.b(r0)     // Catch:{ Exception -> 0x0016 }
            xa.D r10 = xa.C4959D.f44058a     // Catch:{ Exception -> 0x0016 }
            if (r10 != r1) goto L_0x015f
            return r1
        L_0x0119:
            java.util.NoSuchElementException r10 = new java.util.NoSuchElementException     // Catch:{ Exception -> 0x0016 }
            java.lang.String r0 = "Collection contains no element matching the predicate."
            r10.<init>(r0)     // Catch:{ Exception -> 0x0016 }
            throw r10     // Catch:{ Exception -> 0x0016 }
        L_0x0121:
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0016 }
            r10.<init>(r0)     // Catch:{ Exception -> 0x0016 }
            r10.append(r3)     // Catch:{ Exception -> 0x0016 }
            java.lang.String r0 = " in deleteBookmark message. (ID: "
            r10.append(r0)     // Catch:{ Exception -> 0x0016 }
            r10.append(r6)     // Catch:{ Exception -> 0x0016 }
            r0 = 41
            r10.append(r0)     // Catch:{ Exception -> 0x0016 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x0016 }
            kotlin.jvm.internal.l.f(r10, r5)     // Catch:{ Exception -> 0x0016 }
            goto L_0x015f
        L_0x013e:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Error during deleteBookmark with ID="
            r0.<init>(r1)
            r0.append(r6)
            java.lang.String r1 = " and type="
            r0.append(r1)
            r0.append(r3)
            java.lang.String r1 = ". Error: "
            r0.append(r1)
            r0.append(r10)
            java.lang.String r10 = r0.toString()
            kotlin.jvm.internal.l.f(r10, r5)
        L_0x015f:
            xa.D r10 = xa.C4959D.f44058a
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: u9.d.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
