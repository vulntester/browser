package u9;

import Ca.a;
import Da.e;
import Da.i;
import M.k;
import Na.l;
import Na.p;
import io.ktor.http.ContentType;
import io.ktor.http.HttpStatusCode;
import io.ktor.server.response.ApplicationResponseFunctionsKt;
import io.ktor.server.routing.RoutingCall;
import io.ktor.server.routing.RoutingContext;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService$getServer$1$2$2$3$2", f = "HttpServerService.kt", l = {353}, m = "invokeSuspend")
public final class j extends i implements p<RoutingContext, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public int f43572f;

    /* renamed from: i  reason: collision with root package name */
    public /* synthetic */ Object f43573i;

    public j() {
        throw null;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [u9.j, Da.i, Ba.e<xa.D>] */
    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        ? iVar = new i(2, eVar);
        iVar.f43573i = obj;
        return iVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((j) create((RoutingContext) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.f33640f;
        int i10 = this.f43572f;
        if (i10 == 0) {
            C4976p.b(obj);
            RoutingContext routingContext = (RoutingContext) this.f43573i;
            String str = routingContext.getCall().getParameters().get("tab_id");
            RoutingCall call = routingContext.getCall();
            String m10 = k.m("update tab ", str);
            ContentType plain = ContentType.Text.INSTANCE.getPlain();
            this.f43572f = 1;
            if (ApplicationResponseFunctionsKt.respondText$default(call, m10, plain, (HttpStatusCode) null, (l) null, this, 12, (Object) null) == aVar) {
                return aVar;
            }
        } else if (i10 == 1) {
            C4976p.b(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return C4959D.f44058a;
    }
}
