package u9;

import B0.C0491s;
import Ca.a;
import Da.e;
import Da.i;
import Na.p;
import Q5.b;
import Q5.c;
import com.google.gson.f;
import com.google.gson.l;
import com.internet.tvbrowser.services.server.HttpServerService;
import io.ktor.http.ContentDisposition;
import io.ktor.http.ContentType;
import io.ktor.http.HttpStatusCode;
import io.ktor.http.LinkHeader;
import io.ktor.server.response.ApplicationResponseFunctionsKt;
import io.ktor.server.routing.RoutingCall;
import io.ktor.server.routing.RoutingContext;
import java.util.ArrayList;
import java.util.Iterator;
import xa.C4959D;
import xa.C4976p;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService$getServer$1$2$5$1", f = "HttpServerService.kt", l = {469}, m = "invokeSuspend")
public final class m extends i implements p<RoutingContext, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public int f43578f;

    /* renamed from: i  reason: collision with root package name */
    public /* synthetic */ Object f43579i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43580z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public m(HttpServerService httpServerService, Ba.e<? super m> eVar) {
        super(2, eVar);
        this.f43580z = httpServerService;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        m mVar = new m(this.f43580z, eVar);
        mVar.f43579i = obj;
        return mVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((m) create((RoutingContext) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.f33640f;
        int i10 = this.f43578f;
        if (i10 == 0) {
            C4976p.b(obj);
            RoutingContext routingContext = (RoutingContext) this.f43579i;
            l lVar = new l();
            f fVar = new f();
            ArrayList p10 = HttpServerService.d().f11385a.p();
            kotlin.jvm.internal.l.f("/bookmarks with " + p10.size() + " elements", "string");
            Iterator it = p10.iterator();
            while (it.hasNext()) {
                c cVar = (c) it.next();
                l lVar2 = new l();
                lVar2.m("id", new Integer(cVar.f7783a.f7777a));
                lVar2.n(LinkHeader.Parameters.Type, "folder");
                b bVar = cVar.f7783a;
                lVar2.n(ContentDisposition.Parameters.Name, bVar.f7778b);
                lVar2.l("is_favorites", Boolean.valueOf(C0491s.r(bVar)));
                lVar2.l("private", Boolean.valueOf(bVar.f7779c));
                fVar.i(lVar2);
            }
            lVar.i("bookmarks", fVar);
            RoutingCall call = routingContext.getCall();
            String iVar = lVar.toString();
            kotlin.jvm.internal.l.e(iVar, "toString(...)");
            ContentType json = ContentType.Application.INSTANCE.getJson();
            this.f43578f = 1;
            if (ApplicationResponseFunctionsKt.respondText$default(call, iVar, json, (HttpStatusCode) null, (Na.l) null, this, 12, (Object) null) == aVar) {
                return aVar;
            }
        } else if (i10 == 1) {
            C4976p.b(obj);
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return C4959D.f44058a;
    }
}
