package u9;

import Da.e;
import Da.i;
import Na.p;
import com.google.gson.l;
import com.internet.tvbrowser.services.server.HttpServerService;
import io.ktor.server.routing.RoutingContext;
import xa.C4959D;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService$getServer$1$2$5$2", f = "HttpServerService.kt", l = {496, 502}, m = "invokeSuspend")
public final class n extends i implements p<RoutingContext, Ba.e<? super C4959D>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43581E;

    /* renamed from: f  reason: collision with root package name */
    public l f43582f;

    /* renamed from: i  reason: collision with root package name */
    public int f43583i;

    /* renamed from: z  reason: collision with root package name */
    public /* synthetic */ Object f43584z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public n(HttpServerService httpServerService, Ba.e<? super n> eVar) {
        super(2, eVar);
        this.f43581E = httpServerService;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        n nVar = new n(this.f43581E, eVar);
        nVar.f43584z = obj;
        return nVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((n) create((RoutingContext) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v4, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v0, resolved type: io.ktor.server.routing.RoutingContext} */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x00e9, code lost:
        if (io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r0, r1, r2, (io.ktor.http.HttpStatusCode) null, (Na.l) null, r5, 12, (java.lang.Object) null) == r8) goto L_0x011d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x011b, code lost:
        if (io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r1, r0, r2, (io.ktor.http.HttpStatusCode) null, (Na.l) null, r5, 12, (java.lang.Object) null) != r8) goto L_0x011e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x011d, code lost:
        return r8;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r18) {
        /*
            r17 = this;
            r5 = r17
            java.lang.String r0 = "url"
            Ca.a r8 = Ca.a.f33640f
            int r1 = r5.f43583i
            java.lang.String r9 = "toString(...)"
            java.lang.String r10 = "bookmarks"
            r11 = 2
            r2 = 1
            if (r1 == 0) goto L_0x002c
            if (r1 == r2) goto L_0x0021
            if (r1 != r11) goto L_0x0019
            xa.C4976p.b(r18)
            goto L_0x011e
        L_0x0019:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L_0x0021:
            com.google.gson.l r0 = r5.f43582f
            java.lang.Object r1 = r5.f43584z
            io.ktor.server.routing.RoutingContext r1 = (io.ktor.server.routing.RoutingContext) r1
            xa.C4976p.b(r18)     // Catch:{ Exception -> 0x00ec }
            goto L_0x011e
        L_0x002c:
            xa.C4976p.b(r18)
            java.lang.Object r1 = r5.f43584z
            r12 = r1
            io.ktor.server.routing.RoutingContext r12 = (io.ktor.server.routing.RoutingContext) r12
            com.google.gson.l r13 = new com.google.gson.l
            r13.<init>()
            com.google.gson.f r1 = new com.google.gson.f
            r1.<init>()
            io.ktor.server.routing.RoutingCall r3 = r12.getCall()     // Catch:{ Exception -> 0x0088 }
            io.ktor.http.Parameters r3 = r3.getParameters()     // Catch:{ Exception -> 0x0088 }
            java.lang.String r3 = r3.get(r0)     // Catch:{ Exception -> 0x0088 }
            W5.a r4 = com.internet.tvbrowser.services.server.HttpServerService.d()     // Catch:{ Exception -> 0x0088 }
            P5.f r4 = r4.f11385a     // Catch:{ Exception -> 0x0088 }
            java.util.ArrayList r4 = r4.p()     // Catch:{ Exception -> 0x0088 }
            java.util.Iterator r4 = r4.iterator()     // Catch:{ Exception -> 0x0088 }
        L_0x0058:
            boolean r6 = r4.hasNext()     // Catch:{ Exception -> 0x0088 }
            if (r6 == 0) goto L_0x00c5
            java.lang.Object r6 = r4.next()     // Catch:{ Exception -> 0x0088 }
            Q5.c r6 = (Q5.c) r6     // Catch:{ Exception -> 0x0088 }
            java.util.ArrayList r6 = r6.f7784b     // Catch:{ Exception -> 0x0088 }
            java.util.ArrayList r7 = new java.util.ArrayList     // Catch:{ Exception -> 0x0088 }
            r7.<init>()     // Catch:{ Exception -> 0x0088 }
            java.util.Iterator r6 = r6.iterator()     // Catch:{ Exception -> 0x0088 }
        L_0x006f:
            boolean r14 = r6.hasNext()     // Catch:{ Exception -> 0x0088 }
            if (r14 == 0) goto L_0x008b
            java.lang.Object r14 = r6.next()     // Catch:{ Exception -> 0x0088 }
            r15 = r14
            Q5.a r15 = (Q5.a) r15     // Catch:{ Exception -> 0x0088 }
            java.lang.String r15 = r15.f7771d     // Catch:{ Exception -> 0x0088 }
            boolean r15 = kotlin.jvm.internal.l.a(r15, r3)     // Catch:{ Exception -> 0x0088 }
            if (r15 == 0) goto L_0x006f
            r7.add(r14)     // Catch:{ Exception -> 0x0088 }
            goto L_0x006f
        L_0x0088:
            r1 = r12
            r0 = r13
            goto L_0x00ec
        L_0x008b:
            java.util.Iterator r6 = r7.iterator()     // Catch:{ Exception -> 0x0088 }
        L_0x008f:
            boolean r7 = r6.hasNext()     // Catch:{ Exception -> 0x0088 }
            if (r7 == 0) goto L_0x0058
            java.lang.Object r7 = r6.next()     // Catch:{ Exception -> 0x0088 }
            Q5.a r7 = (Q5.a) r7     // Catch:{ Exception -> 0x0088 }
            com.google.gson.l r14 = new com.google.gson.l     // Catch:{ Exception -> 0x0088 }
            r14.<init>()     // Catch:{ Exception -> 0x0088 }
            java.lang.String r15 = "id"
            int r11 = r7.f7768a     // Catch:{ Exception -> 0x0088 }
            java.lang.Integer r2 = new java.lang.Integer     // Catch:{ Exception -> 0x0088 }
            r2.<init>(r11)     // Catch:{ Exception -> 0x0088 }
            r14.m(r15, r2)     // Catch:{ Exception -> 0x0088 }
            java.lang.String r2 = "type"
            java.lang.String r11 = "link"
            r14.n(r2, r11)     // Catch:{ Exception -> 0x0088 }
            java.lang.String r2 = "name"
            java.lang.String r11 = r7.f7770c     // Catch:{ Exception -> 0x0088 }
            r14.n(r2, r11)     // Catch:{ Exception -> 0x0088 }
            java.lang.String r2 = r7.f7771d     // Catch:{ Exception -> 0x0088 }
            r14.n(r0, r2)     // Catch:{ Exception -> 0x0088 }
            r1.i(r14)     // Catch:{ Exception -> 0x0088 }
            r2 = 1
            r11 = 2
            goto L_0x008f
        L_0x00c5:
            r13.i(r10, r1)     // Catch:{ Exception -> 0x0088 }
            io.ktor.server.routing.RoutingCall r0 = r12.getCall()     // Catch:{ Exception -> 0x0088 }
            java.lang.String r1 = r13.toString()     // Catch:{ Exception -> 0x0088 }
            kotlin.jvm.internal.l.e(r1, r9)     // Catch:{ Exception -> 0x0088 }
            io.ktor.http.ContentType$Application r2 = io.ktor.http.ContentType.Application.INSTANCE     // Catch:{ Exception -> 0x0088 }
            io.ktor.http.ContentType r2 = r2.getJson()     // Catch:{ Exception -> 0x0088 }
            r5.f43584z = r12     // Catch:{ Exception -> 0x0088 }
            r5.f43582f = r13     // Catch:{ Exception -> 0x0088 }
            r3 = 1
            r5.f43583i = r3     // Catch:{ Exception -> 0x0088 }
            r6 = 12
            r7 = 0
            r3 = 0
            r4 = 0
            java.lang.Object r0 = io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r0, r1, r2, r3, r4, r5, r6, r7)     // Catch:{ Exception -> 0x0088 }
            if (r0 != r8) goto L_0x011e
            goto L_0x011d
        L_0x00ec:
            com.google.gson.f r2 = new com.google.gson.f
            r2.<init>()
            r0.i(r10, r2)
            io.ktor.server.routing.RoutingCall r1 = r1.getCall()
            java.lang.String r0 = r0.toString()
            kotlin.jvm.internal.l.e(r0, r9)
            io.ktor.http.ContentType$Application r2 = io.ktor.http.ContentType.Application.INSTANCE
            io.ktor.http.ContentType r2 = r2.getJson()
            r3 = 0
            r5.f43584z = r3
            r5.f43582f = r3
            r3 = 2
            r5.f43583i = r3
            r6 = 12
            r7 = 0
            r3 = 0
            r4 = 0
            r16 = r1
            r1 = r0
            r0 = r16
            java.lang.Object r0 = io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r0, r1, r2, r3, r4, r5, r6, r7)
            if (r0 != r8) goto L_0x011e
        L_0x011d:
            return r8
        L_0x011e:
            xa.D r0 = xa.C4959D.f44058a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: u9.n.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
