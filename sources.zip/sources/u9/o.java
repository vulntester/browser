package u9;

import Da.e;
import Da.i;
import Na.p;
import com.google.gson.f;
import com.google.gson.l;
import com.internet.tvbrowser.services.server.HttpServerService;
import io.ktor.server.routing.RoutingContext;
import xa.C4959D;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService$getServer$1$2$5$3$1", f = "HttpServerService.kt", l = {518, 526, 545, 552}, m = "invokeSuspend")
public final class o extends i implements p<RoutingContext, Ba.e<? super C4959D>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public /* synthetic */ Object f43585E;

    /* renamed from: F  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43586F;

    /* renamed from: f  reason: collision with root package name */
    public l f43587f;

    /* renamed from: i  reason: collision with root package name */
    public f f43588i;

    /* renamed from: z  reason: collision with root package name */
    public int f43589z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public o(HttpServerService httpServerService, Ba.e<? super o> eVar) {
        super(2, eVar);
        this.f43586F = httpServerService;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        o oVar = new o(this.f43586F, eVar);
        oVar.f43585E = obj;
        return oVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((o) create((RoutingContext) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v7, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v1, resolved type: io.ktor.server.routing.RoutingContext} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: Q5.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v5, resolved type: Q5.c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v21, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v15, resolved type: io.ktor.server.routing.RoutingContext} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v22, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v17, resolved type: io.ktor.server.routing.RoutingContext} */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x01a8, code lost:
        if (io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r0, r1, r2, (io.ktor.http.HttpStatusCode) null, (Na.l) null, r5, 12, (java.lang.Object) null) != r8) goto L_0x01ab;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r17) {
        /*
            r16 = this;
            r5 = r16
            Ca.a r8 = Ca.a.f33640f
            int r0 = r5.f43589z
            java.lang.String r9 = "toString(...)"
            java.lang.String r10 = "bookmarks"
            r11 = 4
            r1 = 3
            r2 = 2
            r3 = 1
            r12 = 0
            if (r0 == 0) goto L_0x0056
            if (r0 == r3) goto L_0x0041
            if (r0 == r2) goto L_0x0035
            if (r0 == r1) goto L_0x0026
            if (r0 != r11) goto L_0x001e
            xa.C4976p.b(r17)
            goto L_0x01ab
        L_0x001e:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L_0x0026:
            com.google.gson.l r1 = r5.f43587f
            java.lang.Object r0 = r5.f43585E
            r2 = r0
            io.ktor.server.routing.RoutingContext r2 = (io.ktor.server.routing.RoutingContext) r2
            xa.C4976p.b(r17)     // Catch:{ Exception -> 0x0032 }
            goto L_0x01ab
        L_0x0032:
            r0 = move-exception
            goto L_0x0177
        L_0x0035:
            com.google.gson.l r1 = r5.f43587f
            java.lang.Object r0 = r5.f43585E
            r2 = r0
            io.ktor.server.routing.RoutingContext r2 = (io.ktor.server.routing.RoutingContext) r2
            xa.C4976p.b(r17)     // Catch:{ Exception -> 0x0032 }
            goto L_0x00f4
        L_0x0041:
            com.google.gson.f r0 = r5.f43588i
            com.google.gson.l r3 = r5.f43587f
            java.lang.Object r4 = r5.f43585E
            io.ktor.server.routing.RoutingContext r4 = (io.ktor.server.routing.RoutingContext) r4
            xa.C4976p.b(r17)     // Catch:{ Exception -> 0x0051 }
            r13 = r3
            r3 = r17
        L_0x004f:
            r14 = r4
            goto L_0x0094
        L_0x0051:
            r0 = move-exception
            r1 = r3
            r2 = r4
            goto L_0x0177
        L_0x0056:
            xa.C4976p.b(r17)
            java.lang.Object r0 = r5.f43585E
            r4 = r0
            io.ktor.server.routing.RoutingContext r4 = (io.ktor.server.routing.RoutingContext) r4
            com.google.gson.l r6 = new com.google.gson.l
            r6.<init>()
            com.google.gson.f r0 = new com.google.gson.f
            r0.<init>()
            io.ktor.server.routing.RoutingCall r7 = r4.getCall()     // Catch:{ Exception -> 0x016d }
            io.ktor.http.Parameters r7 = r7.getParameters()     // Catch:{ Exception -> 0x016d }
            java.lang.String r13 = "folder_id"
            java.lang.String r7 = r7.get(r13)     // Catch:{ Exception -> 0x016d }
            if (r7 == 0) goto L_0x016f
            int r7 = java.lang.Integer.parseInt(r7)     // Catch:{ Exception -> 0x016d }
            W5.a r13 = com.internet.tvbrowser.services.server.HttpServerService.d()     // Catch:{ Exception -> 0x016d }
            r5.f43585E = r4     // Catch:{ Exception -> 0x016d }
            r5.f43587f = r6     // Catch:{ Exception -> 0x016d }
            r5.f43588i = r0     // Catch:{ Exception -> 0x016d }
            r5.f43589z = r3     // Catch:{ Exception -> 0x016d }
            P5.f r3 = r13.f11385a     // Catch:{ Exception -> 0x016d }
            Q5.c r3 = r3.d(r7)     // Catch:{ Exception -> 0x016d }
            if (r3 != r8) goto L_0x0092
            goto L_0x01aa
        L_0x0092:
            r13 = r6
            goto L_0x004f
        L_0x0094:
            Q5.c r3 = (Q5.c) r3     // Catch:{ Exception -> 0x00f7 }
            if (r3 == 0) goto L_0x0162
            Q5.b r4 = r3.f7783a     // Catch:{ Exception -> 0x00f7 }
            boolean r4 = r4.f7779c     // Catch:{ Exception -> 0x00f7 }
            if (r4 == 0) goto L_0x00fc
            io.ktor.server.routing.RoutingCall r4 = r14.getCall()     // Catch:{ Exception -> 0x00f7 }
            io.ktor.http.Parameters r4 = r4.getParameters()     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r6 = "pin"
            java.lang.String r4 = r4.get(r6)     // Catch:{ Exception -> 0x00f7 }
            int r6 = com.internet.tvbrowser.services.server.HttpServerService.f40243O     // Catch:{ Exception -> 0x00f7 }
            com.browser.App r6 = com.browser.App.f16811f     // Catch:{ Exception -> 0x00f7 }
            Y4.a r6 = com.browser.App.a.a()     // Catch:{ Exception -> 0x00f7 }
            Y4.l r6 = (Y4.l) r6     // Catch:{ Exception -> 0x00f7 }
            N5.f r6 = r6.b()     // Catch:{ Exception -> 0x00f7 }
            N5.m r6 = r6.f6418b     // Catch:{ Exception -> 0x00f7 }
            Z5.q r6 = r6.f6462d     // Catch:{ Exception -> 0x00f7 }
            V.r0 r6 = r6.f12377d     // Catch:{ Exception -> 0x00f7 }
            java.lang.Object r6 = r6.getValue()     // Catch:{ Exception -> 0x00f7 }
            boolean r4 = kotlin.jvm.internal.l.a(r4, r6)     // Catch:{ Exception -> 0x00f7 }
            if (r4 != 0) goto L_0x00fc
            io.ktor.server.routing.RoutingCall r0 = r14.getCall()     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r1 = "Forbidden"
            io.ktor.http.ContentType$Text r3 = io.ktor.http.ContentType.Text.INSTANCE     // Catch:{ Exception -> 0x00f7 }
            io.ktor.http.ContentType r3 = r3.getPlain()     // Catch:{ Exception -> 0x00f7 }
            io.ktor.http.HttpStatusCode$Companion r4 = io.ktor.http.HttpStatusCode.Companion     // Catch:{ Exception -> 0x00f7 }
            io.ktor.http.HttpStatusCode r4 = r4.getForbidden()     // Catch:{ Exception -> 0x00f7 }
            r5.f43585E = r14     // Catch:{ Exception -> 0x00f7 }
            r5.f43587f = r13     // Catch:{ Exception -> 0x00f7 }
            r5.f43588i = r12     // Catch:{ Exception -> 0x00f7 }
            r5.f43589z = r2     // Catch:{ Exception -> 0x00f7 }
            r6 = 8
            r7 = 0
            r2 = r3
            r3 = r4
            r4 = 0
            java.lang.Object r0 = io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r0, r1, r2, r3, r4, r5, r6, r7)     // Catch:{ Exception -> 0x00f7 }
            if (r0 != r8) goto L_0x00f2
            goto L_0x01aa
        L_0x00f2:
            r1 = r13
            r2 = r14
        L_0x00f4:
            xa.D r0 = xa.C4959D.f44058a     // Catch:{ Exception -> 0x0032 }
            return r0
        L_0x00f7:
            r0 = move-exception
            r1 = r13
            r2 = r14
            goto L_0x0177
        L_0x00fc:
            java.util.ArrayList r2 = r3.f7784b     // Catch:{ Exception -> 0x00f7 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x00f7 }
        L_0x0102:
            boolean r3 = r2.hasNext()     // Catch:{ Exception -> 0x00f7 }
            if (r3 == 0) goto L_0x0138
            java.lang.Object r3 = r2.next()     // Catch:{ Exception -> 0x00f7 }
            Q5.a r3 = (Q5.a) r3     // Catch:{ Exception -> 0x00f7 }
            com.google.gson.l r4 = new com.google.gson.l     // Catch:{ Exception -> 0x00f7 }
            r4.<init>()     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r6 = "id"
            int r7 = r3.f7768a     // Catch:{ Exception -> 0x00f7 }
            java.lang.Integer r15 = new java.lang.Integer     // Catch:{ Exception -> 0x00f7 }
            r15.<init>(r7)     // Catch:{ Exception -> 0x00f7 }
            r4.m(r6, r15)     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r6 = "type"
            java.lang.String r7 = "link"
            r4.n(r6, r7)     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r6 = "name"
            java.lang.String r7 = r3.f7770c     // Catch:{ Exception -> 0x00f7 }
            r4.n(r6, r7)     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r6 = "url"
            java.lang.String r3 = r3.f7771d     // Catch:{ Exception -> 0x00f7 }
            r4.n(r6, r3)     // Catch:{ Exception -> 0x00f7 }
            r0.i(r4)     // Catch:{ Exception -> 0x00f7 }
            goto L_0x0102
        L_0x0138:
            r13.i(r10, r0)     // Catch:{ Exception -> 0x00f7 }
            io.ktor.server.routing.RoutingCall r0 = r14.getCall()     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r2 = r13.toString()     // Catch:{ Exception -> 0x00f7 }
            kotlin.jvm.internal.l.e(r2, r9)     // Catch:{ Exception -> 0x00f7 }
            io.ktor.http.ContentType$Application r3 = io.ktor.http.ContentType.Application.INSTANCE     // Catch:{ Exception -> 0x00f7 }
            io.ktor.http.ContentType r3 = r3.getJson()     // Catch:{ Exception -> 0x00f7 }
            r5.f43585E = r14     // Catch:{ Exception -> 0x00f7 }
            r5.f43587f = r13     // Catch:{ Exception -> 0x00f7 }
            r5.f43588i = r12     // Catch:{ Exception -> 0x00f7 }
            r5.f43589z = r1     // Catch:{ Exception -> 0x00f7 }
            r6 = 12
            r7 = 0
            r1 = r2
            r2 = r3
            r3 = 0
            r4 = 0
            java.lang.Object r0 = io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r0, r1, r2, r3, r4, r5, r6, r7)     // Catch:{ Exception -> 0x00f7 }
            if (r0 != r8) goto L_0x01ab
            goto L_0x01aa
        L_0x0162:
            java.lang.Exception r0 = new java.lang.Exception     // Catch:{ Exception -> 0x00f7 }
            java.lang.String r1 = "folder not found"
            r0.<init>(r1)     // Catch:{ Exception -> 0x00f7 }
            throw r0     // Catch:{ Exception -> 0x00f7 }
        L_0x016a:
            r2 = r4
            r1 = r6
            goto L_0x0177
        L_0x016d:
            r0 = move-exception
            goto L_0x016a
        L_0x016f:
            java.lang.Exception r0 = new java.lang.Exception     // Catch:{ Exception -> 0x016d }
            java.lang.String r1 = "folder_id is null"
            r0.<init>(r1)     // Catch:{ Exception -> 0x016d }
            throw r0     // Catch:{ Exception -> 0x016d }
        L_0x0177:
            i8.b r3 = i8.C4466b.a()
            r3.c(r0)
            com.google.gson.f r0 = new com.google.gson.f
            r0.<init>()
            r1.i(r10, r0)
            io.ktor.server.routing.RoutingCall r0 = r2.getCall()
            java.lang.String r1 = r1.toString()
            kotlin.jvm.internal.l.e(r1, r9)
            io.ktor.http.ContentType$Application r2 = io.ktor.http.ContentType.Application.INSTANCE
            io.ktor.http.ContentType r2 = r2.getJson()
            r5.f43585E = r12
            r5.f43587f = r12
            r5.f43588i = r12
            r5.f43589z = r11
            r6 = 12
            r7 = 0
            r3 = 0
            r4 = 0
            java.lang.Object r0 = io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r0, r1, r2, r3, r4, r5, r6, r7)
            if (r0 != r8) goto L_0x01ab
        L_0x01aa:
            return r8
        L_0x01ab:
            xa.D r0 = xa.C4959D.f44058a
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: u9.o.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
