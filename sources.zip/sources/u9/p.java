package u9;

import Da.e;
import Da.i;
import com.google.gson.l;
import com.internet.tvbrowser.services.server.HttpServerService;
import io.ktor.server.routing.RoutingContext;
import xa.C4959D;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService$getServer$1$2$6$1", f = "HttpServerService.kt", l = {566, 576}, m = "invokeSuspend")
public final class p extends i implements Na.p<RoutingContext, Ba.e<? super C4959D>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public int f43590E;

    /* renamed from: F  reason: collision with root package name */
    public /* synthetic */ Object f43591F;

    /* renamed from: G  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43592G;

    /* renamed from: f  reason: collision with root package name */
    public l f43593f;

    /* renamed from: i  reason: collision with root package name */
    public l f43594i;

    /* renamed from: z  reason: collision with root package name */
    public String f43595z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public p(HttpServerService httpServerService, Ba.e<? super p> eVar) {
        super(2, eVar);
        this.f43592G = httpServerService;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        p pVar = new p(this.f43592G, eVar);
        pVar.f43591F = obj;
        return pVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((p) create((RoutingContext) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r15v19, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v1, resolved type: io.ktor.server.routing.RoutingContext} */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x00c4, code lost:
        if (io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r6, r7, r8, (io.ktor.http.HttpStatusCode) null, (Na.l) null, r14, 12, (java.lang.Object) null) == r1) goto L_0x00c6;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r15) {
        /*
            r14 = this;
            r0 = 2
            Ca.a r1 = Ca.a.f33640f
            int r2 = r14.f43590E
            com.internet.tvbrowser.services.server.HttpServerService r3 = r14.f43592G
            r4 = 1
            if (r2 == 0) goto L_0x0029
            if (r2 == r4) goto L_0x001b
            if (r2 != r0) goto L_0x0013
            xa.C4976p.b(r15)
            goto L_0x00c7
        L_0x0013:
            java.lang.IllegalStateException r15 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r15.<init>(r0)
            throw r15
        L_0x001b:
            java.lang.String r2 = r14.f43595z
            com.google.gson.l r3 = r14.f43594i
            com.google.gson.l r4 = r14.f43593f
            java.lang.Object r5 = r14.f43591F
            io.ktor.server.routing.RoutingContext r5 = (io.ktor.server.routing.RoutingContext) r5
            xa.C4976p.b(r15)
            goto L_0x006f
        L_0x0029:
            xa.C4976p.b(r15)
            java.lang.Object r15 = r14.f43591F
            r5 = r15
            io.ktor.server.routing.RoutingContext r5 = (io.ktor.server.routing.RoutingContext) r5
            com.google.gson.l r15 = new com.google.gson.l
            r15.<init>()
            com.browser.App r2 = com.browser.App.f16811f
            Y4.a r2 = com.browser.App.a.a()
            Y4.l r2 = (Y4.l) r2
            r14.f43591F = r5
            r14.f43593f = r15
            r14.f43594i = r15
            java.lang.String r6 = "incognito"
            r14.f43595z = r6
            r14.f43590E = r4
            v9.b r2 = r2.f11926d
            r2.getClass()
            Ba.j r4 = new Ba.j
            Ba.e r7 = A.o.L(r14)
            r4.<init>(r7)
            java.util.concurrent.Executor r3 = u1.C3195a.c(r3)
            V4.q r7 = new V4.q
            r7.<init>(r0, r4, r2)
            r3.execute(r7)
            java.lang.Object r2 = r4.a()
            if (r2 != r1) goto L_0x006b
            goto L_0x00c6
        L_0x006b:
            r3 = r15
            r4 = r3
            r15 = r2
            r2 = r6
        L_0x006f:
            java.lang.Boolean r15 = (java.lang.Boolean) r15
            r3.l(r2, r15)
            int r15 = com.internet.tvbrowser.services.server.HttpServerService.f40243O
            com.browser.App r15 = com.browser.App.f16811f
            Y4.a r15 = com.browser.App.a.a()
            Y4.l r15 = (Y4.l) r15
            N5.f r15 = r15.b()
            N5.h r15 = r15.f6420d
            V.r0 r15 = r15.f6429e
            java.lang.Object r15 = r15.getValue()
            L5.e r15 = (L5.e) r15
            java.lang.String r15 = r15.b()
            java.lang.String r2 = "viewPortMode"
            r4.n(r2, r15)
            java.lang.String r15 = "version"
            java.lang.String r2 = "2.6.3"
            r4.n(r15, r2)
            io.ktor.server.routing.RoutingCall r6 = r5.getCall()
            java.lang.String r7 = r4.toString()
            java.lang.String r15 = "toString(...)"
            kotlin.jvm.internal.l.e(r7, r15)
            io.ktor.http.ContentType$Application r15 = io.ktor.http.ContentType.Application.INSTANCE
            io.ktor.http.ContentType r8 = r15.getJson()
            r15 = 0
            r14.f43591F = r15
            r14.f43593f = r15
            r14.f43594i = r15
            r14.f43595z = r15
            r14.f43590E = r0
            r12 = 12
            r13 = 0
            r9 = 0
            r10 = 0
            r11 = r14
            java.lang.Object r15 = io.ktor.server.response.ApplicationResponseFunctionsKt.respondText$default(r6, r7, r8, r9, r10, r11, r12, r13)
            if (r15 != r1) goto L_0x00c7
        L_0x00c6:
            return r1
        L_0x00c7:
            xa.D r15 = xa.C4959D.f44058a
            return r15
        */
        throw new UnsupportedOperationException("Method not decompiled: u9.p.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
