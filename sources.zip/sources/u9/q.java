package u9;

import Da.e;
import Da.i;
import Na.p;
import com.internet.tvbrowser.services.server.HttpServerService;
import io.ktor.server.websocket.DefaultWebSocketServerSession;
import xa.C4959D;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService$getServer$1$2$7", f = "HttpServerService.kt", l = {584, 587}, m = "invokeSuspend")
public final class q extends i implements p<DefaultWebSocketServerSession, Ba.e<? super C4959D>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public int f43596f;

    /* renamed from: i  reason: collision with root package name */
    public /* synthetic */ Object f43597i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43598z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public q(HttpServerService httpServerService, Ba.e<? super q> eVar) {
        super(2, eVar);
        this.f43598z = httpServerService;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        q qVar = new q(this.f43598z, eVar);
        qVar.f43597i = obj;
        return qVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((q) create((DefaultWebSocketServerSession) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0043, code lost:
        if (com.internet.tvbrowser.services.server.HttpServerService.b(r4, r1, r5) == r0) goto L_0x004e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004c, code lost:
        if (com.internet.tvbrowser.services.server.HttpServerService.a(r4, r6, r5) == r0) goto L_0x004e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object invokeSuspend(java.lang.Object r6) {
        /*
            r5 = this;
            Ca.a r0 = Ca.a.f33640f
            int r1 = r5.f43596f
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L_0x0019
            if (r1 == r3) goto L_0x0015
            if (r1 != r2) goto L_0x000d
            goto L_0x0015
        L_0x000d:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L_0x0015:
            xa.C4976p.b(r6)
            goto L_0x004f
        L_0x0019:
            xa.C4976p.b(r6)
            java.lang.Object r6 = r5.f43597i
            io.ktor.server.websocket.DefaultWebSocketServerSession r6 = (io.ktor.server.websocket.DefaultWebSocketServerSession) r6
            io.ktor.server.application.ApplicationCall r1 = r6.getCall()
            io.ktor.server.request.ApplicationRequest r1 = r1.getRequest()
            java.lang.String r4 = "X-Protocol"
            java.lang.String r1 = io.ktor.server.request.ApplicationRequestPropertiesKt.header(r1, r4)
            java.lang.String r4 = "zeus"
            boolean r1 = kotlin.jvm.internal.l.a(r1, r4)
            com.internet.tvbrowser.services.server.HttpServerService r4 = r5.f43598z
            if (r1 == 0) goto L_0x0046
            Z4.d r1 = new Z4.d
            r1.<init>(r6)
            r5.f43596f = r3
            java.lang.Object r6 = com.internet.tvbrowser.services.server.HttpServerService.b(r4, r1, r5)
            if (r6 != r0) goto L_0x004f
            goto L_0x004e
        L_0x0046:
            r5.f43596f = r2
            java.lang.Object r6 = com.internet.tvbrowser.services.server.HttpServerService.a(r4, r6, r5)
            if (r6 != r0) goto L_0x004f
        L_0x004e:
            return r0
        L_0x004f:
            xa.D r6 = xa.C4959D.f44058a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: u9.q.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
