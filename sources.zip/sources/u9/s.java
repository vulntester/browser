package u9;

import Da.c;
import Da.e;
import com.google.gson.l;
import com.internet.tvbrowser.services.server.HttpServerService;
import io.ktor.websocket.DefaultWebSocketSession;
import kc.k;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService", f = "HttpServerService.kt", l = {647, 660, 671, 696}, m = "handleLegacyRemoteWebSocket")
public final class s extends c {

    /* renamed from: E  reason: collision with root package name */
    public k f43601E;

    /* renamed from: F  reason: collision with root package name */
    public l f43602F;

    /* renamed from: G  reason: collision with root package name */
    public /* synthetic */ Object f43603G;

    /* renamed from: H  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43604H;

    /* renamed from: I  reason: collision with root package name */
    public int f43605I;

    /* renamed from: f  reason: collision with root package name */
    public DefaultWebSocketSession f43606f;

    /* renamed from: i  reason: collision with root package name */
    public b f43607i;

    /* renamed from: z  reason: collision with root package name */
    public l f43608z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public s(HttpServerService httpServerService, c cVar) {
        super(cVar);
        this.f43604H = httpServerService;
    }

    public final Object invokeSuspend(Object obj) {
        this.f43603G = obj;
        this.f43605I |= Integer.MIN_VALUE;
        return HttpServerService.a(this.f43604H, (DefaultWebSocketSession) null, this);
    }
}
