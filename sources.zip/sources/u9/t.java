package u9;

import Da.c;
import Da.e;
import Z4.d;
import com.internet.tvbrowser.services.server.HttpServerService;

@e(c = "com.internet.tvbrowser.services.server.HttpServerService", f = "HttpServerService.kt", l = {605, 609, 612, 620}, m = "handleZeusRemoteWebSocket")
public final class t extends c {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ HttpServerService f43609E;

    /* renamed from: F  reason: collision with root package name */
    public int f43610F;

    /* renamed from: f  reason: collision with root package name */
    public d f43611f;

    /* renamed from: i  reason: collision with root package name */
    public Object f43612i;

    /* renamed from: z  reason: collision with root package name */
    public /* synthetic */ Object f43613z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public t(HttpServerService httpServerService, c cVar) {
        super(cVar);
        this.f43609E = httpServerService;
    }

    public final Object invokeSuspend(Object obj) {
        this.f43613z = obj;
        this.f43610F |= Integer.MIN_VALUE;
        return HttpServerService.b(this.f43609E, (d) null, this);
    }
}
