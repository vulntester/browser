package v0;

import e1.m;
import p0.C2862b;
import p0.C2865e;
import r0.C3018a;
import r0.d;

/* renamed from: v0.a  reason: case insensitive filesystem */
public final class C3303a {

    /* renamed from: a  reason: collision with root package name */
    public C2865e f28895a;

    /* renamed from: b  reason: collision with root package name */
    public C2862b f28896b;

    /* renamed from: c  reason: collision with root package name */
    public d f28897c;

    /* renamed from: d  reason: collision with root package name */
    public long f28898d = 0;

    /* renamed from: e  reason: collision with root package name */
    public int f28899e = 0;

    /* renamed from: f  reason: collision with root package name */
    public final C3018a f28900f = new C3018a();

    public C3303a() {
        m mVar = m.f20656f;
    }
}
