package v0;

import B9.C3805t;
import Na.l;
import S6.b;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.n;
import p0.C2847F;
import p0.C2859S;
import p0.C2869i;
import p0.C2871k;
import p0.C2874n;
import p0.C2879s;
import r0.C3018a;
import r0.d;
import xa.C4959D;
import ya.u;

/* renamed from: v0.c  reason: case insensitive filesystem */
public final class C3305c extends C3311i {

    /* renamed from: b  reason: collision with root package name */
    public float[] f28903b;

    /* renamed from: c  reason: collision with root package name */
    public final ArrayList f28904c = new ArrayList();

    /* renamed from: d  reason: collision with root package name */
    public boolean f28905d = true;

    /* renamed from: e  reason: collision with root package name */
    public long f28906e = C2879s.f26407k;

    /* renamed from: f  reason: collision with root package name */
    public List<? extends C3309g> f28907f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f28908g;

    /* renamed from: h  reason: collision with root package name */
    public C2869i f28909h;

    /* renamed from: i  reason: collision with root package name */
    public n f28910i;

    /* renamed from: j  reason: collision with root package name */
    public final a f28911j;

    /* renamed from: k  reason: collision with root package name */
    public String f28912k;

    /* renamed from: l  reason: collision with root package name */
    public float f28913l;

    /* renamed from: m  reason: collision with root package name */
    public float f28914m;

    /* renamed from: n  reason: collision with root package name */
    public float f28915n;

    /* renamed from: o  reason: collision with root package name */
    public float f28916o;

    /* renamed from: p  reason: collision with root package name */
    public float f28917p;

    /* renamed from: q  reason: collision with root package name */
    public float f28918q;

    /* renamed from: r  reason: collision with root package name */
    public float f28919r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f28920s;

    /* renamed from: v0.c$a */
    public static final class a extends n implements l<C3311i, C4959D> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3305c f28921f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(C3305c cVar) {
            super(1);
            this.f28921f = cVar;
        }

        /* JADX WARNING: type inference failed for: r0v1, types: [Na.l, kotlin.jvm.internal.n] */
        public final Object invoke(Object obj) {
            C3311i iVar = (C3311i) obj;
            C3305c cVar = this.f28921f;
            cVar.g(iVar);
            ? r02 = cVar.f28910i;
            if (r02 != 0) {
                r02.invoke(iVar);
            }
            return C4959D.f44058a;
        }
    }

    public C3305c() {
        int i10 = C3314l.f29064a;
        this.f28907f = u.f44685f;
        this.f28908g = true;
        this.f28911j = new a(this);
        this.f28912k = "";
        this.f28916o = 1.0f;
        this.f28917p = 1.0f;
        this.f28920s = true;
    }

    public final void a(d dVar) {
        if (this.f28920s) {
            float[] fArr = this.f28903b;
            if (fArr == null) {
                fArr = C2847F.a();
                this.f28903b = fArr;
            } else {
                C2847F.d(fArr);
            }
            C2847F.f(fArr, this.f28918q + this.f28914m, this.f28919r + this.f28915n);
            float f10 = this.f28913l;
            if (fArr.length >= 16) {
                double d10 = ((double) f10) * 0.017453292519943295d;
                float sin = (float) Math.sin(d10);
                float cos = (float) Math.cos(d10);
                float f11 = fArr[0];
                float f12 = fArr[4];
                float f13 = (sin * f12) + (cos * f11);
                float f14 = -sin;
                float f15 = (f12 * cos) + (f11 * f14);
                float f16 = fArr[1];
                float f17 = fArr[5];
                float f18 = (sin * f17) + (cos * f16);
                float f19 = (f17 * cos) + (f16 * f14);
                float f20 = fArr[2];
                float f21 = fArr[6];
                float f22 = (sin * f21) + (cos * f20);
                float f23 = (f21 * cos) + (f20 * f14);
                float f24 = fArr[3];
                float f25 = fArr[7];
                fArr[0] = f13;
                fArr[1] = f18;
                fArr[2] = f22;
                fArr[3] = (sin * f25) + (cos * f24);
                fArr[4] = f15;
                fArr[5] = f19;
                fArr[6] = f23;
                fArr[7] = (cos * f25) + (f14 * f24);
            }
            float f26 = this.f28916o;
            float f27 = this.f28917p;
            if (fArr.length >= 16) {
                fArr[0] = fArr[0] * f26;
                fArr[1] = fArr[1] * f26;
                fArr[2] = fArr[2] * f26;
                fArr[3] = fArr[3] * f26;
                fArr[4] = fArr[4] * f27;
                fArr[5] = fArr[5] * f27;
                fArr[6] = fArr[6] * f27;
                fArr[7] = fArr[7] * f27;
                fArr[8] = fArr[8] * 1.0f;
                fArr[9] = fArr[9] * 1.0f;
                fArr[10] = fArr[10] * 1.0f;
                fArr[11] = fArr[11] * 1.0f;
            }
            C2847F.f(fArr, -this.f28914m, -this.f28915n);
            this.f28920s = false;
        }
        if (this.f28908g) {
            if (!this.f28907f.isEmpty()) {
                C2869i iVar = this.f28909h;
                if (iVar == null) {
                    iVar = C2871k.a();
                    this.f28909h = iVar;
                }
                C3310h.b(this.f28907f, iVar);
            }
            this.f28908g = false;
        }
        C3018a.b I02 = dVar.I0();
        long d11 = I02.d();
        I02.a().f();
        try {
            b bVar = I02.f27309a;
            float[] fArr2 = this.f28903b;
            if (fArr2 != null) {
                ((C3018a.b) bVar.f9685f).a().i(fArr2);
            }
            C2869i iVar2 = this.f28909h;
            if (!this.f28907f.isEmpty() && iVar2 != null) {
                bVar.c(iVar2);
            }
            ArrayList arrayList = this.f28904c;
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                ((C3311i) arrayList.get(i10)).a(dVar);
            }
        } finally {
            C3805t.j(I02, d11);
        }
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [Na.l<v0.i, xa.D>, kotlin.jvm.internal.n] */
    public final l<C3311i, C4959D> b() {
        return this.f28910i;
    }

    public final void d(a aVar) {
        this.f28910i = aVar;
    }

    public final void e(int i10, C3311i iVar) {
        ArrayList arrayList = this.f28904c;
        if (i10 < arrayList.size()) {
            arrayList.set(i10, iVar);
        } else {
            arrayList.add(iVar);
        }
        g(iVar);
        iVar.d(this.f28911j);
        c();
    }

    public final void f(long j10) {
        if (this.f28905d && j10 != 16) {
            long j11 = this.f28906e;
            if (j11 == 16) {
                this.f28906e = j10;
                return;
            }
            int i10 = C3314l.f29064a;
            if (C2879s.h(j11) != C2879s.h(j10) || C2879s.g(j11) != C2879s.g(j10) || C2879s.e(j11) != C2879s.e(j10)) {
                this.f28905d = false;
                this.f28906e = C2879s.f26407k;
            }
        }
    }

    public final void g(C3311i iVar) {
        if (iVar instanceof C3308f) {
            C3308f fVar = (C3308f) iVar;
            C2874n nVar = fVar.f28956b;
            if (this.f28905d && nVar != null) {
                if (nVar instanceof C2859S) {
                    f(((C2859S) nVar).f26365a);
                } else {
                    this.f28905d = false;
                    this.f28906e = C2879s.f26407k;
                }
            }
            C2874n nVar2 = fVar.f28961g;
            if (!this.f28905d || nVar2 == null) {
                return;
            }
            if (nVar2 instanceof C2859S) {
                f(((C2859S) nVar2).f26365a);
                return;
            }
            this.f28905d = false;
            this.f28906e = C2879s.f26407k;
        } else if (iVar instanceof C3305c) {
            C3305c cVar = (C3305c) iVar;
            if (!cVar.f28905d || !this.f28905d) {
                this.f28905d = false;
                this.f28906e = C2879s.f26407k;
                return;
            }
            f(cVar.f28906e);
        }
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("VGroup: ");
        sb2.append(this.f28912k);
        ArrayList arrayList = this.f28904c;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            sb2.append("\t");
            sb2.append(((C3311i) arrayList.get(i10)).toString());
            sb2.append("\n");
        }
        return sb2.toString();
    }
}
