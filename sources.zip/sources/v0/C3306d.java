package v0;

import B0.C0493u;
import D1.c;
import e1.f;
import io.netty.handler.codec.http.HttpObjectDecoder;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;
import p0.C2859S;
import p0.C2874n;
import p0.C2879s;
import ya.u;

/* renamed from: v0.d  reason: case insensitive filesystem */
public final class C3306d {

    /* renamed from: k  reason: collision with root package name */
    public static int f28922k;

    /* renamed from: l  reason: collision with root package name */
    public static final b f28923l = new Object();

    /* renamed from: a  reason: collision with root package name */
    public final String f28924a;

    /* renamed from: b  reason: collision with root package name */
    public final float f28925b;

    /* renamed from: c  reason: collision with root package name */
    public final float f28926c;

    /* renamed from: d  reason: collision with root package name */
    public final float f28927d;

    /* renamed from: e  reason: collision with root package name */
    public final float f28928e;

    /* renamed from: f  reason: collision with root package name */
    public final C3313k f28929f;

    /* renamed from: g  reason: collision with root package name */
    public final long f28930g;

    /* renamed from: h  reason: collision with root package name */
    public final int f28931h;

    /* renamed from: i  reason: collision with root package name */
    public final boolean f28932i;

    /* renamed from: j  reason: collision with root package name */
    public final int f28933j;

    /* renamed from: v0.d$a */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final String f28934a;

        /* renamed from: b  reason: collision with root package name */
        public final float f28935b;

        /* renamed from: c  reason: collision with root package name */
        public final float f28936c;

        /* renamed from: d  reason: collision with root package name */
        public final float f28937d;

        /* renamed from: e  reason: collision with root package name */
        public final float f28938e;

        /* renamed from: f  reason: collision with root package name */
        public final long f28939f;

        /* renamed from: g  reason: collision with root package name */
        public final int f28940g;

        /* renamed from: h  reason: collision with root package name */
        public final boolean f28941h;

        /* renamed from: i  reason: collision with root package name */
        public final ArrayList<C0278a> f28942i;

        /* renamed from: j  reason: collision with root package name */
        public final C0278a f28943j;

        /* renamed from: k  reason: collision with root package name */
        public boolean f28944k;

        /* renamed from: v0.d$a$a  reason: collision with other inner class name */
        public static final class C0278a {

            /* renamed from: a  reason: collision with root package name */
            public final String f28945a;

            /* renamed from: b  reason: collision with root package name */
            public final float f28946b;

            /* renamed from: c  reason: collision with root package name */
            public final float f28947c;

            /* renamed from: d  reason: collision with root package name */
            public final float f28948d;

            /* renamed from: e  reason: collision with root package name */
            public final float f28949e;

            /* renamed from: f  reason: collision with root package name */
            public final float f28950f;

            /* renamed from: g  reason: collision with root package name */
            public final float f28951g;

            /* renamed from: h  reason: collision with root package name */
            public final float f28952h;

            /* renamed from: i  reason: collision with root package name */
            public final List<? extends C3309g> f28953i;

            /* renamed from: j  reason: collision with root package name */
            public final ArrayList f28954j;

            public C0278a() {
                this((String) null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, (List) null, 1023);
            }

            public C0278a(String str, float f10, float f11, float f12, float f13, float f14, float f15, float f16, List<? extends C3309g> list, int i10) {
                str = (i10 & 1) != 0 ? "" : str;
                f10 = (i10 & 2) != 0 ? 0.0f : f10;
                f11 = (i10 & 4) != 0 ? 0.0f : f11;
                f12 = (i10 & 8) != 0 ? 0.0f : f12;
                f13 = (i10 & 16) != 0 ? 1.0f : f13;
                f14 = (i10 & 32) != 0 ? 1.0f : f14;
                f15 = (i10 & 64) != 0 ? 0.0f : f15;
                f16 = (i10 & HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE) != 0 ? 0.0f : f16;
                if ((i10 & 256) != 0) {
                    int i11 = C3314l.f29064a;
                    list = u.f44685f;
                }
                ArrayList arrayList = new ArrayList();
                this.f28945a = str;
                this.f28946b = f10;
                this.f28947c = f11;
                this.f28948d = f12;
                this.f28949e = f13;
                this.f28950f = f14;
                this.f28951g = f15;
                this.f28952h = f16;
                this.f28953i = list;
                this.f28954j = arrayList;
            }
        }

        public a(String str, float f10, float f11, float f12, float f13, long j10, int i10, boolean z10, int i11) {
            long j11;
            int i12;
            str = (i11 & 1) != 0 ? "" : str;
            if ((i11 & 32) != 0) {
                j11 = C2879s.f26407k;
            } else {
                j11 = j10;
            }
            if ((i11 & 64) != 0) {
                i12 = 5;
            } else {
                i12 = i10;
            }
            this.f28934a = str;
            this.f28935b = f10;
            this.f28936c = f11;
            this.f28937d = f12;
            this.f28938e = f13;
            this.f28939f = j11;
            this.f28940g = i12;
            this.f28941h = z10;
            ArrayList<C0278a> arrayList = new ArrayList<>();
            this.f28942i = arrayList;
            C0278a aVar = new C0278a((String) null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, (List) null, 1023);
            this.f28943j = aVar;
            arrayList.add(aVar);
        }

        public static void a(a aVar, ArrayList arrayList, C2859S s10) {
            a aVar2 = aVar;
            if (aVar2.f28944k) {
                E0.a.b("ImageVector.Builder is single use, create a new instance to create a new ImageVector");
            }
            ((C0278a) A6.u.m(1, aVar2.f28942i)).f28954j.add(new o("", arrayList, 0, s10, 1.0f, (C2874n) null, 1.0f, 1.0f, 0, 2, 1.0f, 0.0f, 1.0f, 0.0f));
        }

        public final C3306d b() {
            if (this.f28944k) {
                E0.a.b("ImageVector.Builder is single use, create a new instance to create a new ImageVector");
            }
            while (true) {
                ArrayList<C0278a> arrayList = this.f28942i;
                if (arrayList.size() > 1) {
                    if (this.f28944k) {
                        E0.a.b("ImageVector.Builder is single use, create a new instance to create a new ImageVector");
                    }
                    C0278a remove = arrayList.remove(arrayList.size() - 1);
                    ((C0278a) A6.u.m(1, arrayList)).f28954j.add(new C3313k(remove.f28945a, remove.f28946b, remove.f28947c, remove.f28948d, remove.f28949e, remove.f28950f, remove.f28951g, remove.f28952h, remove.f28953i, remove.f28954j));
                } else {
                    C0278a aVar = this.f28943j;
                    C3313k kVar = new C3313k(aVar.f28945a, aVar.f28946b, aVar.f28947c, aVar.f28948d, aVar.f28949e, aVar.f28950f, aVar.f28951g, aVar.f28952h, aVar.f28953i, aVar.f28954j);
                    C3313k kVar2 = kVar;
                    C3306d dVar = new C3306d(this.f28934a, this.f28935b, this.f28936c, this.f28937d, this.f28938e, kVar2, this.f28939f, this.f28940g, this.f28941h);
                    this.f28944k = true;
                    return dVar;
                }
            }
        }
    }

    /* renamed from: v0.d$b */
    public static final class b {
    }

    public C3306d(String str, float f10, float f11, float f12, float f13, C3313k kVar, long j10, int i10, boolean z10) {
        int i11;
        synchronized (f28923l) {
            i11 = f28922k;
            f28922k = i11 + 1;
        }
        this.f28924a = str;
        this.f28925b = f10;
        this.f28926c = f11;
        this.f28927d = f12;
        this.f28928e = f13;
        this.f28929f = kVar;
        this.f28930g = j10;
        this.f28931h = i10;
        this.f28932i = z10;
        this.f28933j = i11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3306d)) {
            return false;
        }
        C3306d dVar = (C3306d) obj;
        if (l.a(this.f28924a, dVar.f28924a) && f.b(this.f28925b, dVar.f28925b) && f.b(this.f28926c, dVar.f28926c) && this.f28927d == dVar.f28927d && this.f28928e == dVar.f28928e && this.f28929f.equals(dVar.f28929f) && C2879s.c(this.f28930g, dVar.f28930g) && this.f28931h == dVar.f28931h && this.f28932i == dVar.f28932i) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i10;
        int g6 = c.g(c.g(c.g(c.g(this.f28924a.hashCode() * 31, this.f28925b, 31), this.f28926c, 31), this.f28927d, 31), this.f28928e, 31);
        int i11 = C2879s.f26408l;
        int e10 = (C0493u.e((this.f28929f.hashCode() + g6) * 31, 31, this.f28930g) + this.f28931h) * 31;
        if (this.f28932i) {
            i10 = 1231;
        } else {
            i10 = 1237;
        }
        return e10 + i10;
    }
}
