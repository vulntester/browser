package v0;

import java.util.ArrayList;
import v0.C3309g;

/* renamed from: v0.e  reason: case insensitive filesystem */
public final class C3307e {

    /* renamed from: a  reason: collision with root package name */
    public final ArrayList<C3309g> f28955a = new ArrayList<>(32);

    public final void a(float f10, float f11, boolean z10, float f12, float f13) {
        this.f28955a.add(new C3309g.j(f10, f11, 0.0f, false, z10, f12, f13));
    }

    public final void b() {
        this.f28955a.add(C3309g.b.f28985c);
    }

    public final void c(float f10, float f11, float f12, float f13, float f14, float f15) {
        this.f28955a.add(new C3309g.c(f10, f11, f12, f13, f14, f15));
    }

    public final void d(float f10, float f11, float f12, float f13, float f14, float f15) {
        this.f28955a.add(new C3309g.k(f10, f11, f12, f13, f14, f15));
    }

    public final void e(float f10) {
        this.f28955a.add(new C3309g.d(f10));
    }

    public final void f(float f10) {
        this.f28955a.add(new C3309g.l(f10));
    }

    public final void g(float f10, float f11) {
        this.f28955a.add(new C3309g.e(f10, f11));
    }

    public final void h(float f10, float f11) {
        this.f28955a.add(new C3309g.m(f10, f11));
    }

    public final void i(float f10, float f11) {
        this.f28955a.add(new C3309g.f(f10, f11));
    }

    public final void j(float f10, float f11, float f12, float f13) {
        this.f28955a.add(new C3309g.h(f10, f11, f12, f13));
    }

    public final void k(float f10, float f11, float f12, float f13) {
        this.f28955a.add(new C3309g.p(f10, f11, f12, f13));
    }

    public final void l(float f10) {
        this.f28955a.add(new C3309g.s(f10));
    }

    public final void m(float f10) {
        this.f28955a.add(new C3309g.r(f10));
    }
}
