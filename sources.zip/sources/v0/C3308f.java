package v0;

import D2.B;
import android.graphics.PathMeasure;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.n;
import p0.C2851J;
import p0.C2869i;
import p0.C2870j;
import p0.C2871k;
import p0.C2874n;
import r0.d;
import r0.h;
import xa.C4969i;
import xa.C4970j;
import ya.u;

/* renamed from: v0.f  reason: case insensitive filesystem */
public final class C3308f extends C3311i {

    /* renamed from: b  reason: collision with root package name */
    public C2874n f28956b;

    /* renamed from: c  reason: collision with root package name */
    public float f28957c = 1.0f;

    /* renamed from: d  reason: collision with root package name */
    public Object f28958d;

    /* renamed from: e  reason: collision with root package name */
    public float f28959e;

    /* renamed from: f  reason: collision with root package name */
    public float f28960f;

    /* renamed from: g  reason: collision with root package name */
    public C2874n f28961g;

    /* renamed from: h  reason: collision with root package name */
    public int f28962h;

    /* renamed from: i  reason: collision with root package name */
    public int f28963i;

    /* renamed from: j  reason: collision with root package name */
    public float f28964j;

    /* renamed from: k  reason: collision with root package name */
    public float f28965k;

    /* renamed from: l  reason: collision with root package name */
    public float f28966l;

    /* renamed from: m  reason: collision with root package name */
    public float f28967m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f28968n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f28969o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f28970p;

    /* renamed from: q  reason: collision with root package name */
    public h f28971q;

    /* renamed from: r  reason: collision with root package name */
    public final C2869i f28972r;

    /* renamed from: s  reason: collision with root package name */
    public C2869i f28973s;

    /* renamed from: t  reason: collision with root package name */
    public final Object f28974t;

    /* renamed from: v0.f$a */
    public static final class a extends n implements Na.a<C2851J> {

        /* renamed from: f  reason: collision with root package name */
        public static final a f28975f = new n(0);

        public final Object invoke() {
            return new C2870j(new PathMeasure());
        }
    }

    public C3308f() {
        int i10 = C3314l.f29064a;
        this.f28958d = u.f44685f;
        this.f28959e = 1.0f;
        this.f28962h = 0;
        this.f28963i = 0;
        this.f28964j = 4.0f;
        this.f28966l = 1.0f;
        this.f28968n = true;
        this.f28969o = true;
        C2869i a10 = C2871k.a();
        this.f28972r = a10;
        this.f28973s = a10;
        this.f28974t = C4969i.d(C4970j.f44069i, a.f28975f);
    }

    /* JADX WARNING: type inference failed for: r0v3, types: [java.util.List, java.lang.Object] */
    public final void a(d dVar) {
        d dVar2;
        h hVar;
        if (this.f28968n) {
            C3310h.b(this.f28958d, this.f28972r);
            e();
        } else if (this.f28970p) {
            e();
        }
        this.f28968n = false;
        this.f28970p = false;
        C2874n nVar = this.f28956b;
        if (nVar != null) {
            dVar2 = dVar;
            B.p(dVar2, this.f28973s, nVar, this.f28957c, (h) null, 56);
        } else {
            dVar2 = dVar;
        }
        C2874n nVar2 = this.f28961g;
        if (nVar2 != null) {
            h hVar2 = this.f28971q;
            if (this.f28969o || hVar2 == null) {
                h hVar3 = new h(this.f28960f, this.f28964j, this.f28962h, this.f28963i, 16);
                this.f28971q = hVar3;
                this.f28969o = false;
                hVar = hVar3;
            } else {
                hVar = hVar2;
            }
            B.p(dVar2, this.f28973s, nVar2, this.f28959e, hVar, 48);
        }
    }

    /* JADX WARNING: type inference failed for: r0v4, types: [xa.h, java.lang.Object] */
    public final void e() {
        int i10 = (this.f28965k > 0.0f ? 1 : (this.f28965k == 0.0f ? 0 : -1));
        C2869i iVar = this.f28972r;
        if (i10 == 0 && this.f28966l == 1.0f) {
            this.f28973s = iVar;
            return;
        }
        if (l.a(this.f28973s, iVar)) {
            this.f28973s = C2871k.a();
        } else {
            int h10 = this.f28973s.h();
            this.f28973s.k();
            this.f28973s.e(h10);
        }
        ? r02 = this.f28974t;
        ((C2851J) r02.getValue()).c(iVar);
        float a10 = ((C2851J) r02.getValue()).a();
        float f10 = this.f28965k;
        float f11 = this.f28967m;
        float f12 = ((f10 + f11) % 1.0f) * a10;
        float f13 = ((this.f28966l + f11) % 1.0f) * a10;
        if (f12 > f13) {
            ((C2851J) r02.getValue()).b(f12, a10, this.f28973s);
            ((C2851J) r02.getValue()).b(0.0f, f13, this.f28973s);
            return;
        }
        ((C2851J) r02.getValue()).b(f12, f13, this.f28973s);
    }

    public final String toString() {
        return this.f28972r.toString();
    }
}
