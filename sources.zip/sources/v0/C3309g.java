package v0;

import D2.E;

/* renamed from: v0.g  reason: case insensitive filesystem */
public abstract class C3309g {

    /* renamed from: a  reason: collision with root package name */
    public final boolean f28976a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f28977b;

    /* renamed from: v0.g$a */
    public static final class a extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f28978c;

        /* renamed from: d  reason: collision with root package name */
        public final float f28979d;

        /* renamed from: e  reason: collision with root package name */
        public final float f28980e;

        /* renamed from: f  reason: collision with root package name */
        public final boolean f28981f;

        /* renamed from: g  reason: collision with root package name */
        public final boolean f28982g;

        /* renamed from: h  reason: collision with root package name */
        public final float f28983h;

        /* renamed from: i  reason: collision with root package name */
        public final float f28984i;

        public a(float f10, float f11, float f12, boolean z10, boolean z11, float f13, float f14) {
            super(3);
            this.f28978c = f10;
            this.f28979d = f11;
            this.f28980e = f12;
            this.f28981f = z10;
            this.f28982g = z11;
            this.f28983h = f13;
            this.f28984i = f14;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            if (Float.compare(this.f28978c, aVar.f28978c) == 0 && Float.compare(this.f28979d, aVar.f28979d) == 0 && Float.compare(this.f28980e, aVar.f28980e) == 0 && this.f28981f == aVar.f28981f && this.f28982g == aVar.f28982g && Float.compare(this.f28983h, aVar.f28983h) == 0 && Float.compare(this.f28984i, aVar.f28984i) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            int i10;
            int g6 = D1.c.g(D1.c.g(Float.floatToIntBits(this.f28978c) * 31, this.f28979d, 31), this.f28980e, 31);
            int i11 = 1237;
            if (this.f28981f) {
                i10 = 1231;
            } else {
                i10 = 1237;
            }
            int i12 = (g6 + i10) * 31;
            if (this.f28982g) {
                i11 = 1231;
            }
            return Float.floatToIntBits(this.f28984i) + D1.c.g((i12 + i11) * 31, this.f28983h, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("ArcTo(horizontalEllipseRadius=");
            sb2.append(this.f28978c);
            sb2.append(", verticalEllipseRadius=");
            sb2.append(this.f28979d);
            sb2.append(", theta=");
            sb2.append(this.f28980e);
            sb2.append(", isMoreThanHalf=");
            sb2.append(this.f28981f);
            sb2.append(", isPositiveArc=");
            sb2.append(this.f28982g);
            sb2.append(", arcStartX=");
            sb2.append(this.f28983h);
            sb2.append(", arcStartY=");
            return E.o(sb2, this.f28984i, ')');
        }
    }

    /* renamed from: v0.g$b */
    public static final class b extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public static final b f28985c = new C3309g(3);
    }

    /* renamed from: v0.g$c */
    public static final class c extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f28986c;

        /* renamed from: d  reason: collision with root package name */
        public final float f28987d;

        /* renamed from: e  reason: collision with root package name */
        public final float f28988e;

        /* renamed from: f  reason: collision with root package name */
        public final float f28989f;

        /* renamed from: g  reason: collision with root package name */
        public final float f28990g;

        /* renamed from: h  reason: collision with root package name */
        public final float f28991h;

        public c(float f10, float f11, float f12, float f13, float f14, float f15) {
            super(2);
            this.f28986c = f10;
            this.f28987d = f11;
            this.f28988e = f12;
            this.f28989f = f13;
            this.f28990g = f14;
            this.f28991h = f15;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof c)) {
                return false;
            }
            c cVar = (c) obj;
            if (Float.compare(this.f28986c, cVar.f28986c) == 0 && Float.compare(this.f28987d, cVar.f28987d) == 0 && Float.compare(this.f28988e, cVar.f28988e) == 0 && Float.compare(this.f28989f, cVar.f28989f) == 0 && Float.compare(this.f28990g, cVar.f28990g) == 0 && Float.compare(this.f28991h, cVar.f28991h) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f28991h) + D1.c.g(D1.c.g(D1.c.g(D1.c.g(Float.floatToIntBits(this.f28986c) * 31, this.f28987d, 31), this.f28988e, 31), this.f28989f, 31), this.f28990g, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("CurveTo(x1=");
            sb2.append(this.f28986c);
            sb2.append(", y1=");
            sb2.append(this.f28987d);
            sb2.append(", x2=");
            sb2.append(this.f28988e);
            sb2.append(", y2=");
            sb2.append(this.f28989f);
            sb2.append(", x3=");
            sb2.append(this.f28990g);
            sb2.append(", y3=");
            return E.o(sb2, this.f28991h, ')');
        }
    }

    /* renamed from: v0.g$d */
    public static final class d extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f28992c;

        public d(float f10) {
            super(3);
            this.f28992c = f10;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if ((obj instanceof d) && Float.compare(this.f28992c, ((d) obj).f28992c) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f28992c);
        }

        public final String toString() {
            return E.o(new StringBuilder("HorizontalTo(x="), this.f28992c, ')');
        }
    }

    /* renamed from: v0.g$e */
    public static final class e extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f28993c;

        /* renamed from: d  reason: collision with root package name */
        public final float f28994d;

        public e(float f10, float f11) {
            super(3);
            this.f28993c = f10;
            this.f28994d = f11;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof e)) {
                return false;
            }
            e eVar = (e) obj;
            if (Float.compare(this.f28993c, eVar.f28993c) == 0 && Float.compare(this.f28994d, eVar.f28994d) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f28994d) + (Float.floatToIntBits(this.f28993c) * 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("LineTo(x=");
            sb2.append(this.f28993c);
            sb2.append(", y=");
            return E.o(sb2, this.f28994d, ')');
        }
    }

    /* renamed from: v0.g$f */
    public static final class f extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f28995c;

        /* renamed from: d  reason: collision with root package name */
        public final float f28996d;

        public f(float f10, float f11) {
            super(3);
            this.f28995c = f10;
            this.f28996d = f11;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof f)) {
                return false;
            }
            f fVar = (f) obj;
            if (Float.compare(this.f28995c, fVar.f28995c) == 0 && Float.compare(this.f28996d, fVar.f28996d) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f28996d) + (Float.floatToIntBits(this.f28995c) * 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("MoveTo(x=");
            sb2.append(this.f28995c);
            sb2.append(", y=");
            return E.o(sb2, this.f28996d, ')');
        }
    }

    /* renamed from: v0.g$g  reason: collision with other inner class name */
    public static final class C0279g extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f28997c;

        /* renamed from: d  reason: collision with root package name */
        public final float f28998d;

        /* renamed from: e  reason: collision with root package name */
        public final float f28999e;

        /* renamed from: f  reason: collision with root package name */
        public final float f29000f;

        public C0279g(float f10, float f11, float f12, float f13) {
            super(1);
            this.f28997c = f10;
            this.f28998d = f11;
            this.f28999e = f12;
            this.f29000f = f13;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0279g)) {
                return false;
            }
            C0279g gVar = (C0279g) obj;
            if (Float.compare(this.f28997c, gVar.f28997c) == 0 && Float.compare(this.f28998d, gVar.f28998d) == 0 && Float.compare(this.f28999e, gVar.f28999e) == 0 && Float.compare(this.f29000f, gVar.f29000f) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29000f) + D1.c.g(D1.c.g(Float.floatToIntBits(this.f28997c) * 31, this.f28998d, 31), this.f28999e, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("QuadTo(x1=");
            sb2.append(this.f28997c);
            sb2.append(", y1=");
            sb2.append(this.f28998d);
            sb2.append(", x2=");
            sb2.append(this.f28999e);
            sb2.append(", y2=");
            return E.o(sb2, this.f29000f, ')');
        }
    }

    /* renamed from: v0.g$h */
    public static final class h extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29001c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29002d;

        /* renamed from: e  reason: collision with root package name */
        public final float f29003e;

        /* renamed from: f  reason: collision with root package name */
        public final float f29004f;

        public h(float f10, float f11, float f12, float f13) {
            super(2);
            this.f29001c = f10;
            this.f29002d = f11;
            this.f29003e = f12;
            this.f29004f = f13;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof h)) {
                return false;
            }
            h hVar = (h) obj;
            if (Float.compare(this.f29001c, hVar.f29001c) == 0 && Float.compare(this.f29002d, hVar.f29002d) == 0 && Float.compare(this.f29003e, hVar.f29003e) == 0 && Float.compare(this.f29004f, hVar.f29004f) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29004f) + D1.c.g(D1.c.g(Float.floatToIntBits(this.f29001c) * 31, this.f29002d, 31), this.f29003e, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("ReflectiveCurveTo(x1=");
            sb2.append(this.f29001c);
            sb2.append(", y1=");
            sb2.append(this.f29002d);
            sb2.append(", x2=");
            sb2.append(this.f29003e);
            sb2.append(", y2=");
            return E.o(sb2, this.f29004f, ')');
        }
    }

    /* renamed from: v0.g$i */
    public static final class i extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29005c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29006d;

        public i(float f10, float f11) {
            super(1);
            this.f29005c = f10;
            this.f29006d = f11;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof i)) {
                return false;
            }
            i iVar = (i) obj;
            if (Float.compare(this.f29005c, iVar.f29005c) == 0 && Float.compare(this.f29006d, iVar.f29006d) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29006d) + (Float.floatToIntBits(this.f29005c) * 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("ReflectiveQuadTo(x=");
            sb2.append(this.f29005c);
            sb2.append(", y=");
            return E.o(sb2, this.f29006d, ')');
        }
    }

    /* renamed from: v0.g$j */
    public static final class j extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29007c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29008d;

        /* renamed from: e  reason: collision with root package name */
        public final float f29009e;

        /* renamed from: f  reason: collision with root package name */
        public final boolean f29010f;

        /* renamed from: g  reason: collision with root package name */
        public final boolean f29011g;

        /* renamed from: h  reason: collision with root package name */
        public final float f29012h;

        /* renamed from: i  reason: collision with root package name */
        public final float f29013i;

        public j(float f10, float f11, float f12, boolean z10, boolean z11, float f13, float f14) {
            super(3);
            this.f29007c = f10;
            this.f29008d = f11;
            this.f29009e = f12;
            this.f29010f = z10;
            this.f29011g = z11;
            this.f29012h = f13;
            this.f29013i = f14;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof j)) {
                return false;
            }
            j jVar = (j) obj;
            if (Float.compare(this.f29007c, jVar.f29007c) == 0 && Float.compare(this.f29008d, jVar.f29008d) == 0 && Float.compare(this.f29009e, jVar.f29009e) == 0 && this.f29010f == jVar.f29010f && this.f29011g == jVar.f29011g && Float.compare(this.f29012h, jVar.f29012h) == 0 && Float.compare(this.f29013i, jVar.f29013i) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            int i10;
            int g6 = D1.c.g(D1.c.g(Float.floatToIntBits(this.f29007c) * 31, this.f29008d, 31), this.f29009e, 31);
            int i11 = 1237;
            if (this.f29010f) {
                i10 = 1231;
            } else {
                i10 = 1237;
            }
            int i12 = (g6 + i10) * 31;
            if (this.f29011g) {
                i11 = 1231;
            }
            return Float.floatToIntBits(this.f29013i) + D1.c.g((i12 + i11) * 31, this.f29012h, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("RelativeArcTo(horizontalEllipseRadius=");
            sb2.append(this.f29007c);
            sb2.append(", verticalEllipseRadius=");
            sb2.append(this.f29008d);
            sb2.append(", theta=");
            sb2.append(this.f29009e);
            sb2.append(", isMoreThanHalf=");
            sb2.append(this.f29010f);
            sb2.append(", isPositiveArc=");
            sb2.append(this.f29011g);
            sb2.append(", arcStartDx=");
            sb2.append(this.f29012h);
            sb2.append(", arcStartDy=");
            return E.o(sb2, this.f29013i, ')');
        }
    }

    /* renamed from: v0.g$k */
    public static final class k extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29014c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29015d;

        /* renamed from: e  reason: collision with root package name */
        public final float f29016e;

        /* renamed from: f  reason: collision with root package name */
        public final float f29017f;

        /* renamed from: g  reason: collision with root package name */
        public final float f29018g;

        /* renamed from: h  reason: collision with root package name */
        public final float f29019h;

        public k(float f10, float f11, float f12, float f13, float f14, float f15) {
            super(2);
            this.f29014c = f10;
            this.f29015d = f11;
            this.f29016e = f12;
            this.f29017f = f13;
            this.f29018g = f14;
            this.f29019h = f15;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof k)) {
                return false;
            }
            k kVar = (k) obj;
            if (Float.compare(this.f29014c, kVar.f29014c) == 0 && Float.compare(this.f29015d, kVar.f29015d) == 0 && Float.compare(this.f29016e, kVar.f29016e) == 0 && Float.compare(this.f29017f, kVar.f29017f) == 0 && Float.compare(this.f29018g, kVar.f29018g) == 0 && Float.compare(this.f29019h, kVar.f29019h) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29019h) + D1.c.g(D1.c.g(D1.c.g(D1.c.g(Float.floatToIntBits(this.f29014c) * 31, this.f29015d, 31), this.f29016e, 31), this.f29017f, 31), this.f29018g, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("RelativeCurveTo(dx1=");
            sb2.append(this.f29014c);
            sb2.append(", dy1=");
            sb2.append(this.f29015d);
            sb2.append(", dx2=");
            sb2.append(this.f29016e);
            sb2.append(", dy2=");
            sb2.append(this.f29017f);
            sb2.append(", dx3=");
            sb2.append(this.f29018g);
            sb2.append(", dy3=");
            return E.o(sb2, this.f29019h, ')');
        }
    }

    /* renamed from: v0.g$l */
    public static final class l extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29020c;

        public l(float f10) {
            super(3);
            this.f29020c = f10;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if ((obj instanceof l) && Float.compare(this.f29020c, ((l) obj).f29020c) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29020c);
        }

        public final String toString() {
            return E.o(new StringBuilder("RelativeHorizontalTo(dx="), this.f29020c, ')');
        }
    }

    /* renamed from: v0.g$m */
    public static final class m extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29021c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29022d;

        public m(float f10, float f11) {
            super(3);
            this.f29021c = f10;
            this.f29022d = f11;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof m)) {
                return false;
            }
            m mVar = (m) obj;
            if (Float.compare(this.f29021c, mVar.f29021c) == 0 && Float.compare(this.f29022d, mVar.f29022d) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29022d) + (Float.floatToIntBits(this.f29021c) * 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("RelativeLineTo(dx=");
            sb2.append(this.f29021c);
            sb2.append(", dy=");
            return E.o(sb2, this.f29022d, ')');
        }
    }

    /* renamed from: v0.g$n */
    public static final class n extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29023c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29024d;

        public n(float f10, float f11) {
            super(3);
            this.f29023c = f10;
            this.f29024d = f11;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof n)) {
                return false;
            }
            n nVar = (n) obj;
            if (Float.compare(this.f29023c, nVar.f29023c) == 0 && Float.compare(this.f29024d, nVar.f29024d) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29024d) + (Float.floatToIntBits(this.f29023c) * 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("RelativeMoveTo(dx=");
            sb2.append(this.f29023c);
            sb2.append(", dy=");
            return E.o(sb2, this.f29024d, ')');
        }
    }

    /* renamed from: v0.g$o */
    public static final class o extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29025c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29026d;

        /* renamed from: e  reason: collision with root package name */
        public final float f29027e;

        /* renamed from: f  reason: collision with root package name */
        public final float f29028f;

        public o(float f10, float f11, float f12, float f13) {
            super(1);
            this.f29025c = f10;
            this.f29026d = f11;
            this.f29027e = f12;
            this.f29028f = f13;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof o)) {
                return false;
            }
            o oVar = (o) obj;
            if (Float.compare(this.f29025c, oVar.f29025c) == 0 && Float.compare(this.f29026d, oVar.f29026d) == 0 && Float.compare(this.f29027e, oVar.f29027e) == 0 && Float.compare(this.f29028f, oVar.f29028f) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29028f) + D1.c.g(D1.c.g(Float.floatToIntBits(this.f29025c) * 31, this.f29026d, 31), this.f29027e, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("RelativeQuadTo(dx1=");
            sb2.append(this.f29025c);
            sb2.append(", dy1=");
            sb2.append(this.f29026d);
            sb2.append(", dx2=");
            sb2.append(this.f29027e);
            sb2.append(", dy2=");
            return E.o(sb2, this.f29028f, ')');
        }
    }

    /* renamed from: v0.g$p */
    public static final class p extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29029c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29030d;

        /* renamed from: e  reason: collision with root package name */
        public final float f29031e;

        /* renamed from: f  reason: collision with root package name */
        public final float f29032f;

        public p(float f10, float f11, float f12, float f13) {
            super(2);
            this.f29029c = f10;
            this.f29030d = f11;
            this.f29031e = f12;
            this.f29032f = f13;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof p)) {
                return false;
            }
            p pVar = (p) obj;
            if (Float.compare(this.f29029c, pVar.f29029c) == 0 && Float.compare(this.f29030d, pVar.f29030d) == 0 && Float.compare(this.f29031e, pVar.f29031e) == 0 && Float.compare(this.f29032f, pVar.f29032f) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29032f) + D1.c.g(D1.c.g(Float.floatToIntBits(this.f29029c) * 31, this.f29030d, 31), this.f29031e, 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("RelativeReflectiveCurveTo(dx1=");
            sb2.append(this.f29029c);
            sb2.append(", dy1=");
            sb2.append(this.f29030d);
            sb2.append(", dx2=");
            sb2.append(this.f29031e);
            sb2.append(", dy2=");
            return E.o(sb2, this.f29032f, ')');
        }
    }

    /* renamed from: v0.g$q */
    public static final class q extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29033c;

        /* renamed from: d  reason: collision with root package name */
        public final float f29034d;

        public q(float f10, float f11) {
            super(1);
            this.f29033c = f10;
            this.f29034d = f11;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof q)) {
                return false;
            }
            q qVar = (q) obj;
            if (Float.compare(this.f29033c, qVar.f29033c) == 0 && Float.compare(this.f29034d, qVar.f29034d) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29034d) + (Float.floatToIntBits(this.f29033c) * 31);
        }

        public final String toString() {
            StringBuilder sb2 = new StringBuilder("RelativeReflectiveQuadTo(dx=");
            sb2.append(this.f29033c);
            sb2.append(", dy=");
            return E.o(sb2, this.f29034d, ')');
        }
    }

    /* renamed from: v0.g$r */
    public static final class r extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29035c;

        public r(float f10) {
            super(3);
            this.f29035c = f10;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if ((obj instanceof r) && Float.compare(this.f29035c, ((r) obj).f29035c) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29035c);
        }

        public final String toString() {
            return E.o(new StringBuilder("RelativeVerticalTo(dy="), this.f29035c, ')');
        }
    }

    /* renamed from: v0.g$s */
    public static final class s extends C3309g {

        /* renamed from: c  reason: collision with root package name */
        public final float f29036c;

        public s(float f10) {
            super(3);
            this.f29036c = f10;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if ((obj instanceof s) && Float.compare(this.f29036c, ((s) obj).f29036c) == 0) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            return Float.floatToIntBits(this.f29036c);
        }

        public final String toString() {
            return E.o(new StringBuilder("VerticalTo(y="), this.f29036c, ')');
        }
    }

    public C3309g(int i10) {
        boolean z10;
        boolean z11 = true;
        if ((i10 & 1) != 0) {
            z10 = false;
        } else {
            z10 = true;
        }
        z11 = (i10 & 2) != 0 ? false : z11;
        this.f28976a = z10;
        this.f28977b = z11;
    }
}
