package v0;

import p0.C2850I;

/* renamed from: v0.h  reason: case insensitive filesystem */
public final class C3310h {
    public static final void a(C2850I i10, double d10, double d11, double d12, double d13, double d14, double d15, double d16, boolean z10, boolean z11) {
        double d17;
        double d18;
        boolean z12;
        double d19 = d10;
        double d20 = d12;
        double d21 = d14;
        double d22 = (d16 / ((double) 180)) * 3.141592653589793d;
        double cos = Math.cos(d22);
        double sin = Math.sin(d22);
        double d23 = ((d11 * sin) + (d19 * cos)) / d21;
        double d24 = ((d11 * cos) + ((-d19) * sin)) / d15;
        double d25 = ((d13 * sin) + (d20 * cos)) / d21;
        double d26 = ((d13 * cos) + ((-d20) * sin)) / d15;
        double d27 = d23 - d25;
        double d28 = d24 - d26;
        double d29 = (double) 2;
        double d30 = (d23 + d25) / d29;
        double d31 = (d24 + d26) / d29;
        double d32 = (d28 * d28) + (d27 * d27);
        if (d32 != 0.0d) {
            double d33 = (1.0d / d32) - 0.25d;
            if (d33 < 0.0d) {
                double sqrt = (double) ((float) (Math.sqrt(d32) / 1.99999d));
                a(i10, d10, d11, d20, d13, d21 * sqrt, d15 * sqrt, d16, z10, z11);
                return;
            }
            boolean z13 = z11;
            double sqrt2 = Math.sqrt(d33);
            double d34 = d27 * sqrt2;
            double d35 = sqrt2 * d28;
            if (z10 == z13) {
                d18 = d30 - d35;
                d17 = d31 + d34;
            } else {
                d18 = d30 + d35;
                d17 = d31 - d34;
            }
            double atan2 = Math.atan2(d24 - d17, d23 - d18);
            double d36 = d29;
            double atan22 = Math.atan2(d26 - d17, d25 - d18) - atan2;
            int i11 = (atan22 > 0.0d ? 1 : (atan22 == 0.0d ? 0 : -1));
            if (i11 >= 0) {
                z12 = true;
            } else {
                z12 = false;
            }
            if (z13 != z12) {
                if (i11 > 0) {
                    atan22 -= 6.283185307179586d;
                } else {
                    atan22 += 6.283185307179586d;
                }
            }
            double d37 = d18 * d21;
            double d38 = d17 * d15;
            double d39 = (d37 * cos) - (d38 * sin);
            double d40 = (d38 * cos) + (d37 * sin);
            double d41 = (double) 4;
            int ceil = (int) Math.ceil(Math.abs((atan22 * d41) / 3.141592653589793d));
            double cos2 = Math.cos(d22);
            double sin2 = Math.sin(d22);
            double cos3 = Math.cos(atan2);
            double sin3 = Math.sin(atan2);
            double d42 = atan22;
            double d43 = -d21;
            double d44 = d43 * cos2;
            double d45 = d15 * sin2;
            double d46 = (d44 * sin3) - (d45 * cos3);
            double d47 = d43 * sin2;
            double d48 = d15 * cos2;
            double d49 = (cos3 * d48) + (sin3 * d47);
            double d50 = d47;
            double d51 = d42 / ((double) ceil);
            double d52 = atan2;
            double d53 = d46;
            int i12 = 0;
            double d54 = d10;
            double d55 = d49;
            double d56 = d11;
            while (i12 < ceil) {
                double d57 = d52 + d51;
                double sin4 = Math.sin(d57);
                double cos4 = Math.cos(d57);
                int i13 = i12;
                double d58 = (((d21 * cos2) * cos4) + d39) - (d45 * sin4);
                int i14 = ceil;
                double d59 = (d48 * sin4) + (d21 * sin2 * cos4) + d40;
                double d60 = (d44 * sin4) - (d45 * cos4);
                double d61 = (cos4 * d48) + (sin4 * d50);
                double d62 = d57 - d52;
                double tan = Math.tan(d62 / d36);
                int i15 = i14;
                double d63 = d54;
                double sqrt3 = ((Math.sqrt(((3.0d * tan) * tan) + d41) - ((double) 1)) * Math.sin(d62)) / ((double) 3);
                float f10 = (float) (d58 - (sqrt3 * d60));
                float f11 = (float) (d59 - (sqrt3 * d61));
                float f12 = (float) ((d53 * sqrt3) + d63);
                i10.j(f12, (float) ((d55 * sqrt3) + d56), f10, f11, (float) d58, (float) d59);
                d54 = d58;
                i12 = i13 + 1;
                d39 = d39;
                sin2 = sin2;
                d41 = d41;
                d52 = d57;
                d55 = d61;
                d53 = d60;
                d56 = d59;
                d21 = d14;
                ceil = i15;
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v1, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v0, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v0, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v0, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v1, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v0, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r13v0, resolved type: v0.g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v2, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v2, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v2, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v5, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v4, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v4, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v6, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v5, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v5, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v8, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v6, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v8, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v10, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v13, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v10, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v15, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v16, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v17, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v14, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v18, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v15, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v19, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v12, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v16, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v19, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v30, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v20, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v20, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v14, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v22, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v36, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v26, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v16, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v27, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v31, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v32, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v27, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v18, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v29, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v31, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v14, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v29, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v36, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v20, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v32, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v22, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v34, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v30, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v37, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v24, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v36, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v31, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v38, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v38, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v32, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v39, resolved type: float} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v26, resolved type: float} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void b(java.util.List r29, p0.C2850I r30) {
        /*
            r0 = r29
            r1 = r30
            int r2 = r1.h()
            r1.k()
            r1.e(r2)
            boolean r2 = r0.isEmpty()
            r3 = 0
            if (r2 == 0) goto L_0x0018
            v0.g$b r2 = v0.C3309g.b.f28985c
            goto L_0x001e
        L_0x0018:
            java.lang.Object r2 = r0.get(r3)
            v0.g r2 = (v0.C3309g) r2
        L_0x001e:
            int r8 = r0.size()
            r9 = 0
            r10 = r3
            r3 = r9
            r4 = r3
            r11 = r4
            r12 = r11
            r18 = r12
            r19 = r18
        L_0x002c:
            if (r10 >= r8) goto L_0x02d1
            java.lang.Object r5 = r0.get(r10)
            r13 = r5
            v0.g r13 = (v0.C3309g) r13
            boolean r5 = r13 instanceof v0.C3309g.b
            if (r5 == 0) goto L_0x004c
            r1.close()
            r22 = r8
            r20 = r9
            r21 = r10
            r23 = r13
            r3 = r18
            r11 = r3
            r4 = r19
        L_0x0049:
            r12 = r4
            goto L_0x02c3
        L_0x004c:
            boolean r5 = r13 instanceof v0.C3309g.n
            if (r5 == 0) goto L_0x006a
            r2 = r13
            v0.g$n r2 = (v0.C3309g.n) r2
            float r5 = r2.f29023c
            float r11 = r11 + r5
            float r2 = r2.f29024d
            float r12 = r12 + r2
            r1.c(r5, r2)
            r22 = r8
            r20 = r9
            r21 = r10
            r18 = r11
            r19 = r12
        L_0x0066:
            r23 = r13
            goto L_0x02c3
        L_0x006a:
            boolean r5 = r13 instanceof v0.C3309g.f
            if (r5 == 0) goto L_0x0085
            r2 = r13
            v0.g$f r2 = (v0.C3309g.f) r2
            float r5 = r2.f28995c
            float r2 = r2.f28996d
            r1.i(r5, r2)
            r12 = r2
            r19 = r12
            r11 = r5
            r18 = r11
        L_0x007e:
            r22 = r8
            r20 = r9
            r21 = r10
            goto L_0x0066
        L_0x0085:
            boolean r5 = r13 instanceof v0.C3309g.m
            if (r5 == 0) goto L_0x0098
            r2 = r13
            v0.g$m r2 = (v0.C3309g.m) r2
            float r5 = r2.f29021c
            float r6 = r2.f29022d
            r1.l(r5, r6)
            float r2 = r2.f29021c
            float r11 = r11 + r2
            float r12 = r12 + r6
            goto L_0x007e
        L_0x0098:
            boolean r5 = r13 instanceof v0.C3309g.e
            if (r5 == 0) goto L_0x00ab
            r2 = r13
            v0.g$e r2 = (v0.C3309g.e) r2
            float r5 = r2.f28993c
            float r6 = r2.f28994d
            r1.m(r5, r6)
            float r2 = r2.f28993c
            r11 = r2
        L_0x00a9:
            r12 = r6
            goto L_0x007e
        L_0x00ab:
            boolean r5 = r13 instanceof v0.C3309g.l
            if (r5 == 0) goto L_0x00bb
            r2 = r13
            v0.g$l r2 = (v0.C3309g.l) r2
            float r5 = r2.f29020c
            r1.l(r5, r9)
            float r2 = r2.f29020c
            float r11 = r11 + r2
            goto L_0x007e
        L_0x00bb:
            boolean r5 = r13 instanceof v0.C3309g.d
            if (r5 == 0) goto L_0x00cb
            r2 = r13
            v0.g$d r2 = (v0.C3309g.d) r2
            float r5 = r2.f28992c
            r1.m(r5, r12)
            float r2 = r2.f28992c
            r11 = r2
            goto L_0x007e
        L_0x00cb:
            boolean r5 = r13 instanceof v0.C3309g.r
            if (r5 == 0) goto L_0x00db
            r2 = r13
            v0.g$r r2 = (v0.C3309g.r) r2
            float r5 = r2.f29035c
            r1.l(r9, r5)
            float r2 = r2.f29035c
            float r12 = r12 + r2
            goto L_0x007e
        L_0x00db:
            boolean r5 = r13 instanceof v0.C3309g.s
            if (r5 == 0) goto L_0x00eb
            r2 = r13
            v0.g$s r2 = (v0.C3309g.s) r2
            float r5 = r2.f29036c
            r1.m(r11, r5)
            float r2 = r2.f29036c
            r12 = r2
            goto L_0x007e
        L_0x00eb:
            boolean r5 = r13 instanceof v0.C3309g.k
            if (r5 == 0) goto L_0x0111
            r14 = r13
            v0.g$k r14 = (v0.C3309g.k) r14
            float r2 = r14.f29014c
            float r3 = r14.f29015d
            float r4 = r14.f29016e
            float r5 = r14.f29017f
            float r6 = r14.f29018g
            float r7 = r14.f29019h
            r1.d(r2, r3, r4, r5, r6, r7)
            float r1 = r14.f29016e
            float r1 = r1 + r11
            float r2 = r14.f29017f
            float r2 = r2 + r12
            float r3 = r14.f29018g
            float r11 = r11 + r3
            float r3 = r14.f29019h
        L_0x010c:
            float r12 = r12 + r3
            r3 = r1
            r4 = r2
            goto L_0x007e
        L_0x0111:
            boolean r1 = r13 instanceof v0.C3309g.c
            if (r1 == 0) goto L_0x013f
            r11 = r13
            v0.g$c r11 = (v0.C3309g.c) r11
            float r2 = r11.f28986c
            float r3 = r11.f28987d
            float r4 = r11.f28988e
            float r5 = r11.f28989f
            float r6 = r11.f28990g
            float r7 = r11.f28991h
            r1 = r30
            r1.j(r2, r3, r4, r5, r6, r7)
            float r1 = r11.f28988e
            float r2 = r11.f28989f
            float r3 = r11.f28990g
            float r4 = r11.f28991h
            r11 = r3
            r12 = r4
            r22 = r8
            r20 = r9
            r21 = r10
            r23 = r13
            r3 = r1
            r4 = r2
            goto L_0x02c3
        L_0x013f:
            boolean r1 = r13 instanceof v0.C3309g.p
            if (r1 == 0) goto L_0x016c
            boolean r1 = r2.f28976a
            if (r1 == 0) goto L_0x014e
            float r1 = r11 - r3
            float r2 = r12 - r4
            r3 = r2
            r2 = r1
            goto L_0x0150
        L_0x014e:
            r2 = r9
            r3 = r2
        L_0x0150:
            r14 = r13
            v0.g$p r14 = (v0.C3309g.p) r14
            float r4 = r14.f29029c
            float r5 = r14.f29030d
            float r6 = r14.f29031e
            float r7 = r14.f29032f
            r1 = r30
            r1.d(r2, r3, r4, r5, r6, r7)
            float r1 = r14.f29029c
            float r1 = r1 + r11
            float r2 = r14.f29030d
            float r2 = r2 + r12
            float r3 = r14.f29031e
            float r11 = r11 + r3
            float r3 = r14.f29032f
            goto L_0x010c
        L_0x016c:
            boolean r1 = r13 instanceof v0.C3309g.h
            r5 = 2
            if (r1 == 0) goto L_0x01a3
            boolean r1 = r2.f28976a
            if (r1 == 0) goto L_0x017b
            float r1 = (float) r5
            float r11 = r11 * r1
            float r11 = r11 - r3
            float r1 = r1 * r12
            float r12 = r1 - r4
        L_0x017b:
            r2 = r11
            r3 = r12
            r11 = r13
            v0.g$h r11 = (v0.C3309g.h) r11
            float r4 = r11.f29001c
            float r5 = r11.f29002d
            float r6 = r11.f29003e
            float r7 = r11.f29004f
            r1 = r30
            r1.j(r2, r3, r4, r5, r6, r7)
            float r2 = r11.f29001c
            float r3 = r11.f29002d
            float r4 = r11.f29003e
            float r5 = r11.f29004f
            r11 = r4
            r12 = r5
            r22 = r8
            r20 = r9
            r21 = r10
            r23 = r13
            r4 = r3
        L_0x01a0:
            r3 = r2
            goto L_0x02c3
        L_0x01a3:
            r1 = r30
            boolean r6 = r13 instanceof v0.C3309g.o
            if (r6 == 0) goto L_0x01c0
            r2 = r13
            v0.g$o r2 = (v0.C3309g.o) r2
            float r3 = r2.f29025c
            float r4 = r2.f29026d
            float r5 = r2.f29027e
            float r6 = r2.f29028f
            r1.a(r3, r4, r5, r6)
            float r2 = r2.f29025c
            float r2 = r2 + r11
            float r4 = r4 + r12
            float r11 = r11 + r5
            float r12 = r12 + r6
            r3 = r2
            goto L_0x007e
        L_0x01c0:
            boolean r6 = r13 instanceof v0.C3309g.C0279g
            if (r6 == 0) goto L_0x01d8
            r2 = r13
            v0.g$g r2 = (v0.C3309g.C0279g) r2
            float r3 = r2.f28997c
            float r4 = r2.f28998d
            float r5 = r2.f28999e
            float r6 = r2.f29000f
            r1.g(r3, r4, r5, r6)
            float r2 = r2.f28997c
            r3 = r2
            r11 = r5
            goto L_0x00a9
        L_0x01d8:
            boolean r6 = r13 instanceof v0.C3309g.q
            if (r6 == 0) goto L_0x0201
            boolean r2 = r2.f28977b
            if (r2 == 0) goto L_0x01e5
            float r2 = r11 - r3
            float r3 = r12 - r4
            goto L_0x01e7
        L_0x01e5:
            r2 = r9
            r3 = r2
        L_0x01e7:
            r4 = r13
            v0.g$q r4 = (v0.C3309g.q) r4
            float r5 = r4.f29033c
            float r6 = r4.f29034d
            r1.a(r2, r3, r5, r6)
            float r2 = r2 + r11
            float r3 = r3 + r12
            float r4 = r4.f29033c
            float r11 = r11 + r4
            float r12 = r12 + r6
            r4 = r3
            r22 = r8
            r20 = r9
            r21 = r10
            r23 = r13
            goto L_0x01a0
        L_0x0201:
            boolean r6 = r13 instanceof v0.C3309g.i
            if (r6 == 0) goto L_0x022a
            boolean r2 = r2.f28977b
            if (r2 == 0) goto L_0x020f
            float r2 = (float) r5
            float r11 = r11 * r2
            float r11 = r11 - r3
            float r2 = r2 * r12
            float r12 = r2 - r4
        L_0x020f:
            r2 = r13
            v0.g$i r2 = (v0.C3309g.i) r2
            float r3 = r2.f29005c
            float r4 = r2.f29006d
            r1.g(r11, r12, r3, r4)
            float r2 = r2.f29005c
            r3 = r12
            r12 = r4
            r4 = r3
            r22 = r8
            r20 = r9
            r21 = r10
            r3 = r11
            r23 = r13
            r11 = r2
            goto L_0x02c3
        L_0x022a:
            boolean r2 = r13 instanceof v0.C3309g.j
            if (r2 == 0) goto L_0x027d
            r2 = r13
            v0.g$j r2 = (v0.C3309g.j) r2
            float r3 = r2.f29012h
            float r3 = r3 + r11
            float r4 = r2.f29013i
            float r4 = r4 + r12
            double r5 = (double) r11
            double r11 = (double) r12
            r14 = r5
            double r6 = (double) r3
            r5 = r8
            r16 = r9
            double r8 = (double) r4
            float r0 = r2.f29007c
            double r0 = (double) r0
            r20 = r0
            float r0 = r2.f29008d
            double r0 = (double) r0
            r22 = r0
            float r0 = r2.f29009e
            double r0 = (double) r0
            r24 = r0
            boolean r0 = r2.f29010f
            boolean r1 = r2.f29011g
            r17 = r1
            r1 = r30
            r26 = r16
            r16 = r0
            r0 = r13
            r27 = r22
            r23 = r3
            r22 = r5
            r2 = r14
            r14 = r24
            r24 = r4
            r4 = r11
            r12 = r27
            r27 = r20
            r21 = r10
            r20 = r26
            r10 = r27
            a(r1, r2, r4, r6, r8, r10, r12, r14, r16, r17)
            r3 = r23
            r11 = r3
            r4 = r24
            r12 = r4
        L_0x027a:
            r23 = r0
            goto L_0x02c3
        L_0x027d:
            r22 = r8
            r20 = r9
            r21 = r10
            r0 = r13
            boolean r1 = r0 instanceof v0.C3309g.a
            if (r1 == 0) goto L_0x027a
            double r2 = (double) r11
            double r4 = (double) r12
            r1 = r0
            v0.g$a r1 = (v0.C3309g.a) r1
            float r6 = r1.f28983h
            double r6 = (double) r6
            float r8 = r1.f28984i
            r10 = r8
            double r8 = (double) r10
            float r11 = r1.f28978c
            double r11 = (double) r11
            float r13 = r1.f28979d
            double r13 = (double) r13
            float r15 = r1.f28980e
            r16 = r2
            double r2 = (double) r15
            boolean r15 = r1.f28981f
            r23 = r0
            boolean r0 = r1.f28982g
            r24 = r10
            r10 = r11
            r12 = r13
            r26 = r1
            r1 = r30
            r27 = r16
            r17 = r0
            r0 = r26
            r16 = r15
            r14 = r2
            r2 = r27
            a(r1, r2, r4, r6, r8, r10, r12, r14, r16, r17)
            float r0 = r0.f28983h
            r3 = r0
            r11 = r3
            r4 = r24
            goto L_0x0049
        L_0x02c3:
            int r10 = r21 + 1
            r0 = r29
            r1 = r30
            r9 = r20
            r8 = r22
            r2 = r23
            goto L_0x002c
        L_0x02d1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: v0.C3310h.b(java.util.List, p0.I):void");
    }
}
