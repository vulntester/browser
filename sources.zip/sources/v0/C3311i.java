package v0;

import Na.l;
import r0.d;
import v0.C3305c;
import xa.C4959D;

/* renamed from: v0.i  reason: case insensitive filesystem */
public abstract class C3311i {

    /* renamed from: a  reason: collision with root package name */
    public C3305c.a f29037a;

    public abstract void a(d dVar);

    public l<C3311i, C4959D> b() {
        return this.f29037a;
    }

    public final void c() {
        l<C3311i, C4959D> b10 = b();
        if (b10 != null) {
            b10.invoke(this);
        }
    }

    public void d(C3305c.a aVar) {
        this.f29037a = aVar;
    }
}
