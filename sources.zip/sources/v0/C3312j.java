package v0;

import B9.C3805t;
import Na.l;
import V.C1187r0;
import kotlin.jvm.internal.n;
import o0.C2749e;
import p0.C2872l;
import p0.C2880t;
import r0.C3018a;
import r0.d;
import xa.C4959D;

/* renamed from: v0.j  reason: case insensitive filesystem */
public final class C3312j extends C3311i {

    /* renamed from: b  reason: collision with root package name */
    public final C3305c f29038b;

    /* renamed from: c  reason: collision with root package name */
    public String f29039c = "";

    /* renamed from: d  reason: collision with root package name */
    public boolean f29040d = true;

    /* renamed from: e  reason: collision with root package name */
    public final C3303a f29041e = new C3303a();

    /* renamed from: f  reason: collision with root package name */
    public n f29042f = c.f29052f;

    /* renamed from: g  reason: collision with root package name */
    public final C1187r0 f29043g = R1.a.t((Object) null);

    /* renamed from: h  reason: collision with root package name */
    public C2872l f29044h;

    /* renamed from: i  reason: collision with root package name */
    public final C1187r0 f29045i = R1.a.t(new C2749e(0));

    /* renamed from: j  reason: collision with root package name */
    public long f29046j = 9205357640488583168L;

    /* renamed from: k  reason: collision with root package name */
    public float f29047k = 1.0f;

    /* renamed from: l  reason: collision with root package name */
    public float f29048l = 1.0f;

    /* renamed from: m  reason: collision with root package name */
    public final b f29049m = new b(this);

    /* renamed from: v0.j$a */
    public static final class a extends n implements l<C3311i, C4959D> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3312j f29050f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(C3312j jVar) {
            super(1);
            this.f29050f = jVar;
        }

        /* JADX WARNING: type inference failed for: r2v3, types: [Na.a, kotlin.jvm.internal.n] */
        public final Object invoke(Object obj) {
            C3311i iVar = (C3311i) obj;
            C3312j jVar = this.f29050f;
            jVar.f29040d = true;
            jVar.f29042f.invoke();
            return C4959D.f44058a;
        }
    }

    /* renamed from: v0.j$b */
    public static final class b extends n implements l<d, C4959D> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3312j f29051f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(C3312j jVar) {
            super(1);
            this.f29051f = jVar;
        }

        /* JADX INFO: finally extract failed */
        public final Object invoke(Object obj) {
            d dVar = (d) obj;
            C3312j jVar = this.f29051f;
            C3305c cVar = jVar.f29038b;
            float f10 = jVar.f29047k;
            float f11 = jVar.f29048l;
            C3018a.b I02 = dVar.I0();
            long d10 = I02.d();
            I02.a().f();
            try {
                I02.f27309a.g(f10, f11, 0);
                cVar.a(dVar);
                C3805t.j(I02, d10);
                return C4959D.f44058a;
            } catch (Throwable th) {
                C3805t.j(I02, d10);
                throw th;
            }
        }
    }

    /* renamed from: v0.j$c */
    public static final class c extends n implements Na.a<C4959D> {

        /* renamed from: f  reason: collision with root package name */
        public static final c f29052f = new n(0);

        public final /* bridge */ /* synthetic */ Object invoke() {
            return C4959D.f44058a;
        }
    }

    public C3312j(C3305c cVar) {
        this.f29038b = cVar;
        cVar.f28910i = new a(this);
    }

    public final void a(d dVar) {
        e(dVar, 1.0f, (C2880t) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0061, code lost:
        if (r4 != r9) goto L_0x0065;
     */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x005b  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0060  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0164  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0167  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x017f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void e(r0.d r22, float r23, p0.C2880t r24) {
        /*
            r21 = this;
            r0 = r21
            r1 = r22
            r2 = r24
            v0.c r3 = r0.f29038b
            boolean r4 = r3.f28905d
            r5 = 5
            V.r0 r6 = r0.f29043g
            r7 = 1
            if (r4 == 0) goto L_0x0044
            long r9 = r3.f28906e
            r11 = 16
            int r4 = (r9 > r11 ? 1 : (r9 == r11 ? 0 : -1))
            if (r4 == 0) goto L_0x0044
            java.lang.Object r4 = r6.getValue()
            p0.t r4 = (p0.C2880t) r4
            int r9 = v0.C3314l.f29064a
            boolean r9 = r4 instanceof p0.C2872l
            r10 = 3
            if (r9 == 0) goto L_0x002f
            p0.l r4 = (p0.C2872l) r4
            int r4 = r4.f26389c
            if (r4 != r5) goto L_0x002c
            goto L_0x0031
        L_0x002c:
            if (r4 != r10) goto L_0x0044
            goto L_0x0031
        L_0x002f:
            if (r4 != 0) goto L_0x0044
        L_0x0031:
            boolean r4 = r2 instanceof p0.C2872l
            if (r4 == 0) goto L_0x0040
            r4 = r2
            p0.l r4 = (p0.C2872l) r4
            int r4 = r4.f26389c
            if (r4 != r5) goto L_0x003d
            goto L_0x0042
        L_0x003d:
            if (r4 != r10) goto L_0x0044
            goto L_0x0042
        L_0x0040:
            if (r2 != 0) goto L_0x0044
        L_0x0042:
            r4 = r7
            goto L_0x0045
        L_0x0044:
            r4 = 0
        L_0x0045:
            boolean r9 = r0.f29040d
            v0.a r10 = r0.f29041e
            if (r9 != 0) goto L_0x0065
            long r11 = r0.f29046j
            long r13 = r1.v()
            boolean r9 = o0.C2749e.a(r11, r13)
            if (r9 == 0) goto L_0x0065
            p0.e r9 = r10.f28895a
            if (r9 == 0) goto L_0x0060
            int r9 = r9.a()
            goto L_0x0061
        L_0x0060:
            r9 = 0
        L_0x0061:
            if (r4 != r9) goto L_0x0065
            goto L_0x0162
        L_0x0065:
            if (r4 != r7) goto L_0x006f
            long r11 = r3.f28906e
            p0.l r3 = new p0.l
            r3.<init>(r11, r5)
            goto L_0x0070
        L_0x006f:
            r3 = 0
        L_0x0070:
            r0.f29044h = r3
            long r11 = r1.v()
            r3 = 32
            long r11 = r11 >> r3
            int r5 = (int) r11
            float r5 = java.lang.Float.intBitsToFloat(r5)
            V.r0 r7 = r0.f29045i
            java.lang.Object r9 = r7.getValue()
            o0.e r9 = (o0.C2749e) r9
            long r11 = r9.f25781a
            long r11 = r11 >> r3
            int r9 = (int) r11
            float r9 = java.lang.Float.intBitsToFloat(r9)
            float r5 = r5 / r9
            r0.f29047k = r5
            long r11 = r1.v()
            r13 = 4294967295(0xffffffff, double:2.1219957905E-314)
            long r11 = r11 & r13
            int r5 = (int) r11
            float r5 = java.lang.Float.intBitsToFloat(r5)
            java.lang.Object r7 = r7.getValue()
            o0.e r7 = (o0.C2749e) r7
            long r11 = r7.f25781a
            long r11 = r11 & r13
            int r7 = (int) r11
            float r7 = java.lang.Float.intBitsToFloat(r7)
            float r5 = r5 / r7
            r0.f29048l = r5
            long r11 = r1.v()
            long r11 = r11 >> r3
            int r5 = (int) r11
            float r5 = java.lang.Float.intBitsToFloat(r5)
            double r11 = (double) r5
            double r11 = java.lang.Math.ceil(r11)
            float r5 = (float) r11
            int r5 = (int) r5
            long r11 = r1.v()
            long r11 = r11 & r13
            int r7 = (int) r11
            float r7 = java.lang.Float.intBitsToFloat(r7)
            double r11 = (double) r7
            double r11 = java.lang.Math.ceil(r11)
            float r7 = (float) r11
            int r7 = (int) r7
            long r11 = (long) r5
            long r11 = r11 << r3
            r15 = r13
            long r13 = (long) r7
            long r13 = r13 & r15
            long r11 = r11 | r13
            e1.m r5 = r1.getLayoutDirection()
            r10.f28897c = r1
            p0.e r7 = r10.f28895a
            p0.b r9 = r10.f28896b
            if (r7 == 0) goto L_0x0104
            if (r9 == 0) goto L_0x0104
            long r13 = r11 >> r3
            int r13 = (int) r13
            android.graphics.Bitmap r14 = r7.f26377a
            r17 = r3
            int r3 = r14.getWidth()
            if (r13 > r3) goto L_0x0106
            r13 = r9
            long r8 = r11 & r15
            int r8 = (int) r8
            int r9 = r14.getHeight()
            if (r8 > r9) goto L_0x0106
            int r8 = r10.f28899e
            if (r8 != r4) goto L_0x0106
            r9 = r13
            goto L_0x011a
        L_0x0104:
            r17 = r3
        L_0x0106:
            long r7 = r11 >> r17
            int r7 = (int) r7
            long r8 = r11 & r15
            int r8 = (int) r8
            p0.e r7 = jb.C4572j.b(r7, r8, r4)
            p0.b r9 = j4.C2564e.b(r7)
            r10.f28895a = r7
            r10.f28896b = r9
            r10.f28899e = r4
        L_0x011a:
            r10.f28898d = r11
            long r11 = V6.b.u(r11)
            r0.a r13 = r10.f28900f
            r0.a$a r4 = r13.f27302f
            e1.c r8 = r4.f27305a
            e1.m r14 = r4.f27306b
            p0.p r15 = r4.f27307c
            long r2 = r4.f27308d
            r4.f27305a = r1
            r4.f27306b = r5
            r4.f27307c = r9
            r4.f27308d = r11
            r9.f()
            r4 = r14
            r5 = r15
            long r14 = p0.C2879s.f26398b
            r16 = 0
            r18 = 0
            r20 = 62
            D2.B.r(r13, r14, r16, r18, r20)
            v0.j$b r11 = r0.f29049m
            r11.invoke(r13)
            r9.t()
            r0.a$a r9 = r13.f27302f
            r9.f27305a = r8
            r9.f27306b = r4
            r9.f27307c = r5
            r9.f27308d = r2
            r7.b()
            r3 = 0
            r0.f29040d = r3
            long r2 = r1.v()
            r0.f29046j = r2
        L_0x0162:
            if (r24 == 0) goto L_0x0167
            r8 = r24
            goto L_0x017a
        L_0x0167:
            java.lang.Object r2 = r6.getValue()
            p0.t r2 = (p0.C2880t) r2
            if (r2 == 0) goto L_0x0177
            java.lang.Object r2 = r6.getValue()
            p0.t r2 = (p0.C2880t) r2
        L_0x0175:
            r8 = r2
            goto L_0x017a
        L_0x0177:
            p0.l r2 = r0.f29044h
            goto L_0x0175
        L_0x017a:
            p0.e r2 = r10.f28895a
            if (r2 == 0) goto L_0x017f
            goto L_0x0184
        L_0x017f:
            java.lang.String r3 = "drawCachedImage must be invoked first before attempting to draw the result into another destination"
            E0.a.b(r3)
        L_0x0184:
            long r3 = r10.f28898d
            r5 = 0
            r10 = 858(0x35a, float:1.202E-42)
            r9 = 0
            r7 = r23
            D2.B.l(r1, r2, r3, r5, r7, r8, r9, r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: v0.C3312j.e(r0.d, float, p0.t):void");
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Params: \tname: ");
        sb2.append(this.f29039c);
        sb2.append("\n\tviewportWidth: ");
        C1187r0 r0Var = this.f29045i;
        sb2.append(Float.intBitsToFloat((int) (((C2749e) r0Var.getValue()).f25781a >> 32)));
        sb2.append("\n\tviewportHeight: ");
        sb2.append(Float.intBitsToFloat((int) (((C2749e) r0Var.getValue()).f25781a & 4294967295L)));
        sb2.append("\n");
        String sb3 = sb2.toString();
        kotlin.jvm.internal.l.e(sb3, "toString(...)");
        return sb3;
    }
}
