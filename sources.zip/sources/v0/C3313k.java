package v0;

import D1.c;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.l;

/* renamed from: v0.k  reason: case insensitive filesystem */
public final class C3313k extends C3315m implements Iterable<C3315m>, Oa.a {

    /* renamed from: E  reason: collision with root package name */
    public final float f29053E;

    /* renamed from: F  reason: collision with root package name */
    public final float f29054F;

    /* renamed from: G  reason: collision with root package name */
    public final float f29055G;

    /* renamed from: H  reason: collision with root package name */
    public final float f29056H;

    /* renamed from: I  reason: collision with root package name */
    public final float f29057I;

    /* renamed from: J  reason: collision with root package name */
    public final List<C3309g> f29058J;

    /* renamed from: K  reason: collision with root package name */
    public final List<C3315m> f29059K;

    /* renamed from: f  reason: collision with root package name */
    public final String f29060f;

    /* renamed from: i  reason: collision with root package name */
    public final float f29061i;

    /* renamed from: z  reason: collision with root package name */
    public final float f29062z;

    /* renamed from: v0.k$a */
    public static final class a implements Iterator<C3315m>, Oa.a {

        /* renamed from: f  reason: collision with root package name */
        public final Iterator<C3315m> f29063f;

        public a(C3313k kVar) {
            this.f29063f = kVar.f29059K.iterator();
        }

        public final boolean hasNext() {
            return this.f29063f.hasNext();
        }

        public final Object next() {
            return this.f29063f.next();
        }

        public final void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public C3313k(String str, float f10, float f11, float f12, float f13, float f14, float f15, float f16, List<? extends C3309g> list, List<? extends C3315m> list2) {
        this.f29060f = str;
        this.f29061i = f10;
        this.f29062z = f11;
        this.f29053E = f12;
        this.f29054F = f13;
        this.f29055G = f14;
        this.f29056H = f15;
        this.f29057I = f16;
        this.f29058J = list;
        this.f29059K = list2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && (obj instanceof C3313k)) {
            C3313k kVar = (C3313k) obj;
            if (l.a(this.f29060f, kVar.f29060f) && this.f29061i == kVar.f29061i && this.f29062z == kVar.f29062z && this.f29053E == kVar.f29053E && this.f29054F == kVar.f29054F && this.f29055G == kVar.f29055G && this.f29056H == kVar.f29056H && this.f29057I == kVar.f29057I && l.a(this.f29058J, kVar.f29058J) && l.a(this.f29059K, kVar.f29059K)) {
                return true;
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int g6 = c.g(c.g(c.g(c.g(c.g(c.g(c.g(this.f29060f.hashCode() * 31, this.f29061i, 31), this.f29062z, 31), this.f29053E, 31), this.f29054F, 31), this.f29055G, 31), this.f29056H, 31), this.f29057I, 31);
        return this.f29059K.hashCode() + ((this.f29058J.hashCode() + g6) * 31);
    }

    public final Iterator<C3315m> iterator() {
        return new a(this);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C3313k() {
        /*
            r11 = this;
            ya.u r9 = ya.u.f44685f
            int r0 = v0.C3314l.f29064a
            r7 = 0
            r8 = 0
            java.lang.String r1 = ""
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 1065353216(0x3f800000, float:1.0)
            r6 = 1065353216(0x3f800000, float:1.0)
            r10 = r9
            r0 = r11
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: v0.C3313k.<init>():void");
    }
}
