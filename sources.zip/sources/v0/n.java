package v0;

import B9.C3805t;
import V.C1184p0;
import V.C1187r0;
import e1.m;
import o0.C2749e;
import p0.C2880t;
import r0.C3018a;
import r0.d;
import u0.C3194c;
import xa.C4959D;

public final class n extends C3194c {

    /* renamed from: G  reason: collision with root package name */
    public final C1187r0 f29065G;

    /* renamed from: H  reason: collision with root package name */
    public final C1187r0 f29066H;

    /* renamed from: I  reason: collision with root package name */
    public final C3312j f29067I;

    /* renamed from: J  reason: collision with root package name */
    public final C1184p0 f29068J;

    /* renamed from: K  reason: collision with root package name */
    public float f29069K;

    /* renamed from: L  reason: collision with root package name */
    public C2880t f29070L;

    /* renamed from: M  reason: collision with root package name */
    public int f29071M;

    public static final class a extends kotlin.jvm.internal.n implements Na.a<C4959D> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ n f29072f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(n nVar) {
            super(0);
            this.f29072f = nVar;
        }

        public final Object invoke() {
            n nVar = this.f29072f;
            int i10 = nVar.f29071M;
            C1184p0 p0Var = nVar.f29068J;
            if (i10 == p0Var.k()) {
                p0Var.j(p0Var.k() + 1);
            }
            return C4959D.f44058a;
        }
    }

    public n() {
        this(new C3305c());
    }

    public final boolean a(float f10) {
        this.f29069K = f10;
        return true;
    }

    public final boolean e(C2880t tVar) {
        this.f29070L = tVar;
        return true;
    }

    public final long h() {
        return ((C2749e) this.f29065G.getValue()).f25781a;
    }

    public final void i(d dVar) {
        C2880t tVar = this.f29070L;
        C3312j jVar = this.f29067I;
        if (tVar == null) {
            tVar = (C2880t) jVar.f29043g.getValue();
        }
        if (!((Boolean) this.f29066H.getValue()).booleanValue() || dVar.getLayoutDirection() != m.f20657i) {
            jVar.e(dVar, this.f29069K, tVar);
        } else {
            long Z02 = dVar.Z0();
            C3018a.b I02 = dVar.I0();
            long d10 = I02.d();
            I02.a().f();
            try {
                I02.f27309a.g(-1.0f, 1.0f, Z02);
                jVar.e(dVar, this.f29069K, tVar);
            } finally {
                C3805t.j(I02, d10);
            }
        }
        this.f29071M = this.f29068J.k();
    }

    public n(C3305c cVar) {
        this.f29065G = R1.a.t(new C2749e(0));
        this.f29066H = R1.a.t(Boolean.FALSE);
        C3312j jVar = new C3312j(cVar);
        jVar.f29042f = new a(this);
        this.f29067I = jVar;
        this.f29068J = new C1184p0(0);
        this.f29069K = 1.0f;
        this.f29071M = -1;
    }
}
