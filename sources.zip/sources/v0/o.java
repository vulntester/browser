package v0;

import D1.c;
import java.util.List;
import kotlin.jvm.internal.l;
import p0.C2874n;

public final class o extends C3315m {

    /* renamed from: E  reason: collision with root package name */
    public final C2874n f29073E;

    /* renamed from: F  reason: collision with root package name */
    public final float f29074F;

    /* renamed from: G  reason: collision with root package name */
    public final C2874n f29075G;

    /* renamed from: H  reason: collision with root package name */
    public final float f29076H;

    /* renamed from: I  reason: collision with root package name */
    public final float f29077I;

    /* renamed from: J  reason: collision with root package name */
    public final int f29078J;

    /* renamed from: K  reason: collision with root package name */
    public final int f29079K;

    /* renamed from: L  reason: collision with root package name */
    public final float f29080L;

    /* renamed from: M  reason: collision with root package name */
    public final float f29081M;

    /* renamed from: N  reason: collision with root package name */
    public final float f29082N;

    /* renamed from: O  reason: collision with root package name */
    public final float f29083O;

    /* renamed from: f  reason: collision with root package name */
    public final String f29084f;

    /* renamed from: i  reason: collision with root package name */
    public final Object f29085i;

    /* renamed from: z  reason: collision with root package name */
    public final int f29086z;

    public o() {
        throw null;
    }

    public o(String str, List list, int i10, C2874n nVar, float f10, C2874n nVar2, float f11, float f12, int i11, int i12, float f13, float f14, float f15, float f16) {
        this.f29084f = str;
        this.f29085i = list;
        this.f29086z = i10;
        this.f29073E = nVar;
        this.f29074F = f10;
        this.f29075G = nVar2;
        this.f29076H = f11;
        this.f29077I = f12;
        this.f29078J = i11;
        this.f29079K = i12;
        this.f29080L = f13;
        this.f29081M = f14;
        this.f29082N = f15;
        this.f29083O = f16;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || o.class != obj.getClass()) {
            return false;
        }
        o oVar = (o) obj;
        if (l.a(this.f29084f, oVar.f29084f) && l.a(this.f29073E, oVar.f29073E) && this.f29074F == oVar.f29074F && l.a(this.f29075G, oVar.f29075G) && this.f29076H == oVar.f29076H && this.f29077I == oVar.f29077I && this.f29078J == oVar.f29078J && this.f29079K == oVar.f29079K && this.f29080L == oVar.f29080L && this.f29081M == oVar.f29081M && this.f29082N == oVar.f29082N && this.f29083O == oVar.f29083O && this.f29086z == oVar.f29086z && l.a(this.f29085i, oVar.f29085i)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i10;
        int hashCode = (this.f29085i.hashCode() + (this.f29084f.hashCode() * 31)) * 31;
        int i11 = 0;
        C2874n nVar = this.f29073E;
        if (nVar != null) {
            i10 = nVar.hashCode();
        } else {
            i10 = 0;
        }
        int g6 = c.g((hashCode + i10) * 31, this.f29074F, 31);
        C2874n nVar2 = this.f29075G;
        if (nVar2 != null) {
            i11 = nVar2.hashCode();
        }
        return c.g(c.g(c.g(c.g((((c.g(c.g((g6 + i11) * 31, this.f29076H, 31), this.f29077I, 31) + this.f29078J) * 31) + this.f29079K) * 31, this.f29080L, 31), this.f29081M, 31), this.f29082N, 31), this.f29083O, 31) + this.f29086z;
    }
}
