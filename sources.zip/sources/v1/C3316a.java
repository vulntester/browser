package v1;

import android.content.pm.PackageInfo;

/* renamed from: v1.a  reason: case insensitive filesystem */
public final class C3316a {
    public static long a(PackageInfo packageInfo) {
        return packageInfo.getLongVersionCode();
    }
}
