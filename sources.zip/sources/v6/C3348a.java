package v6;

import Na.l;
import java.util.Map;
import kotlin.jvm.internal.n;
import xa.C4959D;

/* renamed from: v6.a  reason: case insensitive filesystem */
public final class C3348a extends n implements l<Map<String, ? extends Boolean>, C4959D> {

    /* renamed from: f  reason: collision with root package name */
    public static final C3348a f29437f = new n(1);

    public final Object invoke(Object obj) {
        kotlin.jvm.internal.l.f((Map) obj, "it");
        return C4959D.f44058a;
    }
}
