package v6;

import V.E;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.n;
import v6.g;
import xa.C4959D;

/* renamed from: v6.b  reason: case insensitive filesystem */
public final class C3349b {

    /* renamed from: a  reason: collision with root package name */
    public final List<C3351d> f29438a;

    /* renamed from: b  reason: collision with root package name */
    public final List<e> f29439b;

    /* renamed from: c  reason: collision with root package name */
    public final E f29440c = R1.a.n(new C0282b(this));

    /* renamed from: d  reason: collision with root package name */
    public final E f29441d = R1.a.n(new a(this));

    /* renamed from: e  reason: collision with root package name */
    public C7.a f29442e;

    /* renamed from: v6.b$a */
    public static final class a extends n implements Na.a<Boolean> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3349b f29443f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(C3349b bVar) {
            super(0);
            this.f29443f = bVar;
        }

        public final Object invoke() {
            boolean z10;
            C3349b bVar = this.f29443f;
            List<e> list = bVar.f29439b;
            if (!list.isEmpty()) {
                Iterator<T> it = list.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    g status = ((e) it.next()).getStatus();
                    l.f(status, "<this>");
                    if (!status.equals(g.b.f29455a)) {
                        if (!((List) bVar.f29440c.getValue()).isEmpty()) {
                            z10 = false;
                        }
                    }
                }
                return Boolean.valueOf(z10);
            }
            z10 = true;
            return Boolean.valueOf(z10);
        }
    }

    /* renamed from: v6.b$b  reason: collision with other inner class name */
    public static final class C0282b extends n implements Na.a<List<? extends e>> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3349b f29444f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0282b(C3349b bVar) {
            super(0);
            this.f29444f = bVar;
        }

        public final Object invoke() {
            List<e> list = this.f29444f.f29439b;
            ArrayList arrayList = new ArrayList();
            for (T next : list) {
                if (!l.a(((e) next).getStatus(), g.b.f29455a)) {
                    arrayList.add(next);
                }
            }
            return arrayList;
        }
    }

    /* renamed from: v6.b$c */
    public static final class c extends n implements Na.a<Boolean> {

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ C3349b f29445f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public c(C3349b bVar) {
            super(0);
            this.f29445f = bVar;
        }

        public final Object invoke() {
            boolean z10;
            List<e> list = this.f29445f.f29439b;
            boolean z11 = false;
            if (!list.isEmpty()) {
                Iterator<T> it = list.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    g status = ((e) it.next()).getStatus();
                    l.f(status, "<this>");
                    if (status.equals(g.b.f29455a)) {
                        z10 = false;
                        continue;
                    } else if (status instanceof g.a) {
                        z10 = ((g.a) status).f29454a;
                        continue;
                    } else {
                        throw new RuntimeException();
                    }
                    if (z10) {
                        z11 = true;
                        break;
                    }
                }
            }
            return Boolean.valueOf(z11);
        }
    }

    public C3349b(List<C3351d> list) {
        this.f29438a = list;
        this.f29439b = list;
        R1.a.n(new c(this));
    }

    public final boolean a() {
        return ((Boolean) this.f29441d.getValue()).booleanValue();
    }

    public final void b() {
        C4959D d10;
        C7.a aVar = this.f29442e;
        if (aVar != null) {
            List<e> list = this.f29439b;
            ArrayList arrayList = new ArrayList(ya.n.v(10, list));
            for (e a10 : list) {
                arrayList.add(a10.a());
            }
            aVar.h0(arrayList.toArray(new String[0]));
            d10 = C4959D.f44058a;
        } else {
            d10 = null;
        }
        if (d10 == null) {
            throw new IllegalStateException("ActivityResultLauncher cannot be null");
        }
    }
}
