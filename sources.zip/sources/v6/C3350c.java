package v6;

import Na.l;
import V.I;
import V.J;
import e.C2174b;
import e.C2185m;
import kotlin.jvm.internal.n;

/* renamed from: v6.c  reason: case insensitive filesystem */
public final class C3350c extends n implements l<J, I> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C3351d f29446f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ C2185m<String, Boolean> f29447i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C3350c(C3351d dVar, C2185m<String, Boolean> mVar) {
        super(1);
        this.f29446f = dVar;
        this.f29447i = mVar;
    }

    public final Object invoke(Object obj) {
        kotlin.jvm.internal.l.f((J) obj, "$this$DisposableEffect");
        C3351d dVar = this.f29446f;
        dVar.f29452e = this.f29447i;
        return new C2174b(dVar, 1);
    }
}
