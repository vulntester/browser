package v6;

import R1.a;
import V.C1187r0;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;
import java.lang.reflect.InvocationTargetException;
import kotlin.jvm.internal.l;
import u1.C3195a;
import v6.g;

/* renamed from: v6.d  reason: case insensitive filesystem */
public final class C3351d implements e {

    /* renamed from: a  reason: collision with root package name */
    public final String f29448a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f29449b;

    /* renamed from: c  reason: collision with root package name */
    public final Activity f29450c;

    /* renamed from: d  reason: collision with root package name */
    public final C1187r0 f29451d = a.t(b());

    /* renamed from: e  reason: collision with root package name */
    public C7.a f29452e;

    public C3351d(String str, Context context, Activity activity) {
        l.f(str, "permission");
        this.f29448a = str;
        this.f29449b = context;
        this.f29450c = activity;
    }

    public final String a() {
        return this.f29448a;
    }

    public final g b() {
        boolean shouldShowRequestPermissionRationale;
        boolean z10 = false;
        Context context = this.f29449b;
        String str = this.f29448a;
        l.f(str, "permission");
        if (C3195a.a(context, str) == 0) {
            return g.b.f29455a;
        }
        Activity activity = this.f29450c;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 33 || !TextUtils.equals("android.permission.POST_NOTIFICATIONS", str)) {
            if (i10 >= 32) {
                z10 = activity.shouldShowRequestPermissionRationale(str);
            } else if (i10 == 31) {
                try {
                    PackageManager packageManager = activity.getApplication().getPackageManager();
                    shouldShowRequestPermissionRationale = ((Boolean) PackageManager.class.getMethod("shouldShowRequestPermissionRationale", new Class[]{String.class}).invoke(packageManager, new Object[]{str})).booleanValue();
                } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
                    shouldShowRequestPermissionRationale = activity.shouldShowRequestPermissionRationale(str);
                }
                z10 = shouldShowRequestPermissionRationale;
            } else {
                z10 = activity.shouldShowRequestPermissionRationale(str);
            }
        }
        return new g.a(z10);
    }

    public final void c() {
        this.f29451d.setValue(b());
    }

    public final g getStatus() {
        return (g) this.f29451d.getValue();
    }
}
