package v6;

public interface e {
    String a();

    g getStatus();
}
