package v6;

import Na.l;
import kotlin.jvm.internal.n;
import xa.C4959D;

public final class f extends n implements l<Boolean, C4959D> {

    /* renamed from: f  reason: collision with root package name */
    public static final f f29453f = new n(1);

    public final /* bridge */ /* synthetic */ Object invoke(Object obj) {
        ((Boolean) obj).booleanValue();
        return C4959D.f44058a;
    }
}
