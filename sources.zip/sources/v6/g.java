package v6;

import M.k;

public interface g {

    public static final class a implements g {

        /* renamed from: a  reason: collision with root package name */
        public final boolean f29454a;

        public a(boolean z10) {
            this.f29454a = z10;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if ((obj instanceof a) && this.f29454a == ((a) obj).f29454a) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            boolean z10 = this.f29454a;
            if (z10) {
                return 1;
            }
            return z10 ? 1 : 0;
        }

        public final String toString() {
            return k.n(new StringBuilder("Denied(shouldShowRationale="), this.f29454a, ')');
        }
    }

    public static final class b implements g {

        /* renamed from: a  reason: collision with root package name */
        public static final b f29455a = new Object();
    }
}
