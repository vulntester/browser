package v6;

import V.I;
import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1335m;

public final class h implements I {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C1333k f29456a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ C1335m f29457b;

    public h(C1333k kVar, C1335m mVar) {
        this.f29456a = kVar;
        this.f29457b = mVar;
    }

    public final void dispose() {
        this.f29456a.c(this.f29457b);
    }
}
