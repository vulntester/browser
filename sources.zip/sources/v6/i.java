package v6;

import Na.l;
import V.I;
import V.J;
import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1335m;
import kotlin.jvm.internal.n;

public final class i extends n implements l<J, I> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C1333k f29458f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ C1335m f29459i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public i(C1333k kVar, C1335m mVar) {
        super(1);
        this.f29458f = kVar;
        this.f29459i = mVar;
    }

    public final Object invoke(Object obj) {
        kotlin.jvm.internal.l.f((J) obj, "$this$DisposableEffect");
        C1333k kVar = this.f29458f;
        C1335m mVar = this.f29459i;
        kVar.a(mVar);
        return new h(kVar, mVar);
    }
}
