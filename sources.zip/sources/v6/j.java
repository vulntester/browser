package v6;

import Na.p;
import V.C1169i;
import V6.b;
import androidx.lifecycle.C1333k;
import kotlin.jvm.internal.n;
import xa.C4959D;

public final class j extends n implements p<C1169i, Integer, C4959D> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C3351d f29460f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ C1333k.a f29461i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j(C3351d dVar, C1333k.a aVar, int i10) {
        super(2);
        this.f29460f = dVar;
        this.f29461i = aVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int v10 = b.v(1);
        o.a(this.f29460f, this.f29461i, (C1169i) obj, v10);
        return C4959D.f44058a;
    }
}
