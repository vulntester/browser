package v6;

import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1335m;
import androidx.lifecycle.C1337o;
import kotlin.jvm.internal.l;
import v6.g;

public final class k implements C1335m {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C1333k.a f29462f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ C3351d f29463i;

    public k(C1333k.a aVar, C3351d dVar) {
        this.f29462f = aVar;
        this.f29463i = dVar;
    }

    public final void f(C1337o oVar, C1333k.a aVar) {
        if (aVar == this.f29462f) {
            C3351d dVar = this.f29463i;
            if (!l.a(dVar.getStatus(), g.b.f29455a)) {
                dVar.c();
            }
        }
    }
}
