package v6;

import I0.T;
import V.I;
import V.J;
import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1335m;
import kotlin.jvm.internal.n;

public final class l extends n implements Na.l<J, I> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C1333k f29464f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ C1335m f29465i;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public l(C1333k kVar, C1335m mVar) {
        super(1);
        this.f29464f = kVar;
        this.f29465i = mVar;
    }

    public final Object invoke(Object obj) {
        kotlin.jvm.internal.l.f((J) obj, "$this$DisposableEffect");
        C1333k kVar = this.f29464f;
        C1335m mVar = this.f29465i;
        kVar.a(mVar);
        return new T(1, kVar, mVar);
    }
}
