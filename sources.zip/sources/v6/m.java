package v6;

import Na.p;
import V.C1169i;
import V6.b;
import androidx.lifecycle.C1333k;
import java.util.List;
import kotlin.jvm.internal.n;
import xa.C4959D;

public final class m extends n implements p<C1169i, Integer, C4959D> {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ List<C3351d> f29466f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public m(List list, C1333k.a aVar, int i10) {
        super(2);
        this.f29466f = list;
    }

    public final Object invoke(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int v10 = b.v(9);
        o.b(this.f29466f, (C1169i) obj, v10);
        return C4959D.f44058a;
    }
}
