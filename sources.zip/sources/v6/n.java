package v6;

import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1335m;
import androidx.lifecycle.C1337o;
import java.util.List;
import kotlin.jvm.internal.l;
import v6.g;

public final class n implements C1335m {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C1333k.a f29467f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ List<C3351d> f29468i;

    public n(C1333k.a aVar, List<C3351d> list) {
        this.f29467f = aVar;
        this.f29468i = list;
    }

    public final void f(C1337o oVar, C1333k.a aVar) {
        if (aVar == this.f29467f) {
            for (C3351d next : this.f29468i) {
                if (!l.a(next.getStatus(), g.b.f29455a)) {
                    next.c();
                }
            }
        }
    }
}
