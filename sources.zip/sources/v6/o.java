package v6;

import V.B0;
import V.C1169i;
import V.C1171j;
import V.M;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.lifecycle.C1333k;
import androidx.lifecycle.C1335m;
import androidx.lifecycle.C1337o;
import androidx.lifecycle.C1338p;
import java.util.List;
import kotlin.jvm.internal.l;

public final class o {
    public static final void a(C3351d dVar, C1333k.a aVar, C1169i iVar, int i10) {
        int i11;
        l.f(dVar, "permissionState");
        C1171j q10 = iVar.q(-1770945943);
        if (q10.K(dVar)) {
            i11 = 4;
        } else {
            i11 = 2;
        }
        if (((i11 | i10 | 48) & 91) != 18 || !q10.t()) {
            aVar = C1333k.a.ON_RESUME;
            q10.f(1157296644);
            boolean K10 = q10.K(dVar);
            Object g6 = q10.g();
            if (K10 || g6 == C1169i.a.f10791a) {
                g6 = new k(aVar, dVar);
                q10.E(g6);
            }
            q10.T(false);
            C1335m mVar = (C1335m) g6;
            C1338p W10 = ((C1337o) q10.m(AndroidCompositionLocals_androidKt.getLocalLifecycleOwner())).W();
            M.b(W10, mVar, new i(W10, mVar), q10);
        } else {
            q10.y();
        }
        B0 V10 = q10.V();
        if (V10 != null) {
            V10.f10531d = new j(dVar, aVar, i10);
        }
    }

    public static final void b(List list, C1169i iVar, int i10) {
        C1171j q10 = iVar.q(1533427666);
        C1333k.a aVar = C1333k.a.ON_RESUME;
        q10.f(1157296644);
        boolean K10 = q10.K(list);
        Object g6 = q10.g();
        if (K10 || g6 == C1169i.a.f10791a) {
            g6 = new n(aVar, list);
            q10.E(g6);
        }
        q10.T(false);
        C1335m mVar = (C1335m) g6;
        C1338p W10 = ((C1337o) q10.m(AndroidCompositionLocals_androidKt.getLocalLifecycleOwner())).W();
        M.b(W10, mVar, new l(W10, mVar), q10);
        B0 V10 = q10.V();
        if (V10 != null) {
            V10.f10531d = new m(list, aVar, i10);
        }
    }

    public static final Activity c(Context context) {
        l.f(context, "<this>");
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity) context;
            }
            context = ((ContextWrapper) context).getBaseContext();
            l.e(context, "getBaseContext(...)");
        }
        throw new IllegalStateException("Permissions should be called in the context of an Activity");
    }
}
