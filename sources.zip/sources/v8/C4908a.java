package v8;

/* renamed from: v8.a  reason: case insensitive filesystem */
public interface C4908a {
    StackTraceElement[] c(StackTraceElement[] stackTraceElementArr);
}
