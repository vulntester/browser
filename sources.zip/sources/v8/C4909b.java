package v8;

/* renamed from: v8.b  reason: case insensitive filesystem */
public final class C4909b {

    /* renamed from: a  reason: collision with root package name */
    public final String f43706a;

    /* renamed from: b  reason: collision with root package name */
    public final String f43707b;

    /* renamed from: c  reason: collision with root package name */
    public final StackTraceElement[] f43708c;

    /* renamed from: d  reason: collision with root package name */
    public final C4909b f43709d;

    public C4909b(String str, String str2, StackTraceElement[] stackTraceElementArr, C4909b bVar) {
        this.f43706a = str;
        this.f43707b = str2;
        this.f43708c = stackTraceElementArr;
        this.f43709d = bVar;
    }
}
