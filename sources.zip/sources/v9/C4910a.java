package v9;

import R1.a;
import V.C1186q0;
import V.C1187r0;
import android.graphics.Bitmap;
import android.os.Bundle;

/* renamed from: v9.a  reason: case insensitive filesystem */
public final class C4910a {

    /* renamed from: a  reason: collision with root package name */
    public final int f43710a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f43711b;

    /* renamed from: c  reason: collision with root package name */
    public Bundle f43712c;

    /* renamed from: d  reason: collision with root package name */
    public Bitmap f43713d;

    /* renamed from: e  reason: collision with root package name */
    public final C1186q0 f43714e = new C1186q0(0);

    /* renamed from: f  reason: collision with root package name */
    public final C1187r0 f43715f = a.t("");

    /* renamed from: g  reason: collision with root package name */
    public final C1187r0 f43716g = a.t("");

    public C4910a(int i10, boolean z10) {
        this.f43710a = i10;
        this.f43711b = z10;
    }
}
