package v9;

import A9.o;
import B9.C3783h0;
import B9.Y0;
import R1.a;
import V.C1187r0;
import V.E;
import g0.m;
import java.util.List;
import kotlin.jvm.internal.l;
import ya.r;

/* renamed from: v9.b  reason: case insensitive filesystem */
public final class C4911b {

    /* renamed from: a  reason: collision with root package name */
    public int f43717a;

    /* renamed from: b  reason: collision with root package name */
    public final C1187r0 f43718b;

    /* renamed from: c  reason: collision with root package name */
    public final C1187r0 f43719c;

    /* renamed from: d  reason: collision with root package name */
    public final m<C4910a> f43720d = new m<>();

    /* renamed from: e  reason: collision with root package name */
    public final E f43721e = a.n(new C3783h0(this, 12));

    public C4911b() {
        C1187r0 t10 = a.t(Boolean.FALSE);
        this.f43718b = t10;
        this.f43719c = t10;
    }

    public static void b(C4911b bVar) {
        r.H(bVar.f43720d, new B4.a(bVar, 9));
    }

    public final void a(C4910a aVar) {
        l.f(aVar, "tab");
        m<C4910a> mVar = this.f43720d;
        mVar.remove((Object) aVar);
        if (((List) this.f43721e.getValue()).isEmpty() && !mVar.isEmpty()) {
            this.f43718b.setValue(Boolean.valueOf(!aVar.f43711b));
        }
    }

    public final void c() {
        C1187r0 r0Var = this.f43718b;
        if (((Boolean) r0Var.getValue()).booleanValue()) {
            r.H(this.f43720d, new o(17));
            r0Var.setValue(Boolean.FALSE);
        }
    }

    public final void d() {
        C1187r0 r0Var = this.f43718b;
        if (((Boolean) r0Var.getValue()).booleanValue()) {
            r.H(this.f43720d, new Y0(17));
        }
        r0Var.setValue(Boolean.valueOf(!((Boolean) r0Var.getValue()).booleanValue()));
    }
}
