package va;

import L9.f;
import io.ktor.util.collections.ConcurrentMap;
import j$.util.function.Function$CC;
import java.util.function.Function;

/* renamed from: va.a  reason: case insensitive filesystem */
public final /* synthetic */ class C4912a implements Function {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ f f43722a;

    public /* synthetic */ C4912a(f fVar) {
        this.f43722a = fVar;
    }

    public final /* synthetic */ Function andThen(Function function) {
        return Function$CC.$default$andThen(this, function);
    }

    public final Object apply(Object obj) {
        return ConcurrentMap.computeIfAbsent$lambda$1(this.f43722a, obj);
    }

    public final /* synthetic */ Function compose(Function function) {
        return Function$CC.$default$compose(this, function);
    }
}
