package y2;

/* renamed from: y2.a  reason: case insensitive filesystem */
public final class C3480a implements e {

    /* renamed from: y2.a$a  reason: collision with other inner class name */
    public static final class C0298a extends Exception {
    }
}
