package y2;

import java.util.HashMap;
import l2.q;
import q2.k;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final Object f30690a = new Object();

    public static C3480a a(q.e eVar) {
        new k.a();
        eVar.getClass();
        new HashMap();
        throw null;
    }

    public final e b(q qVar) {
        qVar.f24345b.getClass();
        qVar.f24345b.getClass();
        return e.f30696a;
    }
}
