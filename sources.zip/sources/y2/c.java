package y2;

import java.io.IOException;
import java.util.UUID;
import s2.b;
import y2.d;

public interface c {

    public static class a extends IOException {

        /* renamed from: f  reason: collision with root package name */
        public final int f30691f;

        public a(Throwable th, int i10) {
            super(th);
            this.f30691f = i10;
        }
    }

    UUID a();

    void b(d.a aVar);

    void c(d.a aVar);

    boolean d();

    boolean e(String str);

    b f();

    a getError();

    int getState();
}
