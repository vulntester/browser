package y2;

import I2.C0807w;
import java.util.concurrent.CopyOnWriteArrayList;

public interface d {

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f30692a;

        /* renamed from: b  reason: collision with root package name */
        public final C0807w.b f30693b;

        /* renamed from: c  reason: collision with root package name */
        public final CopyOnWriteArrayList<C0299a> f30694c;

        /* renamed from: y2.d$a$a  reason: collision with other inner class name */
        public static final class C0299a {

            /* renamed from: a  reason: collision with root package name */
            public Object f30695a;
        }

        public a() {
            this(new CopyOnWriteArrayList(), 0, (C0807w.b) null);
        }

        public a(CopyOnWriteArrayList<C0299a> copyOnWriteArrayList, int i10, C0807w.b bVar) {
            this.f30694c = copyOnWriteArrayList;
            this.f30692a = i10;
            this.f30693b = bVar;
        }
    }
}
