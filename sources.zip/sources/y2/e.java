package y2;

import F0.C0637y;
import android.os.Looper;
import l2.n;
import u2.j;
import y2.c;
import y2.d;

public interface e {

    /* renamed from: a  reason: collision with root package name */
    public static final a f30696a = new Object();

    public interface b {

        /* renamed from: C  reason: collision with root package name */
        public static final C0637y f30697C = new C0637y(13);

        void release();
    }

    void a();

    int b(n nVar);

    void c(Looper looper, j jVar);

    c d(d.a aVar, n nVar);

    b e(d.a aVar, n nVar);

    void release();

    public class a implements e {
        public final /* synthetic */ void a() {
        }

        public final int b(n nVar) {
            if (nVar.f24295r != null) {
                return 1;
            }
            return 0;
        }

        public final c d(d.a aVar, n nVar) {
            if (nVar.f24295r == null) {
                return null;
            }
            return new f(new c.a(new Exception(), 6001));
        }

        public final /* synthetic */ b e(d.a aVar, n nVar) {
            return b.f30697C;
        }

        public final /* synthetic */ void release() {
        }

        public final void c(Looper looper, j jVar) {
        }
    }
}
