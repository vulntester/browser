package y2;

import java.util.UUID;
import l2.C2621g;
import s2.b;
import y2.c;
import y2.d;

public final class f implements c {

    /* renamed from: a  reason: collision with root package name */
    public final c.a f30698a;

    public f(c.a aVar) {
        this.f30698a = aVar;
    }

    public final UUID a() {
        return C2621g.f24236a;
    }

    public final boolean d() {
        return false;
    }

    public final boolean e(String str) {
        return false;
    }

    public final b f() {
        return null;
    }

    public final c.a getError() {
        return this.f30698a;
    }

    public final int getState() {
        return 1;
    }

    public final void b(d.a aVar) {
    }

    public final void c(d.a aVar) {
    }
}
