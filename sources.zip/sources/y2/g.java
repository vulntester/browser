package y2;

import android.os.Build;
import s2.b;

public final class g implements b {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f30699a;

    static {
        boolean z10;
        if ("Amazon".equals(Build.MANUFACTURER)) {
            String str = Build.MODEL;
            if ("AFTM".equals(str) || "AFTB".equals(str)) {
                z10 = true;
                f30699a = z10;
            }
        }
        z10 = false;
        f30699a = z10;
    }
}
