package y2;

public final class h extends Exception {
}
