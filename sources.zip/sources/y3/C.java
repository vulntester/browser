package y3;

import R2.C1009e;
import R2.C1013i;
import lc.C4622o;
import o2.C2756B;
import o2.t;
import o2.y;

public final class C extends C1009e {

    public static final class a implements C1009e.f {

        /* renamed from: a  reason: collision with root package name */
        public final y f30709a;

        /* renamed from: b  reason: collision with root package name */
        public final t f30710b = new t();

        /* renamed from: c  reason: collision with root package name */
        public final int f30711c;

        public a(int i10, y yVar) {
            this.f30711c = i10;
            this.f30709a = yVar;
        }

        public final C1009e.C0081e a(C1013i iVar, long j10) {
            long j11;
            C1013i iVar2 = iVar;
            long j12 = iVar2.f8167E;
            int min = (int) Math.min((long) 112800, iVar2.f8173z - j12);
            t tVar = this.f30710b;
            tVar.D(min);
            iVar2.l(tVar.f25885a, 0, min, false);
            int i10 = tVar.f25887c;
            long j13 = -1;
            long j14 = -1;
            long j15 = -9223372036854775807L;
            while (true) {
                if (tVar.a() < 188) {
                    j11 = -9223372036854775807L;
                    break;
                }
                byte[] bArr = tVar.f25885a;
                int i11 = tVar.f25886b;
                while (true) {
                    if (i11 >= i10) {
                        j11 = -9223372036854775807L;
                        break;
                    }
                    j11 = -9223372036854775807L;
                    if (bArr[i11] == 71) {
                        break;
                    }
                    i11++;
                }
                int i12 = i11 + 188;
                if (i12 > i10) {
                    break;
                }
                long w10 = C4622o.w(tVar, i11, this.f30711c);
                if (w10 != j11) {
                    long b10 = this.f30709a.b(w10);
                    if (b10 <= j10) {
                        j15 = b10;
                        if (100000 + j15 > j10) {
                            return new C1009e.C0081e(-9223372036854775807L, j12 + ((long) i11), 0);
                        }
                        j14 = (long) i11;
                    } else if (j15 == j11) {
                        return new C1009e.C0081e(b10, j12, -1);
                    } else {
                        return new C1009e.C0081e(-9223372036854775807L, j12 + j14, 0);
                    }
                }
                tVar.G(i12);
                j13 = (long) i12;
            }
            if (j15 != j11) {
                return new C1009e.C0081e(j15, j12 + j13, -2);
            }
            return C1009e.C0081e.f8150d;
        }

        public final void b() {
            byte[] bArr = C2756B.f25813c;
            t tVar = this.f30710b;
            tVar.getClass();
            tVar.E(bArr.length, bArr);
        }
    }
}
