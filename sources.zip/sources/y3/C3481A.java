package y3;

import R2.p;
import io.ktor.util.cio.ByteBufferPoolKt;
import io.netty.handler.codec.http.HttpObjectDecoder;
import o2.C2756B;
import o2.t;
import o2.y;
import y3.F;

/* renamed from: y3.A  reason: case insensitive filesystem */
public final class C3481A implements F {

    /* renamed from: a  reason: collision with root package name */
    public final z f30700a;

    /* renamed from: b  reason: collision with root package name */
    public final t f30701b = new t(32);

    /* renamed from: c  reason: collision with root package name */
    public int f30702c;

    /* renamed from: d  reason: collision with root package name */
    public int f30703d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f30704e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f30705f;

    public C3481A(z zVar) {
        this.f30700a = zVar;
    }

    public final void a(y yVar, p pVar, F.c cVar) {
        this.f30700a.a(yVar, pVar, cVar);
        this.f30705f = true;
    }

    public final void b() {
        this.f30705f = true;
    }

    public final void c(int i10, t tVar) {
        boolean z10;
        int i11;
        boolean z11;
        if ((i10 & 1) != 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (z10) {
            i11 = tVar.f25886b + tVar.u();
        } else {
            i11 = -1;
        }
        if (this.f30705f) {
            if (z10) {
                this.f30705f = false;
                tVar.G(i11);
                this.f30703d = 0;
            } else {
                return;
            }
        }
        while (tVar.a() > 0) {
            int i12 = this.f30703d;
            t tVar2 = this.f30701b;
            if (i12 < 3) {
                if (i12 == 0) {
                    int u7 = tVar.u();
                    tVar.G(tVar.f25886b - 1);
                    if (u7 == 255) {
                        this.f30705f = true;
                        return;
                    }
                }
                int min = Math.min(tVar.a(), 3 - this.f30703d);
                tVar.f(this.f30703d, tVar2.f25885a, min);
                int i13 = this.f30703d + min;
                this.f30703d = i13;
                if (i13 == 3) {
                    tVar2.G(0);
                    tVar2.F(3);
                    tVar2.H(1);
                    int u10 = tVar2.u();
                    int u11 = tVar2.u();
                    if ((u10 & HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE) != 0) {
                        z11 = true;
                    } else {
                        z11 = false;
                    }
                    this.f30704e = z11;
                    int i14 = (((u10 & 15) << 8) | u11) + 3;
                    this.f30702c = i14;
                    byte[] bArr = tVar2.f25885a;
                    if (bArr.length < i14) {
                        tVar2.b(Math.min(ByteBufferPoolKt.DEFAULT_BUFFER_SIZE, Math.max(i14, bArr.length * 2)));
                    }
                }
            } else {
                int min2 = Math.min(tVar.a(), this.f30702c - this.f30703d);
                tVar.f(this.f30703d, tVar2.f25885a, min2);
                int i15 = this.f30703d + min2;
                this.f30703d = i15;
                int i16 = this.f30702c;
                if (i15 != i16) {
                    continue;
                } else {
                    if (!this.f30704e) {
                        tVar2.F(i16);
                    } else if (C2756B.m(0, i16, -1, tVar2.f25885a) != 0) {
                        this.f30705f = true;
                        return;
                    } else {
                        tVar2.F(this.f30702c - 4);
                    }
                    tVar2.G(0);
                    this.f30700a.c(tVar2);
                    this.f30703d = 0;
                }
            }
        }
    }
}
