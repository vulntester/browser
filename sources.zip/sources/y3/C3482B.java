package y3;

import D2.E;
import I2.K;
import R2.H;
import R2.p;
import f7.M;
import java.util.List;
import l2.n;
import l2.u;
import p2.C2896i;
import y3.F;

/* renamed from: y3.B  reason: case insensitive filesystem */
public final class C3482B {

    /* renamed from: a  reason: collision with root package name */
    public final List<n> f30706a;

    /* renamed from: b  reason: collision with root package name */
    public final H[] f30707b;

    /* renamed from: c  reason: collision with root package name */
    public final C2896i f30708c = new C2896i(new K(this));

    public C3482B(List list) {
        this.f30706a = list;
        this.f30707b = new H[list.size()];
    }

    public final void a(p pVar, F.c cVar) {
        boolean z10;
        int i10 = 0;
        while (true) {
            H[] hArr = this.f30707b;
            if (i10 < hArr.length) {
                cVar.a();
                cVar.b();
                H k10 = pVar.k(cVar.f30756d, 3);
                n nVar = this.f30706a.get(i10);
                String str = nVar.f24291n;
                if ("application/cea-608".equals(str) || "application/cea-708".equals(str)) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                M.g("Invalid closed caption MIME type provided: " + str, z10);
                String str2 = nVar.f24278a;
                if (str2 == null) {
                    cVar.b();
                    str2 = cVar.f30757e;
                }
                n.a aVar = new n.a();
                aVar.f24316a = str2;
                aVar.f24327l = u.p("video/mp2t");
                aVar.f24328m = u.p(str);
                aVar.f24320e = nVar.f24282e;
                aVar.f24319d = nVar.f24281d;
                aVar.f24311H = nVar.f24272I;
                aVar.f24331p = nVar.f24294q;
                E.r(aVar, k10);
                hArr[i10] = k10;
                i10++;
            } else {
                return;
            }
        }
    }
}
