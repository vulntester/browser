package y3;

import R2.C1006b;
import R2.H;
import R2.p;
import U1.c;
import f7.M;
import io.netty.handler.codec.http.HttpObjectDecoder;
import j$.util.Objects;
import l2.n;
import l2.u;
import o2.t;
import y3.F;

/* renamed from: y3.b  reason: case insensitive filesystem */
public final class C3484b implements j {

    /* renamed from: a  reason: collision with root package name */
    public final c f30763a;

    /* renamed from: b  reason: collision with root package name */
    public final t f30764b;

    /* renamed from: c  reason: collision with root package name */
    public final String f30765c;

    /* renamed from: d  reason: collision with root package name */
    public final int f30766d;

    /* renamed from: e  reason: collision with root package name */
    public final String f30767e;

    /* renamed from: f  reason: collision with root package name */
    public String f30768f;

    /* renamed from: g  reason: collision with root package name */
    public H f30769g;

    /* renamed from: h  reason: collision with root package name */
    public int f30770h;

    /* renamed from: i  reason: collision with root package name */
    public int f30771i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f30772j;

    /* renamed from: k  reason: collision with root package name */
    public long f30773k;

    /* renamed from: l  reason: collision with root package name */
    public n f30774l;

    /* renamed from: m  reason: collision with root package name */
    public int f30775m;

    /* renamed from: n  reason: collision with root package name */
    public long f30776n;

    public C3484b(String str) {
        this((String) null, 0, str);
    }

    public final void b() {
        this.f30770h = 0;
        this.f30771i = 0;
        this.f30772j = false;
        this.f30776n = -9223372036854775807L;
    }

    public final void c(t tVar) {
        boolean z10;
        boolean z11;
        M.n(this.f30769g);
        while (tVar.a() > 0) {
            int i10 = this.f30770h;
            t tVar2 = this.f30764b;
            boolean z12 = true;
            if (i10 == 0) {
                while (true) {
                    if (tVar.a() <= 0) {
                        break;
                    } else if (!this.f30772j) {
                        if (tVar.u() == 11) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                        this.f30772j = z11;
                    } else {
                        int u7 = tVar.u();
                        if (u7 == 119) {
                            this.f30772j = false;
                            this.f30770h = 1;
                            byte[] bArr = tVar2.f25885a;
                            bArr[0] = 11;
                            bArr[1] = 119;
                            this.f30771i = 2;
                            break;
                        }
                        if (u7 == 11) {
                            z10 = true;
                        } else {
                            z10 = false;
                        }
                        this.f30772j = z10;
                    }
                }
            } else if (i10 == 1) {
                byte[] bArr2 = tVar2.f25885a;
                int min = Math.min(tVar.a(), 128 - this.f30771i);
                tVar.f(this.f30771i, bArr2, min);
                int i11 = this.f30771i + min;
                this.f30771i = i11;
                if (i11 == 128) {
                    c cVar = this.f30763a;
                    cVar.n(0);
                    C1006b.a b10 = C1006b.b(cVar);
                    n nVar = this.f30774l;
                    int i12 = b10.f8105b;
                    int i13 = b10.f8106c;
                    String str = b10.f8104a;
                    if (nVar == null || i13 != nVar.f24267D || i12 != nVar.f24268E || !Objects.equals(str, nVar.f24291n)) {
                        n.a aVar = new n.a();
                        aVar.f24316a = this.f30768f;
                        aVar.f24327l = u.p(this.f30767e);
                        aVar.f24328m = u.p(str);
                        aVar.f24306C = i13;
                        aVar.f24307D = i12;
                        aVar.f24319d = this.f30765c;
                        aVar.f24321f = this.f30766d;
                        int i14 = b10.f8109f;
                        aVar.f24324i = i14;
                        if ("audio/ac3".equals(str)) {
                            aVar.f24323h = i14;
                        }
                        n nVar2 = new n(aVar);
                        this.f30774l = nVar2;
                        this.f30769g.d(nVar2);
                    }
                    this.f30775m = b10.f8107d;
                    this.f30773k = (((long) b10.f8108e) * 1000000) / ((long) this.f30774l.f24268E);
                    tVar2.G(0);
                    this.f30769g.e(HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE, tVar2);
                    this.f30770h = 2;
                }
            } else if (i10 == 2) {
                int min2 = Math.min(tVar.a(), this.f30775m - this.f30771i);
                this.f30769g.e(min2, tVar);
                int i15 = this.f30771i + min2;
                this.f30771i = i15;
                if (i15 == this.f30775m) {
                    if (this.f30776n == -9223372036854775807L) {
                        z12 = false;
                    }
                    M.m(z12);
                    this.f30769g.b(this.f30776n, 1, this.f30775m, 0, (H.a) null);
                    this.f30776n += this.f30773k;
                    this.f30770h = 0;
                }
            }
        }
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30768f = cVar.f30757e;
        cVar.b();
        this.f30769g = pVar.k(cVar.f30756d, 1);
    }

    public final void f(int i10, long j10) {
        this.f30776n = j10;
    }

    public C3484b(String str, int i10, String str2) {
        c cVar = new c(new byte[HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE], HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE);
        this.f30763a = cVar;
        this.f30764b = new t((byte[]) cVar.f10461d);
        this.f30770h = 0;
        this.f30776n = -9223372036854775807L;
        this.f30765c = str;
        this.f30766d = i10;
        this.f30767e = str2;
    }

    public final void e(boolean z10) {
    }
}
