package y3;

import R2.B;
import R2.C;
import R2.C1013i;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import java.util.List;
import o2.t;
import y3.F;

/* renamed from: y3.c  reason: case insensitive filesystem */
public final class C3485c implements n {

    /* renamed from: a  reason: collision with root package name */
    public final C3486d f30777a = new C3486d((String) null, 0, "audio/ac4");

    /* renamed from: b  reason: collision with root package name */
    public final t f30778b = new t(16384);

    /* renamed from: c  reason: collision with root package name */
    public boolean f30779c;

    public final void a(long j10, long j11) {
        this.f30779c = false;
        this.f30777a.b();
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f30777a.d(pVar, new F.c(0, 1));
        pVar.b();
        pVar.a(new C.b(-9223372036854775807L));
    }

    public final boolean g(o oVar) {
        C1013i iVar;
        int i10;
        t tVar = new t(10);
        int i11 = 0;
        while (true) {
            iVar = (C1013i) oVar;
            iVar.l(tVar.f25885a, 0, 10, false);
            tVar.G(0);
            if (tVar.x() != 4801587) {
                break;
            }
            tVar.H(3);
            int t10 = tVar.t();
            i11 += t10 + 10;
            iVar.b(t10, false);
        }
        iVar.f8169G = 0;
        iVar.b(i11, false);
        int i12 = 0;
        int i13 = i11;
        while (true) {
            int i14 = 7;
            iVar.l(tVar.f25885a, 0, 7, false);
            tVar.G(0);
            int A10 = tVar.A();
            if (A10 == 44096 || A10 == 44097) {
                i12++;
                if (i12 >= 4) {
                    return true;
                }
                byte[] bArr = tVar.f25885a;
                if (bArr.length < 7) {
                    i10 = -1;
                } else {
                    byte b10 = ((bArr[2] & 255) << 8) | (bArr[3] & 255);
                    if (b10 == 65535) {
                        b10 = ((bArr[4] & 255) << 16) | ((bArr[5] & 255) << 8) | (bArr[6] & 255);
                    } else {
                        i14 = 4;
                    }
                    if (A10 == 44097) {
                        i14 += 2;
                    }
                    i10 = b10 + i14;
                }
                if (i10 == -1) {
                    break;
                }
                iVar.b(i10 - 7, false);
            } else {
                iVar.f8169G = 0;
                i13++;
                if (i13 - i11 >= 8192) {
                    break;
                }
                iVar.b(i13, false);
                i12 = 0;
            }
        }
        return false;
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    public final int i(o oVar, B b10) {
        t tVar = this.f30778b;
        int read = ((C1013i) oVar).read(tVar.f25885a, 0, 16384);
        if (read == -1) {
            return -1;
        }
        tVar.G(0);
        tVar.F(read);
        boolean z10 = this.f30779c;
        C3486d dVar = this.f30777a;
        if (!z10) {
            dVar.f30793n = 0;
            this.f30779c = true;
        }
        dVar.c(tVar);
        return 0;
    }

    public final void release() {
    }
}
