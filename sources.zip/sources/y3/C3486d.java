package y3;

import R2.H;
import R2.p;
import U1.c;
import l2.n;
import o2.t;
import y3.F;

/* renamed from: y3.d  reason: case insensitive filesystem */
public final class C3486d implements j {

    /* renamed from: a  reason: collision with root package name */
    public final c f30780a;

    /* renamed from: b  reason: collision with root package name */
    public final t f30781b;

    /* renamed from: c  reason: collision with root package name */
    public final String f30782c;

    /* renamed from: d  reason: collision with root package name */
    public final int f30783d;

    /* renamed from: e  reason: collision with root package name */
    public final String f30784e;

    /* renamed from: f  reason: collision with root package name */
    public String f30785f;

    /* renamed from: g  reason: collision with root package name */
    public H f30786g;

    /* renamed from: h  reason: collision with root package name */
    public int f30787h = 0;

    /* renamed from: i  reason: collision with root package name */
    public int f30788i = 0;

    /* renamed from: j  reason: collision with root package name */
    public boolean f30789j = false;

    /* renamed from: k  reason: collision with root package name */
    public long f30790k;

    /* renamed from: l  reason: collision with root package name */
    public n f30791l;

    /* renamed from: m  reason: collision with root package name */
    public int f30792m;

    /* renamed from: n  reason: collision with root package name */
    public long f30793n = -9223372036854775807L;

    public C3486d(String str, int i10, String str2) {
        c cVar = new c(new byte[16], 16);
        this.f30780a = cVar;
        this.f30781b = new t((byte[]) cVar.f10461d);
        this.f30782c = str;
        this.f30783d = i10;
        this.f30784e = str2;
    }

    public final void b() {
        this.f30787h = 0;
        this.f30788i = 0;
        this.f30789j = false;
        this.f30793n = -9223372036854775807L;
    }

    /* JADX WARNING: Removed duplicated region for block: B:42:0x0112  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0114  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(o2.t r13) {
        /*
            r12 = this;
            R2.H r0 = r12.f30786g
            f7.M.n(r0)
        L_0x0005:
            int r0 = r13.a()
            if (r0 <= 0) goto L_0x0128
            int r0 = r12.f30787h
            o2.t r1 = r12.f30781b
            r2 = 2
            r3 = 1
            r4 = 0
            if (r0 == 0) goto L_0x00e5
            if (r0 == r3) goto L_0x005a
            if (r0 == r2) goto L_0x0019
            goto L_0x0005
        L_0x0019:
            int r0 = r13.a()
            int r1 = r12.f30792m
            int r2 = r12.f30788i
            int r1 = r1 - r2
            int r0 = java.lang.Math.min(r0, r1)
            R2.H r1 = r12.f30786g
            r1.e(r0, r13)
            int r1 = r12.f30788i
            int r1 = r1 + r0
            r12.f30788i = r1
            int r0 = r12.f30792m
            if (r1 != r0) goto L_0x0005
            long r0 = r12.f30793n
            r5 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r0 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r0 == 0) goto L_0x0040
            goto L_0x0041
        L_0x0040:
            r3 = r4
        L_0x0041:
            f7.M.m(r3)
            R2.H r5 = r12.f30786g
            long r6 = r12.f30793n
            int r9 = r12.f30792m
            r11 = 0
            r8 = 1
            r10 = 0
            r5.b(r6, r8, r9, r10, r11)
            long r0 = r12.f30793n
            long r2 = r12.f30790k
            long r0 = r0 + r2
            r12.f30793n = r0
            r12.f30787h = r4
            goto L_0x0005
        L_0x005a:
            byte[] r0 = r1.f25885a
            int r3 = r13.a()
            int r5 = r12.f30788i
            r6 = 16
            int r5 = 16 - r5
            int r3 = java.lang.Math.min(r3, r5)
            int r5 = r12.f30788i
            r13.f(r5, r0, r3)
            int r0 = r12.f30788i
            int r0 = r0 + r3
            r12.f30788i = r0
            if (r0 != r6) goto L_0x0005
            U1.c r0 = r12.f30780a
            r0.n(r4)
            R2.c$b r0 = R2.C1007c.b(r0)
            l2.n r3 = r12.f30791l
            java.lang.String r5 = "audio/ac4"
            int r7 = r0.f8117a
            if (r3 == 0) goto L_0x0097
            int r8 = r3.f24267D
            if (r2 != r8) goto L_0x0097
            int r8 = r3.f24268E
            if (r7 != r8) goto L_0x0097
            java.lang.String r3 = r3.f24291n
            boolean r3 = r5.equals(r3)
            if (r3 != 0) goto L_0x00c6
        L_0x0097:
            l2.n$a r3 = new l2.n$a
            r3.<init>()
            java.lang.String r8 = r12.f30785f
            r3.f24316a = r8
            java.lang.String r8 = r12.f30784e
            java.lang.String r8 = l2.u.p(r8)
            r3.f24327l = r8
            java.lang.String r5 = l2.u.p(r5)
            r3.f24328m = r5
            r3.f24306C = r2
            r3.f24307D = r7
            java.lang.String r5 = r12.f30782c
            r3.f24319d = r5
            int r5 = r12.f30783d
            r3.f24321f = r5
            l2.n r5 = new l2.n
            r5.<init>(r3)
            r12.f30791l = r5
            R2.H r3 = r12.f30786g
            r3.d(r5)
        L_0x00c6:
            int r3 = r0.f8118b
            r12.f30792m = r3
            int r0 = r0.f8119c
            long r7 = (long) r0
            r9 = 1000000(0xf4240, double:4.940656E-318)
            long r7 = r7 * r9
            l2.n r0 = r12.f30791l
            int r0 = r0.f24268E
            long r9 = (long) r0
            long r7 = r7 / r9
            r12.f30790k = r7
            r1.G(r4)
            R2.H r0 = r12.f30786g
            r0.e(r6, r1)
            r12.f30787h = r2
            goto L_0x0005
        L_0x00e5:
            int r0 = r13.a()
            if (r0 <= 0) goto L_0x0005
            boolean r0 = r12.f30789j
            r5 = 172(0xac, float:2.41E-43)
            if (r0 != 0) goto L_0x00fd
            int r0 = r13.u()
            if (r0 != r5) goto L_0x00f9
            r0 = r3
            goto L_0x00fa
        L_0x00f9:
            r0 = r4
        L_0x00fa:
            r12.f30789j = r0
            goto L_0x00e5
        L_0x00fd:
            int r0 = r13.u()
            if (r0 != r5) goto L_0x0105
            r5 = r3
            goto L_0x0106
        L_0x0105:
            r5 = r4
        L_0x0106:
            r12.f30789j = r5
            r5 = 65
            r6 = 64
            if (r0 == r6) goto L_0x0110
            if (r0 != r5) goto L_0x00e5
        L_0x0110:
            if (r0 != r5) goto L_0x0114
            r0 = r3
            goto L_0x0115
        L_0x0114:
            r0 = r4
        L_0x0115:
            r12.f30787h = r3
            byte[] r1 = r1.f25885a
            r7 = -84
            r1[r4] = r7
            if (r0 == 0) goto L_0x0120
            goto L_0x0121
        L_0x0120:
            r5 = r6
        L_0x0121:
            byte r0 = (byte) r5
            r1[r3] = r0
            r12.f30788i = r2
            goto L_0x0005
        L_0x0128:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.C3486d.c(o2.t):void");
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30785f = cVar.f30757e;
        cVar.b();
        this.f30786g = pVar.k(cVar.f30756d, 1);
    }

    public final void f(int i10, long j10) {
        this.f30793n = j10;
    }

    public final void e(boolean z10) {
    }
}
