package y3;

import R2.B;
import R2.C;
import R2.C1013i;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import U1.c;
import f7.M;
import java.util.List;
import o2.t;
import y3.F;

/* renamed from: y3.e  reason: case insensitive filesystem */
public final class C3487e implements n {

    /* renamed from: a  reason: collision with root package name */
    public final C3488f f30794a = new C3488f((String) null, 0, "audio/mp4a-latm", true);

    /* renamed from: b  reason: collision with root package name */
    public final t f30795b = new t(2048);

    /* renamed from: c  reason: collision with root package name */
    public final t f30796c;

    /* renamed from: d  reason: collision with root package name */
    public final c f30797d;

    /* renamed from: e  reason: collision with root package name */
    public p f30798e;

    /* renamed from: f  reason: collision with root package name */
    public long f30799f;

    /* renamed from: g  reason: collision with root package name */
    public long f30800g = -1;

    /* renamed from: h  reason: collision with root package name */
    public boolean f30801h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f30802i;

    public C3487e() {
        t tVar = new t(10);
        this.f30796c = tVar;
        byte[] bArr = tVar.f25885a;
        this.f30797d = new c(bArr, bArr.length);
    }

    public final void a(long j10, long j11) {
        this.f30801h = false;
        this.f30794a.b();
        this.f30799f = j11;
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f30798e = pVar;
        this.f30794a.d(pVar, new F.c(0, 1));
        pVar.b();
    }

    public final boolean g(o oVar) {
        C1013i iVar = (C1013i) oVar;
        int i10 = 0;
        while (true) {
            t tVar = this.f30796c;
            iVar.l(tVar.f25885a, 0, 10, false);
            tVar.G(0);
            if (tVar.x() != 4801587) {
                break;
            }
            tVar.H(3);
            int t10 = tVar.t();
            i10 += t10 + 10;
            iVar.b(t10, false);
        }
        iVar.f8169G = 0;
        iVar.b(i10, false);
        if (this.f30800g == -1) {
            this.f30800g = (long) i10;
        }
        int i11 = i10;
        int i12 = 0;
        int i13 = 0;
        do {
            t tVar2 = this.f30796c;
            iVar.l(tVar2.f25885a, 0, 2, false);
            tVar2.G(0);
            if ((tVar2.A() & 65526) == 65520) {
                i12++;
                if (i12 >= 4 && i13 > 188) {
                    return true;
                }
                iVar.l(tVar2.f25885a, 0, 4, false);
                c cVar = this.f30797d;
                cVar.n(14);
                int h10 = cVar.h(13);
                if (h10 <= 6) {
                    i11++;
                    iVar.f8169G = 0;
                    iVar.b(i11, false);
                } else {
                    iVar.b(h10 - 6, false);
                    i13 += h10;
                }
            } else {
                i11++;
                iVar.f8169G = 0;
                iVar.b(i11, false);
            }
            i12 = 0;
            i13 = 0;
        } while (i11 - i10 < 8192);
        return false;
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    public final int i(o oVar, B b10) {
        boolean z10;
        M.n(this.f30798e);
        long j10 = ((C1013i) oVar).f8173z;
        t tVar = this.f30795b;
        int read = ((C1013i) oVar).read(tVar.f25885a, 0, 2048);
        if (read == -1) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (!this.f30802i) {
            this.f30798e.a(new C.b(-9223372036854775807L));
            this.f30802i = true;
        }
        if (z10) {
            return -1;
        }
        tVar.G(0);
        tVar.F(read);
        boolean z11 = this.f30801h;
        C3488f fVar = this.f30794a;
        if (!z11) {
            fVar.f30824u = this.f30799f;
            this.f30801h = true;
        }
        fVar.c(tVar);
        return 0;
    }

    public final void release() {
    }
}
