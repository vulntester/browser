package y3;

import D2.E;
import R2.C1015k;
import R2.H;
import R2.p;
import U1.c;
import java.util.Arrays;
import l2.n;
import l2.u;
import o2.t;
import y3.F;

/* renamed from: y3.f  reason: case insensitive filesystem */
public final class C3488f implements j {

    /* renamed from: x  reason: collision with root package name */
    public static final byte[] f30803x = {73, 68, 51};

    /* renamed from: a  reason: collision with root package name */
    public final boolean f30804a;

    /* renamed from: b  reason: collision with root package name */
    public final c f30805b = new c(new byte[7], 7);

    /* renamed from: c  reason: collision with root package name */
    public final t f30806c = new t(Arrays.copyOf(f30803x, 10));

    /* renamed from: d  reason: collision with root package name */
    public final String f30807d;

    /* renamed from: e  reason: collision with root package name */
    public final int f30808e;

    /* renamed from: f  reason: collision with root package name */
    public final String f30809f;

    /* renamed from: g  reason: collision with root package name */
    public String f30810g;

    /* renamed from: h  reason: collision with root package name */
    public H f30811h;

    /* renamed from: i  reason: collision with root package name */
    public H f30812i;

    /* renamed from: j  reason: collision with root package name */
    public int f30813j;

    /* renamed from: k  reason: collision with root package name */
    public int f30814k;

    /* renamed from: l  reason: collision with root package name */
    public int f30815l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f30816m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f30817n;

    /* renamed from: o  reason: collision with root package name */
    public int f30818o = -1;

    /* renamed from: p  reason: collision with root package name */
    public int f30819p = -1;

    /* renamed from: q  reason: collision with root package name */
    public int f30820q;

    /* renamed from: r  reason: collision with root package name */
    public boolean f30821r;

    /* renamed from: s  reason: collision with root package name */
    public long f30822s = -9223372036854775807L;

    /* renamed from: t  reason: collision with root package name */
    public int f30823t;

    /* renamed from: u  reason: collision with root package name */
    public long f30824u = -9223372036854775807L;

    /* renamed from: v  reason: collision with root package name */
    public H f30825v;

    /* renamed from: w  reason: collision with root package name */
    public long f30826w;

    public C3488f(String str, int i10, String str2, boolean z10) {
        this.f30804a = z10;
        this.f30807d = str;
        this.f30808e = i10;
        this.f30809f = str2;
        this.f30813j = 0;
        this.f30814k = 0;
        this.f30815l = 256;
    }

    public final void b() {
        this.f30824u = -9223372036854775807L;
        this.f30817n = false;
        this.f30813j = 0;
        this.f30814k = 0;
        this.f30815l = 256;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v7, resolved type: int} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v2, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v24, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v3, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v4, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v5, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v6, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v7, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v8, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v9, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r22v10, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v23, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v24, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v25, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v26, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v27, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v28, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v29, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v30, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v31, resolved type: boolean} */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x022d, code lost:
        r11 = -1;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:151:0x022d A[EDGE_INSN: B:151:0x022d->B:70:0x022d ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x0255  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(o2.t r24) {
        /*
            r23 = this;
            r0 = r23
            r1 = r24
            r2 = 2
            r3 = -1
            r5 = 1
            R2.H r6 = r0.f30811h
            r6.getClass()
            int r6 = o2.C2756B.f25811a
        L_0x000e:
            int r6 = r1.a()
            if (r6 <= 0) goto L_0x0348
            int r6 = r0.f30813j
            U1.c r7 = r0.f30805b
            r8 = 256(0x100, float:3.59E-43)
            r9 = 4
            r10 = 3
            r11 = 0
            r12 = 13
            o2.t r13 = r0.f30806c
            if (r6 == 0) goto L_0x01c5
            if (r6 == r5) goto L_0x0186
            r14 = 10
            if (r6 == r2) goto L_0x014c
            if (r6 == r10) goto L_0x007d
            if (r6 != r9) goto L_0x0077
            int r6 = r1.a()
            int r7 = r0.f30823t
            int r9 = r0.f30814k
            int r7 = r7 - r9
            int r6 = java.lang.Math.min(r6, r7)
            R2.H r7 = r0.f30825v
            r7.e(r6, r1)
            int r7 = r0.f30814k
            int r7 = r7 + r6
            r0.f30814k = r7
            int r6 = r0.f30823t
            if (r7 != r6) goto L_0x000e
            long r6 = r0.f30824u
            r9 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r6 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            if (r6 == 0) goto L_0x0055
            r6 = r5
            goto L_0x0056
        L_0x0055:
            r6 = r11
        L_0x0056:
            f7.M.m(r6)
            R2.H r12 = r0.f30825v
            long r13 = r0.f30824u
            int r6 = r0.f30823t
            r15 = 1
            r17 = 0
            r18 = 0
            r16 = r6
            r12.b(r13, r15, r16, r17, r18)
            long r6 = r0.f30824u
            long r9 = r0.f30826w
            long r6 = r6 + r9
            r0.f30824u = r6
            r0.f30813j = r11
            r0.f30814k = r11
            r0.f30815l = r8
            goto L_0x000e
        L_0x0077:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x007d:
            boolean r6 = r0.f30816m
            r8 = 5
            if (r6 == 0) goto L_0x0084
            r6 = 7
            goto L_0x0085
        L_0x0084:
            r6 = r8
        L_0x0085:
            java.lang.Object r13 = r7.f10461d
            byte[] r13 = (byte[]) r13
            int r15 = r1.a()
            r16 = 7
            int r4 = r0.f30814k
            int r4 = r6 - r4
            int r4 = java.lang.Math.min(r15, r4)
            int r15 = r0.f30814k
            r1.f(r15, r13, r4)
            int r13 = r0.f30814k
            int r13 = r13 + r4
            r0.f30814k = r13
            if (r13 != r6) goto L_0x000e
            r7.n(r11)
            boolean r4 = r0.f30821r
            if (r4 != 0) goto L_0x012a
            int r4 = r7.h(r2)
            int r4 = r4 + r5
            if (r4 == r2) goto L_0x00ca
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String r13 = "Detected audio object type: "
            r6.<init>(r13)
            r6.append(r4)
            java.lang.String r4 = ", but assuming AAC LC."
            r6.append(r4)
            java.lang.String r4 = r6.toString()
            java.lang.String r6 = "AdtsReader"
            o2.n.f(r6, r4)
            r4 = r2
        L_0x00ca:
            r7.p(r8)
            int r6 = r7.h(r10)
            int r8 = r0.f30819p
            byte[] r4 = R2.C1005a.a(r4, r8, r6)
            U1.c r6 = new U1.c
            r6.<init>(r4, r2)
            R2.a$a r6 = R2.C1005a.c(r6, r11)
            l2.n$a r8 = new l2.n$a
            r8.<init>()
            java.lang.String r10 = r0.f30810g
            r8.f24316a = r10
            java.lang.String r10 = r0.f30809f
            java.lang.String r10 = l2.u.p(r10)
            r8.f24327l = r10
            java.lang.String r10 = "audio/mp4a-latm"
            java.lang.String r10 = l2.u.p(r10)
            r8.f24328m = r10
            java.lang.String r10 = r6.f8097c
            r8.f24325j = r10
            int r10 = r6.f8096b
            r8.f24306C = r10
            int r6 = r6.f8095a
            r8.f24307D = r6
            java.util.List r4 = java.util.Collections.singletonList(r4)
            r8.f24331p = r4
            java.lang.String r4 = r0.f30807d
            r8.f24319d = r4
            int r4 = r0.f30808e
            r8.f24321f = r4
            l2.n r4 = new l2.n
            r4.<init>(r8)
            int r6 = r4.f24268E
            long r13 = (long) r6
            r17 = 1024000000(0x3d090000, double:5.059232213E-315)
            long r13 = r17 / r13
            r0.f30822s = r13
            R2.H r6 = r0.f30811h
            r6.d(r4)
            r0.f30821r = r5
            goto L_0x012d
        L_0x012a:
            r7.p(r14)
        L_0x012d:
            r7.p(r9)
            int r4 = r7.h(r12)
            int r6 = r4 + -7
            boolean r7 = r0.f30816m
            if (r7 == 0) goto L_0x013c
            int r6 = r4 + -9
        L_0x013c:
            R2.H r4 = r0.f30811h
            long r7 = r0.f30822s
            r0.f30813j = r9
            r0.f30814k = r11
            r0.f30825v = r4
            r0.f30826w = r7
            r0.f30823t = r6
            goto L_0x000e
        L_0x014c:
            r16 = 7
            byte[] r4 = r13.f25885a
            int r6 = r1.a()
            int r7 = r0.f30814k
            int r7 = 10 - r7
            int r6 = java.lang.Math.min(r6, r7)
            int r7 = r0.f30814k
            r1.f(r7, r4, r6)
            int r4 = r0.f30814k
            int r4 = r4 + r6
            r0.f30814k = r4
            if (r4 != r14) goto L_0x000e
            R2.H r4 = r0.f30812i
            r4.e(r14, r13)
            r4 = 6
            r13.G(r4)
            R2.H r4 = r0.f30812i
            int r6 = r13.t()
            int r6 = r6 + r14
            r0.f30813j = r9
            r0.f30814k = r14
            r0.f30825v = r4
            r7 = 0
            r0.f30826w = r7
            r0.f30823t = r6
            goto L_0x000e
        L_0x0186:
            r16 = 7
            int r4 = r1.a()
            if (r4 != 0) goto L_0x0190
            goto L_0x000e
        L_0x0190:
            java.lang.Object r4 = r7.f10461d
            byte[] r4 = (byte[]) r4
            byte[] r6 = r1.f25885a
            int r12 = r1.f25886b
            byte r6 = r6[r12]
            r4[r11] = r6
            r7.n(r2)
            int r4 = r7.h(r9)
            int r6 = r0.f30819p
            if (r6 == r3) goto L_0x01b3
            if (r4 == r6) goto L_0x01b3
            r0.f30817n = r11
            r0.f30813j = r11
            r0.f30814k = r11
            r0.f30815l = r8
            goto L_0x000e
        L_0x01b3:
            boolean r6 = r0.f30817n
            if (r6 != 0) goto L_0x01bf
            r0.f30817n = r5
            int r6 = r0.f30820q
            r0.f30818o = r6
            r0.f30819p = r4
        L_0x01bf:
            r0.f30813j = r10
            r0.f30814k = r11
            goto L_0x000e
        L_0x01c5:
            r16 = 7
            byte[] r4 = r1.f25885a
            int r6 = r1.f25886b
            int r14 = r1.f25887c
        L_0x01cd:
            if (r6 >= r14) goto L_0x033d
            int r15 = r6 + 1
            byte r8 = r4[r6]
            r18 = r10
            r10 = r8 & 255(0xff, float:3.57E-43)
            int r12 = r0.f30815l
            r2 = 512(0x200, float:7.175E-43)
            if (r12 != r2) goto L_0x02de
            byte r12 = (byte) r10
            r12 = r12 & 255(0xff, float:3.57E-43)
            r20 = 65280(0xff00, float:9.1477E-41)
            r12 = r20 | r12
            r21 = 65526(0xfff6, float:9.1821E-41)
            r12 = r12 & r21
            r2 = 65520(0xfff0, float:9.1813E-41)
            if (r12 != r2) goto L_0x02de
            boolean r12 = r0.f30817n
            if (r12 != 0) goto L_0x02b0
            int r12 = r6 + -1
            r1.G(r6)
            java.lang.Object r2 = r7.f10461d
            byte[] r2 = (byte[]) r2
            int r3 = r1.a()
            if (r3 >= r5) goto L_0x0207
            r22 = r5
        L_0x0204:
            r11 = -1
            goto L_0x02ad
        L_0x0207:
            r1.f(r11, r2, r5)
            r7.n(r9)
            int r2 = r7.h(r5)
            int r3 = r0.f30818o
            r9 = -1
            if (r3 == r9) goto L_0x021d
            if (r2 == r3) goto L_0x021d
            r22 = r5
            r11 = r9
            goto L_0x02ad
        L_0x021d:
            int r3 = r0.f30819p
            if (r3 == r9) goto L_0x0247
            java.lang.Object r3 = r7.f10461d
            byte[] r3 = (byte[]) r3
            int r9 = r1.a()
            if (r9 >= r5) goto L_0x0230
            r22 = r5
        L_0x022d:
            r11 = -1
            goto L_0x02b3
        L_0x0230:
            r1.f(r11, r3, r5)
            r3 = 2
            r7.n(r3)
            r3 = 4
            int r9 = r7.h(r3)
            r22 = r5
            int r5 = r0.f30819p
            if (r9 == r5) goto L_0x0243
        L_0x0242:
            goto L_0x0204
        L_0x0243:
            r1.G(r15)
            goto L_0x024a
        L_0x0247:
            r22 = r5
            r3 = 4
        L_0x024a:
            java.lang.Object r5 = r7.f10461d
            byte[] r5 = (byte[]) r5
            int r9 = r1.a()
            if (r9 >= r3) goto L_0x0255
        L_0x0254:
            goto L_0x022d
        L_0x0255:
            r1.f(r11, r5, r3)
            r5 = 14
            r7.n(r5)
            r5 = 13
            int r9 = r7.h(r5)
            r3 = r16
            if (r9 >= r3) goto L_0x0268
            goto L_0x0242
        L_0x0268:
            byte[] r3 = r1.f25885a
            int r5 = r1.f25887c
            int r12 = r12 + r9
            if (r12 < r5) goto L_0x0270
            goto L_0x0254
        L_0x0270:
            byte r9 = r3[r12]
            r11 = -1
            if (r9 != r11) goto L_0x028e
            int r12 = r12 + 1
            if (r12 != r5) goto L_0x027a
            goto L_0x02b3
        L_0x027a:
            byte r3 = r3[r12]
            r5 = r3 & 255(0xff, float:3.57E-43)
            r5 = r20 | r5
            r5 = r5 & r21
            r9 = 65520(0xfff0, float:9.1813E-41)
            if (r5 != r9) goto L_0x02ad
            r3 = r3 & 8
            int r3 = r3 >> 3
            if (r3 != r2) goto L_0x02ad
            goto L_0x02b3
        L_0x028e:
            r2 = 73
            if (r9 == r2) goto L_0x0293
            goto L_0x02ad
        L_0x0293:
            int r2 = r12 + 1
            if (r2 != r5) goto L_0x0298
            goto L_0x02b3
        L_0x0298:
            byte r2 = r3[r2]
            r9 = 68
            if (r2 == r9) goto L_0x029f
            goto L_0x02ad
        L_0x029f:
            r19 = 2
            int r12 = r12 + 2
            if (r12 != r5) goto L_0x02a6
            goto L_0x02b3
        L_0x02a6:
            byte r2 = r3[r12]
            r3 = 51
            if (r2 != r3) goto L_0x02ad
            goto L_0x02b3
        L_0x02ad:
            r2 = r22
            goto L_0x02e0
        L_0x02b0:
            r11 = r3
            r22 = r5
        L_0x02b3:
            r2 = r8 & 8
            int r2 = r2 >> 3
            r0.f30820q = r2
            r2 = r8 & 1
            if (r2 != 0) goto L_0x02c0
            r2 = r22
            goto L_0x02c1
        L_0x02c0:
            r2 = 0
        L_0x02c1:
            r0.f30816m = r2
            boolean r2 = r0.f30817n
            if (r2 != 0) goto L_0x02cf
            r2 = r22
            r0.f30813j = r2
            r3 = 0
            r0.f30814k = r3
            goto L_0x02d8
        L_0x02cf:
            r4 = r18
            r2 = r22
            r3 = 0
            r0.f30813j = r4
            r0.f30814k = r3
        L_0x02d8:
            r1.G(r15)
            r3 = 2
            goto L_0x0343
        L_0x02de:
            r11 = r3
            r2 = r5
        L_0x02e0:
            int r3 = r0.f30815l
            r5 = r3 | r10
            r8 = 329(0x149, float:4.61E-43)
            if (r5 == r8) goto L_0x0326
            r8 = 511(0x1ff, float:7.16E-43)
            if (r5 == r8) goto L_0x031c
            r8 = 836(0x344, float:1.171E-42)
            if (r5 == r8) goto L_0x0312
            r8 = 1075(0x433, float:1.506E-42)
            if (r5 == r8) goto L_0x0302
            r5 = 256(0x100, float:3.59E-43)
            if (r3 == r5) goto L_0x02fe
            r0.f30815l = r5
            r3 = 2
            r8 = 3
            r9 = 0
            goto L_0x0330
        L_0x02fe:
            r3 = 2
            r8 = 3
            r9 = 0
            goto L_0x032f
        L_0x0302:
            r3 = 2
            r0.f30813j = r3
            r8 = 3
            r0.f30814k = r8
            r9 = 0
            r0.f30823t = r9
            r13.G(r9)
            r1.G(r15)
            goto L_0x0343
        L_0x0312:
            r3 = 2
            r5 = 256(0x100, float:3.59E-43)
            r8 = 3
            r9 = 0
            r6 = 1024(0x400, float:1.435E-42)
            r0.f30815l = r6
            goto L_0x032f
        L_0x031c:
            r3 = 2
            r5 = 256(0x100, float:3.59E-43)
            r6 = 512(0x200, float:7.175E-43)
            r8 = 3
            r9 = 0
            r0.f30815l = r6
            goto L_0x032f
        L_0x0326:
            r3 = 2
            r5 = 256(0x100, float:3.59E-43)
            r8 = 3
            r9 = 0
            r6 = 768(0x300, float:1.076E-42)
            r0.f30815l = r6
        L_0x032f:
            r6 = r15
        L_0x0330:
            r10 = r8
            r12 = 13
            r16 = 7
            r8 = r5
            r5 = r2
            r2 = r3
            r3 = r11
            r11 = r9
            r9 = 4
            goto L_0x01cd
        L_0x033d:
            r11 = r3
            r3 = r2
            r2 = r5
            r1.G(r6)
        L_0x0343:
            r5 = r2
            r2 = r3
            r3 = r11
            goto L_0x000e
        L_0x0348:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.C3488f.c(o2.t):void");
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30810g = cVar.f30757e;
        cVar.b();
        H k10 = pVar.k(cVar.f30756d, 1);
        this.f30811h = k10;
        this.f30825v = k10;
        if (this.f30804a) {
            cVar.a();
            cVar.b();
            H k11 = pVar.k(cVar.f30756d, 5);
            this.f30812i = k11;
            n.a aVar = new n.a();
            cVar.b();
            aVar.f24316a = cVar.f30757e;
            aVar.f24327l = u.p(this.f30809f);
            aVar.f24328m = u.p("application/id3");
            E.r(aVar, k11);
            return;
        }
        this.f30812i = new C1015k();
    }

    public final void f(int i10, long j10) {
        this.f30824u = j10;
    }

    public final void e(boolean z10) {
    }
}
