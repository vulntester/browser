package y3;

import io.netty.handler.codec.http.HttpObjectDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import l2.n;
import l2.u;
import o2.d;
import o2.t;
import y3.F;

/* renamed from: y3.g  reason: case insensitive filesystem */
public final class C3489g {

    /* renamed from: a  reason: collision with root package name */
    public final int f30827a;

    /* renamed from: b  reason: collision with root package name */
    public final List<n> f30828b;

    public C3489g(int i10, List<n> list) {
        this.f30827a = i10;
        this.f30828b = list;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:34:0x006b, code lost:
        return new y3.v(new y3.C3484b(r3, r7.a(), "video/mp2t"));
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final y3.F a(int r6, y3.F.b r7) {
        /*
            r5 = this;
            r0 = 2
            java.lang.String r1 = "video/mp2t"
            if (r6 == r0) goto L_0x015a
            r2 = 3
            java.lang.String r3 = r7.f30749a
            if (r6 == r2) goto L_0x014b
            r2 = 4
            if (r6 == r2) goto L_0x014b
            r4 = 21
            if (r6 == r4) goto L_0x0140
            r4 = 27
            if (r6 == r4) goto L_0x0119
            r2 = 36
            if (r6 == r2) goto L_0x0105
            r2 = 45
            if (r6 == r2) goto L_0x00fa
            r2 = 89
            if (r6 == r2) goto L_0x00ed
            r2 = 172(0xac, float:2.41E-43)
            if (r6 == r2) goto L_0x00de
            r2 = 257(0x101, float:3.6E-43)
            if (r6 == r2) goto L_0x00d1
            r2 = 138(0x8a, float:1.93E-43)
            if (r6 == r2) goto L_0x00c0
            r2 = 139(0x8b, float:1.95E-43)
            if (r6 == r2) goto L_0x00af
            switch(r6) {
                case 15: goto L_0x0097;
                case 16: goto L_0x0083;
                case 17: goto L_0x006c;
                default: goto L_0x0034;
            }
        L_0x0034:
            switch(r6) {
                case 128: goto L_0x015a;
                case 129: goto L_0x005d;
                case 130: goto L_0x0053;
                default: goto L_0x0037;
            }
        L_0x0037:
            switch(r6) {
                case 134: goto L_0x003c;
                case 135: goto L_0x005d;
                case 136: goto L_0x00c0;
                default: goto L_0x003a;
            }
        L_0x003a:
            goto L_0x011f
        L_0x003c:
            r6 = 16
            boolean r6 = r5.c(r6)
            if (r6 == 0) goto L_0x0046
            goto L_0x011f
        L_0x0046:
            y3.A r6 = new y3.A
            y3.u r7 = new y3.u
            java.lang.String r0 = "application/x-scte35"
            r7.<init>(r0)
            r6.<init>(r7)
            return r6
        L_0x0053:
            r6 = 64
            boolean r6 = r5.c(r6)
            if (r6 != 0) goto L_0x00c0
            goto L_0x011f
        L_0x005d:
            y3.v r6 = new y3.v
            y3.b r0 = new y3.b
            int r7 = r7.a()
            r0.<init>(r3, r7, r1)
            r6.<init>(r0)
            return r6
        L_0x006c:
            boolean r6 = r5.c(r0)
            if (r6 == 0) goto L_0x0074
            goto L_0x011f
        L_0x0074:
            y3.v r6 = new y3.v
            y3.p r0 = new y3.p
            int r7 = r7.a()
            r0.<init>(r3, r7)
            r6.<init>(r0)
            return r6
        L_0x0083:
            y3.v r6 = new y3.v
            y3.l r0 = new y3.l
            y3.G r1 = new y3.G
            java.util.List r7 = r5.b(r7)
            r1.<init>(r7)
            r0.<init>(r1)
            r6.<init>(r0)
            return r6
        L_0x0097:
            boolean r6 = r5.c(r0)
            if (r6 == 0) goto L_0x009f
            goto L_0x011f
        L_0x009f:
            y3.v r6 = new y3.v
            y3.f r0 = new y3.f
            int r7 = r7.a()
            r2 = 0
            r0.<init>(r3, r7, r1, r2)
            r6.<init>(r0)
            return r6
        L_0x00af:
            y3.v r6 = new y3.v
            y3.h r0 = new y3.h
            int r7 = r7.a()
            r1 = 5408(0x1520, float:7.578E-42)
            r0.<init>(r3, r7, r1)
            r6.<init>(r0)
            return r6
        L_0x00c0:
            y3.v r6 = new y3.v
            y3.h r0 = new y3.h
            int r7 = r7.a()
            r1 = 4096(0x1000, float:5.74E-42)
            r0.<init>(r3, r7, r1)
            r6.<init>(r0)
            return r6
        L_0x00d1:
            y3.A r6 = new y3.A
            y3.u r7 = new y3.u
            java.lang.String r0 = "application/vnd.dvb.ait"
            r7.<init>(r0)
            r6.<init>(r7)
            return r6
        L_0x00de:
            y3.v r6 = new y3.v
            y3.d r0 = new y3.d
            int r7 = r7.a()
            r0.<init>(r3, r7, r1)
            r6.<init>(r0)
            return r6
        L_0x00ed:
            y3.v r6 = new y3.v
            y3.i r0 = new y3.i
            java.util.List<y3.F$a> r7 = r7.f30751c
            r0.<init>(r7)
            r6.<init>(r0)
            return r6
        L_0x00fa:
            y3.v r6 = new y3.v
            y3.r r7 = new y3.r
            r7.<init>()
            r6.<init>(r7)
            return r6
        L_0x0105:
            y3.v r6 = new y3.v
            y3.n r0 = new y3.n
            y3.B r1 = new y3.B
            java.util.List r7 = r5.b(r7)
            r1.<init>(r7)
            r0.<init>(r1)
            r6.<init>(r0)
            return r6
        L_0x0119:
            boolean r6 = r5.c(r2)
            if (r6 == 0) goto L_0x0121
        L_0x011f:
            r6 = 0
            return r6
        L_0x0121:
            y3.v r6 = new y3.v
            y3.m r0 = new y3.m
            y3.B r1 = new y3.B
            java.util.List r7 = r5.b(r7)
            r1.<init>(r7)
            r7 = 1
            boolean r7 = r5.c(r7)
            r2 = 8
            boolean r2 = r5.c(r2)
            r0.<init>(r1, r7, r2)
            r6.<init>(r0)
            return r6
        L_0x0140:
            y3.v r6 = new y3.v
            y3.o r7 = new y3.o
            r7.<init>()
            r6.<init>(r7)
            return r6
        L_0x014b:
            y3.v r6 = new y3.v
            y3.q r0 = new y3.q
            int r7 = r7.a()
            r0.<init>(r3, r7, r1)
            r6.<init>(r0)
            return r6
        L_0x015a:
            y3.v r6 = new y3.v
            y3.k r0 = new y3.k
            y3.G r2 = new y3.G
            java.util.List r7 = r5.b(r7)
            r2.<init>(r7)
            r0.<init>(r2, r1)
            r6.<init>(r0)
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.C3489g.a(int, y3.F$b):y3.F");
    }

    public final List<n> b(F.b bVar) {
        boolean z10;
        String str;
        int i10;
        List<byte[]> list;
        boolean z11;
        boolean c10 = c(32);
        List<n> list2 = this.f30828b;
        if (c10) {
            return list2;
        }
        t tVar = new t(bVar.f30752d);
        while (tVar.a() > 0) {
            int u7 = tVar.u();
            int u10 = tVar.f25886b + tVar.u();
            if (u7 == 134) {
                ArrayList arrayList = new ArrayList();
                int u11 = tVar.u() & 31;
                for (int i11 = 0; i11 < u11; i11++) {
                    String s10 = tVar.s(3, StandardCharsets.UTF_8);
                    int u12 = tVar.u();
                    if ((u12 & HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE) != 0) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    if (z10) {
                        i10 = u12 & 63;
                        str = "application/cea-708";
                    } else {
                        str = "application/cea-608";
                        i10 = 1;
                    }
                    byte u13 = (byte) tVar.u();
                    tVar.H(1);
                    if (z10) {
                        if ((u13 & 64) != 0) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                        byte[] bArr = d.f25832a;
                        list = Collections.singletonList(z11 ? new byte[]{1} : new byte[]{0});
                    } else {
                        list = null;
                    }
                    n.a aVar = new n.a();
                    aVar.f24328m = u.p(str);
                    aVar.f24319d = s10;
                    aVar.f24311H = i10;
                    aVar.f24331p = list;
                    arrayList.add(new n(aVar));
                }
                list2 = arrayList;
            }
            tVar.G(u10);
        }
        return list2;
    }

    public final boolean c(int i10) {
        if ((i10 & this.f30827a) != 0) {
            return true;
        }
        return false;
    }
}
