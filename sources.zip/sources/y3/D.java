package y3;

import R2.C1013i;
import o2.C2756B;
import o2.t;
import o2.y;

public final class D {

    /* renamed from: a  reason: collision with root package name */
    public final y f30712a = new y(0);

    /* renamed from: b  reason: collision with root package name */
    public final t f30713b = new t();

    /* renamed from: c  reason: collision with root package name */
    public boolean f30714c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f30715d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f30716e;

    /* renamed from: f  reason: collision with root package name */
    public long f30717f = -9223372036854775807L;

    /* renamed from: g  reason: collision with root package name */
    public long f30718g = -9223372036854775807L;

    /* renamed from: h  reason: collision with root package name */
    public long f30719h = -9223372036854775807L;

    public final void a(C1013i iVar) {
        byte[] bArr = C2756B.f25813c;
        t tVar = this.f30713b;
        tVar.getClass();
        tVar.E(bArr.length, bArr);
        this.f30714c = true;
        iVar.f8169G = 0;
    }
}
