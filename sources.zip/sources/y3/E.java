package y3;

import R2.C1013i;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import U1.c;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.util.SparseIntArray;
import f7.M;
import io.netty.handler.codec.http.HttpObjectDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import o2.C2756B;
import o2.t;
import o2.y;
import o3.C2772n;
import o3.C2773o;
import y3.F;

public final class E implements n {

    /* renamed from: a  reason: collision with root package name */
    public final int f30720a;

    /* renamed from: b  reason: collision with root package name */
    public final int f30721b;

    /* renamed from: c  reason: collision with root package name */
    public final List<y> f30722c;

    /* renamed from: d  reason: collision with root package name */
    public final t f30723d;

    /* renamed from: e  reason: collision with root package name */
    public final SparseIntArray f30724e;

    /* renamed from: f  reason: collision with root package name */
    public final C3489g f30725f;

    /* renamed from: g  reason: collision with root package name */
    public final C2772n.a f30726g;

    /* renamed from: h  reason: collision with root package name */
    public final SparseArray<F> f30727h;

    /* renamed from: i  reason: collision with root package name */
    public final SparseBooleanArray f30728i;

    /* renamed from: j  reason: collision with root package name */
    public final SparseBooleanArray f30729j;

    /* renamed from: k  reason: collision with root package name */
    public final D f30730k;

    /* renamed from: l  reason: collision with root package name */
    public C f30731l;

    /* renamed from: m  reason: collision with root package name */
    public p f30732m;

    /* renamed from: n  reason: collision with root package name */
    public int f30733n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f30734o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f30735p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f30736q;

    /* renamed from: r  reason: collision with root package name */
    public F f30737r;

    /* renamed from: s  reason: collision with root package name */
    public int f30738s;

    /* renamed from: t  reason: collision with root package name */
    public int f30739t;

    public E(int i10, int i11, C2772n.a aVar, y yVar, C3489g gVar) {
        this.f30725f = gVar;
        this.f30720a = i10;
        this.f30721b = i11;
        this.f30726g = aVar;
        if (i10 == 1 || i10 == 2) {
            this.f30722c = Collections.singletonList(yVar);
        } else {
            ArrayList arrayList = new ArrayList();
            this.f30722c = arrayList;
            arrayList.add(yVar);
        }
        this.f30723d = new t(new byte[9400], 0);
        SparseBooleanArray sparseBooleanArray = new SparseBooleanArray();
        this.f30728i = sparseBooleanArray;
        this.f30729j = new SparseBooleanArray();
        SparseArray<F> sparseArray = new SparseArray<>();
        this.f30727h = sparseArray;
        this.f30724e = new SparseIntArray();
        this.f30730k = new D();
        this.f30732m = p.f8197h;
        this.f30739t = -1;
        sparseBooleanArray.clear();
        sparseArray.clear();
        SparseArray sparseArray2 = new SparseArray();
        int size = sparseArray2.size();
        for (int i12 = 0; i12 < size; i12++) {
            sparseArray.put(sparseArray2.keyAt(i12), (F) sparseArray2.valueAt(i12));
        }
        sparseArray.put(0, new C3481A(new a()));
        this.f30737r = null;
    }

    public final void a(long j10, long j11) {
        boolean z10;
        C c10;
        boolean z11;
        if (this.f30720a != 2) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.m(z10);
        List<y> list = this.f30722c;
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            y yVar = list.get(i10);
            if (yVar.e() == -9223372036854775807L) {
                z11 = true;
            } else {
                z11 = false;
            }
            if (!z11) {
                long d10 = yVar.d();
                if (d10 == -9223372036854775807L || d10 == 0 || d10 == j11) {
                    z11 = false;
                } else {
                    z11 = true;
                }
            }
            if (z11) {
                yVar.g(j11);
            }
        }
        if (!(j11 == 0 || (c10 = this.f30731l) == null)) {
            c10.c(j11);
        }
        this.f30723d.D(0);
        this.f30724e.clear();
        int i11 = 0;
        while (true) {
            SparseArray<F> sparseArray = this.f30727h;
            if (i11 < sparseArray.size()) {
                sparseArray.valueAt(i11).b();
                i11++;
            } else {
                this.f30738s = 0;
                return;
            }
        }
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        if ((this.f30721b & 1) == 0) {
            pVar = new C2773o(pVar, this.f30726g);
        }
        this.f30732m = pVar;
    }

    public final boolean g(o oVar) {
        byte[] bArr = this.f30723d.f25885a;
        C1013i iVar = (C1013i) oVar;
        iVar.l(bArr, 0, 940, false);
        int i10 = 0;
        while (i10 < 188) {
            int i11 = 0;
            while (i11 < 5) {
                if (bArr[(i11 * 188) + i10] != 71) {
                    i10++;
                } else {
                    i11++;
                }
            }
            iVar.s(i10);
            return true;
        }
        return false;
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v6, resolved type: boolean} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v7, resolved type: boolean} */
    /* JADX WARNING: type inference failed for: r3v15, types: [R2.e, y3.C] */
    /* JADX WARNING: type inference failed for: r4v22, types: [R2.e$d, java.lang.Object] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int i(R2.o r26, R2.B r27) {
        /*
            r25 = this;
            r0 = r25
            r1 = r27
            r2 = r26
            R2.i r2 = (R2.C1013i) r2
            long r12 = r2.f8173z
            r2 = 0
            r3 = 1
            int r4 = r0.f30720a
            r5 = 2
            if (r4 != r5) goto L_0x0014
            r17 = r3
            goto L_0x0016
        L_0x0014:
            r17 = r2
        L_0x0016:
            boolean r6 = r0.f30734o
            r7 = 71
            r18 = -1
            if (r6 == 0) goto L_0x0196
            int r6 = (r12 > r18 ? 1 : (r12 == r18 ? 0 : -1))
            y3.D r10 = r0.f30730k
            if (r6 == 0) goto L_0x0116
            if (r17 != 0) goto L_0x0116
            boolean r6 = r10.f30714c
            if (r6 != 0) goto L_0x0116
            int r4 = r0.f30739t
            if (r4 > 0) goto L_0x0036
            r1 = r26
            R2.i r1 = (R2.C1013i) r1
            r10.a(r1)
            return r2
        L_0x0036:
            boolean r5 = r10.f30716e
            o2.t r6 = r10.f30713b
            r11 = 112800(0x1b8a0, float:1.58066E-40)
            if (r5 != 0) goto L_0x009b
            r5 = r26
            R2.i r5 = (R2.C1013i) r5
            long r11 = (long) r11
            long r13 = r5.f8173z
            long r11 = java.lang.Math.min(r11, r13)
            int r11 = (int) r11
            r15 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            long r8 = (long) r11
            long r13 = r13 - r8
            long r8 = r5.f8167E
            int r8 = (r8 > r13 ? 1 : (r8 == r13 ? 0 : -1))
            if (r8 == 0) goto L_0x005b
            r1.f8054a = r13
            return r3
        L_0x005b:
            r6.D(r11)
            r5.f8169G = r2
            byte[] r1 = r6.f25885a
            r5.l(r1, r2, r11, r2)
            int r1 = r6.f25886b
            int r5 = r6.f25887c
            int r8 = r5 + -188
        L_0x006b:
            if (r8 < r1) goto L_0x0095
            byte[] r9 = r6.f25885a
            r11 = -4
            r12 = r2
        L_0x0071:
            r13 = 4
            if (r11 > r13) goto L_0x0092
            int r13 = r11 * 188
            int r13 = r13 + r8
            if (r13 < r1) goto L_0x008e
            if (r13 >= r5) goto L_0x008e
            byte r13 = r9[r13]
            if (r13 == r7) goto L_0x0080
            goto L_0x008e
        L_0x0080:
            int r12 = r12 + r3
            r13 = 5
            if (r12 != r13) goto L_0x008f
            long r11 = lc.C4622o.w(r6, r8, r4)
            int r9 = (r11 > r15 ? 1 : (r11 == r15 ? 0 : -1))
            if (r9 == 0) goto L_0x0092
            r8 = r11
            goto L_0x0096
        L_0x008e:
            r12 = r2
        L_0x008f:
            int r11 = r11 + 1
            goto L_0x0071
        L_0x0092:
            int r8 = r8 + -1
            goto L_0x006b
        L_0x0095:
            r8 = r15
        L_0x0096:
            r10.f30718g = r8
            r10.f30716e = r3
            return r2
        L_0x009b:
            r15 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            long r8 = r10.f30718g
            int r5 = (r8 > r15 ? 1 : (r8 == r15 ? 0 : -1))
            if (r5 != 0) goto L_0x00ae
            r1 = r26
            R2.i r1 = (R2.C1013i) r1
            r10.a(r1)
            return r2
        L_0x00ae:
            boolean r5 = r10.f30715d
            if (r5 != 0) goto L_0x00f1
            long r8 = (long) r11
            r5 = r26
            R2.i r5 = (R2.C1013i) r5
            long r11 = r5.f8173z
            long r8 = java.lang.Math.min(r8, r11)
            int r8 = (int) r8
            long r11 = r5.f8167E
            long r13 = (long) r2
            int r9 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r9 == 0) goto L_0x00c8
            r1.f8054a = r13
            return r3
        L_0x00c8:
            r6.D(r8)
            r5.f8169G = r2
            byte[] r1 = r6.f25885a
            r5.l(r1, r2, r8, r2)
            int r1 = r6.f25886b
            int r5 = r6.f25887c
        L_0x00d6:
            if (r1 >= r5) goto L_0x00eb
            byte[] r8 = r6.f25885a
            byte r8 = r8[r1]
            if (r8 == r7) goto L_0x00df
            goto L_0x00e8
        L_0x00df:
            long r8 = lc.C4622o.w(r6, r1, r4)
            int r11 = (r8 > r15 ? 1 : (r8 == r15 ? 0 : -1))
            if (r11 == 0) goto L_0x00e8
            goto L_0x00ec
        L_0x00e8:
            int r1 = r1 + 1
            goto L_0x00d6
        L_0x00eb:
            r8 = r15
        L_0x00ec:
            r10.f30717f = r8
            r10.f30715d = r3
            return r2
        L_0x00f1:
            long r3 = r10.f30717f
            int r1 = (r3 > r15 ? 1 : (r3 == r15 ? 0 : -1))
            if (r1 != 0) goto L_0x00ff
            r1 = r26
            R2.i r1 = (R2.C1013i) r1
            r10.a(r1)
            return r2
        L_0x00ff:
            o2.y r1 = r10.f30712a
            long r3 = r1.b(r3)
            long r5 = r10.f30718g
            long r5 = r1.c(r5)
            long r5 = r5 - r3
            r10.f30719h = r5
            r1 = r26
            R2.i r1 = (R2.C1013i) r1
            r10.a(r1)
            return r2
        L_0x0116:
            r15 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            boolean r6 = r0.f30735p
            if (r6 != 0) goto L_0x0169
            r0.f30735p = r3
            r8 = r7
            long r6 = r10.f30719h
            int r9 = (r6 > r15 ? 1 : (r6 == r15 ? 0 : -1))
            if (r9 == 0) goto L_0x015c
            r9 = r3
            y3.C r3 = new y3.C
            int r11 = r0.f30739t
            r14 = r4
            R2.e$b r4 = new R2.e$b
            r4.<init>()
            r15 = r5
            y3.C$a r5 = new y3.C$a
            o2.y r10 = r10.f30712a
            r5.<init>(r11, r10)
            r10 = 1
            long r10 = r10 + r6
            r16 = 940(0x3ac, float:1.317E-42)
            r21 = r8
            r20 = r9
            r8 = r10
            r10 = 0
            r22 = r14
            r23 = r15
            r14 = 188(0xbc, double:9.3E-322)
            r24 = r22
            r3.<init>(r4, r5, r6, r8, r10, r12, r14, r16)
            r0.f30731l = r3
            R2.p r4 = r0.f30732m
            R2.e$a r3 = r3.f8132a
            r4.a(r3)
            goto L_0x016b
        L_0x015c:
            r24 = r4
            R2.p r3 = r0.f30732m
            R2.C$b r4 = new R2.C$b
            r4.<init>(r6)
            r3.a(r4)
            goto L_0x016b
        L_0x0169:
            r24 = r4
        L_0x016b:
            boolean r3 = r0.f30736q
            if (r3 == 0) goto L_0x0184
            r0.f30736q = r2
            r3 = 0
            r0.a(r3, r3)
            r5 = r26
            R2.i r5 = (R2.C1013i) r5
            long r5 = r5.f8167E
            int r5 = (r5 > r3 ? 1 : (r5 == r3 ? 0 : -1))
            if (r5 == 0) goto L_0x0184
            r1.f8054a = r3
            r9 = 1
            return r9
        L_0x0184:
            r9 = 1
            y3.C r3 = r0.f30731l
            if (r3 == 0) goto L_0x0199
            R2.e$c r4 = r3.f8134c
            if (r4 == 0) goto L_0x0199
            r2 = r26
            R2.i r2 = (R2.C1013i) r2
            int r1 = r3.a(r2, r1)
            return r1
        L_0x0196:
            r9 = r3
            r24 = r4
        L_0x0199:
            o2.t r1 = r0.f30723d
            byte[] r3 = r1.f25885a
            int r4 = r1.f25886b
            int r4 = 9400 - r4
            r5 = 188(0xbc, float:2.63E-43)
            if (r4 >= r5) goto L_0x01b3
            int r4 = r1.a()
            if (r4 <= 0) goto L_0x01b0
            int r6 = r1.f25886b
            java.lang.System.arraycopy(r3, r6, r3, r2, r4)
        L_0x01b0:
            r1.E(r4, r3)
        L_0x01b3:
            int r4 = r1.a()
            android.util.SparseArray<y3.F> r6 = r0.f30727h
            if (r4 >= r5) goto L_0x020d
            int r4 = r1.f25887c
            int r7 = 9400 - r4
            r8 = r26
            R2.i r8 = (R2.C1013i) r8
            int r7 = r8.read(r3, r4, r7)
            r8 = -1
            if (r7 != r8) goto L_0x0208
            r1 = r2
        L_0x01cb:
            int r3 = r6.size()
            if (r1 >= r3) goto L_0x0207
            java.lang.Object r3 = r6.valueAt(r1)
            y3.F r3 = (y3.F) r3
            boolean r4 = r3 instanceof y3.v
            if (r4 == 0) goto L_0x0204
            y3.v r3 = (y3.v) r3
            if (r17 == 0) goto L_0x01e8
            boolean r4 = r3.e()
            if (r4 == 0) goto L_0x01e6
            goto L_0x01e8
        L_0x01e6:
            r4 = r2
            goto L_0x01e9
        L_0x01e8:
            r4 = r9
        L_0x01e9:
            int r5 = r3.f31054c
            r7 = 3
            if (r5 != r7) goto L_0x0204
            int r5 = r3.f31061j
            if (r5 != r8) goto L_0x0204
            if (r17 == 0) goto L_0x01fa
            y3.j r5 = r3.f31052a
            boolean r5 = r5 instanceof y3.k
            if (r5 != 0) goto L_0x0204
        L_0x01fa:
            if (r4 == 0) goto L_0x0204
            o2.t r4 = new o2.t
            r4.<init>()
            r3.c(r9, r4)
        L_0x0204:
            int r1 = r1 + 1
            goto L_0x01cb
        L_0x0207:
            return r8
        L_0x0208:
            int r4 = r4 + r7
            r1.F(r4)
            goto L_0x01b3
        L_0x020d:
            int r3 = r1.f25886b
            int r4 = r1.f25887c
            byte[] r5 = r1.f25885a
            r7 = r3
        L_0x0214:
            if (r7 >= r4) goto L_0x021f
            byte r8 = r5[r7]
            r10 = 71
            if (r8 == r10) goto L_0x021f
            int r7 = r7 + 1
            goto L_0x0214
        L_0x021f:
            r1.G(r7)
            int r5 = r7 + 188
            r8 = 0
            if (r5 <= r4) goto L_0x023e
            int r4 = r0.f30738s
            int r7 = r7 - r3
            int r7 = r7 + r4
            r0.f30738s = r7
            r14 = r24
            r15 = 2
            if (r14 != r15) goto L_0x0243
            r3 = 376(0x178, float:5.27E-43)
            if (r7 > r3) goto L_0x0237
            goto L_0x0243
        L_0x0237:
            java.lang.String r1 = "Cannot find sync byte. Most likely not a Transport Stream."
            l2.v r1 = l2.v.a(r8, r1)
            throw r1
        L_0x023e:
            r14 = r24
            r15 = 2
            r0.f30738s = r2
        L_0x0243:
            int r3 = r1.f25887c
            if (r5 <= r3) goto L_0x0248
            return r2
        L_0x0248:
            int r4 = r1.h()
            r7 = 8388608(0x800000, float:1.17549435E-38)
            r7 = r7 & r4
            if (r7 == 0) goto L_0x0255
            r1.G(r5)
            return r2
        L_0x0255:
            r7 = 4194304(0x400000, float:5.877472E-39)
            r7 = r7 & r4
            if (r7 == 0) goto L_0x025c
            r7 = r9
            goto L_0x025d
        L_0x025c:
            r7 = r2
        L_0x025d:
            r10 = 2096896(0x1fff00, float:2.938377E-39)
            r10 = r10 & r4
            int r10 = r10 >> 8
            r11 = r4 & 32
            if (r11 == 0) goto L_0x0269
            r11 = r9
            goto L_0x026a
        L_0x0269:
            r11 = r2
        L_0x026a:
            r16 = r4 & 16
            if (r16 == 0) goto L_0x0275
            java.lang.Object r6 = r6.get(r10)
            r8 = r6
            y3.F r8 = (y3.F) r8
        L_0x0275:
            if (r8 != 0) goto L_0x027b
            r1.G(r5)
            return r2
        L_0x027b:
            if (r14 == r15) goto L_0x029c
            r4 = r4 & 15
            android.util.SparseIntArray r6 = r0.f30724e
            r20 = r9
            int r9 = r4 + -1
            int r9 = r6.get(r10, r9)
            r6.put(r10, r4)
            if (r9 != r4) goto L_0x0292
            r1.G(r5)
            return r2
        L_0x0292:
            int r9 = r9 + 1
            r6 = r9 & 15
            if (r4 == r6) goto L_0x029e
            r8.b()
            goto L_0x029e
        L_0x029c:
            r20 = r9
        L_0x029e:
            if (r11 == 0) goto L_0x02b5
            int r4 = r1.u()
            int r6 = r1.u()
            r6 = r6 & 64
            if (r6 == 0) goto L_0x02ae
            r6 = r15
            goto L_0x02af
        L_0x02ae:
            r6 = r2
        L_0x02af:
            r7 = r7 | r6
            int r4 = r4 + -1
            r1.H(r4)
        L_0x02b5:
            boolean r4 = r0.f30734o
            if (r14 == r15) goto L_0x02c3
            if (r4 != 0) goto L_0x02c3
            android.util.SparseBooleanArray r6 = r0.f30729j
            boolean r6 = r6.get(r10, r2)
            if (r6 != 0) goto L_0x02cc
        L_0x02c3:
            r1.F(r5)
            r8.c(r7, r1)
            r1.F(r3)
        L_0x02cc:
            if (r14 == r15) goto L_0x02dc
            if (r4 != 0) goto L_0x02dc
            boolean r3 = r0.f30734o
            if (r3 == 0) goto L_0x02dc
            int r3 = (r12 > r18 ? 1 : (r12 == r18 ? 0 : -1))
            if (r3 == 0) goto L_0x02dc
            r9 = r20
            r0.f30736q = r9
        L_0x02dc:
            r1.G(r5)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.E.i(R2.o, R2.B):int");
    }

    public final void release() {
    }

    public class a implements z {

        /* renamed from: a  reason: collision with root package name */
        public final c f30740a = new c(new byte[4], 4);

        public a() {
        }

        public final void c(t tVar) {
            E e10;
            if (tVar.u() == 0 && (tVar.u() & HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE) != 0) {
                tVar.H(6);
                int a10 = tVar.a() / 4;
                int i10 = 0;
                while (true) {
                    e10 = E.this;
                    if (i10 >= a10) {
                        break;
                    }
                    c cVar = this.f30740a;
                    tVar.f(0, (byte[]) cVar.f10461d, 4);
                    cVar.n(0);
                    int h10 = cVar.h(16);
                    cVar.p(3);
                    if (h10 == 0) {
                        cVar.p(13);
                    } else {
                        int h11 = cVar.h(13);
                        if (e10.f30727h.get(h11) == null) {
                            e10.f30727h.put(h11, new C3481A(new b(h11)));
                            e10.f30733n++;
                        }
                    }
                    i10++;
                }
                if (e10.f30720a != 2) {
                    e10.f30727h.remove(0);
                }
            }
        }

        public final void a(y yVar, p pVar, F.c cVar) {
        }
    }

    public class b implements z {

        /* renamed from: a  reason: collision with root package name */
        public final c f30742a = new c(new byte[5], 5);

        /* renamed from: b  reason: collision with root package name */
        public final SparseArray<F> f30743b = new SparseArray<>();

        /* renamed from: c  reason: collision with root package name */
        public final SparseIntArray f30744c = new SparseIntArray();

        /* renamed from: d  reason: collision with root package name */
        public final int f30745d;

        public b(int i10) {
            this.f30745d = i10;
        }

        public final void c(t tVar) {
            y yVar;
            SparseBooleanArray sparseBooleanArray;
            SparseArray<F> sparseArray;
            int i10;
            int i11;
            y yVar2;
            int i12;
            int i13;
            char c10;
            F f10;
            int i14;
            int i15;
            y yVar3;
            t tVar2 = tVar;
            if (tVar2.u() == 2) {
                E e10 = E.this;
                int i16 = e10.f30720a;
                int i17 = 0;
                List<y> list = e10.f30722c;
                if (i16 == 1 || i16 == 2 || e10.f30733n == 1) {
                    yVar = list.get(0);
                } else {
                    yVar = new y(list.get(0).d());
                    list.add(yVar);
                }
                if ((tVar2.u() & HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE) != 0) {
                    tVar2.H(1);
                    int A10 = tVar2.A();
                    int i18 = 3;
                    tVar2.H(3);
                    c cVar = this.f30742a;
                    tVar2.f(0, (byte[]) cVar.f10461d, 2);
                    cVar.n(0);
                    cVar.p(3);
                    e10.f30739t = cVar.h(13);
                    tVar2.f(0, (byte[]) cVar.f10461d, 2);
                    cVar.n(0);
                    cVar.p(4);
                    tVar2.H(cVar.h(12));
                    C3489g gVar = e10.f30725f;
                    int i19 = e10.f30720a;
                    if (i19 == 2 && e10.f30737r == null) {
                        F a10 = gVar.a(21, new F.b(21, (String) null, 0, (ArrayList) null, C2756B.f25813c));
                        e10.f30737r = a10;
                        if (a10 != null) {
                            a10.a(yVar, e10.f30732m, new F.c(A10, 21, 8192));
                        }
                    }
                    SparseArray<F> sparseArray2 = this.f30743b;
                    sparseArray2.clear();
                    SparseIntArray sparseIntArray = this.f30744c;
                    sparseIntArray.clear();
                    int a11 = tVar2.a();
                    while (true) {
                        sparseBooleanArray = e10.f30728i;
                        if (a11 <= 0) {
                            break;
                        }
                        tVar2.f(i17, (byte[]) cVar.f10461d, 5);
                        cVar.n(i17);
                        int h10 = cVar.h(8);
                        cVar.p(i18);
                        int h11 = cVar.h(13);
                        cVar.p(4);
                        int h12 = cVar.h(12);
                        int i20 = tVar2.f25886b;
                        int i21 = i20 + h12;
                        String str = null;
                        ArrayList arrayList = null;
                        int i22 = -1;
                        int i23 = 0;
                        c cVar2 = cVar;
                        while (true) {
                            if (tVar2.f25886b >= i21) {
                                i12 = a11;
                                break;
                            }
                            int u7 = tVar2.u();
                            i12 = a11;
                            int u10 = tVar2.f25886b + tVar2.u();
                            if (u10 > i21) {
                                break;
                            }
                            if (u7 == 5) {
                                long w10 = tVar2.w();
                                if (w10 == 1094921523) {
                                    i22 = 129;
                                } else if (w10 == 1161904947) {
                                    i22 = 135;
                                } else if (w10 != 1094921524) {
                                    if (w10 == 1212503619) {
                                        i22 = 36;
                                    }
                                }
                                yVar3 = yVar;
                                i14 = A10;
                                i15 = u10;
                                tVar2.H(i15 - tVar2.f25886b);
                                yVar = yVar3;
                                a11 = i12;
                                A10 = i14;
                            } else if (u7 == 106) {
                                yVar3 = yVar;
                                i14 = A10;
                                i15 = u10;
                                i22 = 129;
                                tVar2.H(i15 - tVar2.f25886b);
                                yVar = yVar3;
                                a11 = i12;
                                A10 = i14;
                            } else if (u7 == 122) {
                                yVar3 = yVar;
                                i14 = A10;
                                i22 = 135;
                                i15 = u10;
                                tVar2.H(i15 - tVar2.f25886b);
                                yVar = yVar3;
                                a11 = i12;
                                A10 = i14;
                            } else {
                                if (u7 == 127) {
                                    int u11 = tVar2.u();
                                    if (u11 != 21) {
                                        if (u11 == 14) {
                                            i22 = 136;
                                        } else if (u11 == 33) {
                                            i22 = 139;
                                        }
                                    }
                                } else if (u7 == 123) {
                                    i22 = 138;
                                } else if (u7 == 10) {
                                    String trim = tVar2.s(3, StandardCharsets.UTF_8).trim();
                                    i23 = tVar2.u();
                                    str = trim;
                                } else {
                                    if (u7 == 89) {
                                        ArrayList arrayList2 = new ArrayList();
                                        while (tVar2.f25886b < u10) {
                                            String trim2 = tVar2.s(3, StandardCharsets.UTF_8).trim();
                                            tVar2.u();
                                            y yVar4 = yVar;
                                            byte[] bArr = new byte[4];
                                            tVar2.f(0, bArr, 4);
                                            arrayList2.add(new F.a(bArr, trim2));
                                            yVar = yVar4;
                                            u10 = u10;
                                            A10 = A10;
                                        }
                                        yVar3 = yVar;
                                        i14 = A10;
                                        i15 = u10;
                                        arrayList = arrayList2;
                                        i22 = 89;
                                    } else {
                                        yVar3 = yVar;
                                        i14 = A10;
                                        i15 = u10;
                                        if (u7 == 111) {
                                            i22 = 257;
                                        }
                                    }
                                    tVar2.H(i15 - tVar2.f25886b);
                                    yVar = yVar3;
                                    a11 = i12;
                                    A10 = i14;
                                }
                                yVar3 = yVar;
                                i14 = A10;
                                i15 = u10;
                                tVar2.H(i15 - tVar2.f25886b);
                                yVar = yVar3;
                                a11 = i12;
                                A10 = i14;
                            }
                            i22 = 172;
                            yVar3 = yVar;
                            i14 = A10;
                            i15 = u10;
                            tVar2.H(i15 - tVar2.f25886b);
                            yVar = yVar3;
                            a11 = i12;
                            A10 = i14;
                        }
                        y yVar5 = yVar;
                        int i24 = A10;
                        tVar2.G(i21);
                        F.b bVar = new F.b(i22, str, i23, arrayList, Arrays.copyOfRange(tVar2.f25885a, i20, i21));
                        if (h10 == 6 || h10 == 5) {
                            h10 = i22;
                        }
                        int i25 = i12 - (h12 + 5);
                        if (i19 == 2) {
                            i13 = h10;
                        } else {
                            i13 = h11;
                        }
                        if (sparseBooleanArray.get(i13)) {
                            c10 = 21;
                        } else {
                            c10 = 21;
                            if (i19 == 2 && h10 == 21) {
                                f10 = e10.f30737r;
                            } else {
                                f10 = gVar.a(h10, bVar);
                            }
                            if (i19 != 2 || h11 < sparseIntArray.get(i13, 8192)) {
                                sparseIntArray.put(i13, h11);
                                sparseArray2.put(i13, f10);
                            }
                        }
                        a11 = i25;
                        char c11 = c10;
                        yVar = yVar5;
                        cVar = cVar2;
                        A10 = i24;
                        i17 = 0;
                        i18 = 3;
                    }
                    y yVar6 = yVar;
                    int i26 = A10;
                    int size = sparseIntArray.size();
                    int i27 = 0;
                    while (true) {
                        sparseArray = e10.f30727h;
                        if (i27 >= size) {
                            break;
                        }
                        int keyAt = sparseIntArray.keyAt(i27);
                        int valueAt = sparseIntArray.valueAt(i27);
                        sparseBooleanArray.put(keyAt, true);
                        e10.f30729j.put(valueAt, true);
                        F valueAt2 = sparseArray2.valueAt(i27);
                        if (valueAt2 != null) {
                            if (valueAt2 != e10.f30737r) {
                                p pVar = e10.f30732m;
                                i11 = i26;
                                F.c cVar3 = new F.c(i11, keyAt, 8192);
                                yVar2 = yVar6;
                                valueAt2.a(yVar2, pVar, cVar3);
                            } else {
                                yVar2 = yVar6;
                                i11 = i26;
                            }
                            sparseArray.put(valueAt, valueAt2);
                        } else {
                            yVar2 = yVar6;
                            i11 = i26;
                        }
                        i27++;
                        yVar6 = yVar2;
                        i26 = i11;
                    }
                    if (i19 != 2) {
                        sparseArray.remove(this.f30745d);
                        if (i19 == 1) {
                            i10 = 0;
                        } else {
                            i10 = e10.f30733n - 1;
                        }
                        e10.f30733n = i10;
                        if (i10 == 0) {
                            e10.f30732m.b();
                            e10.f30734o = true;
                        }
                    } else if (!e10.f30734o) {
                        e10.f30732m.b();
                        e10.f30733n = 0;
                        e10.f30734o = true;
                    }
                }
            }
        }

        public final void a(y yVar, p pVar, F.c cVar) {
        }
    }
}
