package y3;

import R2.p;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import o2.t;
import o2.y;

public interface F {

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final String f30747a;

        /* renamed from: b  reason: collision with root package name */
        public final byte[] f30748b;

        public a(byte[] bArr, String str) {
            this.f30747a = str;
            this.f30748b = bArr;
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        public final String f30749a;

        /* renamed from: b  reason: collision with root package name */
        public final int f30750b;

        /* renamed from: c  reason: collision with root package name */
        public final List<a> f30751c;

        /* renamed from: d  reason: collision with root package name */
        public final byte[] f30752d;

        public b(int i10, String str, int i11, ArrayList arrayList, byte[] bArr) {
            List<a> list;
            this.f30749a = str;
            this.f30750b = i11;
            if (arrayList == null) {
                list = Collections.EMPTY_LIST;
            } else {
                list = Collections.unmodifiableList(arrayList);
            }
            this.f30751c = list;
            this.f30752d = bArr;
        }

        public final int a() {
            int i10 = this.f30750b;
            if (i10 == 2) {
                return 2048;
            }
            if (i10 != 3) {
                return 0;
            }
            return 512;
        }
    }

    public static final class c {

        /* renamed from: a  reason: collision with root package name */
        public final String f30753a;

        /* renamed from: b  reason: collision with root package name */
        public final int f30754b;

        /* renamed from: c  reason: collision with root package name */
        public final int f30755c;

        /* renamed from: d  reason: collision with root package name */
        public int f30756d;

        /* renamed from: e  reason: collision with root package name */
        public String f30757e;

        public c(int i10, int i11) {
            this(Integer.MIN_VALUE, i10, i11);
        }

        public final void a() {
            int i10;
            int i11 = this.f30756d;
            if (i11 == Integer.MIN_VALUE) {
                i10 = this.f30754b;
            } else {
                i10 = i11 + this.f30755c;
            }
            this.f30756d = i10;
            this.f30757e = this.f30753a + this.f30756d;
        }

        public final void b() {
            if (this.f30756d == Integer.MIN_VALUE) {
                throw new IllegalStateException("generateNewId() must be called before retrieving ids.");
            }
        }

        public c(int i10, int i11, int i12) {
            String str;
            if (i10 != Integer.MIN_VALUE) {
                str = i10 + "/";
            } else {
                str = "";
            }
            this.f30753a = str;
            this.f30754b = i11;
            this.f30755c = i12;
            this.f30756d = Integer.MIN_VALUE;
            this.f30757e = "";
        }
    }

    void a(y yVar, p pVar, c cVar);

    void b();

    void c(int i10, t tVar);
}
