package y3;

import D2.E;
import R2.C1010f;
import R2.H;
import R2.p;
import f7.M;
import java.util.List;
import l2.n;
import l2.u;
import o2.t;
import y3.F;

public final class G {

    /* renamed from: a  reason: collision with root package name */
    public final List<n> f30758a;

    /* renamed from: b  reason: collision with root package name */
    public final H[] f30759b;

    public G(List list) {
        this.f30758a = list;
        this.f30759b = new H[list.size()];
    }

    public final void a(long j10, t tVar) {
        if (tVar.a() >= 9) {
            int h10 = tVar.h();
            int h11 = tVar.h();
            int u7 = tVar.u();
            if (h10 == 434 && h11 == 1195456820 && u7 == 3) {
                C1010f.b(j10, tVar, this.f30759b);
            }
        }
    }

    public final void b(p pVar, F.c cVar) {
        boolean z10;
        int i10 = 0;
        while (true) {
            H[] hArr = this.f30759b;
            if (i10 < hArr.length) {
                cVar.a();
                cVar.b();
                H k10 = pVar.k(cVar.f30756d, 3);
                n nVar = this.f30758a.get(i10);
                String str = nVar.f24291n;
                if ("application/cea-608".equals(str) || "application/cea-708".equals(str)) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                M.g("Invalid closed caption MIME type provided: " + str, z10);
                n.a aVar = new n.a();
                cVar.b();
                aVar.f24316a = cVar.f30757e;
                aVar.f24327l = u.p("video/mp2t");
                aVar.f24328m = u.p(str);
                aVar.f24320e = nVar.f24282e;
                aVar.f24319d = nVar.f24281d;
                aVar.f24311H = nVar.f24272I;
                aVar.f24331p = nVar.f24294q;
                E.r(aVar, k10);
                hArr[i10] = k10;
                i10++;
            } else {
                return;
            }
        }
    }
}
