package y3;

import R2.H;
import R2.m;
import R2.p;
import java.util.concurrent.atomic.AtomicInteger;
import l2.n;
import l2.u;
import o2.t;
import y3.F;

public final class h implements j {

    /* renamed from: a  reason: collision with root package name */
    public final t f30829a;

    /* renamed from: b  reason: collision with root package name */
    public final AtomicInteger f30830b = new AtomicInteger();

    /* renamed from: c  reason: collision with root package name */
    public final String f30831c;

    /* renamed from: d  reason: collision with root package name */
    public final int f30832d;

    /* renamed from: e  reason: collision with root package name */
    public final String f30833e;

    /* renamed from: f  reason: collision with root package name */
    public String f30834f;

    /* renamed from: g  reason: collision with root package name */
    public H f30835g;

    /* renamed from: h  reason: collision with root package name */
    public int f30836h = 0;

    /* renamed from: i  reason: collision with root package name */
    public int f30837i;

    /* renamed from: j  reason: collision with root package name */
    public int f30838j;

    /* renamed from: k  reason: collision with root package name */
    public long f30839k;

    /* renamed from: l  reason: collision with root package name */
    public n f30840l;

    /* renamed from: m  reason: collision with root package name */
    public int f30841m;

    /* renamed from: n  reason: collision with root package name */
    public int f30842n;

    /* renamed from: o  reason: collision with root package name */
    public int f30843o = -1;

    /* renamed from: p  reason: collision with root package name */
    public int f30844p = -1;

    /* renamed from: q  reason: collision with root package name */
    public long f30845q = -9223372036854775807L;

    public h(String str, int i10, int i11) {
        this.f30829a = new t(new byte[i11]);
        this.f30831c = str;
        this.f30832d = i10;
        this.f30833e = "video/mp2t";
    }

    public final boolean a(t tVar, byte[] bArr, int i10) {
        int min = Math.min(tVar.a(), i10 - this.f30837i);
        tVar.f(this.f30837i, bArr, min);
        int i11 = this.f30837i + min;
        this.f30837i = i11;
        if (i11 == i10) {
            return true;
        }
        return false;
    }

    public final void b() {
        this.f30836h = 0;
        this.f30837i = 0;
        this.f30838j = 0;
        this.f30845q = -9223372036854775807L;
        this.f30830b.set(0);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x01d1, code lost:
        r3 = r29;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(o2.t r42) {
        /*
            r41 = this;
            r0 = r41
            r1 = r42
            r3 = 4
            r8 = 1
            R2.H r9 = r0.f30835g
            f7.M.n(r9)
        L_0x000b:
            int r9 = r1.a()
            if (r9 <= 0) goto L_0x0596
            int r9 = r0.f30836h
            r16 = 32000(0x7d00, float:4.4842E-41)
            r17 = 44100(0xac44, float:6.1797E-41)
            r18 = 48000(0xbb80, float:6.7262E-41)
            r19 = 16
            r12 = 1078008818(0x40411bf2, float:3.0173306)
            r13 = 5
            r21 = -1
            r4 = 32
            r22 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r11 = 2
            r27 = 12
            r7 = 0
            r28 = 8
            o2.t r5 = r0.f30829a
            switch(r9) {
                case 0: goto L_0x04f8;
                case 1: goto L_0x0379;
                case 2: goto L_0x034f;
                case 3: goto L_0x0204;
                case 4: goto L_0x01d5;
                case 5: goto L_0x007e;
                case 6: goto L_0x003b;
                default: goto L_0x0035;
            }
        L_0x0035:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x003b:
            int r2 = r1.a()
            int r4 = r0.f30841m
            int r5 = r0.f30837i
            int r4 = r4 - r5
            int r2 = java.lang.Math.min(r2, r4)
            R2.H r4 = r0.f30835g
            r4.e(r2, r1)
            int r4 = r0.f30837i
            int r4 = r4 + r2
            r0.f30837i = r4
            int r2 = r0.f30841m
            if (r4 != r2) goto L_0x000b
            long r4 = r0.f30845q
            int r2 = (r4 > r22 ? 1 : (r4 == r22 ? 0 : -1))
            if (r2 == 0) goto L_0x005e
            r2 = r8
            goto L_0x005f
        L_0x005e:
            r2 = r7
        L_0x005f:
            f7.M.m(r2)
            R2.H r9 = r0.f30835g
            long r10 = r0.f30845q
            int r2 = r0.f30842n
            if (r2 != r3) goto L_0x006c
            r12 = r7
            goto L_0x006d
        L_0x006c:
            r12 = r8
        L_0x006d:
            int r13 = r0.f30841m
            r14 = 0
            r15 = 0
            r9.b(r10, r12, r13, r14, r15)
            long r4 = r0.f30845q
            long r9 = r0.f30839k
            long r4 = r4 + r9
            r0.f30845q = r4
            r0.f30836h = r7
            goto L_0x000b
        L_0x007e:
            byte[] r9 = r5.f25885a
            int r13 = r0.f30844p
            boolean r9 = r0.a(r1, r9, r13)
            if (r9 == 0) goto L_0x000b
            byte[] r9 = r5.f25885a
            java.util.concurrent.atomic.AtomicInteger r13 = r0.f30830b
            r29 = r3
            U1.c r3 = R2.m.a(r9)
            int r4 = r3.h(r4)
            if (r4 != r12) goto L_0x009a
            r4 = r8
            goto L_0x009b
        L_0x009a:
            r4 = r7
        L_0x009b:
            int[] r12 = R2.m.f8189e
            int r12 = R2.m.b(r3, r12)
            int r24 = r12 + 1
            if (r4 == 0) goto L_0x0179
            boolean r20 = r3.g()
            if (r20 == 0) goto L_0x0172
            int r6 = r12 + -1
            byte r20 = r9[r6]
            int r20 = r20 << 8
            r25 = 65535(0xffff, float:9.1834E-41)
            r20 = r20 & r25
            byte r12 = r9[r12]
            r12 = r12 & 255(0xff, float:3.57E-43)
            r12 = r20 | r12
            int r20 = o2.C2756B.f25811a
            r10 = r7
            r7 = r25
        L_0x00c1:
            if (r10 >= r6) goto L_0x00ef
            byte r15 = r9[r10]
            r2 = r15 & 255(0xff, float:3.57E-43)
            int r2 = r2 >> 4
            int r14 = r7 >> 12
            r14 = r14 & 255(0xff, float:3.57E-43)
            r2 = r2 ^ r14
            r2 = r2 & 255(0xff, float:3.57E-43)
            int r7 = r7 << 4
            r7 = r7 & r25
            int[] r14 = o2.C2756B.f25822l
            r2 = r14[r2]
            r2 = r2 ^ r7
            r2 = r2 & r25
            r7 = r15 & 15
            int r15 = r2 >> 12
            r15 = r15 & 255(0xff, float:3.57E-43)
            r7 = r7 ^ r15
            r7 = r7 & 255(0xff, float:3.57E-43)
            int r2 = r2 << 4
            r2 = r2 & r25
            r7 = r14[r7]
            r2 = r2 ^ r7
            r7 = r2 & r25
            int r10 = r10 + r8
            goto L_0x00c1
        L_0x00ef:
            if (r12 != r7) goto L_0x016a
            int r2 = r3.h(r11)
            if (r2 == 0) goto L_0x0116
            if (r2 == r8) goto L_0x0113
            if (r2 != r11) goto L_0x00ff
            r6 = 384(0x180, float:5.38E-43)
        L_0x00fd:
            r2 = 3
            goto L_0x0119
        L_0x00ff:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r3 = "Unsupported base duration index in DTS UHD header: "
            r1.<init>(r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r2 = 0
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x0113:
            r6 = 480(0x1e0, float:6.73E-43)
            goto L_0x00fd
        L_0x0116:
            r2 = 3
            r6 = 512(0x200, float:7.175E-43)
        L_0x0119:
            int r7 = r3.h(r2)
            int r7 = r7 + r8
            int r7 = r7 * r6
            int r2 = r3.h(r11)
            if (r2 == 0) goto L_0x0143
            if (r2 == r8) goto L_0x0140
            if (r2 != r11) goto L_0x012c
            r2 = r18
            goto L_0x0145
        L_0x012c:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r3 = "Unsupported clock rate index in DTS UHD header: "
            r1.<init>(r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r2 = 0
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x0140:
            r2 = r17
            goto L_0x0145
        L_0x0143:
            r2 = r16
        L_0x0145:
            boolean r6 = r3.g()
            if (r6 == 0) goto L_0x0150
            r6 = 36
            r3.p(r6)
        L_0x0150:
            int r6 = r3.h(r11)
            int r6 = r8 << r6
            int r14 = r2 * r6
            long r6 = (long) r7
            long r9 = (long) r2
            java.math.RoundingMode r39 = java.math.RoundingMode.DOWN
            r35 = 1000000(0xf4240, double:4.940656E-318)
            r33 = r6
            r37 = r9
            long r6 = o2.C2756B.W(r33, r35, r37, r39)
            r12 = r14
            r14 = r6
            goto L_0x017e
        L_0x016a:
            java.lang.String r1 = "CRC check failed"
            r2 = 0
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x0172:
            java.lang.String r1 = "Only supports full channel mask-based audio presentation"
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x0179:
            r14 = r22
            r12 = -2147483647(0xffffffff80000001, float:-1.4E-45)
        L_0x017e:
            r2 = 0
            r6 = 0
        L_0x0180:
            if (r2 >= r4) goto L_0x018b
            int[] r7 = R2.m.f8190f
            int r7 = R2.m.b(r3, r7)
            int r6 = r6 + r7
            int r2 = r2 + r8
            goto L_0x0180
        L_0x018b:
            if (r4 == 0) goto L_0x0196
            int[] r2 = R2.m.f8191g
            int r2 = R2.m.b(r3, r2)
            r13.set(r2)
        L_0x0196:
            int r2 = r13.get()
            if (r2 == 0) goto L_0x01a3
            int[] r2 = R2.m.f8192h
            int r2 = R2.m.b(r3, r2)
            goto L_0x01a4
        L_0x01a3:
            r2 = 0
        L_0x01a4:
            int r6 = r6 + r2
            int r13 = r6 + r24
            R2.m$a r9 = new R2.m$a
            java.lang.String r10 = "audio/vnd.dts.uhd;profile=p2"
            r11 = 2
            r9.<init>(r10, r11, r12, r13, r14)
            int r2 = r0.f30842n
            r3 = 3
            if (r2 != r3) goto L_0x01b7
            r0.g(r9)
        L_0x01b7:
            r0.f30841m = r13
            int r2 = (r14 > r22 ? 1 : (r14 == r22 ? 0 : -1))
            if (r2 != 0) goto L_0x01c0
            r12 = 0
            goto L_0x01c1
        L_0x01c0:
            r12 = r14
        L_0x01c1:
            r0.f30839k = r12
            r2 = 0
            r5.G(r2)
            R2.H r2 = r0.f30835g
            int r3 = r0.f30844p
            r2.e(r3, r5)
            r2 = 6
            r0.f30836h = r2
        L_0x01d1:
            r3 = r29
            goto L_0x000b
        L_0x01d5:
            r29 = r3
            r2 = 6
            byte[] r3 = r5.f25885a
            boolean r2 = r0.a(r1, r3, r2)
            if (r2 == 0) goto L_0x01d1
            byte[] r2 = r5.f25885a
            U1.c r2 = R2.m.a(r2)
            r2.p(r4)
            int[] r3 = R2.m.f8193i
            int r2 = R2.m.b(r2, r3)
            int r2 = r2 + r8
            r0.f30844p = r2
            int r3 = r0.f30837i
            if (r3 <= r2) goto L_0x0201
            int r2 = r3 - r2
            int r3 = r3 - r2
            r0.f30837i = r3
            int r3 = r1.f25886b
            int r3 = r3 - r2
            r1.G(r3)
        L_0x0201:
            r0.f30836h = r13
            goto L_0x01d1
        L_0x0204:
            r29 = r3
            byte[] r2 = r5.f25885a
            int r3 = r0.f30843o
            boolean r2 = r0.a(r1, r2, r3)
            if (r2 == 0) goto L_0x034c
            byte[] r2 = r5.f25885a
            U1.c r2 = R2.m.a(r2)
            r3 = 40
            r2.p(r3)
            int r3 = r2.h(r11)
            boolean r4 = r2.g()
            if (r4 != 0) goto L_0x022a
            r4 = r19
            r6 = r28
            goto L_0x022e
        L_0x022a:
            r4 = 20
            r6 = r27
        L_0x022e:
            r2.p(r6)
            int r6 = r2.h(r4)
            int r38 = r6 + 1
            boolean r6 = r2.g()
            if (r6 == 0) goto L_0x029c
            int r7 = r2.h(r11)
            r9 = 3
            int r10 = r2.h(r9)
            int r10 = r10 + r8
            r12 = 512(0x200, float:7.175E-43)
            int r10 = r10 * r12
            boolean r12 = r2.g()
            if (r12 == 0) goto L_0x0255
            r12 = 36
            r2.p(r12)
        L_0x0255:
            int r12 = r2.h(r9)
            int r12 = r12 + r8
            int r9 = r2.h(r9)
            int r9 = r9 + r8
            if (r12 != r8) goto L_0x0295
            if (r9 != r8) goto L_0x0295
            int r3 = r3 + r8
            int r9 = r2.h(r3)
            r12 = 0
        L_0x0269:
            if (r12 >= r3) goto L_0x0279
            int r14 = r9 >> r12
            r14 = r14 & r8
            if (r14 != r8) goto L_0x0275
            r14 = r28
            r2.p(r14)
        L_0x0275:
            int r12 = r12 + r8
            r28 = 8
            goto L_0x0269
        L_0x0279:
            boolean r3 = r2.g()
            if (r3 == 0) goto L_0x029f
            r2.p(r11)
            int r3 = r2.h(r11)
            int r3 = r3 + r8
            int r3 = r3 << r11
            int r9 = r2.h(r11)
            int r9 = r9 + r8
            r12 = 0
        L_0x028e:
            if (r12 >= r9) goto L_0x029f
            r2.p(r3)
            int r12 = r12 + r8
            goto L_0x028e
        L_0x0295:
            java.lang.String r1 = "Multiple audio presentations or assets not supported"
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x029c:
            r7 = r21
            r10 = 0
        L_0x029f:
            r2.p(r4)
            r3 = r27
            r2.p(r3)
            if (r6 == 0) goto L_0x02e7
            boolean r3 = r2.g()
            if (r3 == 0) goto L_0x02b4
            r3 = r29
            r2.p(r3)
        L_0x02b4:
            boolean r3 = r2.g()
            if (r3 == 0) goto L_0x02bf
            r3 = 24
            r2.p(r3)
        L_0x02bf:
            boolean r3 = r2.g()
            if (r3 == 0) goto L_0x02cf
            r3 = 10
            int r3 = r2.h(r3)
            int r3 = r3 + r8
            r2.q(r3)
        L_0x02cf:
            r2.p(r13)
            int[] r3 = R2.m.f8188d
            r4 = 4
            int r9 = r2.h(r4)
            r14 = r3[r9]
            r3 = 8
            int r2 = r2.h(r3)
            int r2 = r2 + r8
            r36 = r2
            r37 = r14
            goto L_0x02ec
        L_0x02e7:
            r36 = r21
            r37 = -2147483647(0xffffffff80000001, float:-1.4E-45)
        L_0x02ec:
            if (r6 == 0) goto L_0x0321
            if (r7 == 0) goto L_0x030e
            if (r7 == r8) goto L_0x030b
            if (r7 != r11) goto L_0x02f7
            r2 = r18
            goto L_0x0310
        L_0x02f7:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Unsupported reference clock code in DTS HD header: "
            r1.<init>(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            r2 = 0
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x030b:
            r2 = r17
            goto L_0x0310
        L_0x030e:
            r2 = r16
        L_0x0310:
            long r11 = (long) r10
            long r2 = (long) r2
            int r4 = o2.C2756B.f25811a
            java.math.RoundingMode r17 = java.math.RoundingMode.DOWN
            r13 = 1000000(0xf4240, double:4.940656E-318)
            r15 = r2
            long r2 = o2.C2756B.W(r11, r13, r15, r17)
            r39 = r2
            goto L_0x0323
        L_0x0321:
            r39 = r22
        L_0x0323:
            R2.m$a r34 = new R2.m$a
            java.lang.String r35 = "audio/vnd.dts.hd;profile=lbr"
            r34.<init>(r35, r36, r37, r38, r39)
            r2 = r34
            r6 = r38
            r0.g(r2)
            r0.f30841m = r6
            int r2 = (r39 > r22 ? 1 : (r39 == r22 ? 0 : -1))
            if (r2 != 0) goto L_0x033a
            r12 = 0
            goto L_0x033c
        L_0x033a:
            r12 = r39
        L_0x033c:
            r0.f30839k = r12
            r2 = 0
            r5.G(r2)
            R2.H r2 = r0.f30835g
            int r3 = r0.f30843o
            r2.e(r3, r5)
            r2 = 6
            r0.f30836h = r2
        L_0x034c:
            r3 = 4
            goto L_0x000b
        L_0x034f:
            byte[] r2 = r5.f25885a
            r3 = 7
            boolean r2 = r0.a(r1, r2, r3)
            if (r2 == 0) goto L_0x034c
            byte[] r2 = r5.f25885a
            U1.c r2 = R2.m.a(r2)
            r3 = 42
            r2.p(r3)
            boolean r3 = r2.g()
            if (r3 == 0) goto L_0x036c
            r3 = 12
            goto L_0x036e
        L_0x036c:
            r3 = 8
        L_0x036e:
            int r2 = r2.h(r3)
            int r2 = r2 + r8
            r0.f30843o = r2
            r2 = 3
            r0.f30836h = r2
            goto L_0x034c
        L_0x0379:
            byte[] r2 = r5.f25885a
            r3 = 18
            boolean r2 = r0.a(r1, r2, r3)
            if (r2 == 0) goto L_0x04f4
            byte[] r2 = r5.f25885a
            l2.n r6 = r0.f30840l
            r7 = 60
            if (r6 != 0) goto L_0x03fc
            java.lang.String r6 = r0.f30834f
            U1.c r9 = R2.m.a(r2)
            r9.p(r7)
            r10 = 6
            int r12 = r9.h(r10)
            int[] r10 = R2.m.f8185a
            r10 = r10[r12]
            r12 = 4
            int r14 = r9.h(r12)
            int[] r12 = R2.m.f8186b
            r12 = r12[r14]
            int r14 = r9.h(r13)
            r15 = 29
            if (r14 < r15) goto L_0x03b3
            r14 = r21
        L_0x03b0:
            r15 = 10
            goto L_0x03bb
        L_0x03b3:
            int[] r15 = R2.m.f8187c
            r14 = r15[r14]
            int r14 = r14 * 1000
            int r14 = r14 / r11
            goto L_0x03b0
        L_0x03bb:
            r9.p(r15)
            int r9 = r9.h(r11)
            if (r9 <= 0) goto L_0x03c6
            r9 = r8
            goto L_0x03c7
        L_0x03c6:
            r9 = 0
        L_0x03c7:
            int r10 = r10 + r9
            l2.n$a r9 = new l2.n$a
            r9.<init>()
            r9.f24316a = r6
            java.lang.String r6 = r0.f30833e
            java.lang.String r6 = l2.u.p(r6)
            r9.f24327l = r6
            java.lang.String r6 = "audio/vnd.dts"
            java.lang.String r6 = l2.u.p(r6)
            r9.f24328m = r6
            r9.f24323h = r14
            r9.f24306C = r10
            r9.f24307D = r12
            r6 = 0
            r9.f24332q = r6
            java.lang.String r6 = r0.f30831c
            r9.f24319d = r6
            int r6 = r0.f30832d
            r9.f24321f = r6
            l2.n r6 = new l2.n
            r6.<init>(r9)
            r0.f30840l = r6
            R2.H r9 = r0.f30835g
            r9.d(r6)
        L_0x03fc:
            r31 = 0
            byte r6 = r2[r31]
            r9 = 31
            r10 = -2
            if (r6 == r10) goto L_0x046b
            r12 = r21
            if (r6 == r12) goto L_0x044f
            if (r6 == r9) goto L_0x042e
            byte r12 = r2[r13]
            r32 = 3
            r12 = r12 & 3
            r27 = 12
            int r12 = r12 << 12
            r30 = 6
            byte r14 = r2[r30]
            r14 = r14 & 255(0xff, float:3.57E-43)
            r29 = 4
            int r14 = r14 << 4
            r12 = r12 | r14
            r24 = 7
            byte r14 = r2[r24]
            r14 = r14 & 240(0xf0, float:3.36E-43)
            int r14 = r14 >> 4
            r12 = r12 | r14
            int r12 = r12 + r8
            r14 = 0
        L_0x042b:
            r27 = 12
            goto L_0x048b
        L_0x042e:
            r24 = 7
            r29 = 4
            r30 = 6
            byte r12 = r2[r30]
            r32 = 3
            r12 = r12 & 3
            r27 = 12
            int r12 = r12 << 12
            byte r14 = r2[r24]
            r14 = r14 & 255(0xff, float:3.57E-43)
            int r14 = r14 << 4
            r12 = r12 | r14
            r28 = 8
            byte r14 = r2[r28]
        L_0x0449:
            r14 = r14 & r7
            int r14 = r14 >> r11
            r12 = r12 | r14
            int r12 = r12 + r8
            r14 = r8
            goto L_0x042b
        L_0x044f:
            r24 = 7
            byte r12 = r2[r24]
            r32 = 3
            r12 = r12 & 3
            r27 = 12
            int r12 = r12 << 12
            r30 = 6
            byte r14 = r2[r30]
            r14 = r14 & 255(0xff, float:3.57E-43)
            r29 = 4
            int r14 = r14 << 4
            r12 = r12 | r14
            r14 = 9
            byte r14 = r2[r14]
            goto L_0x0449
        L_0x046b:
            r29 = 4
            byte r12 = r2[r29]
            r32 = 3
            r12 = r12 & 3
            r27 = 12
            int r12 = r12 << 12
            r24 = 7
            byte r14 = r2[r24]
            r14 = r14 & 255(0xff, float:3.57E-43)
            int r14 = r14 << 4
            r12 = r12 | r14
            r30 = 6
            byte r14 = r2[r30]
            r14 = r14 & 240(0xf0, float:3.36E-43)
            int r14 = r14 >> 4
            r12 = r12 | r14
            int r12 = r12 + r8
            r14 = 0
        L_0x048b:
            if (r14 == 0) goto L_0x0491
            int r12 = r12 * 16
            int r12 = r12 / 14
        L_0x0491:
            r0.f30841m = r12
            if (r6 == r10) goto L_0x04c7
            r10 = -1
            if (r6 == r10) goto L_0x04ba
            if (r6 == r9) goto L_0x04aa
            r29 = 4
            byte r6 = r2[r29]
            r6 = r6 & r8
            r30 = 6
            int r6 = r6 << 6
            byte r2 = r2[r13]
        L_0x04a5:
            r2 = r2 & 252(0xfc, float:3.53E-43)
        L_0x04a7:
            int r2 = r2 >> r11
            r2 = r2 | r6
            goto L_0x04d4
        L_0x04aa:
            r29 = 4
            r30 = 6
            byte r6 = r2[r13]
            r24 = 7
            r6 = r6 & 7
            int r6 = r6 << 4
            byte r2 = r2[r30]
        L_0x04b8:
            r2 = r2 & r7
            goto L_0x04a7
        L_0x04ba:
            r24 = 7
            r29 = 4
            byte r6 = r2[r29]
            r6 = r6 & 7
            int r6 = r6 << 4
            byte r2 = r2[r24]
            goto L_0x04b8
        L_0x04c7:
            r10 = -1
            r29 = 4
            byte r6 = r2[r13]
            r6 = r6 & r8
            r30 = 6
            int r6 = r6 << 6
            byte r2 = r2[r29]
            goto L_0x04a5
        L_0x04d4:
            int r2 = r2 + r8
            int r2 = r2 * r4
            long r6 = (long) r2
            l2.n r2 = r0.f30840l
            int r2 = r2.f24268E
            long r6 = o2.C2756B.U(r2, r6)
            int r2 = W7.b.s0(r6)
            long r6 = (long) r2
            r0.f30839k = r6
            r2 = 0
            r5.G(r2)
            R2.H r2 = r0.f30835g
            r2.e(r3, r5)
            r2 = 6
            r0.f30836h = r2
            goto L_0x034c
        L_0x04f4:
            r27 = 12
            goto L_0x034c
        L_0x04f8:
            r10 = r21
        L_0x04fa:
            int r2 = r1.a()
            if (r2 <= 0) goto L_0x0590
            int r2 = r0.f30838j
            r28 = 8
            int r2 = r2 << 8
            r0.f30838j = r2
            int r3 = r1.u()
            r2 = r2 | r3
            r0.f30838j = r2
            r3 = 2147385345(0x7ffe8001, float:NaN)
            if (r2 == r3) goto L_0x054a
            r3 = -25230976(0xfffffffffe7f0180, float:-8.474023E37)
            if (r2 == r3) goto L_0x054a
            r3 = 536864768(0x1fffe800, float:1.0838051E-19)
            if (r2 == r3) goto L_0x054a
            r3 = -14745368(0xffffffffff1f00e8, float:-2.1135196E38)
            if (r2 != r3) goto L_0x0524
            goto L_0x054a
        L_0x0524:
            r3 = 1683496997(0x64582025, float:1.5947252E22)
            if (r2 == r3) goto L_0x0548
            r3 = 622876772(0x25205864, float:1.3907736E-16)
            if (r2 != r3) goto L_0x052f
            goto L_0x0548
        L_0x052f:
            if (r2 == r12) goto L_0x0546
            r3 = -233094848(0xfffffffff21b4140, float:-3.0751398E30)
            if (r2 != r3) goto L_0x0537
            goto L_0x0546
        L_0x0537:
            r3 = 1908687592(0x71c442e8, float:1.9436783E30)
            if (r2 == r3) goto L_0x0544
            r3 = -398277519(0xffffffffe842c471, float:-3.6790512E24)
            if (r2 != r3) goto L_0x0542
            goto L_0x0544
        L_0x0542:
            r3 = 0
            goto L_0x054b
        L_0x0544:
            r3 = 4
            goto L_0x054b
        L_0x0546:
            r3 = 3
            goto L_0x054b
        L_0x0548:
            r3 = r11
            goto L_0x054b
        L_0x054a:
            r3 = r8
        L_0x054b:
            r0.f30842n = r3
            if (r3 == 0) goto L_0x058a
            byte[] r4 = r5.f25885a
            r26 = 24
            int r5 = r2 >> 24
            r5 = r5 & 255(0xff, float:3.57E-43)
            byte r5 = (byte) r5
            r31 = 0
            r4[r31] = r5
            int r5 = r2 >> 16
            r5 = r5 & 255(0xff, float:3.57E-43)
            byte r5 = (byte) r5
            r4[r8] = r5
            r28 = 8
            int r5 = r2 >> 8
            r5 = r5 & 255(0xff, float:3.57E-43)
            byte r5 = (byte) r5
            r4[r11] = r5
            r2 = r2 & 255(0xff, float:3.57E-43)
            byte r2 = (byte) r2
            r9 = 3
            r4[r9] = r2
            r4 = 4
            r0.f30837i = r4
            r2 = 0
            r0.f30838j = r2
            if (r3 == r9) goto L_0x0587
            if (r3 != r4) goto L_0x057d
            goto L_0x0587
        L_0x057d:
            if (r3 != r8) goto L_0x0584
            r0.f30836h = r8
        L_0x0581:
            r3 = r4
            goto L_0x000b
        L_0x0584:
            r0.f30836h = r11
            goto L_0x0581
        L_0x0587:
            r0.f30836h = r4
            goto L_0x0581
        L_0x058a:
            r26 = 24
            r28 = 8
            goto L_0x04fa
        L_0x0590:
            r26 = 24
            r28 = 8
            goto L_0x034c
        L_0x0596:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.h.c(o2.t):void");
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30834f = cVar.f30757e;
        cVar.b();
        this.f30835g = pVar.k(cVar.f30756d, 1);
    }

    public final void f(int i10, long j10) {
        this.f30845q = j10;
    }

    public final void g(m.a aVar) {
        int i10;
        n.a aVar2;
        int i11 = aVar.f8195b;
        if (i11 != -2147483647 && (i10 = aVar.f8196c) != -1) {
            n nVar = this.f30840l;
            String str = aVar.f8194a;
            if (nVar == null || i10 != nVar.f24267D || i11 != nVar.f24268E || !str.equals(nVar.f24291n)) {
                n nVar2 = this.f30840l;
                if (nVar2 == null) {
                    aVar2 = new n.a();
                } else {
                    aVar2 = nVar2.a();
                }
                aVar2.f24316a = this.f30834f;
                aVar2.f24327l = u.p(this.f30833e);
                aVar2.f24328m = u.p(str);
                aVar2.f24306C = i10;
                aVar2.f24307D = i11;
                aVar2.f24319d = this.f30831c;
                aVar2.f24321f = this.f30832d;
                n nVar3 = new n(aVar2);
                this.f30840l = nVar3;
                this.f30835g.d(nVar3);
            }
        }
    }

    public final void e(boolean z10) {
    }
}
