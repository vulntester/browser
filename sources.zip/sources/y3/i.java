package y3;

import D2.E;
import R2.H;
import R2.p;
import f7.M;
import java.util.Collections;
import java.util.List;
import l2.n;
import l2.u;
import o2.t;
import y3.F;

public final class i implements j {

    /* renamed from: a  reason: collision with root package name */
    public final List<F.a> f30846a;

    /* renamed from: b  reason: collision with root package name */
    public final H[] f30847b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f30848c;

    /* renamed from: d  reason: collision with root package name */
    public int f30849d;

    /* renamed from: e  reason: collision with root package name */
    public int f30850e;

    /* renamed from: f  reason: collision with root package name */
    public long f30851f = -9223372036854775807L;

    public i(List list) {
        this.f30846a = list;
        this.f30847b = new H[list.size()];
    }

    public final void b() {
        this.f30848c = false;
        this.f30851f = -9223372036854775807L;
    }

    public final void c(t tVar) {
        boolean z10;
        boolean z11;
        if (this.f30848c) {
            if (this.f30849d == 2) {
                if (tVar.a() == 0) {
                    z11 = false;
                } else {
                    if (tVar.u() != 32) {
                        this.f30848c = false;
                    }
                    this.f30849d--;
                    z11 = this.f30848c;
                }
                if (!z11) {
                    return;
                }
            }
            if (this.f30849d == 1) {
                if (tVar.a() == 0) {
                    z10 = false;
                } else {
                    if (tVar.u() != 0) {
                        this.f30848c = false;
                    }
                    this.f30849d--;
                    z10 = this.f30848c;
                }
                if (!z10) {
                    return;
                }
            }
            int i10 = tVar.f25886b;
            int a10 = tVar.a();
            for (H e10 : this.f30847b) {
                tVar.G(i10);
                e10.e(a10, tVar);
            }
            this.f30850e += a10;
        }
    }

    public final void d(p pVar, F.c cVar) {
        int i10 = 0;
        while (true) {
            H[] hArr = this.f30847b;
            if (i10 < hArr.length) {
                F.a aVar = this.f30846a.get(i10);
                cVar.a();
                cVar.b();
                H k10 = pVar.k(cVar.f30756d, 3);
                n.a aVar2 = new n.a();
                cVar.b();
                aVar2.f24316a = cVar.f30757e;
                aVar2.f24327l = u.p("video/mp2t");
                aVar2.f24328m = u.p("application/dvbsubs");
                aVar2.f24331p = Collections.singletonList(aVar.f30748b);
                aVar2.f24319d = aVar.f30747a;
                E.r(aVar2, k10);
                hArr[i10] = k10;
                i10++;
            } else {
                return;
            }
        }
    }

    public final void e(boolean z10) {
        boolean z11;
        if (this.f30848c) {
            if (this.f30851f != -9223372036854775807L) {
                z11 = true;
            } else {
                z11 = false;
            }
            M.m(z11);
            for (H b10 : this.f30847b) {
                b10.b(this.f30851f, 1, this.f30850e, 0, (H.a) null);
            }
            this.f30848c = false;
        }
    }

    public final void f(int i10, long j10) {
        if ((i10 & 4) != 0) {
            this.f30848c = true;
            this.f30851f = j10;
            this.f30850e = 0;
            this.f30849d = 2;
        }
    }
}
