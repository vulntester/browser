package y3;

import R2.p;
import o2.t;
import y3.F;

public interface j {
    void b();

    void c(t tVar);

    void d(p pVar, F.c cVar);

    void e(boolean z10);

    void f(int i10, long j10);
}
