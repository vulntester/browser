package y3;

import R2.H;
import R2.p;
import f7.M;
import io.netty.handler.codec.http.HttpObjectDecoder;
import java.util.Arrays;
import o2.t;
import p2.C2893f;
import y3.F;

public final class k implements j {

    /* renamed from: r  reason: collision with root package name */
    public static final double[] f30852r = {23.976023976023978d, 24.0d, 25.0d, 29.97002997002997d, 30.0d, 50.0d, 59.94005994005994d, 60.0d};

    /* renamed from: a  reason: collision with root package name */
    public String f30853a;

    /* renamed from: b  reason: collision with root package name */
    public H f30854b;

    /* renamed from: c  reason: collision with root package name */
    public final G f30855c;

    /* renamed from: d  reason: collision with root package name */
    public final String f30856d;

    /* renamed from: e  reason: collision with root package name */
    public final t f30857e;

    /* renamed from: f  reason: collision with root package name */
    public final t f30858f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean[] f30859g = new boolean[4];

    /* renamed from: h  reason: collision with root package name */
    public final a f30860h;

    /* renamed from: i  reason: collision with root package name */
    public long f30861i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f30862j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f30863k;

    /* renamed from: l  reason: collision with root package name */
    public long f30864l;

    /* renamed from: m  reason: collision with root package name */
    public long f30865m;

    /* renamed from: n  reason: collision with root package name */
    public long f30866n;

    /* renamed from: o  reason: collision with root package name */
    public long f30867o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f30868p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f30869q;

    public static final class a {

        /* renamed from: e  reason: collision with root package name */
        public static final byte[] f30870e = {0, 0, 1};

        /* renamed from: a  reason: collision with root package name */
        public boolean f30871a;

        /* renamed from: b  reason: collision with root package name */
        public int f30872b;

        /* renamed from: c  reason: collision with root package name */
        public int f30873c;

        /* renamed from: d  reason: collision with root package name */
        public byte[] f30874d;

        public final void a(int i10, byte[] bArr, int i11) {
            if (this.f30871a) {
                int i12 = i11 - i10;
                byte[] bArr2 = this.f30874d;
                int length = bArr2.length;
                int i13 = this.f30872b + i12;
                if (length < i13) {
                    this.f30874d = Arrays.copyOf(bArr2, i13 * 2);
                }
                System.arraycopy(bArr, i10, this.f30874d, this.f30872b, i12);
                this.f30872b += i12;
            }
        }
    }

    /* JADX WARNING: type inference failed for: r3v3, types: [java.lang.Object, y3.k$a] */
    public k(G g6, String str) {
        this.f30855c = g6;
        this.f30856d = str;
        ? obj = new Object();
        obj.f30874d = new byte[HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE];
        this.f30860h = obj;
        if (g6 != null) {
            this.f30858f = new t(178);
            this.f30857e = new t();
        } else {
            this.f30858f = null;
            this.f30857e = null;
        }
        this.f30865m = -9223372036854775807L;
        this.f30867o = -9223372036854775807L;
    }

    public final void b() {
        C2893f.a(this.f30859g);
        a aVar = this.f30860h;
        aVar.f30871a = false;
        aVar.f30872b = 0;
        aVar.f30873c = 0;
        t tVar = this.f30858f;
        if (tVar != null) {
            tVar.c();
        }
        this.f30861i = 0;
        this.f30862j = false;
        this.f30865m = -9223372036854775807L;
        this.f30867o = -9223372036854775807L;
    }

    /* JADX WARNING: Removed duplicated region for block: B:66:0x01a9  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x01b1  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(o2.t r29) {
        /*
            r28 = this;
            r0 = r28
            r1 = r29
            r5 = 3
            R2.H r6 = r0.f30854b
            f7.M.n(r6)
            int r6 = r1.f25886b
            int r7 = r1.f25887c
            byte[] r8 = r1.f25885a
            long r9 = r0.f30861i
            int r11 = r1.a()
            long r11 = (long) r11
            long r9 = r9 + r11
            r0.f30861i = r9
            R2.H r9 = r0.f30854b
            int r10 = r1.a()
            r9.e(r10, r1)
        L_0x0023:
            boolean[] r9 = r0.f30859g
            int r9 = p2.C2893f.b(r8, r6, r7, r9)
            y3.k$a r10 = r0.f30860h
            y3.t r11 = r0.f30858f
            if (r9 != r7) goto L_0x003c
            boolean r1 = r0.f30863k
            if (r1 != 0) goto L_0x0036
            r10.a(r6, r8, r7)
        L_0x0036:
            if (r11 == 0) goto L_0x003b
            r11.a(r6, r8, r7)
        L_0x003b:
            return
        L_0x003c:
            byte[] r12 = r1.f25885a
            int r13 = r9 + 3
            byte r12 = r12[r13]
            r12 = r12 & 255(0xff, float:3.57E-43)
            int r14 = r9 - r6
            boolean r15 = r0.f30863k
            r16 = 1
            r4 = 0
            if (r15 != 0) goto L_0x0161
            if (r14 <= 0) goto L_0x0052
            r10.a(r6, r8, r9)
        L_0x0052:
            if (r14 >= 0) goto L_0x0058
            int r15 = -r14
        L_0x0055:
            r17 = 4
            goto L_0x005a
        L_0x0058:
            r15 = r4
            goto L_0x0055
        L_0x005a:
            boolean r3 = r10.f30871a
            if (r3 == 0) goto L_0x0151
            int r3 = r10.f30872b
            int r3 = r3 - r15
            r10.f30872b = r3
            int r15 = r10.f30873c
            if (r15 != 0) goto L_0x006f
            r15 = 181(0xb5, float:2.54E-43)
            if (r12 != r15) goto L_0x006f
            r10.f30873c = r3
            goto L_0x0159
        L_0x006f:
            r10.f30871a = r4
            java.lang.String r3 = r0.f30853a
            r3.getClass()
            byte[] r15 = r10.f30874d
            int r4 = r10.f30872b
            byte[] r4 = java.util.Arrays.copyOf(r15, r4)
            byte r15 = r4[r17]
            r15 = r15 & 255(0xff, float:3.57E-43)
            r18 = 5
            byte r5 = r4[r18]
            r2 = r5 & 255(0xff, float:3.57E-43)
            r21 = 6
            r22 = r2
            byte r2 = r4[r21]
            r2 = r2 & 255(0xff, float:3.57E-43)
            int r15 = r15 << 4
            int r21 = r22 >> 4
            r15 = r15 | r21
            r5 = r5 & 15
            r21 = r2
            r2 = 8
            int r5 = r5 << r2
            r5 = r5 | r21
            r21 = 7
            byte r2 = r4[r21]
            r2 = r2 & 240(0xf0, float:3.36E-43)
            int r2 = r2 >> 4
            r23 = r4
            r4 = 2
            if (r2 == r4) goto L_0x00c6
            r4 = 3
            if (r2 == r4) goto L_0x00c0
            r4 = r17
            if (r2 == r4) goto L_0x00b8
            r2 = 1065353216(0x3f800000, float:1.0)
        L_0x00b5:
            r17 = 4
            goto L_0x00cf
        L_0x00b8:
            int r2 = r5 * 121
            float r2 = (float) r2
            int r4 = r15 * 100
        L_0x00bd:
            float r4 = (float) r4
            float r2 = r2 / r4
            goto L_0x00b5
        L_0x00c0:
            int r2 = r5 * 16
            float r2 = (float) r2
            int r4 = r15 * 9
            goto L_0x00bd
        L_0x00c6:
            int r2 = r5 * 4
            float r2 = (float) r2
            r19 = 3
            int r4 = r15 * 3
            float r4 = (float) r4
            float r2 = r2 / r4
        L_0x00cf:
            l2.n$a r4 = new l2.n$a
            r4.<init>()
            r4.f24316a = r3
            java.lang.String r3 = r0.f30856d
            java.lang.String r3 = l2.u.p(r3)
            r4.f24327l = r3
            java.lang.String r3 = "video/mpeg2"
            java.lang.String r3 = l2.u.p(r3)
            r4.f24328m = r3
            r4.f24335t = r15
            r4.f24336u = r5
            r4.f24339x = r2
            java.util.List r2 = java.util.Collections.singletonList(r23)
            r4.f24331p = r2
            l2.n r2 = new l2.n
            r2.<init>(r4)
            byte r3 = r23[r21]
            r3 = r3 & 15
            int r3 = r3 + -1
            if (r3 < 0) goto L_0x012e
            r4 = 8
            if (r3 >= r4) goto L_0x012e
            double[] r4 = f30852r
            r3 = r4[r3]
            int r5 = r10.f30873c
            int r5 = r5 + 9
            byte r5 = r23[r5]
            r10 = r5 & 96
            int r10 = r10 >> 5
            r5 = r5 & 31
            r21 = r3
            if (r10 == r5) goto L_0x0125
            double r3 = (double) r10
            r23 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            double r3 = r3 + r23
            int r5 = r5 + 1
            r23 = r3
            double r3 = (double) r5
            double r3 = r23 / r3
            double r3 = r3 * r21
        L_0x0125:
            r21 = 4696837146684686336(0x412e848000000000, double:1000000.0)
            double r3 = r21 / r3
            long r3 = (long) r3
            goto L_0x0130
        L_0x012e:
            r3 = 0
        L_0x0130:
            java.lang.Long r3 = java.lang.Long.valueOf(r3)
            android.util.Pair r2 = android.util.Pair.create(r2, r3)
            R2.H r3 = r0.f30854b
            java.lang.Object r4 = r2.first
            l2.n r4 = (l2.n) r4
            r3.d(r4)
            java.lang.Object r2 = r2.second
            java.lang.Long r2 = (java.lang.Long) r2
            long r2 = r2.longValue()
            r0.f30864l = r2
            r2 = r16
            r0.f30863k = r2
            r4 = 3
            goto L_0x0164
        L_0x0151:
            r2 = r16
            r3 = 179(0xb3, float:2.51E-43)
            if (r12 != r3) goto L_0x0159
            r10.f30871a = r2
        L_0x0159:
            byte[] r2 = y3.k.a.f30870e
            r3 = 0
            r4 = 3
            r10.a(r3, r2, r4)
            goto L_0x0164
        L_0x0161:
            r4 = r5
            r17 = 4
        L_0x0164:
            if (r11 == 0) goto L_0x019f
            if (r14 <= 0) goto L_0x016d
            r11.a(r6, r8, r9)
            r3 = 0
            goto L_0x016e
        L_0x016d:
            int r3 = -r14
        L_0x016e:
            boolean r2 = r11.b(r3)
            if (r2 == 0) goto L_0x018c
            byte[] r2 = r11.f31047d
            int r3 = r11.f31048e
            int r2 = p2.C2893f.l(r3, r2)
            int r3 = o2.C2756B.f25811a
            byte[] r3 = r11.f31047d
            o2.t r5 = r0.f30857e
            r5.E(r2, r3)
            long r2 = r0.f30867o
            y3.G r6 = r0.f30855c
            r6.a(r2, r5)
        L_0x018c:
            r2 = 178(0xb2, float:2.5E-43)
            if (r12 != r2) goto L_0x019f
            byte[] r2 = r1.f25885a
            r20 = 2
            int r3 = r9 + 2
            byte r2 = r2[r3]
            r3 = 1
            if (r2 != r3) goto L_0x01a2
            r11.d(r12)
            goto L_0x01a2
        L_0x019f:
            r3 = 1
            r20 = 2
        L_0x01a2:
            if (r12 == 0) goto L_0x01b1
            r2 = 179(0xb3, float:2.51E-43)
            if (r12 != r2) goto L_0x01a9
            goto L_0x01b1
        L_0x01a9:
            r2 = 184(0xb8, float:2.58E-43)
            if (r12 != r2) goto L_0x01af
            r0.f30868p = r3
        L_0x01af:
            r2 = r3
            goto L_0x0212
        L_0x01b1:
            int r26 = r7 - r9
            boolean r2 = r0.f30869q
            r5 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            if (r2 == 0) goto L_0x01dd
            boolean r2 = r0.f30863k
            if (r2 == 0) goto L_0x01dd
            long r2 = r0.f30867o
            int r9 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r9 == 0) goto L_0x01dd
            boolean r9 = r0.f30868p
            long r10 = r0.f30861i
            long r14 = r0.f30866n
            long r10 = r10 - r14
            int r10 = (int) r10
            int r25 = r10 - r26
            R2.H r10 = r0.f30854b
            r27 = 0
            r22 = r2
            r24 = r9
            r21 = r10
            r21.b(r22, r24, r25, r26, r27)
        L_0x01dd:
            r2 = r26
            boolean r3 = r0.f30862j
            if (r3 == 0) goto L_0x01eb
            boolean r3 = r0.f30869q
            if (r3 == 0) goto L_0x01e8
            goto L_0x01eb
        L_0x01e8:
            r2 = 1
            r3 = 0
            goto L_0x020d
        L_0x01eb:
            long r9 = r0.f30861i
            long r2 = (long) r2
            long r9 = r9 - r2
            r0.f30866n = r9
            long r2 = r0.f30865m
            int r9 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r9 == 0) goto L_0x01f8
            goto L_0x0203
        L_0x01f8:
            long r2 = r0.f30867o
            int r9 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r9 == 0) goto L_0x0202
            long r9 = r0.f30864l
            long r2 = r2 + r9
            goto L_0x0203
        L_0x0202:
            r2 = r5
        L_0x0203:
            r0.f30867o = r2
            r3 = 0
            r0.f30868p = r3
            r0.f30865m = r5
            r2 = 1
            r0.f30862j = r2
        L_0x020d:
            if (r12 != 0) goto L_0x0210
            r3 = r2
        L_0x0210:
            r0.f30869q = r3
        L_0x0212:
            r5 = r4
            r6 = r13
            goto L_0x0023
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.k.c(o2.t):void");
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30853a = cVar.f30757e;
        cVar.b();
        this.f30854b = pVar.k(cVar.f30756d, 2);
        G g6 = this.f30855c;
        if (g6 != null) {
            g6.b(pVar, cVar);
        }
    }

    public final void e(boolean z10) {
        M.n(this.f30854b);
        if (z10) {
            boolean z11 = this.f30868p;
            this.f30854b.b(this.f30867o, z11 ? 1 : 0, (int) (this.f30861i - this.f30866n), 0, (H.a) null);
        }
    }

    public final void f(int i10, long j10) {
        this.f30865m = j10;
    }
}
