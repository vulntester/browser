package y3;

import R2.H;
import R2.p;
import f7.M;
import io.netty.handler.codec.http.HttpObjectDecoder;
import java.util.Arrays;
import o2.t;
import p2.C2893f;
import y3.F;

public final class l implements j {

    /* renamed from: l  reason: collision with root package name */
    public static final float[] f30875l = {1.0f, 1.0f, 1.0909091f, 0.90909094f, 1.4545455f, 1.2121212f, 1.0f};

    /* renamed from: a  reason: collision with root package name */
    public final G f30876a;

    /* renamed from: b  reason: collision with root package name */
    public final t f30877b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean[] f30878c = new boolean[4];

    /* renamed from: d  reason: collision with root package name */
    public final a f30879d;

    /* renamed from: e  reason: collision with root package name */
    public final t f30880e;

    /* renamed from: f  reason: collision with root package name */
    public b f30881f;

    /* renamed from: g  reason: collision with root package name */
    public long f30882g;

    /* renamed from: h  reason: collision with root package name */
    public String f30883h;

    /* renamed from: i  reason: collision with root package name */
    public H f30884i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f30885j;

    /* renamed from: k  reason: collision with root package name */
    public long f30886k;

    public static final class a {

        /* renamed from: f  reason: collision with root package name */
        public static final byte[] f30887f = {0, 0, 1};

        /* renamed from: a  reason: collision with root package name */
        public boolean f30888a;

        /* renamed from: b  reason: collision with root package name */
        public int f30889b;

        /* renamed from: c  reason: collision with root package name */
        public int f30890c;

        /* renamed from: d  reason: collision with root package name */
        public int f30891d;

        /* renamed from: e  reason: collision with root package name */
        public byte[] f30892e;

        public final void a(int i10, byte[] bArr, int i11) {
            if (this.f30888a) {
                int i12 = i11 - i10;
                byte[] bArr2 = this.f30892e;
                int length = bArr2.length;
                int i13 = this.f30890c + i12;
                if (length < i13) {
                    this.f30892e = Arrays.copyOf(bArr2, i13 * 2);
                }
                System.arraycopy(bArr, i10, this.f30892e, this.f30890c, i12);
                this.f30890c += i12;
            }
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        public final H f30893a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f30894b;

        /* renamed from: c  reason: collision with root package name */
        public boolean f30895c;

        /* renamed from: d  reason: collision with root package name */
        public boolean f30896d;

        /* renamed from: e  reason: collision with root package name */
        public int f30897e;

        /* renamed from: f  reason: collision with root package name */
        public int f30898f;

        /* renamed from: g  reason: collision with root package name */
        public long f30899g;

        /* renamed from: h  reason: collision with root package name */
        public long f30900h;

        public b(H h10) {
            this.f30893a = h10;
        }

        public final void a(int i10, byte[] bArr, int i11) {
            boolean z10;
            if (this.f30895c) {
                int i12 = this.f30898f;
                int i13 = (i10 + 1) - i12;
                if (i13 < i11) {
                    if (((bArr[i13] & 192) >> 6) == 0) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    this.f30896d = z10;
                    this.f30895c = false;
                    return;
                }
                this.f30898f = (i11 - i10) + i12;
            }
        }

        public final void b(int i10, long j10, boolean z10) {
            boolean z11;
            if (this.f30900h != -9223372036854775807L) {
                z11 = true;
            } else {
                z11 = false;
            }
            M.m(z11);
            if (this.f30897e == 182 && z10 && this.f30894b) {
                boolean z12 = this.f30896d;
                long j11 = this.f30900h;
                this.f30893a.b(j11, z12 ? 1 : 0, (int) (j10 - this.f30899g), i10, (H.a) null);
            }
            if (this.f30897e != 179) {
                this.f30899g = j10;
            }
        }
    }

    /* JADX WARNING: type inference failed for: r3v3, types: [java.lang.Object, y3.l$a] */
    public l(G g6) {
        this.f30876a = g6;
        ? obj = new Object();
        obj.f30892e = new byte[HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE];
        this.f30879d = obj;
        this.f30886k = -9223372036854775807L;
        this.f30880e = new t(178);
        this.f30877b = new t();
    }

    public final void b() {
        C2893f.a(this.f30878c);
        a aVar = this.f30879d;
        aVar.f30888a = false;
        aVar.f30890c = 0;
        aVar.f30889b = 0;
        b bVar = this.f30881f;
        if (bVar != null) {
            bVar.f30894b = false;
            bVar.f30895c = false;
            bVar.f30896d = false;
            bVar.f30897e = -1;
        }
        t tVar = this.f30880e;
        if (tVar != null) {
            tVar.c();
        }
        this.f30882g = 0;
        this.f30886k = -9223372036854775807L;
    }

    /* JADX WARNING: Removed duplicated region for block: B:102:0x025f  */
    /* JADX WARNING: Removed duplicated region for block: B:103:0x0261  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0123  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x013a  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x01fd  */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x0258  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x025a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(o2.t r22) {
        /*
            r21 = this;
            r0 = r21
            r1 = r22
            r3 = 3
            r4 = 1
            y3.l$b r5 = r0.f30881f
            f7.M.n(r5)
            R2.H r5 = r0.f30884i
            f7.M.n(r5)
            int r5 = r1.f25886b
            int r6 = r1.f25887c
            byte[] r7 = r1.f25885a
            long r8 = r0.f30882g
            int r10 = r1.a()
            long r10 = (long) r10
            long r8 = r8 + r10
            r0.f30882g = r8
            R2.H r8 = r0.f30884i
            int r9 = r1.a()
            r8.e(r9, r1)
        L_0x0029:
            boolean[] r8 = r0.f30878c
            int r8 = p2.C2893f.b(r7, r5, r6, r8)
            y3.l$a r9 = r0.f30879d
            y3.t r10 = r0.f30880e
            if (r8 != r6) goto L_0x0047
            boolean r1 = r0.f30885j
            if (r1 != 0) goto L_0x003c
            r9.a(r5, r7, r6)
        L_0x003c:
            y3.l$b r1 = r0.f30881f
            r1.a(r5, r7, r6)
            if (r10 == 0) goto L_0x0046
            r10.a(r5, r7, r6)
        L_0x0046:
            return
        L_0x0047:
            byte[] r11 = r1.f25885a
            int r12 = r8 + 3
            byte r11 = r11[r12]
            r13 = r11 & 255(0xff, float:3.57E-43)
            int r14 = r8 - r5
            boolean r15 = r0.f30885j
            if (r15 != 0) goto L_0x01f1
            if (r14 <= 0) goto L_0x005a
            r9.a(r5, r7, r8)
        L_0x005a:
            if (r14 >= 0) goto L_0x005e
            int r15 = -r14
            goto L_0x005f
        L_0x005e:
            r15 = 0
        L_0x005f:
            int r3 = r9.f30889b
            if (r3 == 0) goto L_0x01dc
            java.lang.String r2 = "H263Reader"
            r17 = r6
            java.lang.String r6 = "Unexpected start code value"
            if (r3 == r4) goto L_0x01c7
            r4 = 2
            if (r3 == r4) goto L_0x01b2
            r4 = 4
            r19 = r12
            r12 = 3
            if (r3 == r12) goto L_0x0199
            if (r3 != r4) goto L_0x0193
            r3 = 179(0xb3, float:2.51E-43)
            if (r13 == r3) goto L_0x007e
            r3 = 181(0xb5, float:2.54E-43)
            if (r13 != r3) goto L_0x01e9
        L_0x007e:
            int r3 = r9.f30890c
            int r3 = r3 - r15
            r9.f30890c = r3
            r3 = 0
            r9.f30888a = r3
            R2.H r3 = r0.f30884i
            int r6 = r9.f30891d
            java.lang.String r11 = r0.f30883h
            r11.getClass()
            byte[] r12 = r9.f30892e
            int r9 = r9.f30890c
            byte[] r9 = java.util.Arrays.copyOf(r12, r9)
            U1.c r12 = new U1.c
            int r15 = r9.length
            r12.<init>(r9, r15)
            r12.q(r6)
            r12.q(r4)
            r12.o()
            r6 = 8
            r12.p(r6)
            boolean r15 = r12.g()
            if (r15 == 0) goto L_0x00b8
            r12.p(r4)
            r15 = 3
            r12.p(r15)
        L_0x00b8:
            int r4 = r12.h(r4)
            java.lang.String r15 = "Invalid aspect ratio"
            r20 = r9
            r9 = 15
            if (r4 != r9) goto L_0x00d7
            int r4 = r12.h(r6)
            int r6 = r12.h(r6)
            if (r6 != 0) goto L_0x00d2
            o2.n.f(r2, r15)
            goto L_0x00e2
        L_0x00d2:
            float r4 = (float) r4
            float r6 = (float) r6
            float r15 = r4 / r6
            goto L_0x00e4
        L_0x00d7:
            r6 = 7
            if (r4 >= r6) goto L_0x00df
            float[] r6 = f30875l
            r15 = r6[r4]
            goto L_0x00e4
        L_0x00df:
            o2.n.f(r2, r15)
        L_0x00e2:
            r15 = 1065353216(0x3f800000, float:1.0)
        L_0x00e4:
            boolean r4 = r12.g()
            if (r4 == 0) goto L_0x011c
            r4 = 2
            r12.p(r4)
            r4 = 1
            r12.p(r4)
            boolean r4 = r12.g()
            if (r4 == 0) goto L_0x011c
            r12.p(r9)
            r12.o()
            r12.p(r9)
            r12.o()
            r12.p(r9)
            r12.o()
            r4 = 3
            r12.p(r4)
            r4 = 11
            r12.p(r4)
            r12.o()
            r12.p(r9)
            r12.o()
        L_0x011c:
            r4 = 2
            int r6 = r12.h(r4)
            if (r6 == 0) goto L_0x0128
            java.lang.String r4 = "Unhandled video object layer shape"
            o2.n.f(r2, r4)
        L_0x0128:
            r12.o()
            r4 = 16
            int r4 = r12.h(r4)
            r12.o()
            boolean r6 = r12.g()
            if (r6 == 0) goto L_0x0151
            if (r4 != 0) goto L_0x0142
            java.lang.String r4 = "Invalid vop_increment_time_resolution"
            o2.n.f(r2, r4)
            goto L_0x0151
        L_0x0142:
            int r4 = r4 + -1
            r2 = 0
        L_0x0145:
            if (r4 <= 0) goto L_0x014e
            r18 = 1
            int r2 = r2 + 1
            int r4 = r4 >> 1
            goto L_0x0145
        L_0x014e:
            r12.p(r2)
        L_0x0151:
            r12.o()
            r2 = 13
            int r4 = r12.h(r2)
            r12.o()
            int r2 = r12.h(r2)
            r12.o()
            r12.o()
            l2.n$a r6 = new l2.n$a
            r6.<init>()
            r6.f24316a = r11
            java.lang.String r9 = "video/mp2t"
            java.lang.String r9 = l2.u.p(r9)
            r6.f24327l = r9
            java.lang.String r9 = "video/mp4v-es"
            java.lang.String r9 = l2.u.p(r9)
            r6.f24328m = r9
            r6.f24335t = r4
            r6.f24336u = r2
            r6.f24339x = r15
            java.util.List r2 = java.util.Collections.singletonList(r20)
            r6.f24331p = r2
            D2.E.r(r6, r3)
            r4 = 1
            r0.f30885j = r4
        L_0x0190:
            r15 = 3
            goto L_0x01f6
        L_0x0193:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x0199:
            r3 = r11 & 240(0xf0, float:3.36E-43)
            r11 = 32
            if (r3 == r11) goto L_0x01aa
            o2.n.f(r2, r6)
            r3 = 0
            r9.f30888a = r3
            r9.f30890c = r3
            r9.f30889b = r3
            goto L_0x01e9
        L_0x01aa:
            r3 = 0
            int r2 = r9.f30890c
            r9.f30891d = r2
            r9.f30889b = r4
            goto L_0x01e9
        L_0x01b2:
            r19 = r12
            r3 = 0
            r4 = 31
            if (r13 <= r4) goto L_0x01c3
            o2.n.f(r2, r6)
            r9.f30888a = r3
            r9.f30890c = r3
            r9.f30889b = r3
            goto L_0x01e9
        L_0x01c3:
            r15 = 3
            r9.f30889b = r15
            goto L_0x01e9
        L_0x01c7:
            r19 = r12
            r3 = 0
            r4 = 181(0xb5, float:2.54E-43)
            if (r13 == r4) goto L_0x01d8
            o2.n.f(r2, r6)
            r9.f30888a = r3
            r9.f30890c = r3
            r9.f30889b = r3
            goto L_0x01e9
        L_0x01d8:
            r4 = 2
            r9.f30889b = r4
            goto L_0x01e9
        L_0x01dc:
            r17 = r6
            r19 = r12
            r2 = 176(0xb0, float:2.47E-43)
            if (r13 != r2) goto L_0x01e9
            r4 = 1
            r9.f30889b = r4
            r9.f30888a = r4
        L_0x01e9:
            byte[] r2 = y3.l.a.f30887f
            r3 = 0
            r15 = 3
            r9.a(r3, r2, r15)
            goto L_0x01f6
        L_0x01f1:
            r17 = r6
            r19 = r12
            goto L_0x0190
        L_0x01f6:
            y3.l$b r2 = r0.f30881f
            r2.a(r5, r7, r8)
            if (r10 == 0) goto L_0x0236
            if (r14 <= 0) goto L_0x0204
            r10.a(r5, r7, r8)
            r2 = 0
            goto L_0x0205
        L_0x0204:
            int r2 = -r14
        L_0x0205:
            boolean r2 = r10.b(r2)
            if (r2 == 0) goto L_0x0223
            byte[] r2 = r10.f31047d
            int r3 = r10.f31048e
            int r2 = p2.C2893f.l(r3, r2)
            int r3 = o2.C2756B.f25811a
            byte[] r3 = r10.f31047d
            o2.t r4 = r0.f30877b
            r4.E(r2, r3)
            long r2 = r0.f30886k
            y3.G r5 = r0.f30876a
            r5.a(r2, r4)
        L_0x0223:
            r2 = 178(0xb2, float:2.5E-43)
            if (r13 != r2) goto L_0x0236
            byte[] r2 = r1.f25885a
            r16 = 2
            int r3 = r8 + 2
            byte r2 = r2[r3]
            r4 = 1
            if (r2 != r4) goto L_0x0239
            r10.d(r13)
            goto L_0x0239
        L_0x0236:
            r4 = 1
            r16 = 2
        L_0x0239:
            int r6 = r17 - r8
            long r2 = r0.f30882g
            long r8 = (long) r6
            long r2 = r2 - r8
            y3.l$b r5 = r0.f30881f
            boolean r8 = r0.f30885j
            r5.b(r6, r2, r8)
            y3.l$b r2 = r0.f30881f
            long r5 = r0.f30886k
            r2.f30897e = r13
            r3 = 0
            r2.f30896d = r3
            r3 = 182(0xb6, float:2.55E-43)
            if (r13 == r3) goto L_0x025a
            r8 = 179(0xb3, float:2.51E-43)
            if (r13 != r8) goto L_0x0258
            goto L_0x025a
        L_0x0258:
            r8 = 0
            goto L_0x025b
        L_0x025a:
            r8 = r4
        L_0x025b:
            r2.f30894b = r8
            if (r13 != r3) goto L_0x0261
            r3 = r4
            goto L_0x0262
        L_0x0261:
            r3 = 0
        L_0x0262:
            r2.f30895c = r3
            r3 = 0
            r2.f30898f = r3
            r2.f30900h = r5
            r3 = r15
            r6 = r17
            r5 = r19
            goto L_0x0029
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.l.c(o2.t):void");
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30883h = cVar.f30757e;
        cVar.b();
        H k10 = pVar.k(cVar.f30756d, 2);
        this.f30884i = k10;
        this.f30881f = new b(k10);
        this.f30876a.b(pVar, cVar);
    }

    public final void e(boolean z10) {
        M.n(this.f30881f);
        if (z10) {
            this.f30881f.b(0, this.f30882g, this.f30885j);
            b bVar = this.f30881f;
            bVar.f30894b = false;
            bVar.f30895c = false;
            bVar.f30896d = false;
            bVar.f30897e = -1;
        }
    }

    public final void f(int i10, long j10) {
        this.f30886k = j10;
    }
}
