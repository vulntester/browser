package y3;

import R2.H;
import R2.p;
import android.util.SparseArray;
import f7.M;
import io.netty.handler.codec.http.HttpObjectDecoder;
import o2.C2756B;
import o2.t;
import p2.C2893f;
import p2.C2895h;
import y3.F;

public final class m implements j {

    /* renamed from: a  reason: collision with root package name */
    public final C3482B f30901a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f30902b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f30903c;

    /* renamed from: d  reason: collision with root package name */
    public final t f30904d = new t(7);

    /* renamed from: e  reason: collision with root package name */
    public final t f30905e = new t(8);

    /* renamed from: f  reason: collision with root package name */
    public final t f30906f = new t(6);

    /* renamed from: g  reason: collision with root package name */
    public long f30907g;

    /* renamed from: h  reason: collision with root package name */
    public final boolean[] f30908h = new boolean[3];

    /* renamed from: i  reason: collision with root package name */
    public String f30909i;

    /* renamed from: j  reason: collision with root package name */
    public H f30910j;

    /* renamed from: k  reason: collision with root package name */
    public a f30911k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f30912l;

    /* renamed from: m  reason: collision with root package name */
    public long f30913m = -9223372036854775807L;

    /* renamed from: n  reason: collision with root package name */
    public boolean f30914n;

    /* renamed from: o  reason: collision with root package name */
    public final t f30915o = new t();

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final H f30916a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f30917b;

        /* renamed from: c  reason: collision with root package name */
        public final boolean f30918c;

        /* renamed from: d  reason: collision with root package name */
        public final SparseArray<C2893f.m> f30919d = new SparseArray<>();

        /* renamed from: e  reason: collision with root package name */
        public final SparseArray<C2893f.l> f30920e = new SparseArray<>();

        /* renamed from: f  reason: collision with root package name */
        public final C2895h f30921f;

        /* renamed from: g  reason: collision with root package name */
        public byte[] f30922g;

        /* renamed from: h  reason: collision with root package name */
        public int f30923h;

        /* renamed from: i  reason: collision with root package name */
        public int f30924i;

        /* renamed from: j  reason: collision with root package name */
        public long f30925j;

        /* renamed from: k  reason: collision with root package name */
        public boolean f30926k;

        /* renamed from: l  reason: collision with root package name */
        public long f30927l;

        /* renamed from: m  reason: collision with root package name */
        public C0300a f30928m = new Object();

        /* renamed from: n  reason: collision with root package name */
        public C0300a f30929n = new Object();

        /* renamed from: o  reason: collision with root package name */
        public boolean f30930o;

        /* renamed from: p  reason: collision with root package name */
        public long f30931p;

        /* renamed from: q  reason: collision with root package name */
        public long f30932q;

        /* renamed from: r  reason: collision with root package name */
        public boolean f30933r;

        /* renamed from: s  reason: collision with root package name */
        public boolean f30934s;

        /* renamed from: y3.m$a$a  reason: collision with other inner class name */
        public static final class C0300a {

            /* renamed from: a  reason: collision with root package name */
            public boolean f30935a;

            /* renamed from: b  reason: collision with root package name */
            public boolean f30936b;

            /* renamed from: c  reason: collision with root package name */
            public C2893f.m f30937c;

            /* renamed from: d  reason: collision with root package name */
            public int f30938d;

            /* renamed from: e  reason: collision with root package name */
            public int f30939e;

            /* renamed from: f  reason: collision with root package name */
            public int f30940f;

            /* renamed from: g  reason: collision with root package name */
            public int f30941g;

            /* renamed from: h  reason: collision with root package name */
            public boolean f30942h;

            /* renamed from: i  reason: collision with root package name */
            public boolean f30943i;

            /* renamed from: j  reason: collision with root package name */
            public boolean f30944j;

            /* renamed from: k  reason: collision with root package name */
            public boolean f30945k;

            /* renamed from: l  reason: collision with root package name */
            public int f30946l;

            /* renamed from: m  reason: collision with root package name */
            public int f30947m;

            /* renamed from: n  reason: collision with root package name */
            public int f30948n;

            /* renamed from: o  reason: collision with root package name */
            public int f30949o;

            /* renamed from: p  reason: collision with root package name */
            public int f30950p;
        }

        /* JADX WARNING: type inference failed for: r1v3, types: [java.lang.Object, y3.m$a$a] */
        /* JADX WARNING: type inference failed for: r1v4, types: [java.lang.Object, y3.m$a$a] */
        public a(H h10, boolean z10, boolean z11) {
            this.f30916a = h10;
            this.f30917b = z10;
            this.f30918c = z11;
            byte[] bArr = new byte[HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE];
            this.f30922g = bArr;
            this.f30921f = new C2895h(bArr, 0, 0);
            this.f30926k = false;
            this.f30930o = false;
            C0300a aVar = this.f30929n;
            aVar.f30936b = false;
            aVar.f30935a = false;
        }
    }

    public m(C3482B b10, boolean z10, boolean z11) {
        this.f30901a = b10;
        this.f30902b = z10;
        this.f30903c = z11;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:58:0x01c7, code lost:
        if (r3.f30948n != r4.f30948n) goto L_0x01e7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x01d7, code lost:
        if (r3.f30950p != r4.f30950p) goto L_0x01e7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x01e5, code lost:
        if (r3.f30946l != r4.f30946l) goto L_0x01e7;
     */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x0221  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0233  */
    /* JADX WARNING: Removed duplicated region for block: B:97:0x024c  */
    /* JADX WARNING: Removed duplicated region for block: B:99:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(int r23, int r24, long r25, long r27) {
        /*
            r22 = this;
            r0 = r22
            r1 = r24
            boolean r2 = r0.f30912l
            y3.B r3 = r0.f30901a
            r5 = 4
            r6 = 1
            p2.i r3 = r3.f30708c
            if (r2 == 0) goto L_0x0014
            y3.m$a r2 = r0.f30911k
            boolean r2 = r2.f30918c
            if (r2 == 0) goto L_0x0144
        L_0x0014:
            y3.t r2 = r0.f30904d
            r2.b(r1)
            y3.t r7 = r0.f30905e
            r7.b(r1)
            boolean r8 = r0.f30912l
            r9 = 3
            if (r8 != 0) goto L_0x00ed
            boolean r8 = r2.f31046c
            if (r8 == 0) goto L_0x0144
            boolean r8 = r7.f31046c
            if (r8 == 0) goto L_0x0144
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            byte[] r10 = r2.f31047d
            int r11 = r2.f31048e
            byte[] r10 = java.util.Arrays.copyOf(r10, r11)
            r8.add(r10)
            byte[] r10 = r7.f31047d
            int r11 = r7.f31048e
            byte[] r10 = java.util.Arrays.copyOf(r10, r11)
            r8.add(r10)
            byte[] r10 = r2.f31047d
            int r11 = r2.f31048e
            p2.f$m r9 = p2.C2893f.j(r9, r10, r11)
            byte[] r10 = r7.f31047d
            int r11 = r7.f31048e
            p2.h r12 = new p2.h
            r12.<init>(r10, r5, r11)
            int r10 = r12.f()
            int r11 = r12.f()
            r12.i()
            boolean r12 = r12.d()
            p2.f$l r13 = new p2.f$l
            r13.<init>(r10, r11, r12)
            int r11 = r9.f26507c
            int r12 = r9.f26505a
            int r14 = r9.f26506b
            java.lang.String r11 = o2.d.a(r12, r14, r11)
            R2.H r12 = r0.f30910j
            l2.n$a r14 = new l2.n$a
            r14.<init>()
            java.lang.String r15 = r0.f30909i
            r14.f24316a = r15
            java.lang.String r15 = "video/mp2t"
            java.lang.String r15 = l2.u.p(r15)
            r14.f24327l = r15
            java.lang.String r15 = "video/avc"
            java.lang.String r15 = l2.u.p(r15)
            r14.f24328m = r15
            r14.f24325j = r11
            int r11 = r9.f26509e
            r14.f24335t = r11
            int r11 = r9.f26510f
            r14.f24336u = r11
            int r11 = r9.f26512h
            int r20 = r11 + 8
            int r11 = r9.f26513i
            int r21 = r11 + 8
            l2.h r15 = new l2.h
            int r11 = r9.f26522r
            r19 = 0
            int r4 = r9.f26520p
            int r5 = r9.f26521q
            r16 = r4
            r17 = r5
            r18 = r11
            r15.<init>(r16, r17, r18, r19, r20, r21)
            r14.f24304A = r15
            float r4 = r9.f26511g
            r14.f24339x = r4
            r14.f24331p = r8
            int r4 = r9.f26523s
            r14.f24330o = r4
            D2.E.r(r14, r12)
            r0.f30912l = r6
            r3.getClass()
            if (r4 < 0) goto L_0x00cd
            r5 = r6
            goto L_0x00ce
        L_0x00cd:
            r5 = 0
        L_0x00ce:
            f7.M.m(r5)
            r3.f26535e = r4
            r3.b(r4)
            y3.m$a r4 = r0.f30911k
            android.util.SparseArray<p2.f$m> r4 = r4.f30919d
            int r5 = r9.f26508d
            r4.append(r5, r9)
            y3.m$a r4 = r0.f30911k
            android.util.SparseArray<p2.f$l> r4 = r4.f30920e
            r4.append(r10, r13)
            r2.c()
            r7.c()
            goto L_0x0144
        L_0x00ed:
            boolean r4 = r2.f31046c
            if (r4 == 0) goto L_0x0118
            byte[] r4 = r2.f31047d
            int r5 = r2.f31048e
            p2.f$m r4 = p2.C2893f.j(r9, r4, r5)
            r3.getClass()
            int r5 = r4.f26523s
            if (r5 < 0) goto L_0x0102
            r7 = r6
            goto L_0x0103
        L_0x0102:
            r7 = 0
        L_0x0103:
            f7.M.m(r7)
            r3.f26535e = r5
            r3.b(r5)
            y3.m$a r5 = r0.f30911k
            android.util.SparseArray<p2.f$m> r5 = r5.f30919d
            int r7 = r4.f26508d
            r5.append(r7, r4)
            r2.c()
            goto L_0x0144
        L_0x0118:
            boolean r2 = r7.f31046c
            if (r2 == 0) goto L_0x0144
            byte[] r2 = r7.f31047d
            int r4 = r7.f31048e
            p2.h r5 = new p2.h
            r8 = 4
            r5.<init>(r2, r8, r4)
            int r2 = r5.f()
            int r4 = r5.f()
            r5.i()
            boolean r5 = r5.d()
            p2.f$l r8 = new p2.f$l
            r8.<init>(r2, r4, r5)
            y3.m$a r4 = r0.f30911k
            android.util.SparseArray<p2.f$l> r4 = r4.f30920e
            r4.append(r2, r8)
            r7.c()
        L_0x0144:
            y3.t r2 = r0.f30906f
            boolean r1 = r2.b(r1)
            if (r1 == 0) goto L_0x0164
            byte[] r1 = r2.f31047d
            int r4 = r2.f31048e
            int r1 = p2.C2893f.l(r4, r1)
            byte[] r2 = r2.f31047d
            o2.t r4 = r0.f30915o
            r4.E(r1, r2)
            r8 = 4
            r4.G(r8)
            r1 = r27
            r3.a(r1, r4)
        L_0x0164:
            y3.m$a r1 = r0.f30911k
            boolean r2 = r0.f30912l
            int r3 = r1.f30924i
            r4 = 9
            if (r3 == r4) goto L_0x01e7
            boolean r3 = r1.f30918c
            if (r3 == 0) goto L_0x021d
            y3.m$a$a r3 = r1.f30929n
            y3.m$a$a r4 = r1.f30928m
            boolean r5 = r3.f30935a
            if (r5 != 0) goto L_0x017c
            goto L_0x021d
        L_0x017c:
            boolean r5 = r4.f30935a
            if (r5 != 0) goto L_0x0181
            goto L_0x01e7
        L_0x0181:
            p2.f$m r5 = r3.f30937c
            f7.M.n(r5)
            p2.f$m r7 = r4.f30937c
            f7.M.n(r7)
            int r8 = r3.f30940f
            int r9 = r4.f30940f
            if (r8 != r9) goto L_0x01e7
            int r8 = r3.f30941g
            int r9 = r4.f30941g
            if (r8 != r9) goto L_0x01e7
            boolean r8 = r3.f30942h
            boolean r9 = r4.f30942h
            if (r8 != r9) goto L_0x01e7
            boolean r8 = r3.f30943i
            if (r8 == 0) goto L_0x01ab
            boolean r8 = r4.f30943i
            if (r8 == 0) goto L_0x01ab
            boolean r8 = r3.f30944j
            boolean r9 = r4.f30944j
            if (r8 != r9) goto L_0x01e7
        L_0x01ab:
            int r8 = r3.f30938d
            int r9 = r4.f30938d
            if (r8 == r9) goto L_0x01b5
            if (r8 == 0) goto L_0x01e7
            if (r9 == 0) goto L_0x01e7
        L_0x01b5:
            int r7 = r7.f26517m
            int r5 = r5.f26517m
            if (r5 != 0) goto L_0x01c9
            if (r7 != 0) goto L_0x01c9
            int r8 = r3.f30947m
            int r9 = r4.f30947m
            if (r8 != r9) goto L_0x01e7
            int r8 = r3.f30948n
            int r9 = r4.f30948n
            if (r8 != r9) goto L_0x01e7
        L_0x01c9:
            if (r5 != r6) goto L_0x01d9
            if (r7 != r6) goto L_0x01d9
            int r5 = r3.f30949o
            int r7 = r4.f30949o
            if (r5 != r7) goto L_0x01e7
            int r5 = r3.f30950p
            int r7 = r4.f30950p
            if (r5 != r7) goto L_0x01e7
        L_0x01d9:
            boolean r5 = r3.f30945k
            boolean r7 = r4.f30945k
            if (r5 != r7) goto L_0x01e7
            if (r5 == 0) goto L_0x021d
            int r3 = r3.f30946l
            int r4 = r4.f30946l
            if (r3 == r4) goto L_0x021d
        L_0x01e7:
            if (r2 == 0) goto L_0x0210
            boolean r2 = r1.f30930o
            if (r2 == 0) goto L_0x0210
            long r2 = r1.f30925j
            long r4 = r25 - r2
            int r4 = (int) r4
            int r12 = r23 + r4
            long r8 = r1.f30932q
            r4 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r4 = (r8 > r4 ? 1 : (r8 == r4 ? 0 : -1))
            if (r4 == 0) goto L_0x0210
            long r4 = r1.f30931p
            int r7 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r7 != 0) goto L_0x0206
            goto L_0x0210
        L_0x0206:
            boolean r10 = r1.f30933r
            long r2 = r2 - r4
            int r11 = (int) r2
            R2.H r7 = r1.f30916a
            r13 = 0
            r7.b(r8, r10, r11, r12, r13)
        L_0x0210:
            long r2 = r1.f30925j
            r1.f30931p = r2
            long r2 = r1.f30927l
            r1.f30932q = r2
            r2 = 0
            r1.f30933r = r2
            r1.f30930o = r6
        L_0x021d:
            boolean r2 = r1.f30917b
            if (r2 == 0) goto L_0x0233
            y3.m$a$a r2 = r1.f30929n
            boolean r3 = r2.f30936b
            if (r3 == 0) goto L_0x0231
            int r2 = r2.f30939e
            r3 = 7
            if (r2 == r3) goto L_0x022f
            r3 = 2
            if (r2 != r3) goto L_0x0231
        L_0x022f:
            r2 = r6
            goto L_0x0235
        L_0x0231:
            r2 = 0
            goto L_0x0235
        L_0x0233:
            boolean r2 = r1.f30934s
        L_0x0235:
            boolean r3 = r1.f30933r
            int r4 = r1.f30924i
            r5 = 5
            if (r4 == r5) goto L_0x0242
            if (r2 == 0) goto L_0x0241
            if (r4 != r6) goto L_0x0241
            goto L_0x0242
        L_0x0241:
            r6 = 0
        L_0x0242:
            r2 = r3 | r6
            r1.f30933r = r2
            r3 = 24
            r1.f30924i = r3
            if (r2 == 0) goto L_0x024f
            r2 = 0
            r0.f30914n = r2
        L_0x024f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.m.a(int, int, long, long):void");
    }

    public final void b() {
        this.f30907g = 0;
        this.f30914n = false;
        this.f30913m = -9223372036854775807L;
        C2893f.a(this.f30908h);
        this.f30904d.c();
        this.f30905e.c();
        this.f30906f.c();
        this.f30901a.f30708c.b(0);
        a aVar = this.f30911k;
        if (aVar != null) {
            aVar.f30926k = false;
            aVar.f30930o = false;
            a.C0300a aVar2 = aVar.f30929n;
            aVar2.f30936b = false;
            aVar2.f30935a = false;
        }
    }

    public final void c(t tVar) {
        int i10;
        int i11;
        M.n(this.f30910j);
        int i12 = C2756B.f25811a;
        int i13 = tVar.f25886b;
        int i14 = tVar.f25887c;
        byte[] bArr = tVar.f25885a;
        this.f30907g += (long) tVar.a();
        this.f30910j.e(tVar.a(), tVar);
        while (true) {
            int b10 = C2893f.b(bArr, i13, i14, this.f30908h);
            if (b10 == i14) {
                g(i13, bArr, i14);
                return;
            }
            byte b11 = bArr[b10 + 3] & 31;
            if (b10 <= 0 || bArr[b10 - 1] != 0) {
                i10 = 3;
            } else {
                b10--;
                i10 = 4;
            }
            int i15 = b10;
            int i16 = i15 - i13;
            if (i16 > 0) {
                g(i13, bArr, i15);
            }
            int i17 = i14 - i15;
            long j10 = this.f30907g - ((long) i17);
            if (i16 < 0) {
                i11 = -i16;
            } else {
                i11 = 0;
            }
            int i18 = i17;
            int i19 = i11;
            int i20 = i18;
            a(i20, i19, j10, this.f30913m);
            h(j10, this.f30913m, b11);
            i13 = i15 + i10;
        }
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30909i = cVar.f30757e;
        cVar.b();
        H k10 = pVar.k(cVar.f30756d, 2);
        this.f30910j = k10;
        this.f30911k = new a(k10, this.f30902b, this.f30903c);
        this.f30901a.a(pVar, cVar);
    }

    public final void e(boolean z10) {
        M.n(this.f30910j);
        int i10 = C2756B.f25811a;
        if (z10) {
            this.f30901a.f30708c.b(0);
            a(0, 0, this.f30907g, this.f30913m);
            h(this.f30907g, this.f30913m, 9);
            a(0, 0, this.f30907g, this.f30913m);
        }
    }

    public final void f(int i10, long j10) {
        boolean z10;
        this.f30913m = j10;
        boolean z11 = this.f30914n;
        if ((i10 & 2) != 0) {
            z10 = true;
        } else {
            z10 = false;
        }
        this.f30914n = z10 | z11;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00fe  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0100  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0103  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x010f  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x0116  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x013a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void g(int r18, byte[] r19, int r20) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            r3 = r20
            boolean r4 = r0.f30912l
            if (r4 == 0) goto L_0x0012
            y3.m$a r4 = r0.f30911k
            boolean r4 = r4.f30918c
            if (r4 == 0) goto L_0x001c
        L_0x0012:
            y3.t r4 = r0.f30904d
            r4.a(r1, r2, r3)
            y3.t r4 = r0.f30905e
            r4.a(r1, r2, r3)
        L_0x001c:
            y3.t r4 = r0.f30906f
            r4.a(r1, r2, r3)
            y3.m$a r4 = r0.f30911k
            boolean r5 = r4.f30926k
            if (r5 != 0) goto L_0x0029
            goto L_0x0155
        L_0x0029:
            int r3 = r3 - r1
            byte[] r5 = r4.f30922g
            int r6 = r5.length
            int r7 = r4.f30923h
            int r7 = r7 + r3
            r8 = 2
            if (r6 >= r7) goto L_0x003a
            int r7 = r7 * r8
            byte[] r5 = java.util.Arrays.copyOf(r5, r7)
            r4.f30922g = r5
        L_0x003a:
            byte[] r5 = r4.f30922g
            int r6 = r4.f30923h
            java.lang.System.arraycopy(r2, r1, r5, r6, r3)
            int r1 = r4.f30923h
            int r1 = r1 + r3
            r4.f30923h = r1
            byte[] r2 = r4.f30922g
            p2.h r3 = r4.f30921f
            r3.f26527a = r2
            r2 = 0
            r3.f26529c = r2
            r3.f26528b = r1
            r3.f26530d = r2
            r3.a()
            r1 = 8
            boolean r1 = r3.b(r1)
            if (r1 != 0) goto L_0x0060
            goto L_0x0155
        L_0x0060:
            r3.i()
            int r1 = r3.e(r8)
            r5 = 5
            r3.j(r5)
            boolean r6 = r3.c()
            if (r6 != 0) goto L_0x0073
            goto L_0x0155
        L_0x0073:
            r3.f()
            boolean r6 = r3.c()
            if (r6 != 0) goto L_0x007e
            goto L_0x0155
        L_0x007e:
            int r6 = r3.f()
            boolean r7 = r4.f30918c
            r9 = 1
            if (r7 != 0) goto L_0x0090
            r4.f30926k = r2
            y3.m$a$a r1 = r4.f30929n
            r1.f30939e = r6
            r1.f30936b = r9
            return
        L_0x0090:
            boolean r7 = r3.c()
            if (r7 != 0) goto L_0x0098
            goto L_0x0155
        L_0x0098:
            int r7 = r3.f()
            android.util.SparseArray<p2.f$l> r10 = r4.f30920e
            int r11 = r10.indexOfKey(r7)
            if (r11 >= 0) goto L_0x00a7
            r4.f30926k = r2
            return
        L_0x00a7:
            java.lang.Object r10 = r10.get(r7)
            p2.f$l r10 = (p2.C2893f.l) r10
            android.util.SparseArray<p2.f$m> r11 = r4.f30919d
            int r12 = r10.f26503a
            java.lang.Object r11 = r11.get(r12)
            p2.f$m r11 = (p2.C2893f.m) r11
            boolean r12 = r11.f26514j
            if (r12 == 0) goto L_0x00c6
            boolean r12 = r3.b(r8)
            if (r12 != 0) goto L_0x00c3
            goto L_0x0155
        L_0x00c3:
            r3.j(r8)
        L_0x00c6:
            int r8 = r11.f26516l
            boolean r12 = r3.b(r8)
            if (r12 != 0) goto L_0x00d0
            goto L_0x0155
        L_0x00d0:
            int r8 = r3.e(r8)
            boolean r12 = r11.f26515k
            if (r12 != 0) goto L_0x00f7
            boolean r12 = r3.b(r9)
            if (r12 != 0) goto L_0x00e0
            goto L_0x0155
        L_0x00e0:
            boolean r12 = r3.d()
            if (r12 == 0) goto L_0x00f4
            boolean r13 = r3.b(r9)
            if (r13 != 0) goto L_0x00ee
            goto L_0x0155
        L_0x00ee:
            boolean r13 = r3.d()
            r14 = r9
            goto L_0x00fa
        L_0x00f4:
            r13 = r2
        L_0x00f5:
            r14 = r13
            goto L_0x00fa
        L_0x00f7:
            r12 = r2
            r13 = r12
            goto L_0x00f5
        L_0x00fa:
            int r15 = r4.f30924i
            if (r15 != r5) goto L_0x0100
            r5 = r9
            goto L_0x0101
        L_0x0100:
            r5 = r2
        L_0x0101:
            if (r5 == 0) goto L_0x010f
            boolean r15 = r3.c()
            if (r15 != 0) goto L_0x010a
            goto L_0x0155
        L_0x010a:
            int r15 = r3.f()
            goto L_0x0110
        L_0x010f:
            r15 = r2
        L_0x0110:
            boolean r10 = r10.f26504b
            int r2 = r11.f26517m
            if (r2 != 0) goto L_0x013a
            int r2 = r11.f26518n
            boolean r16 = r3.b(r2)
            if (r16 != 0) goto L_0x011f
            goto L_0x0155
        L_0x011f:
            int r2 = r3.e(r2)
            if (r10 == 0) goto L_0x0136
            if (r12 != 0) goto L_0x0136
            boolean r10 = r3.c()
            if (r10 != 0) goto L_0x012e
            goto L_0x0155
        L_0x012e:
            int r3 = r3.g()
            r10 = r3
            r3 = 0
            r9 = 0
            goto L_0x0164
        L_0x0136:
            r3 = 0
        L_0x0137:
            r9 = 0
            r10 = 0
            goto L_0x0164
        L_0x013a:
            if (r2 != r9) goto L_0x0162
            boolean r2 = r11.f26519o
            if (r2 != 0) goto L_0x0162
            boolean r2 = r3.c()
            if (r2 != 0) goto L_0x0147
            goto L_0x0155
        L_0x0147:
            int r2 = r3.g()
            if (r10 == 0) goto L_0x015f
            if (r12 != 0) goto L_0x015f
            boolean r10 = r3.c()
            if (r10 != 0) goto L_0x0156
        L_0x0155:
            return
        L_0x0156:
            int r3 = r3.g()
            r9 = r3
            r10 = 0
            r3 = r2
            r2 = 0
            goto L_0x0164
        L_0x015f:
            r3 = r2
            r2 = 0
            goto L_0x0137
        L_0x0162:
            r2 = 0
            goto L_0x0136
        L_0x0164:
            y3.m$a$a r0 = r4.f30929n
            r0.f30937c = r11
            r0.f30938d = r1
            r0.f30939e = r6
            r0.f30940f = r8
            r0.f30941g = r7
            r0.f30942h = r12
            r0.f30943i = r14
            r0.f30944j = r13
            r0.f30945k = r5
            r0.f30946l = r15
            r0.f30947m = r2
            r0.f30948n = r10
            r0.f30949o = r3
            r0.f30950p = r9
            r1 = 1
            r0.f30935a = r1
            r0.f30936b = r1
            r0 = 0
            r4.f30926k = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.m.g(int, byte[], int):void");
    }

    public final void h(long j10, long j11, int i10) {
        if (!this.f30912l || this.f30911k.f30918c) {
            this.f30904d.d(i10);
            this.f30905e.d(i10);
        }
        this.f30906f.d(i10);
        a aVar = this.f30911k;
        boolean z10 = this.f30914n;
        aVar.f30924i = i10;
        aVar.f30927l = j11;
        aVar.f30925j = j10;
        aVar.f30934s = z10;
        if (!aVar.f30917b || i10 != 1) {
            if (!aVar.f30918c) {
                return;
            }
            if (!(i10 == 5 || i10 == 1 || i10 == 2)) {
                return;
            }
        }
        a.C0300a aVar2 = aVar.f30928m;
        aVar.f30928m = aVar.f30929n;
        aVar.f30929n = aVar2;
        aVar2.f30936b = false;
        aVar2.f30935a = false;
        aVar.f30923h = 0;
        aVar.f30926k = true;
    }
}
