package y3;

import R2.H;
import R2.p;
import f7.M;
import java.util.Collections;
import l2.C2622h;
import l2.n;
import l2.u;
import o2.C2756B;
import o2.d;
import o2.t;
import p2.C2893f;
import p2.C2896i;
import y3.F;

public final class n implements j {

    /* renamed from: a  reason: collision with root package name */
    public final C3482B f30951a;

    /* renamed from: b  reason: collision with root package name */
    public String f30952b;

    /* renamed from: c  reason: collision with root package name */
    public H f30953c;

    /* renamed from: d  reason: collision with root package name */
    public a f30954d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f30955e;

    /* renamed from: f  reason: collision with root package name */
    public final boolean[] f30956f = new boolean[3];

    /* renamed from: g  reason: collision with root package name */
    public final t f30957g = new t(32);

    /* renamed from: h  reason: collision with root package name */
    public final t f30958h = new t(33);

    /* renamed from: i  reason: collision with root package name */
    public final t f30959i = new t(34);

    /* renamed from: j  reason: collision with root package name */
    public final t f30960j = new t(39);

    /* renamed from: k  reason: collision with root package name */
    public final t f30961k = new t(40);

    /* renamed from: l  reason: collision with root package name */
    public long f30962l;

    /* renamed from: m  reason: collision with root package name */
    public long f30963m = -9223372036854775807L;

    /* renamed from: n  reason: collision with root package name */
    public final t f30964n = new t();

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final H f30965a;

        /* renamed from: b  reason: collision with root package name */
        public long f30966b;

        /* renamed from: c  reason: collision with root package name */
        public boolean f30967c;

        /* renamed from: d  reason: collision with root package name */
        public int f30968d;

        /* renamed from: e  reason: collision with root package name */
        public long f30969e;

        /* renamed from: f  reason: collision with root package name */
        public boolean f30970f;

        /* renamed from: g  reason: collision with root package name */
        public boolean f30971g;

        /* renamed from: h  reason: collision with root package name */
        public boolean f30972h;

        /* renamed from: i  reason: collision with root package name */
        public boolean f30973i;

        /* renamed from: j  reason: collision with root package name */
        public boolean f30974j;

        /* renamed from: k  reason: collision with root package name */
        public long f30975k;

        /* renamed from: l  reason: collision with root package name */
        public long f30976l;

        /* renamed from: m  reason: collision with root package name */
        public boolean f30977m;

        public a(H h10) {
            this.f30965a = h10;
        }

        public final void a(int i10) {
            long j10 = this.f30976l;
            if (j10 != -9223372036854775807L) {
                long j11 = this.f30966b;
                long j12 = this.f30975k;
                if (j11 != j12) {
                    long j13 = j11;
                    boolean z10 = this.f30977m;
                    this.f30965a.b(j10, z10 ? 1 : 0, (int) (j13 - j12), i10, (H.a) null);
                }
            }
        }
    }

    public n(C3482B b10) {
        this.f30951a = b10;
    }

    public final void a(int i10, int i11, long j10, long j11) {
        int i12 = i11;
        long j12 = j11;
        a aVar = this.f30954d;
        boolean z10 = this.f30955e;
        boolean z11 = false;
        if (aVar.f30974j && aVar.f30971g) {
            aVar.f30977m = aVar.f30967c;
            aVar.f30974j = false;
        } else if (aVar.f30972h || aVar.f30971g) {
            if (z10 && aVar.f30973i) {
                aVar.a(i10 + ((int) (j10 - aVar.f30966b)));
            }
            aVar.f30975k = aVar.f30966b;
            aVar.f30976l = aVar.f30969e;
            aVar.f30977m = aVar.f30967c;
            aVar.f30973i = true;
        }
        boolean z12 = this.f30955e;
        C2896i iVar = this.f30951a.f30708c;
        if (!z12) {
            t tVar = this.f30957g;
            tVar.b(i12);
            t tVar2 = this.f30958h;
            tVar2.b(i12);
            t tVar3 = this.f30959i;
            tVar3.b(i12);
            if (tVar.f31046c && tVar2.f31046c && tVar3.f31046c) {
                String str = this.f30952b;
                int i13 = tVar.f31048e;
                byte[] bArr = new byte[(tVar2.f31048e + i13 + tVar3.f31048e)];
                System.arraycopy(tVar.f31047d, 0, bArr, 0, i13);
                System.arraycopy(tVar2.f31047d, 0, bArr, tVar.f31048e, tVar2.f31048e);
                System.arraycopy(tVar3.f31047d, 0, bArr, tVar.f31048e + tVar2.f31048e, tVar3.f31048e);
                String str2 = null;
                C2893f.h h10 = C2893f.h(tVar2.f31047d, 3, tVar2.f31048e, (C2893f.k) null);
                C2893f.c cVar = h10.f26484b;
                if (cVar != null) {
                    str2 = d.b(cVar.f26467a, cVar.f26468b, cVar.f26469c, cVar.f26470d, cVar.f26471e, cVar.f26472f);
                }
                n.a aVar2 = new n.a();
                aVar2.f24316a = str;
                aVar2.f24327l = u.p("video/mp2t");
                aVar2.f24328m = u.p("video/hevc");
                aVar2.f24325j = str2;
                aVar2.f24335t = h10.f26487e;
                aVar2.f24336u = h10.f26488f;
                aVar2.f24304A = new C2622h(h10.f26491i, h10.f26492j, h10.f26493k, (byte[]) null, h10.f26485c + 8, h10.f26486d + 8);
                aVar2.f24339x = h10.f26489g;
                aVar2.f24330o = h10.f26490h;
                aVar2.f24305B = h10.f26483a + 1;
                aVar2.f24331p = Collections.singletonList(bArr);
                l2.n nVar = new l2.n(aVar2);
                this.f30953c.d(nVar);
                int i14 = nVar.f24293p;
                if (i14 != -1) {
                    iVar.getClass();
                    if (i14 >= 0) {
                        z11 = true;
                    }
                    M.m(z11);
                    iVar.f26535e = i14;
                    iVar.b(i14);
                    this.f30955e = true;
                } else {
                    throw new IllegalStateException();
                }
            }
        }
        t tVar4 = this.f30960j;
        boolean b10 = tVar4.b(i12);
        t tVar5 = this.f30964n;
        if (b10) {
            tVar5.E(C2893f.l(tVar4.f31048e, tVar4.f31047d), tVar4.f31047d);
            tVar5.H(5);
            iVar.a(j12, tVar5);
        }
        t tVar6 = this.f30961k;
        if (tVar6.b(i12)) {
            tVar5.E(C2893f.l(tVar6.f31048e, tVar6.f31047d), tVar6.f31047d);
            tVar5.H(5);
            iVar.a(j12, tVar5);
        }
    }

    public final void b() {
        this.f30962l = 0;
        this.f30963m = -9223372036854775807L;
        C2893f.a(this.f30956f);
        this.f30957g.c();
        this.f30958h.c();
        this.f30959i.c();
        this.f30960j.c();
        this.f30961k.c();
        this.f30951a.f30708c.b(0);
        a aVar = this.f30954d;
        if (aVar != null) {
            aVar.f30970f = false;
            aVar.f30971g = false;
            aVar.f30972h = false;
            aVar.f30973i = false;
            aVar.f30974j = false;
        }
    }

    public final void c(t tVar) {
        int i10;
        int i11;
        M.n(this.f30953c);
        int i12 = C2756B.f25811a;
        while (tVar.a() > 0) {
            int i13 = tVar.f25886b;
            int i14 = tVar.f25887c;
            byte[] bArr = tVar.f25885a;
            this.f30962l += (long) tVar.a();
            this.f30953c.e(tVar.a(), tVar);
            while (true) {
                if (i13 < i14) {
                    int b10 = C2893f.b(bArr, i13, i14, this.f30956f);
                    if (b10 == i14) {
                        g(i13, bArr, i14);
                        return;
                    }
                    int i15 = (bArr[b10 + 3] & 126) >> 1;
                    if (b10 <= 0 || bArr[b10 - 1] != 0) {
                        i10 = 3;
                    } else {
                        b10--;
                        i10 = 4;
                    }
                    int i16 = b10;
                    int i17 = i16 - i13;
                    if (i17 > 0) {
                        g(i13, bArr, i16);
                    }
                    int i18 = i14 - i16;
                    long j10 = this.f30962l - ((long) i18);
                    if (i17 < 0) {
                        i11 = -i17;
                    } else {
                        i11 = 0;
                    }
                    a(i18, i11, j10, this.f30963m);
                    h(i18, i15, j10, this.f30963m);
                    i13 = i16 + i10;
                }
            }
        }
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30952b = cVar.f30757e;
        cVar.b();
        H k10 = pVar.k(cVar.f30756d, 2);
        this.f30953c = k10;
        this.f30954d = new a(k10);
        this.f30951a.a(pVar, cVar);
    }

    public final void e(boolean z10) {
        M.n(this.f30953c);
        int i10 = C2756B.f25811a;
        if (z10) {
            this.f30951a.f30708c.b(0);
            a(0, 0, this.f30962l, this.f30963m);
            h(0, 48, this.f30962l, this.f30963m);
        }
    }

    public final void f(int i10, long j10) {
        this.f30963m = j10;
    }

    public final void g(int i10, byte[] bArr, int i11) {
        boolean z10;
        a aVar = this.f30954d;
        if (aVar.f30970f) {
            int i12 = aVar.f30968d;
            int i13 = (i10 + 2) - i12;
            if (i13 < i11) {
                if ((bArr[i13] & 128) != 0) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                aVar.f30971g = z10;
                aVar.f30970f = false;
            } else {
                aVar.f30968d = (i11 - i10) + i12;
            }
        }
        if (!this.f30955e) {
            this.f30957g.a(i10, bArr, i11);
            this.f30958h.a(i10, bArr, i11);
            this.f30959i.a(i10, bArr, i11);
        }
        this.f30960j.a(i10, bArr, i11);
        this.f30961k.a(i10, bArr, i11);
    }

    public final void h(int i10, int i11, long j10, long j11) {
        boolean z10;
        a aVar = this.f30954d;
        boolean z11 = this.f30955e;
        boolean z12 = false;
        aVar.f30971g = false;
        aVar.f30972h = false;
        aVar.f30969e = j11;
        aVar.f30968d = 0;
        aVar.f30966b = j10;
        if (i11 >= 32 && i11 != 40) {
            if (aVar.f30973i && !aVar.f30974j) {
                if (z11) {
                    aVar.a(i10);
                }
                aVar.f30973i = false;
            }
            if ((32 <= i11 && i11 <= 35) || i11 == 39) {
                aVar.f30972h = !aVar.f30974j;
                aVar.f30974j = true;
            }
        }
        if (i11 < 16 || i11 > 21) {
            z10 = false;
        } else {
            z10 = true;
        }
        aVar.f30967c = z10;
        if (z10 || i11 <= 9) {
            z12 = true;
        }
        aVar.f30970f = z12;
        if (!this.f30955e) {
            this.f30957g.d(i11);
            this.f30958h.d(i11);
            this.f30959i.d(i11);
        }
        this.f30960j.d(i11);
        this.f30961k.d(i11);
    }
}
