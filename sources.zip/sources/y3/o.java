package y3;

import D2.E;
import R2.H;
import R2.p;
import f7.M;
import l2.n;
import l2.u;
import o2.n;
import o2.t;
import y3.F;

public final class o implements j {

    /* renamed from: a  reason: collision with root package name */
    public final t f30978a = new t(10);

    /* renamed from: b  reason: collision with root package name */
    public H f30979b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f30980c;

    /* renamed from: d  reason: collision with root package name */
    public long f30981d = -9223372036854775807L;

    /* renamed from: e  reason: collision with root package name */
    public int f30982e;

    /* renamed from: f  reason: collision with root package name */
    public int f30983f;

    public final void b() {
        this.f30980c = false;
        this.f30981d = -9223372036854775807L;
    }

    public final void c(t tVar) {
        M.n(this.f30979b);
        if (this.f30980c) {
            int a10 = tVar.a();
            int i10 = this.f30983f;
            if (i10 < 10) {
                int min = Math.min(a10, 10 - i10);
                byte[] bArr = tVar.f25885a;
                int i11 = tVar.f25886b;
                t tVar2 = this.f30978a;
                System.arraycopy(bArr, i11, tVar2.f25885a, this.f30983f, min);
                if (this.f30983f + min == 10) {
                    tVar2.G(0);
                    if (73 == tVar2.u() && 68 == tVar2.u() && 51 == tVar2.u()) {
                        tVar2.H(3);
                        this.f30982e = tVar2.t() + 10;
                    } else {
                        n.f("Id3Reader", "Discarding invalid ID3 tag");
                        this.f30980c = false;
                        return;
                    }
                }
            }
            int min2 = Math.min(a10, this.f30982e - this.f30983f);
            this.f30979b.e(min2, tVar);
            this.f30983f += min2;
        }
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        H k10 = pVar.k(cVar.f30756d, 5);
        this.f30979b = k10;
        n.a aVar = new n.a();
        cVar.b();
        aVar.f24316a = cVar.f30757e;
        aVar.f24327l = u.p("video/mp2t");
        aVar.f24328m = u.p("application/id3");
        E.r(aVar, k10);
    }

    public final void e(boolean z10) {
        int i10;
        boolean z11;
        M.n(this.f30979b);
        if (this.f30980c && (i10 = this.f30982e) != 0 && this.f30983f == i10) {
            if (this.f30981d != -9223372036854775807L) {
                z11 = true;
            } else {
                z11 = false;
            }
            M.m(z11);
            this.f30979b.b(this.f30981d, 1, this.f30982e, 0, (H.a) null);
            this.f30980c = false;
        }
    }

    public final void f(int i10, long j10) {
        if ((i10 & 4) != 0) {
            this.f30980c = true;
            this.f30981d = j10;
            this.f30982e = 0;
            this.f30983f = 0;
        }
    }
}
