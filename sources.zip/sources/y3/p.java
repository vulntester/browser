package y3;

import R2.H;
import U1.c;
import l2.n;
import o2.t;
import y3.F;

public final class p implements j {

    /* renamed from: a  reason: collision with root package name */
    public final String f30984a;

    /* renamed from: b  reason: collision with root package name */
    public final int f30985b;

    /* renamed from: c  reason: collision with root package name */
    public final t f30986c;

    /* renamed from: d  reason: collision with root package name */
    public final c f30987d;

    /* renamed from: e  reason: collision with root package name */
    public H f30988e;

    /* renamed from: f  reason: collision with root package name */
    public String f30989f;

    /* renamed from: g  reason: collision with root package name */
    public n f30990g;

    /* renamed from: h  reason: collision with root package name */
    public int f30991h;

    /* renamed from: i  reason: collision with root package name */
    public int f30992i;

    /* renamed from: j  reason: collision with root package name */
    public int f30993j;

    /* renamed from: k  reason: collision with root package name */
    public int f30994k;

    /* renamed from: l  reason: collision with root package name */
    public long f30995l = -9223372036854775807L;

    /* renamed from: m  reason: collision with root package name */
    public boolean f30996m;

    /* renamed from: n  reason: collision with root package name */
    public int f30997n;

    /* renamed from: o  reason: collision with root package name */
    public int f30998o;

    /* renamed from: p  reason: collision with root package name */
    public int f30999p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f31000q;

    /* renamed from: r  reason: collision with root package name */
    public long f31001r;

    /* renamed from: s  reason: collision with root package name */
    public int f31002s;

    /* renamed from: t  reason: collision with root package name */
    public long f31003t;

    /* renamed from: u  reason: collision with root package name */
    public int f31004u;

    /* renamed from: v  reason: collision with root package name */
    public String f31005v;

    public p(String str, int i10) {
        this.f30984a = str;
        this.f30985b = i10;
        t tVar = new t(1024);
        this.f30986c = tVar;
        byte[] bArr = tVar.f25885a;
        this.f30987d = new c(bArr, bArr.length);
    }

    public final void b() {
        this.f30991h = 0;
        this.f30995l = -9223372036854775807L;
        this.f30996m = false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:64:0x01a0, code lost:
        if (r0.f30996m == false) goto L_0x020b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(o2.t r24) {
        /*
            r23 = this;
            r0 = r23
            R2.H r1 = r0.f30988e
            f7.M.n(r1)
        L_0x0007:
            int r1 = r24.a()
            if (r1 <= 0) goto L_0x0273
            int r1 = r0.f30991h
            r2 = 1
            r3 = 86
            if (r1 == 0) goto L_0x0267
            r4 = 2
            r5 = 0
            if (r1 == r2) goto L_0x024e
            r3 = 3
            r6 = 8
            o2.t r7 = r0.f30986c
            U1.c r8 = r0.f30987d
            if (r1 == r4) goto L_0x0228
            if (r1 != r3) goto L_0x0222
            int r1 = r24.a()
            int r9 = r0.f30993j
            int r10 = r0.f30992i
            int r9 = r9 - r10
            int r1 = java.lang.Math.min(r1, r9)
            java.lang.Object r9 = r8.f10461d
            byte[] r9 = (byte[]) r9
            int r10 = r0.f30992i
            r11 = r24
            r11.f(r10, r9, r1)
            int r9 = r0.f30992i
            int r9 = r9 + r1
            r0.f30992i = r9
            int r1 = r0.f30993j
            if (r9 != r1) goto L_0x0007
            r8.n(r5)
            boolean r1 = r8.g()
            r9 = 0
            if (r1 != 0) goto L_0x019e
            r0.f30996m = r2
            int r1 = r8.h(r2)
            if (r1 != r2) goto L_0x005b
            int r10 = r8.h(r2)
            goto L_0x005c
        L_0x005b:
            r10 = r5
        L_0x005c:
            r0.f30997n = r10
            if (r10 != 0) goto L_0x0199
            if (r1 != r2) goto L_0x006b
            int r10 = r8.h(r4)
            int r10 = r10 + r2
            int r10 = r10 * r6
            r8.h(r10)
        L_0x006b:
            boolean r10 = r8.g()
            if (r10 == 0) goto L_0x0194
            r10 = 6
            int r12 = r8.h(r10)
            r0.f30998o = r12
            r12 = 4
            int r13 = r8.h(r12)
            int r14 = r8.h(r3)
            if (r13 != 0) goto L_0x018f
            if (r14 != 0) goto L_0x018f
            if (r1 != 0) goto L_0x0101
            int r13 = r8.f()
            int r14 = r8.c()
            R2.a$a r15 = R2.C1005a.c(r8, r2)
            java.lang.String r5 = r15.f8097c
            r0.f31005v = r5
            int r5 = r15.f8095a
            r0.f31002s = r5
            int r5 = r15.f8096b
            r0.f31004u = r5
            int r5 = r8.c()
            int r14 = r14 - r5
            r8.n(r13)
            int r5 = r14 + 7
            int r5 = r5 / r6
            byte[] r5 = new byte[r5]
            r8.i(r14, r5)
            l2.n$a r13 = new l2.n$a
            r13.<init>()
            java.lang.String r14 = r0.f30989f
            r13.f24316a = r14
            java.lang.String r14 = "video/mp2t"
            java.lang.String r14 = l2.u.p(r14)
            r13.f24327l = r14
            java.lang.String r14 = "audio/mp4a-latm"
            java.lang.String r14 = l2.u.p(r14)
            r13.f24328m = r14
            java.lang.String r14 = r0.f31005v
            r13.f24325j = r14
            int r14 = r0.f31004u
            r13.f24306C = r14
            int r14 = r0.f31002s
            r13.f24307D = r14
            java.util.List r5 = java.util.Collections.singletonList(r5)
            r13.f24331p = r5
            java.lang.String r5 = r0.f30984a
            r13.f24319d = r5
            int r5 = r0.f30985b
            r13.f24321f = r5
            l2.n r5 = new l2.n
            r5.<init>(r13)
            l2.n r13 = r0.f30990g
            boolean r13 = r5.equals(r13)
            if (r13 != 0) goto L_0x012a
            r0.f30990g = r5
            int r13 = r5.f24268E
            long r13 = (long) r13
            r16 = 1024000000(0x3d090000, double:5.059232213E-315)
            long r13 = r16 / r13
            r0.f31003t = r13
            R2.H r13 = r0.f30988e
            r13.d(r5)
            goto L_0x012a
        L_0x0101:
            int r5 = r8.h(r4)
            int r5 = r5 + r2
            int r5 = r5 * r6
            int r5 = r8.h(r5)
            long r13 = (long) r5
            int r5 = (int) r13
            int r13 = r8.c()
            R2.a$a r14 = R2.C1005a.c(r8, r2)
            java.lang.String r15 = r14.f8097c
            r0.f31005v = r15
            int r15 = r14.f8095a
            r0.f31002s = r15
            int r14 = r14.f8096b
            r0.f31004u = r14
            int r14 = r8.c()
            int r13 = r13 - r14
            int r5 = r5 - r13
            r8.p(r5)
        L_0x012a:
            int r5 = r8.h(r3)
            r0.f30999p = r5
            if (r5 == 0) goto L_0x0155
            if (r5 == r2) goto L_0x014f
            if (r5 == r3) goto L_0x014b
            if (r5 == r12) goto L_0x014b
            r3 = 5
            if (r5 == r3) goto L_0x014b
            if (r5 == r10) goto L_0x0147
            r3 = 7
            if (r5 != r3) goto L_0x0141
            goto L_0x0147
        L_0x0141:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x0147:
            r8.p(r2)
            goto L_0x0158
        L_0x014b:
            r8.p(r10)
            goto L_0x0158
        L_0x014f:
            r3 = 9
            r8.p(r3)
            goto L_0x0158
        L_0x0155:
            r8.p(r6)
        L_0x0158:
            boolean r3 = r8.g()
            r0.f31000q = r3
            r12 = 0
            r0.f31001r = r12
            if (r3 == 0) goto L_0x0185
            if (r1 != r2) goto L_0x0174
            int r1 = r8.h(r4)
            int r1 = r1 + r2
            int r1 = r1 * r6
            int r1 = r8.h(r1)
            long r3 = (long) r1
            r0.f31001r = r3
            goto L_0x0185
        L_0x0174:
            boolean r1 = r8.g()
            long r3 = r0.f31001r
            long r3 = r3 << r6
            int r5 = r8.h(r6)
            long r12 = (long) r5
            long r3 = r3 + r12
            r0.f31001r = r3
            if (r1 != 0) goto L_0x0174
        L_0x0185:
            boolean r1 = r8.g()
            if (r1 == 0) goto L_0x01a3
            r8.p(r6)
            goto L_0x01a3
        L_0x018f:
            l2.v r1 = l2.v.a(r9, r9)
            throw r1
        L_0x0194:
            l2.v r1 = l2.v.a(r9, r9)
            throw r1
        L_0x0199:
            l2.v r1 = l2.v.a(r9, r9)
            throw r1
        L_0x019e:
            boolean r1 = r0.f30996m
            if (r1 != 0) goto L_0x01a3
            goto L_0x020b
        L_0x01a3:
            int r1 = r0.f30997n
            if (r1 != 0) goto L_0x021d
            int r1 = r0.f30998o
            if (r1 != 0) goto L_0x0218
            int r1 = r0.f30999p
            if (r1 != 0) goto L_0x0213
            r1 = 0
        L_0x01b0:
            int r3 = r8.h(r6)
            int r1 = r1 + r3
            r4 = 255(0xff, float:3.57E-43)
            if (r3 == r4) goto L_0x0210
            int r3 = r8.f()
            r4 = r3 & 7
            if (r4 != 0) goto L_0x01c7
            int r3 = r3 >> 3
            r7.G(r3)
            goto L_0x01d2
        L_0x01c7:
            byte[] r3 = r7.f25885a
            int r4 = r1 * 8
            r8.i(r4, r3)
            r3 = 0
            r7.G(r3)
        L_0x01d2:
            R2.H r3 = r0.f30988e
            r3.e(r1, r7)
            long r3 = r0.f30995l
            r5 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 == 0) goto L_0x01e3
            goto L_0x01e4
        L_0x01e3:
            r2 = 0
        L_0x01e4:
            f7.M.m(r2)
            R2.H r2 = r0.f30988e
            long r3 = r0.f30995l
            r21 = 0
            r22 = 0
            r19 = 1
            r20 = r1
            r16 = r2
            r17 = r3
            r16.b(r17, r19, r20, r21, r22)
            long r1 = r0.f30995l
            long r3 = r0.f31003t
            long r1 = r1 + r3
            r0.f30995l = r1
            boolean r1 = r0.f31000q
            if (r1 == 0) goto L_0x020b
            long r1 = r0.f31001r
            int r1 = (int) r1
            r8.p(r1)
        L_0x020b:
            r3 = 0
            r0.f30991h = r3
            goto L_0x0007
        L_0x0210:
            r20 = r1
            goto L_0x01b0
        L_0x0213:
            l2.v r1 = l2.v.a(r9, r9)
            throw r1
        L_0x0218:
            l2.v r1 = l2.v.a(r9, r9)
            throw r1
        L_0x021d:
            l2.v r1 = l2.v.a(r9, r9)
            throw r1
        L_0x0222:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x0228:
            r11 = r24
            int r1 = r0.f30994k
            r1 = r1 & -225(0xffffffffffffff1f, float:NaN)
            int r1 = r1 << r6
            int r2 = r11.u()
            r1 = r1 | r2
            r0.f30993j = r1
            byte[] r2 = r7.f25885a
            int r2 = r2.length
            if (r1 <= r2) goto L_0x0247
            r7.D(r1)
            byte[] r1 = r7.f25885a
            r8.getClass()
            int r2 = r1.length
            r8.l(r2, r1)
        L_0x0247:
            r1 = 0
            r0.f30992i = r1
            r0.f30991h = r3
            goto L_0x0007
        L_0x024e:
            r11 = r24
            int r1 = r11.u()
            r2 = r1 & 224(0xe0, float:3.14E-43)
            r5 = 224(0xe0, float:3.14E-43)
            if (r2 != r5) goto L_0x0260
            r0.f30994k = r1
            r0.f30991h = r4
            goto L_0x0007
        L_0x0260:
            if (r1 == r3) goto L_0x0007
            r3 = 0
            r0.f30991h = r3
            goto L_0x0007
        L_0x0267:
            r11 = r24
            int r1 = r11.u()
            if (r1 != r3) goto L_0x0007
            r0.f30991h = r2
            goto L_0x0007
        L_0x0273:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.p.c(o2.t):void");
    }

    public final void d(R2.p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f30988e = pVar.k(cVar.f30756d, 1);
        cVar.b();
        this.f30989f = cVar.f30757e;
    }

    public final void f(int i10, long j10) {
        this.f30995l = j10;
    }

    public final void e(boolean z10) {
    }
}
