package y3;

import R2.A;
import R2.H;
import R2.p;
import f7.M;
import l2.n;
import l2.u;
import o2.t;
import y3.F;

public final class q implements j {

    /* renamed from: a  reason: collision with root package name */
    public final t f31006a;

    /* renamed from: b  reason: collision with root package name */
    public final A.a f31007b;

    /* renamed from: c  reason: collision with root package name */
    public final String f31008c;

    /* renamed from: d  reason: collision with root package name */
    public final int f31009d;

    /* renamed from: e  reason: collision with root package name */
    public final String f31010e;

    /* renamed from: f  reason: collision with root package name */
    public H f31011f;

    /* renamed from: g  reason: collision with root package name */
    public String f31012g;

    /* renamed from: h  reason: collision with root package name */
    public int f31013h = 0;

    /* renamed from: i  reason: collision with root package name */
    public int f31014i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f31015j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f31016k;

    /* renamed from: l  reason: collision with root package name */
    public long f31017l;

    /* renamed from: m  reason: collision with root package name */
    public int f31018m;

    /* renamed from: n  reason: collision with root package name */
    public long f31019n;

    /* JADX WARNING: type inference failed for: r0v1, types: [R2.A$a, java.lang.Object] */
    public q(String str, int i10, String str2) {
        t tVar = new t(4);
        this.f31006a = tVar;
        tVar.f25885a[0] = -1;
        this.f31007b = new Object();
        this.f31019n = -9223372036854775807L;
        this.f31008c = str;
        this.f31009d = i10;
        this.f31010e = str2;
    }

    public final void b() {
        this.f31013h = 0;
        this.f31014i = 0;
        this.f31016k = false;
        this.f31019n = -9223372036854775807L;
    }

    public final void c(t tVar) {
        boolean z10;
        boolean z11;
        M.n(this.f31011f);
        while (tVar.a() > 0) {
            int i10 = this.f31013h;
            boolean z12 = true;
            t tVar2 = this.f31006a;
            if (i10 == 0) {
                byte[] bArr = tVar.f25885a;
                int i11 = tVar.f25886b;
                int i12 = tVar.f25887c;
                while (true) {
                    if (i11 >= i12) {
                        tVar.G(i12);
                        break;
                    }
                    byte b10 = bArr[i11];
                    if ((b10 & 255) == 255) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    if (!this.f31016k || (b10 & 224) != 224) {
                        z11 = false;
                    } else {
                        z11 = true;
                    }
                    this.f31016k = z10;
                    if (z11) {
                        tVar.G(i11 + 1);
                        this.f31016k = false;
                        tVar2.f25885a[1] = bArr[i11];
                        this.f31014i = 2;
                        this.f31013h = 1;
                        break;
                    }
                    i11++;
                }
            } else if (i10 == 1) {
                int min = Math.min(tVar.a(), 4 - this.f31014i);
                tVar.f(this.f31014i, tVar2.f25885a, min);
                int i13 = this.f31014i + min;
                this.f31014i = i13;
                if (i13 >= 4) {
                    tVar2.G(0);
                    int h10 = tVar2.h();
                    A.a aVar = this.f31007b;
                    if (!aVar.a(h10)) {
                        this.f31014i = 0;
                        this.f31013h = 1;
                    } else {
                        this.f31018m = aVar.f8049c;
                        if (!this.f31015j) {
                            this.f31017l = (((long) aVar.f8053g) * 1000000) / ((long) aVar.f8050d);
                            n.a aVar2 = new n.a();
                            aVar2.f24316a = this.f31012g;
                            aVar2.f24327l = u.p(this.f31010e);
                            aVar2.f24328m = u.p(aVar.f8048b);
                            aVar2.f24329n = 4096;
                            aVar2.f24306C = aVar.f8051e;
                            aVar2.f24307D = aVar.f8050d;
                            aVar2.f24319d = this.f31008c;
                            aVar2.f24321f = this.f31009d;
                            this.f31011f.d(new n(aVar2));
                            this.f31015j = true;
                        }
                        tVar2.G(0);
                        this.f31011f.e(4, tVar2);
                        this.f31013h = 2;
                    }
                }
            } else if (i10 == 2) {
                int min2 = Math.min(tVar.a(), this.f31018m - this.f31014i);
                this.f31011f.e(min2, tVar);
                int i14 = this.f31014i + min2;
                this.f31014i = i14;
                if (i14 >= this.f31018m) {
                    if (this.f31019n == -9223372036854775807L) {
                        z12 = false;
                    }
                    M.m(z12);
                    this.f31011f.b(this.f31019n, 1, this.f31018m, 0, (H.a) null);
                    this.f31019n += this.f31017l;
                    this.f31014i = 0;
                    this.f31013h = 0;
                }
            } else {
                throw new IllegalStateException();
            }
        }
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f31012g = cVar.f30757e;
        cVar.b();
        this.f31011f = pVar.k(cVar.f30756d, 1);
    }

    public final void f(int i10, long j10) {
        this.f31019n = j10;
    }

    public final void e(boolean z10) {
    }
}
