package y3;

import R2.H;
import R2.p;
import U1.c;
import o2.t;
import y3.F;
import y3.s;

public final class r implements j {

    /* renamed from: a  reason: collision with root package name */
    public final t f31020a = new t(new byte[15], 2);

    /* renamed from: b  reason: collision with root package name */
    public final c f31021b = new c(1);

    /* renamed from: c  reason: collision with root package name */
    public final t f31022c = new t();

    /* renamed from: d  reason: collision with root package name */
    public int f31023d = 0;

    /* renamed from: e  reason: collision with root package name */
    public String f31024e;

    /* renamed from: f  reason: collision with root package name */
    public H f31025f;

    /* renamed from: g  reason: collision with root package name */
    public double f31026g = -9.223372036854776E18d;

    /* renamed from: h  reason: collision with root package name */
    public double f31027h = -9.223372036854776E18d;

    /* renamed from: i  reason: collision with root package name */
    public boolean f31028i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f31029j = true;

    /* renamed from: k  reason: collision with root package name */
    public int f31030k;

    /* renamed from: l  reason: collision with root package name */
    public int f31031l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f31032m = true;

    /* renamed from: n  reason: collision with root package name */
    public int f31033n;

    /* renamed from: o  reason: collision with root package name */
    public int f31034o;

    /* renamed from: p  reason: collision with root package name */
    public final s.a f31035p = new Object();

    /* renamed from: q  reason: collision with root package name */
    public int f31036q = -2147483647;

    /* renamed from: r  reason: collision with root package name */
    public int f31037r = -1;

    /* renamed from: s  reason: collision with root package name */
    public int f31038s;

    /* renamed from: t  reason: collision with root package name */
    public long f31039t = -1;

    /* renamed from: u  reason: collision with root package name */
    public boolean f31040u;

    public final void b() {
        this.f31023d = 0;
        this.f31031l = 0;
        this.f31020a.D(2);
        this.f31033n = 0;
        this.f31034o = 0;
        this.f31036q = -2147483647;
        this.f31037r = -1;
        this.f31038s = 0;
        this.f31039t = -1;
        this.f31040u = false;
        this.f31028i = false;
        this.f31032m = true;
        this.f31029j = true;
        this.f31026g = -9.223372036854776E18d;
        this.f31027h = -9.223372036854776E18d;
    }

    /* JADX WARNING: Removed duplicated region for block: B:212:0x0420  */
    /* JADX WARNING: Removed duplicated region for block: B:231:0x0460  */
    /* JADX WARNING: Removed duplicated region for block: B:232:0x046c  */
    /* JADX WARNING: Removed duplicated region for block: B:234:0x046f  */
    /* JADX WARNING: Removed duplicated region for block: B:235:0x0488  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c(o2.t r27) {
        /*
            r26 = this;
            r0 = r26
            r1 = r27
            r2 = 4
            r3 = 2
            r5 = 8
            r6 = 1
            R2.H r7 = r0.f31025f
            f7.M.n(r7)
        L_0x000e:
            int r7 = r1.a()
            if (r7 <= 0) goto L_0x04fa
            int r7 = r0.f31023d
            r8 = 3
            if (r7 == 0) goto L_0x04b3
            y3.s$a r9 = r0.f31035p
            r12 = 24
            r13 = 17
            o2.t r14 = r0.f31022c
            if (r7 == r6) goto L_0x0387
            if (r7 != r3) goto L_0x0381
            int r7 = r9.f31041a
            if (r7 == r6) goto L_0x002b
            if (r7 != r13) goto L_0x0046
        L_0x002b:
            int r7 = r1.f25886b
            int r15 = r1.a()
            int r11 = r14.a()
            int r11 = java.lang.Math.min(r15, r11)
            byte[] r15 = r14.f25885a
            int r13 = r14.f25886b
            r1.f(r13, r15, r11)
            r14.H(r11)
            r1.G(r7)
        L_0x0046:
            int r7 = r1.a()
            int r11 = r9.f31043c
            int r13 = r0.f31033n
            int r11 = r11 - r13
            int r7 = java.lang.Math.min(r7, r11)
            R2.H r11 = r0.f31025f
            r11.e(r7, r1)
            int r11 = r0.f31033n
            int r11 = r11 + r7
            r0.f31033n = r11
            int r7 = r9.f31043c
            if (r11 != r7) goto L_0x000e
            int r7 = r9.f31041a
            if (r7 != r6) goto L_0x0316
            U1.c r7 = new U1.c
            byte[] r13 = r14.f25885a
            int r14 = r13.length
            r7.<init>(r13, r14)
            int r13 = r7.h(r5)
            r14 = 5
            int r15 = r7.h(r14)
            r10 = 31
            if (r15 != r10) goto L_0x0080
            int r10 = r7.h(r12)
            goto L_0x00ef
        L_0x0080:
            switch(r15) {
                case 0: goto L_0x00ec;
                case 1: goto L_0x00e8;
                case 2: goto L_0x00e4;
                case 3: goto L_0x00e0;
                case 4: goto L_0x00dc;
                case 5: goto L_0x00d9;
                case 6: goto L_0x00d6;
                case 7: goto L_0x00d3;
                case 8: goto L_0x00d0;
                case 9: goto L_0x00cd;
                case 10: goto L_0x00ca;
                case 11: goto L_0x00c7;
                case 12: goto L_0x00c4;
                case 13: goto L_0x0083;
                case 14: goto L_0x0083;
                case 15: goto L_0x00c0;
                case 16: goto L_0x00bc;
                case 17: goto L_0x00b8;
                case 18: goto L_0x00b4;
                case 19: goto L_0x00b0;
                case 20: goto L_0x00ad;
                case 21: goto L_0x00aa;
                case 22: goto L_0x00a7;
                case 23: goto L_0x00a4;
                case 24: goto L_0x00a1;
                case 25: goto L_0x009e;
                case 26: goto L_0x009a;
                case 27: goto L_0x0096;
                default: goto L_0x0083;
            }
        L_0x0083:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Unsupported sampling rate index "
            r1.<init>(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x0096:
            r10 = 9600(0x2580, float:1.3452E-41)
            goto L_0x00ef
        L_0x009a:
            r10 = 12800(0x3200, float:1.7937E-41)
            goto L_0x00ef
        L_0x009e:
            r10 = 14400(0x3840, float:2.0179E-41)
            goto L_0x00ef
        L_0x00a1:
            r10 = 17075(0x42b3, float:2.3927E-41)
            goto L_0x00ef
        L_0x00a4:
            r10 = 19200(0x4b00, float:2.6905E-41)
            goto L_0x00ef
        L_0x00a7:
            r10 = 20000(0x4e20, float:2.8026E-41)
            goto L_0x00ef
        L_0x00aa:
            r10 = 25600(0x6400, float:3.5873E-41)
            goto L_0x00ef
        L_0x00ad:
            r10 = 28800(0x7080, float:4.0357E-41)
            goto L_0x00ef
        L_0x00b0:
            r10 = 34150(0x8566, float:4.7854E-41)
            goto L_0x00ef
        L_0x00b4:
            r10 = 38400(0x9600, float:5.381E-41)
            goto L_0x00ef
        L_0x00b8:
            r10 = 40000(0x9c40, float:5.6052E-41)
            goto L_0x00ef
        L_0x00bc:
            r10 = 51200(0xc800, float:7.1746E-41)
            goto L_0x00ef
        L_0x00c0:
            r10 = 57600(0xe100, float:8.0715E-41)
            goto L_0x00ef
        L_0x00c4:
            r10 = 7350(0x1cb6, float:1.03E-41)
            goto L_0x00ef
        L_0x00c7:
            r10 = 8000(0x1f40, float:1.121E-41)
            goto L_0x00ef
        L_0x00ca:
            r10 = 11025(0x2b11, float:1.545E-41)
            goto L_0x00ef
        L_0x00cd:
            r10 = 12000(0x2ee0, float:1.6816E-41)
            goto L_0x00ef
        L_0x00d0:
            r10 = 16000(0x3e80, float:2.2421E-41)
            goto L_0x00ef
        L_0x00d3:
            r10 = 22050(0x5622, float:3.0899E-41)
            goto L_0x00ef
        L_0x00d6:
            r10 = 24000(0x5dc0, float:3.3631E-41)
            goto L_0x00ef
        L_0x00d9:
            r10 = 32000(0x7d00, float:4.4842E-41)
            goto L_0x00ef
        L_0x00dc:
            r10 = 44100(0xac44, float:6.1797E-41)
            goto L_0x00ef
        L_0x00e0:
            r10 = 48000(0xbb80, float:6.7262E-41)
            goto L_0x00ef
        L_0x00e4:
            r10 = 64000(0xfa00, float:8.9683E-41)
            goto L_0x00ef
        L_0x00e8:
            r10 = 88200(0x15888, float:1.23595E-40)
            goto L_0x00ef
        L_0x00ec:
            r10 = 96000(0x17700, float:1.34525E-40)
        L_0x00ef:
            int r12 = r7.h(r8)
            java.lang.String r15 = "Unsupported coreSbrFrameLengthIndex "
            if (r12 == 0) goto L_0x011b
            if (r12 == r6) goto L_0x0118
            if (r12 == r3) goto L_0x0115
            if (r12 == r8) goto L_0x0115
            if (r12 != r2) goto L_0x0104
            r16 = 4096(0x1000, float:5.74E-42)
        L_0x0101:
            r17 = r16
            goto L_0x011e
        L_0x0104:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r15)
            r1.append(r12)
            java.lang.String r1 = r1.toString()
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x0115:
            r16 = 2048(0x800, float:2.87E-42)
            goto L_0x0101
        L_0x0118:
            r16 = 1024(0x400, float:1.435E-42)
            goto L_0x0101
        L_0x011b:
            r16 = 768(0x300, float:1.076E-42)
            goto L_0x0101
        L_0x011e:
            if (r12 == 0) goto L_0x013f
            if (r12 == r6) goto L_0x013f
            if (r12 == r3) goto L_0x013d
            if (r12 == r8) goto L_0x013b
            if (r12 != r2) goto L_0x012a
            r12 = r6
            goto L_0x0140
        L_0x012a:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r15)
            r1.append(r12)
            java.lang.String r1 = r1.toString()
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x013b:
            r12 = r8
            goto L_0x0140
        L_0x013d:
            r12 = r3
            goto L_0x0140
        L_0x013f:
            r12 = 0
        L_0x0140:
            r7.p(r3)
            y3.s.c(r7)
            int r15 = r7.h(r14)
            r11 = 0
            r18 = 0
        L_0x014d:
            int r4 = r15 + 1
            r20 = r6
            r6 = 16
            if (r11 >= r4) goto L_0x0173
            int r4 = r7.h(r8)
            int r6 = y3.s.a(r7, r14, r5, r6)
            int r6 = r6 + 1
            int r18 = r6 + r18
            if (r4 == 0) goto L_0x0165
            if (r4 != r3) goto L_0x016e
        L_0x0165:
            boolean r4 = r7.g()
            if (r4 == 0) goto L_0x016e
            y3.s.c(r7)
        L_0x016e:
            int r11 = r11 + 1
            r6 = r20
            goto L_0x014d
        L_0x0173:
            int r4 = y3.s.a(r7, r2, r5, r6)
            int r4 = r4 + 1
            r7.o()
            r11 = 0
        L_0x017d:
            r21 = 4611686018427387904(0x4000000000000000, double:2.0)
            if (r11 >= r4) goto L_0x0246
            int r15 = r7.h(r3)
            if (r15 == 0) goto L_0x0228
            r14 = r20
            if (r15 == r14) goto L_0x01ad
            if (r15 == r8) goto L_0x0192
        L_0x018d:
            r2 = 5
        L_0x018e:
            r20 = 1
            goto L_0x023e
        L_0x0192:
            y3.s.a(r7, r2, r5, r6)
            int r14 = y3.s.a(r7, r2, r5, r6)
            boolean r15 = r7.g()
            if (r15 == 0) goto L_0x01a3
            r15 = 0
            y3.s.a(r7, r5, r6, r15)
        L_0x01a3:
            r7.o()
            if (r14 <= 0) goto L_0x018d
            int r14 = r14 * r5
            r7.p(r14)
            goto L_0x018d
        L_0x01ad:
            r7.p(r8)
            boolean r14 = r7.g()
            if (r14 == 0) goto L_0x01bb
            r15 = 13
            r7.p(r15)
        L_0x01bb:
            if (r14 == 0) goto L_0x01c0
            r7.o()
        L_0x01c0:
            if (r12 <= 0) goto L_0x01ca
            y3.s.b(r7)
            int r14 = r7.h(r3)
            goto L_0x01cb
        L_0x01ca:
            r14 = 0
        L_0x01cb:
            if (r14 <= 0) goto L_0x01f1
            r15 = 6
            r7.p(r15)
            int r6 = r7.h(r3)
            r7.p(r2)
            boolean r25 = r7.g()
            r2 = 5
            if (r25 == 0) goto L_0x01e2
            r7.p(r2)
        L_0x01e2:
            if (r14 == r3) goto L_0x01e6
            if (r14 != r8) goto L_0x01e9
        L_0x01e6:
            r7.p(r15)
        L_0x01e9:
            if (r6 != r3) goto L_0x01ee
            r7.o()
        L_0x01ee:
            r20 = 1
            goto L_0x01f3
        L_0x01f1:
            r2 = 5
            goto L_0x01ee
        L_0x01f3:
            int r6 = r18 + -1
            double r14 = (double) r6
            double r14 = java.lang.Math.log(r14)
            double r21 = java.lang.Math.log(r21)
            double r14 = r14 / r21
            double r14 = java.lang.Math.floor(r14)
            int r6 = (int) r14
            int r6 = r6 + 1
            int r14 = r7.h(r3)
            if (r14 <= 0) goto L_0x0216
            boolean r15 = r7.g()
            if (r15 == 0) goto L_0x0216
            r7.p(r6)
        L_0x0216:
            boolean r15 = r7.g()
            if (r15 == 0) goto L_0x021f
            r7.p(r6)
        L_0x021f:
            if (r12 != 0) goto L_0x018e
            if (r14 != 0) goto L_0x018e
            r7.o()
            goto L_0x018e
        L_0x0228:
            r2 = r14
            r7.p(r8)
            boolean r6 = r7.g()
            if (r6 == 0) goto L_0x0237
            r15 = 13
            r7.p(r15)
        L_0x0237:
            if (r12 <= 0) goto L_0x018e
            y3.s.b(r7)
            goto L_0x018e
        L_0x023e:
            int r11 = r11 + 1
            r14 = r2
            r2 = 4
            r6 = 16
            goto L_0x017d
        L_0x0246:
            boolean r2 = r7.g()
            if (r2 == 0) goto L_0x0288
            r2 = 4
            int r4 = y3.s.a(r7, r3, r2, r5)
            int r4 = r4 + 1
            r6 = 0
            r8 = 0
        L_0x0255:
            if (r6 >= r4) goto L_0x0289
            r11 = 16
            int r12 = y3.s.a(r7, r2, r5, r11)
            int r14 = y3.s.a(r7, r2, r5, r11)
            r15 = 7
            if (r12 != r15) goto L_0x027e
            int r8 = r7.h(r2)
            int r8 = r8 + 1
            r7.p(r2)
            byte[] r2 = new byte[r8]
            r12 = 0
        L_0x0270:
            if (r12 >= r8) goto L_0x027c
            int r14 = r7.h(r5)
            byte r14 = (byte) r14
            r2[r12] = r14
            int r12 = r12 + 1
            goto L_0x0270
        L_0x027c:
            r8 = r2
            goto L_0x0282
        L_0x027e:
            int r14 = r14 * r5
            r7.p(r14)
        L_0x0282:
            int r6 = r6 + 1
            r2 = 4
            r20 = 1
            goto L_0x0255
        L_0x0288:
            r8 = 0
        L_0x0289:
            switch(r10) {
                case 14700: goto L_0x02a5;
                case 16000: goto L_0x02a5;
                case 22050: goto L_0x02a7;
                case 24000: goto L_0x02a7;
                case 29400: goto L_0x02a2;
                case 32000: goto L_0x02a2;
                case 44100: goto L_0x029f;
                case 48000: goto L_0x029f;
                case 58800: goto L_0x02a2;
                case 64000: goto L_0x02a2;
                case 88200: goto L_0x029f;
                case 96000: goto L_0x029f;
                default: goto L_0x028c;
            }
        L_0x028c:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Unsupported sampling rate "
            r1.<init>(r2)
            r1.append(r10)
            java.lang.String r1 = r1.toString()
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x029f:
            r21 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            goto L_0x02a7
        L_0x02a2:
            r21 = 4609434218613702656(0x3ff8000000000000, double:1.5)
            goto L_0x02a7
        L_0x02a5:
            r21 = 4613937818241073152(0x4008000000000000, double:3.0)
        L_0x02a7:
            double r6 = (double) r10
            double r6 = r6 * r21
            int r2 = (int) r6
            r4 = r17
            double r6 = (double) r4
            double r6 = r6 * r21
            int r4 = (int) r6
            r0.f31036q = r2
            r0.f31037r = r4
            long r6 = r0.f31039t
            long r9 = r9.f31042b
            int r2 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            if (r2 == 0) goto L_0x0311
            r0.f31039t = r9
            java.lang.String r2 = "mhm1"
            r4 = -1
            if (r13 == r4) goto L_0x02d9
            java.lang.Integer r4 = java.lang.Integer.valueOf(r13)
            r14 = 1
            java.lang.Object[] r6 = new java.lang.Object[r14]
            r19 = 0
            r6[r19] = r4
            java.lang.String r4 = ".%02X"
            java.lang.String r4 = java.lang.String.format(r4, r6)
            java.lang.String r2 = r2.concat(r4)
        L_0x02d9:
            if (r8 == 0) goto L_0x02e5
            int r4 = r8.length
            if (r4 <= 0) goto L_0x02e5
            byte[] r4 = o2.C2756B.f25813c
            S7.O r11 = S7.C1150x.w(r4, r8)
            goto L_0x02e6
        L_0x02e5:
            r11 = 0
        L_0x02e6:
            l2.n$a r4 = new l2.n$a
            r4.<init>()
            java.lang.String r6 = r0.f31024e
            r4.f24316a = r6
            java.lang.String r6 = "video/mp2t"
            java.lang.String r6 = l2.u.p(r6)
            r4.f24327l = r6
            java.lang.String r6 = "audio/mhm1"
            java.lang.String r6 = l2.u.p(r6)
            r4.f24328m = r6
            int r6 = r0.f31036q
            r4.f24307D = r6
            r4.f24325j = r2
            r4.f24331p = r11
            l2.n r2 = new l2.n
            r2.<init>(r4)
            R2.H r4 = r0.f31025f
            r4.d(r2)
        L_0x0311:
            r14 = 1
            r0.f31040u = r14
        L_0x0314:
            r14 = 1
            goto L_0x037b
        L_0x0316:
            r2 = 17
            if (r7 != r2) goto L_0x0336
            U1.c r2 = new U1.c
            byte[] r4 = r14.f25885a
            int r6 = r4.length
            r2.<init>(r4, r6)
            boolean r4 = r2.g()
            if (r4 == 0) goto L_0x0332
            r2.p(r3)
            r15 = 13
            int r2 = r2.h(r15)
            goto L_0x0333
        L_0x0332:
            r2 = 0
        L_0x0333:
            r0.f31038s = r2
            goto L_0x0314
        L_0x0336:
            if (r7 != r3) goto L_0x0314
            boolean r2 = r0.f31040u
            if (r2 == 0) goto L_0x0341
            r15 = 0
            r0.f31029j = r15
            r9 = 1
            goto L_0x0342
        L_0x0341:
            r9 = 0
        L_0x0342:
            int r2 = r0.f31037r
            int r4 = r0.f31038s
            int r2 = r2 - r4
            double r6 = (double) r2
            r10 = 4696837146684686336(0x412e848000000000, double:1000000.0)
            double r6 = r6 * r10
            int r2 = r0.f31036q
            double r10 = (double) r2
            double r6 = r6 / r10
            double r10 = r0.f31026g
            long r10 = java.lang.Math.round(r10)
            boolean r2 = r0.f31028i
            if (r2 == 0) goto L_0x0364
            r15 = 0
            r0.f31028i = r15
            double r6 = r0.f31027h
            r0.f31026g = r6
            goto L_0x0369
        L_0x0364:
            double r12 = r0.f31026g
            double r12 = r12 + r6
            r0.f31026g = r12
        L_0x0369:
            R2.H r6 = r0.f31025f
            r7 = r10
            int r10 = r0.f31034o
            r11 = 0
            r12 = 0
            r6.b(r7, r9, r10, r11, r12)
            r15 = 0
            r0.f31040u = r15
            r0.f31038s = r15
            r0.f31034o = r15
            goto L_0x0314
        L_0x037b:
            r0.f31023d = r14
        L_0x037d:
            r6 = r14
            r2 = 4
            goto L_0x000e
        L_0x0381:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x0387:
            int r2 = r1.a()
            o2.t r4 = r0.f31020a
            int r6 = r4.a()
            int r2 = java.lang.Math.min(r2, r6)
            byte[] r6 = r4.f25885a
            int r7 = r4.f25886b
            r1.f(r7, r6, r2)
            r4.H(r2)
            int r2 = r4.a()
            if (r2 != 0) goto L_0x04af
            int r2 = r4.f25887c
            byte[] r6 = r4.f25885a
            U1.c r7 = r0.f31021b
            r7.l(r2, r6)
            r7.e()
            int r6 = y3.s.a(r7, r8, r5, r5)
            r9.f31041a = r6
            r8 = -1
            if (r6 != r8) goto L_0x03be
            r15 = r9
        L_0x03bb:
            r6 = 0
            goto L_0x045e
        L_0x03be:
            int r6 = java.lang.Math.max(r3, r5)
            r8 = 32
            int r6 = java.lang.Math.max(r6, r8)
            r10 = 63
            if (r6 > r10) goto L_0x03ce
            r6 = 1
            goto L_0x03cf
        L_0x03ce:
            r6 = 0
        L_0x03cf:
            f7.M.h(r6)
            r10 = 3
            r12 = 255(0xff, double:1.26E-321)
            r15 = r9
            long r8 = U7.d.a(r10, r12)
            r21 = r10
            r10 = 4294967296(0x100000000, double:2.121995791E-314)
            U7.d.a(r8, r10)
            int r8 = r7.c()
            r9 = -1
            if (r8 >= r3) goto L_0x03ef
        L_0x03ed:
            r11 = r9
            goto L_0x0419
        L_0x03ef:
            long r23 = r7.j(r3)
            int r8 = (r23 > r21 ? 1 : (r23 == r21 ? 0 : -1))
            if (r8 != 0) goto L_0x0417
            int r8 = r7.c()
            if (r8 >= r5) goto L_0x03fe
            goto L_0x03ed
        L_0x03fe:
            long r21 = r7.j(r5)
            long r23 = r23 + r21
            int r8 = (r21 > r12 ? 1 : (r21 == r12 ? 0 : -1))
            if (r8 != 0) goto L_0x0417
            int r8 = r7.c()
            r11 = 32
            if (r8 >= r11) goto L_0x0411
            goto L_0x03ed
        L_0x0411:
            long r11 = r7.j(r11)
            long r23 = r11 + r23
        L_0x0417:
            r11 = r23
        L_0x0419:
            r15.f31042b = r11
            int r8 = (r11 > r9 ? 1 : (r11 == r9 ? 0 : -1))
            if (r8 != 0) goto L_0x0420
            goto L_0x03bb
        L_0x0420:
            r8 = 16
            int r8 = (r11 > r8 ? 1 : (r11 == r8 ? 0 : -1))
            if (r8 > 0) goto L_0x049a
            r8 = 0
            int r8 = (r11 > r8 ? 1 : (r11 == r8 ? 0 : -1))
            if (r8 != 0) goto L_0x0450
            int r8 = r15.f31041a
            r9 = 1
            if (r8 == r9) goto L_0x0448
            if (r8 == r3) goto L_0x0440
            r9 = 17
            if (r8 == r9) goto L_0x0438
            goto L_0x0450
        L_0x0438:
            java.lang.String r1 = "AudioTruncation packet with invalid packet label 0"
            r2 = 0
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x0440:
            r2 = 0
            java.lang.String r1 = "Mpegh3daFrame packet with invalid packet label 0"
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x0448:
            r2 = 0
            java.lang.String r1 = "Mpegh3daConfig packet with invalid packet label 0"
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        L_0x0450:
            r8 = 11
            r6 = 24
            int r6 = y3.s.a(r7, r8, r6, r6)
            r15.f31043c = r6
            r8 = -1
            if (r6 == r8) goto L_0x03bb
            r6 = 1
        L_0x045e:
            if (r6 == 0) goto L_0x046c
            r7 = 0
            r0.f31033n = r7
            int r8 = r0.f31034o
            int r9 = r15.f31043c
            int r9 = r9 + r2
            int r9 = r9 + r8
            r0.f31034o = r9
            goto L_0x046d
        L_0x046c:
            r7 = 0
        L_0x046d:
            if (r6 == 0) goto L_0x0488
            r4.G(r7)
            R2.H r2 = r0.f31025f
            int r6 = r4.f25887c
            r2.e(r6, r4)
            r4.D(r3)
            int r2 = r15.f31043c
            r14.D(r2)
            r14 = 1
            r0.f31032m = r14
            r0.f31023d = r3
            goto L_0x037d
        L_0x0488:
            r14 = 1
            int r2 = r4.f25887c
            r6 = 15
            if (r2 >= r6) goto L_0x037d
            int r2 = r2 + r14
            r4.F(r2)
            r7 = 0
            r0.f31032m = r7
        L_0x0496:
            r2 = 4
        L_0x0497:
            r6 = 1
            goto L_0x000e
        L_0x049a:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Contains sub-stream with an invalid packet label "
            r1.<init>(r2)
            long r2 = r15.f31042b
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x04af:
            r7 = 0
            r0.f31032m = r7
            goto L_0x0496
        L_0x04b3:
            int r2 = r0.f31030k
            r4 = r2 & 2
            if (r4 != 0) goto L_0x04c2
            int r2 = r1.f25887c
            r1.G(r2)
            r25 = 4
        L_0x04c0:
            r15 = 0
            goto L_0x04ee
        L_0x04c2:
            r25 = 4
            r2 = r2 & 4
            if (r2 != 0) goto L_0x04f1
        L_0x04c8:
            int r2 = r1.a()
            if (r2 <= 0) goto L_0x04c0
            int r2 = r0.f31031l
            int r2 = r2 << r5
            r0.f31031l = r2
            int r4 = r1.u()
            r2 = r2 | r4
            r0.f31031l = r2
            r4 = 16777215(0xffffff, float:2.3509886E-38)
            r2 = r2 & r4
            r4 = 12583333(0xc001a5, float:1.7633005E-38)
            if (r2 != r4) goto L_0x04c8
            int r2 = r1.f25886b
            int r2 = r2 - r8
            r1.G(r2)
            r15 = 0
            r0.f31031l = r15
        L_0x04ec:
            r14 = 1
            goto L_0x04f3
        L_0x04ee:
            r2 = r25
            goto L_0x0497
        L_0x04f1:
            r15 = 0
            goto L_0x04ec
        L_0x04f3:
            r0.f31023d = r14
            r6 = r14
            r2 = r25
            goto L_0x000e
        L_0x04fa:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: y3.r.c(o2.t):void");
    }

    public final void d(p pVar, F.c cVar) {
        cVar.a();
        cVar.b();
        this.f31024e = cVar.f30757e;
        cVar.b();
        this.f31025f = pVar.k(cVar.f30756d, 1);
    }

    public final void f(int i10, long j10) {
        this.f31030k = i10;
        if (!this.f31029j && (this.f31034o != 0 || !this.f31032m)) {
            this.f31028i = true;
        }
        if (j10 == -9223372036854775807L) {
            return;
        }
        if (this.f31028i) {
            this.f31027h = (double) j10;
        } else {
            this.f31026g = (double) j10;
        }
    }

    public final void e(boolean z10) {
    }
}
