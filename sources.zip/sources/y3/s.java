package y3;

import U1.c;
import f7.M;

public final class s {

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public int f31041a;

        /* renamed from: b  reason: collision with root package name */
        public long f31042b;

        /* renamed from: c  reason: collision with root package name */
        public int f31043c;
    }

    public static int a(c cVar, int i10, int i11, int i12) {
        boolean z10;
        if (Math.max(Math.max(i10, i11), i12) <= 31) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.h(z10);
        int i13 = (1 << i10) - 1;
        int i14 = (1 << i11) - 1;
        U7.c.a(U7.c.a(i13, i14), 1 << i12);
        if (cVar.c() < i10) {
            return -1;
        }
        int h10 = cVar.h(i10);
        if (h10 == i13) {
            if (cVar.c() < i11) {
                return -1;
            }
            int h11 = cVar.h(i11);
            h10 += h11;
            if (h11 == i14) {
                if (cVar.c() < i12) {
                    return -1;
                }
                return cVar.h(i12) + h10;
            }
        }
        return h10;
    }

    public static void b(c cVar) {
        cVar.p(3);
        cVar.p(8);
        boolean g6 = cVar.g();
        boolean g10 = cVar.g();
        if (g6) {
            cVar.p(5);
        }
        if (g10) {
            cVar.p(6);
        }
    }

    public static void c(c cVar) {
        int i10;
        int i11;
        int h10 = cVar.h(2);
        int i12 = 6;
        if (h10 == 0) {
            cVar.p(6);
            return;
        }
        int i13 = 5;
        int a10 = a(cVar, 5, 8, 16) + 1;
        if (h10 == 1) {
            cVar.p(a10 * 7);
        } else if (h10 == 2) {
            boolean g6 = cVar.g();
            if (g6) {
                i10 = 1;
            } else {
                i10 = 5;
            }
            if (g6) {
                i13 = 7;
            }
            if (g6) {
                i12 = 8;
            }
            int i14 = 0;
            while (i14 < a10) {
                if (cVar.g()) {
                    cVar.p(7);
                    i11 = 0;
                } else {
                    if (cVar.h(2) == 3 && cVar.h(i13) * i10 != 0) {
                        cVar.o();
                    }
                    i11 = cVar.h(i12) * i10;
                    if (!(i11 == 0 || i11 == 180)) {
                        cVar.o();
                    }
                    cVar.o();
                }
                if (!(i11 == 0 || i11 == 180 || !cVar.g())) {
                    i14++;
                }
                i14++;
            }
        }
    }
}
