package y3;

import f7.M;
import java.util.Arrays;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    public final int f31044a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f31045b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f31046c;

    /* renamed from: d  reason: collision with root package name */
    public byte[] f31047d;

    /* renamed from: e  reason: collision with root package name */
    public int f31048e;

    public t(int i10) {
        this.f31044a = i10;
        byte[] bArr = new byte[131];
        this.f31047d = bArr;
        bArr[2] = 1;
    }

    public final void a(int i10, byte[] bArr, int i11) {
        if (this.f31045b) {
            int i12 = i11 - i10;
            byte[] bArr2 = this.f31047d;
            int length = bArr2.length;
            int i13 = this.f31048e;
            if (length < i13 + i12) {
                this.f31047d = Arrays.copyOf(bArr2, (i13 + i12) * 2);
            }
            System.arraycopy(bArr, i10, this.f31047d, this.f31048e, i12);
            this.f31048e += i12;
        }
    }

    public final boolean b(int i10) {
        if (!this.f31045b) {
            return false;
        }
        this.f31048e -= i10;
        this.f31045b = false;
        this.f31046c = true;
        return true;
    }

    public final void c() {
        this.f31045b = false;
        this.f31046c = false;
    }

    public final void d(int i10) {
        boolean z10 = true;
        M.m(!this.f31045b);
        if (i10 != this.f31044a) {
            z10 = false;
        }
        this.f31045b = z10;
        if (z10) {
            this.f31048e = 3;
            this.f31046c = false;
        }
    }
}
