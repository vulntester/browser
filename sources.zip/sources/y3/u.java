package y3;

import R2.H;
import R2.p;
import f7.M;
import l2.n;
import o2.C2756B;
import o2.t;
import o2.y;
import y3.F;

public final class u implements z {

    /* renamed from: a  reason: collision with root package name */
    public n f31049a;

    /* renamed from: b  reason: collision with root package name */
    public y f31050b;

    /* renamed from: c  reason: collision with root package name */
    public H f31051c;

    public u(String str) {
        n.a aVar = new n.a();
        aVar.f24327l = l2.u.p("video/mp2t");
        aVar.f24328m = l2.u.p(str);
        this.f31049a = new n(aVar);
    }

    public final void a(y yVar, p pVar, F.c cVar) {
        this.f31050b = yVar;
        cVar.a();
        cVar.b();
        H k10 = pVar.k(cVar.f30756d, 5);
        this.f31051c = k10;
        k10.d(this.f31049a);
    }

    public final void c(t tVar) {
        long d10;
        long j10;
        M.n(this.f31050b);
        int i10 = C2756B.f25811a;
        y yVar = this.f31050b;
        synchronized (yVar) {
            try {
                long j11 = yVar.f25900c;
                if (j11 != -9223372036854775807L) {
                    d10 = j11 + yVar.f25899b;
                } else {
                    d10 = yVar.d();
                }
                j10 = d10;
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        long e10 = this.f31050b.e();
        if (j10 != -9223372036854775807L && e10 != -9223372036854775807L) {
            n nVar = this.f31049a;
            if (e10 != nVar.f24296s) {
                n.a a10 = nVar.a();
                a10.f24333r = e10;
                n nVar2 = new n(a10);
                this.f31049a = nVar2;
                this.f31051c.d(nVar2);
            }
            int a11 = tVar.a();
            this.f31051c.e(a11, tVar);
            this.f31051c.b(j10, 1, a11, 0, (H.a) null);
        }
    }
}
