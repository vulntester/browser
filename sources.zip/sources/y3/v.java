package y3;

import A6.u;
import R2.p;
import U1.c;
import f7.M;
import o2.n;
import o2.t;
import o2.y;
import y3.F;

public final class v implements F {

    /* renamed from: a  reason: collision with root package name */
    public final j f31052a;

    /* renamed from: b  reason: collision with root package name */
    public final c f31053b = new c(new byte[10], 10);

    /* renamed from: c  reason: collision with root package name */
    public int f31054c = 0;

    /* renamed from: d  reason: collision with root package name */
    public int f31055d;

    /* renamed from: e  reason: collision with root package name */
    public y f31056e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f31057f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f31058g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f31059h;

    /* renamed from: i  reason: collision with root package name */
    public int f31060i;

    /* renamed from: j  reason: collision with root package name */
    public int f31061j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f31062k;

    /* renamed from: l  reason: collision with root package name */
    public long f31063l;

    public v(j jVar) {
        this.f31052a = jVar;
    }

    public final void a(y yVar, p pVar, F.c cVar) {
        this.f31056e = yVar;
        this.f31052a.d(pVar, cVar);
    }

    public final void b() {
        this.f31054c = 0;
        this.f31055d = 0;
        this.f31059h = false;
        this.f31052a.b();
    }

    public final void c(int i10, t tVar) {
        int i11;
        int i12;
        int i13;
        boolean z10;
        t tVar2 = tVar;
        M.n(this.f31056e);
        int i14 = i10 & 1;
        j jVar = this.f31052a;
        int i15 = -1;
        int i16 = 2;
        if (i14 != 0) {
            int i17 = this.f31054c;
            if (!(i17 == 0 || i17 == 1)) {
                if (i17 == 2) {
                    n.f("PesReader", "Unexpected start indicator reading extended header");
                } else if (i17 == 3) {
                    if (this.f31061j != -1) {
                        n.f("PesReader", "Unexpected start indicator: expected " + this.f31061j + " more bytes");
                    }
                    if (tVar2.f25887c == 0) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                    jVar.e(z10);
                } else {
                    throw new IllegalStateException();
                }
            }
            this.f31054c = 1;
            this.f31055d = 0;
        }
        int i18 = i10;
        while (tVar2.a() > 0) {
            int i19 = this.f31054c;
            if (i19 != 0) {
                c cVar = this.f31053b;
                if (i19 != 1) {
                    if (i19 == i16) {
                        if (d(tVar2, (byte[]) cVar.f10461d, Math.min(10, this.f31060i)) && d(tVar2, (byte[]) null, this.f31060i)) {
                            cVar.n(0);
                            this.f31063l = -9223372036854775807L;
                            if (this.f31057f) {
                                cVar.p(4);
                                cVar.p(1);
                                long h10 = (long) (cVar.h(15) << 15);
                                cVar.p(1);
                                long h11 = h10 | (((long) cVar.h(3)) << 30) | ((long) cVar.h(15));
                                cVar.p(1);
                                if (!this.f31059h && this.f31058g) {
                                    cVar.p(4);
                                    cVar.p(1);
                                    cVar.p(1);
                                    cVar.p(1);
                                    this.f31056e.b((((long) cVar.h(3)) << 30) | ((long) (cVar.h(15) << 15)) | ((long) cVar.h(15)));
                                    this.f31059h = true;
                                }
                                this.f31063l = this.f31056e.b(h11);
                            }
                            if (this.f31062k) {
                                i12 = 4;
                            } else {
                                i12 = 0;
                            }
                            i18 |= i12;
                            jVar.f(i18, this.f31063l);
                            this.f31054c = 3;
                            this.f31055d = 0;
                        }
                    } else if (i19 == 3) {
                        int a10 = tVar2.a();
                        int i20 = this.f31061j;
                        if (i20 == i15) {
                            i13 = 0;
                        } else {
                            i13 = a10 - i20;
                        }
                        if (i13 > 0) {
                            a10 -= i13;
                            tVar2.F(tVar2.f25886b + a10);
                        }
                        jVar.c(tVar2);
                        int i21 = this.f31061j;
                        if (i21 != i15) {
                            int i22 = i21 - a10;
                            this.f31061j = i22;
                            if (i22 == 0) {
                                jVar.e(false);
                                this.f31054c = 1;
                                this.f31055d = 0;
                            }
                        }
                    } else {
                        throw new IllegalStateException();
                    }
                } else if (d(tVar2, (byte[]) cVar.f10461d, 9)) {
                    if (e()) {
                        i11 = 2;
                    } else {
                        i11 = 0;
                    }
                    this.f31054c = i11;
                    this.f31055d = 0;
                }
            } else {
                tVar2.H(tVar2.a());
            }
            i15 = -1;
            i16 = 2;
        }
    }

    public final boolean d(t tVar, byte[] bArr, int i10) {
        int min = Math.min(tVar.a(), i10 - this.f31055d);
        if (min <= 0) {
            return true;
        }
        if (bArr == null) {
            tVar.H(min);
        } else {
            tVar.f(this.f31055d, bArr, min);
        }
        int i11 = this.f31055d + min;
        this.f31055d = i11;
        if (i11 == i10) {
            return true;
        }
        return false;
    }

    public final boolean e() {
        c cVar = this.f31053b;
        cVar.n(0);
        int h10 = cVar.h(24);
        if (h10 != 1) {
            u.r(h10, "Unexpected start code prefix: ", "PesReader");
            this.f31061j = -1;
            return false;
        }
        cVar.p(8);
        int h11 = cVar.h(16);
        cVar.p(5);
        this.f31062k = cVar.g();
        cVar.p(2);
        this.f31057f = cVar.g();
        this.f31058g = cVar.g();
        cVar.p(6);
        int h12 = cVar.h(8);
        this.f31060i = h12;
        if (h11 == 0) {
            this.f31061j = -1;
        } else {
            int i10 = (h11 - 3) - h12;
            this.f31061j = i10;
            if (i10 < 0) {
                n.f("PesReader", "Found negative packet payload size: " + this.f31061j);
                this.f31061j = -1;
            }
        }
        return true;
    }
}
