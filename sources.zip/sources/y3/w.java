package y3;

import R2.C1009e;
import R2.C1013i;
import o2.C2756B;
import o2.t;
import o2.y;

public final class w extends C1009e {

    public static final class a implements C1009e.f {

        /* renamed from: a  reason: collision with root package name */
        public final y f31064a;

        /* renamed from: b  reason: collision with root package name */
        public final t f31065b = new t();

        public a(y yVar) {
            this.f31064a = yVar;
        }

        public final C1009e.C0081e a(C1013i iVar, long j10) {
            int d10;
            C1013i iVar2 = iVar;
            long j11 = iVar2.f8167E;
            int min = (int) Math.min(20000, iVar2.f8173z - j11);
            t tVar = this.f31065b;
            tVar.D(min);
            iVar2.l(tVar.f25885a, 0, min, false);
            int i10 = -1;
            int i11 = -1;
            long j12 = -9223372036854775807L;
            while (tVar.a() >= 4) {
                if (w.d(tVar.f25886b, tVar.f25885a) != 442) {
                    tVar.H(1);
                } else {
                    tVar.H(4);
                    long c10 = x.c(tVar);
                    if (c10 != -9223372036854775807L) {
                        long b10 = this.f31064a.b(c10);
                        if (b10 <= j10) {
                            long j13 = b10;
                            if (j13 + 100000 > j10) {
                                return new C1009e.C0081e(-9223372036854775807L, j11 + ((long) tVar.f25886b), 0);
                            }
                            j12 = j13;
                            i11 = tVar.f25886b;
                        } else if (j12 == -9223372036854775807L) {
                            return new C1009e.C0081e(b10, j11, -1);
                        } else {
                            return new C1009e.C0081e(-9223372036854775807L, j11 + ((long) i11), 0);
                        }
                    }
                    int i12 = tVar.f25887c;
                    if (tVar.a() >= 10) {
                        tVar.H(9);
                        int u7 = tVar.u() & 7;
                        if (tVar.a() >= u7) {
                            tVar.H(u7);
                            if (tVar.a() >= 4) {
                                if (w.d(tVar.f25886b, tVar.f25885a) == 443) {
                                    tVar.H(4);
                                    int A10 = tVar.A();
                                    if (tVar.a() < A10) {
                                        tVar.G(i12);
                                    } else {
                                        tVar.H(A10);
                                    }
                                }
                                while (true) {
                                    if (tVar.a() < 4 || (d10 = w.d(tVar.f25886b, tVar.f25885a)) == 442 || d10 == 441 || (d10 >>> 8) != 1) {
                                        break;
                                    }
                                    tVar.H(4);
                                    if (tVar.a() < 2) {
                                        tVar.G(i12);
                                        break;
                                    }
                                    tVar.G(Math.min(tVar.f25887c, tVar.f25886b + tVar.A()));
                                }
                            } else {
                                tVar.G(i12);
                            }
                        } else {
                            tVar.G(i12);
                        }
                    } else {
                        tVar.G(i12);
                    }
                    i10 = tVar.f25886b;
                }
            }
            if (j12 != -9223372036854775807L) {
                return new C1009e.C0081e(j12, j11 + ((long) i10), -2);
            }
            return C1009e.C0081e.f8150d;
        }

        public final void b() {
            byte[] bArr = C2756B.f25813c;
            t tVar = this.f31065b;
            tVar.getClass();
            tVar.E(bArr.length, bArr);
        }
    }

    public static int d(int i10, byte[] bArr) {
        return (bArr[i10 + 3] & 255) | ((bArr[i10] & 255) << 24) | ((bArr[i10 + 1] & 255) << 16) | ((bArr[i10 + 2] & 255) << 8);
    }
}
