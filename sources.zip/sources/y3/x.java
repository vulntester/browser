package y3;

import R2.C1013i;
import o2.C2756B;
import o2.t;
import o2.y;

public final class x {

    /* renamed from: a  reason: collision with root package name */
    public final y f31066a = new y(0);

    /* renamed from: b  reason: collision with root package name */
    public final t f31067b = new t();

    /* renamed from: c  reason: collision with root package name */
    public boolean f31068c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f31069d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f31070e;

    /* renamed from: f  reason: collision with root package name */
    public long f31071f = -9223372036854775807L;

    /* renamed from: g  reason: collision with root package name */
    public long f31072g = -9223372036854775807L;

    /* renamed from: h  reason: collision with root package name */
    public long f31073h = -9223372036854775807L;

    public static int b(int i10, byte[] bArr) {
        return (bArr[i10 + 3] & 255) | ((bArr[i10] & 255) << 24) | ((bArr[i10 + 1] & 255) << 16) | ((bArr[i10 + 2] & 255) << 8);
    }

    public static long c(t tVar) {
        t tVar2 = tVar;
        int i10 = tVar2.f25886b;
        if (tVar2.a() < 9) {
            return -9223372036854775807L;
        }
        byte[] bArr = new byte[9];
        tVar2.f(0, bArr, 9);
        tVar2.G(i10);
        byte b10 = bArr[0];
        if ((b10 & 196) == 68) {
            byte b11 = bArr[2];
            if ((b11 & 4) == 4) {
                byte b12 = bArr[4];
                if ((b12 & 4) == 4 && (bArr[5] & 1) == 1 && (bArr[8] & 3) == 3) {
                    long j10 = (long) b10;
                    long j11 = (long) b11;
                    return ((j11 & 3) << 13) | ((j10 & 3) << 28) | (((56 & j10) >> 3) << 30) | ((((long) bArr[1]) & 255) << 20) | (((j11 & 248) >> 3) << 15) | ((((long) bArr[3]) & 255) << 5) | ((((long) b12) & 248) >> 3);
                }
            }
        }
        return -9223372036854775807L;
    }

    public final void a(C1013i iVar) {
        byte[] bArr = C2756B.f25813c;
        t tVar = this.f31067b;
        tVar.getClass();
        tVar.E(bArr.length, bArr);
        this.f31068c = true;
        iVar.f8169G = 0;
    }
}
