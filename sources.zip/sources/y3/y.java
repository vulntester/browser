package y3;

import R2.B;
import R2.C;
import R2.C1009e;
import R2.C1013i;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import U1.c;
import android.util.SparseArray;
import f7.M;
import io.ktor.client.utils.CIOKt;
import io.netty.handler.codec.http2.Http2CodecUtil;
import java.util.List;
import o2.t;
import y3.F;
import y3.w;

public final class y implements n {

    /* renamed from: a  reason: collision with root package name */
    public final o2.y f31074a = new o2.y(0);

    /* renamed from: b  reason: collision with root package name */
    public final SparseArray<a> f31075b = new SparseArray<>();

    /* renamed from: c  reason: collision with root package name */
    public final t f31076c = new t(4096);

    /* renamed from: d  reason: collision with root package name */
    public final x f31077d = new x();

    /* renamed from: e  reason: collision with root package name */
    public boolean f31078e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f31079f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f31080g;

    /* renamed from: h  reason: collision with root package name */
    public long f31081h;

    /* renamed from: i  reason: collision with root package name */
    public w f31082i;

    /* renamed from: j  reason: collision with root package name */
    public p f31083j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f31084k;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final j f31085a;

        /* renamed from: b  reason: collision with root package name */
        public final o2.y f31086b;

        /* renamed from: c  reason: collision with root package name */
        public final c f31087c = new c(new byte[64], 64);

        /* renamed from: d  reason: collision with root package name */
        public boolean f31088d;

        /* renamed from: e  reason: collision with root package name */
        public boolean f31089e;

        /* renamed from: f  reason: collision with root package name */
        public boolean f31090f;

        /* renamed from: g  reason: collision with root package name */
        public long f31091g;

        public a(j jVar, o2.y yVar) {
            this.f31085a = jVar;
            this.f31086b = yVar;
        }
    }

    public final void a(long j10, long j11) {
        boolean z10;
        o2.y yVar = this.f31074a;
        boolean z11 = true;
        if (yVar.e() == -9223372036854775807L) {
            z10 = true;
        } else {
            z10 = false;
        }
        if (!z10) {
            long d10 = yVar.d();
            if (d10 == -9223372036854775807L || d10 == 0 || d10 == j11) {
                z11 = false;
            }
            z10 = z11;
        }
        if (z10) {
            yVar.g(j11);
        }
        w wVar = this.f31082i;
        if (wVar != null) {
            wVar.c(j11);
        }
        int i10 = 0;
        while (true) {
            SparseArray<a> sparseArray = this.f31075b;
            if (i10 < sparseArray.size()) {
                a valueAt = sparseArray.valueAt(i10);
                valueAt.f31090f = false;
                valueAt.f31085a.b();
                i10++;
            } else {
                return;
            }
        }
    }

    public final n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f31083j = pVar;
    }

    public final boolean g(o oVar) {
        byte[] bArr = new byte[14];
        C1013i iVar = (C1013i) oVar;
        iVar.l(bArr, 0, 14, false);
        if (442 == (((bArr[0] & 255) << 24) | ((bArr[1] & 255) << 16) | ((bArr[2] & 255) << 8) | (bArr[3] & 255)) && (bArr[4] & 196) == 68 && (bArr[6] & 4) == 4 && (bArr[8] & 4) == 4 && (bArr[9] & 1) == 1 && (bArr[12] & 3) == 3) {
            iVar.b(bArr[13] & 7, false);
            iVar.l(bArr, 0, 3, false);
            if (1 == (((bArr[0] & 255) << 16) | ((bArr[1] & 255) << 8) | (bArr[2] & 255))) {
                return true;
            }
        }
        return false;
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    /* JADX WARNING: type inference failed for: r3v14, types: [R2.e, y3.w] */
    /* JADX WARNING: type inference failed for: r4v38, types: [R2.e$d, java.lang.Object] */
    public final int i(o oVar, B b10) {
        int i10;
        boolean z10;
        long j10;
        t tVar;
        long j11;
        j jVar;
        B b11 = b10;
        M.n(this.f31083j);
        long j12 = ((C1013i) oVar).f8173z;
        int i11 = (j12 > -1 ? 1 : (j12 == -1 ? 0 : -1));
        long j13 = -9223372036854775807L;
        x xVar = this.f31077d;
        if (i11 == 0 || xVar.f31068c) {
            if (!this.f31084k) {
                this.f31084k = true;
                long j14 = xVar.f31073h;
                if (j14 != -9223372036854775807L) {
                    i10 = i11;
                    z10 = false;
                    ? eVar = new C1009e(new Object(), new w.a(xVar.f31066a), j14, j14 + 1, 0, j12, 188, CIOKt.DEFAULT_HTTP_POOL_SIZE);
                    this.f31082i = eVar;
                    this.f31083j.a(eVar.f8132a);
                } else {
                    i10 = i11;
                    z10 = false;
                    this.f31083j.a(new C.b(j14));
                }
            } else {
                i10 = i11;
                z10 = false;
            }
            w wVar = this.f31082i;
            if (wVar != null && wVar.f8134c != null) {
                return wVar.a((C1013i) oVar, b11);
            }
            C1013i iVar = (C1013i) oVar;
            iVar.f8169G = z10 ? 1 : 0;
            if (i10 != 0) {
                j10 = j12 - iVar.m();
            } else {
                j10 = -1;
            }
            if (j10 != -1 && j10 < 4) {
                return -1;
            }
            t tVar2 = this.f31076c;
            if (!iVar.l(tVar2.f25885a, z10, 4, true)) {
                return -1;
            }
            tVar2.G(z10);
            int h10 = tVar2.h();
            if (h10 == 441) {
                return -1;
            }
            if (h10 == 442) {
                iVar.l(tVar2.f25885a, z10, 10, z10);
                tVar2.G(9);
                iVar.s((tVar2.u() & 7) + 14);
                return z10;
            } else if (h10 == 443) {
                iVar.l(tVar2.f25885a, z10, 2, z10);
                tVar2.G(z10);
                iVar.s(tVar2.A() + 6);
                return z10;
            } else if (((h10 & -256) >> 8) != 1) {
                iVar.s(1);
                return z10;
            } else {
                int i12 = h10 & 255;
                SparseArray<a> sparseArray = this.f31075b;
                a aVar = sparseArray.get(i12);
                if (!this.f31078e) {
                    if (aVar == null) {
                        if (i12 == 189) {
                            jVar = new C3484b("video/mp2p");
                            this.f31079f = true;
                            this.f31081h = iVar.f8167E;
                        } else if ((h10 & 224) == 192) {
                            jVar = new q((String) null, z10, "video/mp2p");
                            this.f31079f = true;
                            this.f31081h = iVar.f8167E;
                        } else if ((h10 & 240) == 224) {
                            jVar = new k((G) null, "video/mp2p");
                            this.f31080g = true;
                            this.f31081h = iVar.f8167E;
                        } else {
                            jVar = null;
                        }
                        if (jVar != null) {
                            jVar.d(this.f31083j, new F.c(i12, 256));
                            aVar = new a(jVar, this.f31074a);
                            sparseArray.put(i12, aVar);
                        }
                    }
                    if (!this.f31079f || !this.f31080g) {
                        j11 = 1048576;
                    } else {
                        j11 = this.f31081h + Http2CodecUtil.DEFAULT_HEADER_LIST_SIZE;
                    }
                    if (iVar.f8167E > j11) {
                        this.f31078e = true;
                        this.f31083j.b();
                    }
                }
                iVar.l(tVar2.f25885a, z10, 2, z10);
                tVar2.G(z10);
                int A10 = tVar2.A() + 6;
                if (aVar == null) {
                    iVar.s(A10);
                    return z10;
                }
                tVar2.D(A10);
                iVar.e(tVar2.f25885a, z10, A10, z10);
                tVar2.G(6);
                c cVar = aVar.f31087c;
                tVar2.f(z10, (byte[]) cVar.f10461d, 3);
                cVar.n(z10);
                cVar.p(8);
                aVar.f31088d = cVar.g();
                aVar.f31089e = cVar.g();
                cVar.p(6);
                tVar2.f(z10, (byte[]) cVar.f10461d, cVar.h(8));
                cVar.n(z10);
                aVar.f31091g = 0;
                if (aVar.f31088d) {
                    cVar.p(4);
                    cVar.p(1);
                    cVar.p(1);
                    long h11 = (((long) cVar.h(3)) << 30) | ((long) (cVar.h(15) << 15)) | ((long) cVar.h(15));
                    cVar.p(1);
                    boolean z11 = aVar.f31090f;
                    o2.y yVar = aVar.f31086b;
                    if (z11 || !aVar.f31089e) {
                        tVar = tVar2;
                    } else {
                        cVar.p(4);
                        cVar.p(1);
                        tVar = tVar2;
                        long h12 = (long) (cVar.h(15) << 15);
                        cVar.p(1);
                        cVar.p(1);
                        yVar.b(h12 | (((long) cVar.h(3)) << 30) | ((long) cVar.h(15)));
                        aVar.f31090f = true;
                    }
                    aVar.f31091g = yVar.b(h11);
                } else {
                    tVar = tVar2;
                }
                long j15 = aVar.f31091g;
                j jVar2 = aVar.f31085a;
                jVar2.f(4, j15);
                jVar2.c(tVar);
                jVar2.e(false);
                tVar.F(tVar.f25885a.length);
                return 0;
            }
        } else {
            boolean z12 = xVar.f31070e;
            t tVar3 = xVar.f31067b;
            if (!z12) {
                C1013i iVar2 = (C1013i) oVar;
                long j16 = iVar2.f8173z;
                int min = (int) Math.min(20000, j16);
                long j17 = j16 - ((long) min);
                if (iVar2.f8167E != j17) {
                    b11.f8054a = j17;
                    return 1;
                }
                tVar3.D(min);
                iVar2.f8169G = 0;
                iVar2.l(tVar3.f25885a, 0, min, false);
                int i13 = tVar3.f25886b;
                int i14 = tVar3.f25887c - 4;
                while (true) {
                    if (i14 < i13) {
                        break;
                    }
                    if (x.b(i14, tVar3.f25885a) == 442) {
                        tVar3.G(i14 + 4);
                        long c10 = x.c(tVar3);
                        if (c10 != -9223372036854775807L) {
                            j13 = c10;
                            break;
                        }
                    }
                    i14--;
                }
                xVar.f31072g = j13;
                xVar.f31070e = true;
                return 0;
            } else if (xVar.f31072g == -9223372036854775807L) {
                xVar.a((C1013i) oVar);
                return 0;
            } else if (!xVar.f31069d) {
                C1013i iVar3 = (C1013i) oVar;
                int min2 = (int) Math.min(20000, iVar3.f8173z);
                long j18 = (long) 0;
                if (iVar3.f8167E != j18) {
                    b11.f8054a = j18;
                    return 1;
                }
                tVar3.D(min2);
                iVar3.f8169G = 0;
                iVar3.l(tVar3.f25885a, 0, min2, false);
                int i15 = tVar3.f25886b;
                int i16 = tVar3.f25887c;
                while (true) {
                    if (i15 >= i16 - 3) {
                        break;
                    }
                    if (x.b(i15, tVar3.f25885a) == 442) {
                        tVar3.G(i15 + 4);
                        long c11 = x.c(tVar3);
                        if (c11 != -9223372036854775807L) {
                            j13 = c11;
                            break;
                        }
                    }
                    i15++;
                }
                xVar.f31071f = j13;
                xVar.f31069d = true;
                return 0;
            } else {
                long j19 = xVar.f31071f;
                if (j19 == -9223372036854775807L) {
                    xVar.a((C1013i) oVar);
                    return 0;
                }
                o2.y yVar2 = xVar.f31066a;
                xVar.f31073h = yVar2.c(xVar.f31072g) - yVar2.b(j19);
                xVar.a((C1013i) oVar);
                return 0;
            }
        }
    }

    public final void release() {
    }
}
