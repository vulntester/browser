package y3;

import R2.p;
import o2.t;
import o2.y;
import y3.F;

public interface z {
    void a(y yVar, p pVar, F.c cVar);

    void c(t tVar);
}
