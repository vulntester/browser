package y4;

import kotlin.jvm.internal.l;
import l4.C2640i;

/* renamed from: y4.a  reason: case insensitive filesystem */
public final class C3490a {

    /* renamed from: a  reason: collision with root package name */
    public static final String f31092a;

    static {
        String f10 = C2640i.f("ConstraintTrkngWrkr");
        l.e(f10, "tagWithPrefix(\"ConstraintTrkngWrkr\")");
        f31092a = f10;
    }
}
