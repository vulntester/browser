package y4;

import M.k;
import java.util.Iterator;
import java.util.List;
import k5.b;
import kotlin.jvm.internal.l;
import l4.C2640i;
import u4.C3209E;
import u4.C3218h;
import u4.C3219i;
import u4.C3225o;
import u4.v;
import ya.s;

/* renamed from: y4.b  reason: case insensitive filesystem */
public final class C3491b {

    /* renamed from: a  reason: collision with root package name */
    public static final String f31093a;

    static {
        String f10 = C2640i.f("DiagnosticsWrkr");
        l.e(f10, "tagWithPrefix(\"DiagnosticsWrkr\")");
        f31093a = f10;
    }

    public static final String a(C3225o oVar, C3209E e10, C3219i iVar, List list) {
        Integer num;
        StringBuilder sb2 = new StringBuilder("\n Id \t Class Name\t Job Id\t State\t Unique Name\t Tags\t");
        Iterator it = list.iterator();
        while (it.hasNext()) {
            v vVar = (v) it.next();
            C3218h a10 = iVar.a(b.j(vVar));
            if (a10 != null) {
                num = Integer.valueOf(a10.f28647c);
            } else {
                num = null;
            }
            String str = vVar.f28657a;
            String a02 = s.a0(oVar.c(str), ",", (String) null, (String) null, (Na.l) null, 62);
            String a03 = s.a0(e10.a(str), ",", (String) null, (String) null, (Na.l) null, 62);
            StringBuilder o10 = k.o("\n", str, "\t ");
            o10.append(vVar.f28659c);
            o10.append("\t ");
            o10.append(num);
            o10.append("\t ");
            o10.append(vVar.f28658b.name());
            o10.append("\t ");
            o10.append(a02);
            o10.append("\t ");
            o10.append(a03);
            o10.append(9);
            sb2.append(o10.toString());
        }
        String sb3 = sb2.toString();
        l.e(sb3, "StringBuilder().apply(builderAction).toString()");
        return sb3;
    }
}
