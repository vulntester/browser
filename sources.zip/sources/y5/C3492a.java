package y5;

import B5.a;
import C5.b;
import C5.j;
import android.graphics.drawable.Drawable;
import com.bumptech.glide.d;
import f5.e;
import f5.f;
import f5.g;
import i5.l;
import io.ktor.utils.io.ByteChannelKt;
import io.netty.handler.codec.http.HttpObjectDecoder;
import p5.C2906g;
import p5.C2911l;
import t.C3104a;
import y5.C3492a;

/* renamed from: y5.a  reason: case insensitive filesystem */
public abstract class C3492a<T extends C3492a<T>> implements Cloneable {

    /* renamed from: E  reason: collision with root package name */
    public Drawable f31094E;

    /* renamed from: F  reason: collision with root package name */
    public boolean f31095F = true;

    /* renamed from: G  reason: collision with root package name */
    public int f31096G = -1;

    /* renamed from: H  reason: collision with root package name */
    public int f31097H = -1;

    /* renamed from: I  reason: collision with root package name */
    public e f31098I = a.f884b;

    /* renamed from: J  reason: collision with root package name */
    public boolean f31099J;

    /* renamed from: K  reason: collision with root package name */
    public boolean f31100K = true;

    /* renamed from: L  reason: collision with root package name */
    public g f31101L = new g();

    /* renamed from: M  reason: collision with root package name */
    public b f31102M = new C3104a();

    /* renamed from: N  reason: collision with root package name */
    public Class<?> f31103N = Object.class;

    /* renamed from: O  reason: collision with root package name */
    public boolean f31104O;

    /* renamed from: P  reason: collision with root package name */
    public boolean f31105P;

    /* renamed from: Q  reason: collision with root package name */
    public boolean f31106Q = true;

    /* renamed from: R  reason: collision with root package name */
    public boolean f31107R;

    /* renamed from: f  reason: collision with root package name */
    public int f31108f;

    /* renamed from: i  reason: collision with root package name */
    public l f31109i = l.f23155c;

    /* renamed from: z  reason: collision with root package name */
    public d f31110z = d.f16875f;

    public static boolean e(int i10, int i11) {
        if ((i10 & i11) != 0) {
            return true;
        }
        return false;
    }

    public T a(C3492a<?> aVar) {
        if (this.f31105P) {
            return clone().a(aVar);
        }
        int i10 = aVar.f31108f;
        if (e(aVar.f31108f, ByteChannelKt.CHANNEL_MAX_SIZE)) {
            this.f31107R = aVar.f31107R;
        }
        if (e(aVar.f31108f, 4)) {
            this.f31109i = aVar.f31109i;
        }
        if (e(aVar.f31108f, 8)) {
            this.f31110z = aVar.f31110z;
        }
        if (e(aVar.f31108f, 16)) {
            this.f31108f &= -33;
        }
        if (e(aVar.f31108f, 32)) {
            this.f31108f &= -17;
        }
        if (e(aVar.f31108f, 64)) {
            this.f31094E = aVar.f31094E;
            this.f31108f &= -129;
        }
        if (e(aVar.f31108f, HttpObjectDecoder.DEFAULT_INITIAL_BUFFER_SIZE)) {
            this.f31094E = null;
            this.f31108f &= -65;
        }
        if (e(aVar.f31108f, 256)) {
            this.f31095F = aVar.f31095F;
        }
        if (e(aVar.f31108f, 512)) {
            this.f31097H = aVar.f31097H;
            this.f31096G = aVar.f31096G;
        }
        if (e(aVar.f31108f, 1024)) {
            this.f31098I = aVar.f31098I;
        }
        if (e(aVar.f31108f, 4096)) {
            this.f31103N = aVar.f31103N;
        }
        if (e(aVar.f31108f, 8192)) {
            this.f31108f &= -16385;
        }
        if (e(aVar.f31108f, 16384)) {
            this.f31108f &= -8193;
        }
        if (e(aVar.f31108f, 65536)) {
            this.f31100K = aVar.f31100K;
        }
        if (e(aVar.f31108f, 131072)) {
            this.f31099J = aVar.f31099J;
        }
        if (e(aVar.f31108f, 2048)) {
            this.f31102M.putAll(aVar.f31102M);
            this.f31106Q = aVar.f31106Q;
        }
        if (!this.f31100K) {
            this.f31102M.clear();
            int i11 = this.f31108f;
            this.f31099J = false;
            this.f31108f = i11 & -133121;
            this.f31106Q = true;
        }
        this.f31108f |= aVar.f31108f;
        this.f31101L.f21256b.j(aVar.f31101L.f21256b);
        i();
        return this;
    }

    /* JADX WARNING: type inference failed for: r1v3, types: [t.a, C5.b] */
    /* renamed from: b */
    public T clone() {
        try {
            T t10 = (C3492a) super.clone();
            g gVar = new g();
            t10.f31101L = gVar;
            gVar.f21256b.j(this.f31101L.f21256b);
            ? aVar = new C3104a();
            t10.f31102M = aVar;
            aVar.putAll(this.f31102M);
            t10.f31104O = false;
            t10.f31105P = false;
            return t10;
        } catch (CloneNotSupportedException e10) {
            throw new RuntimeException(e10);
        }
    }

    public final T c(Class<?> cls) {
        if (this.f31105P) {
            return clone().c(cls);
        }
        this.f31103N = cls;
        this.f31108f |= 4096;
        i();
        return this;
    }

    public final T d(l lVar) {
        if (this.f31105P) {
            return clone().d(lVar);
        }
        V6.b.f(lVar, "Argument must not be null");
        this.f31109i = lVar;
        this.f31108f |= 4;
        i();
        return this;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C3492a)) {
            return false;
        }
        C3492a aVar = (C3492a) obj;
        aVar.getClass();
        if (Float.compare(1.0f, 1.0f) != 0) {
            return false;
        }
        char[] cArr = j.f1390a;
        if (!j.a(this.f31094E, aVar.f31094E) || this.f31095F != aVar.f31095F || this.f31096G != aVar.f31096G || this.f31097H != aVar.f31097H || this.f31099J != aVar.f31099J || this.f31100K != aVar.f31100K || !this.f31109i.equals(aVar.f31109i) || this.f31110z != aVar.f31110z || !this.f31101L.equals(aVar.f31101L) || !this.f31102M.equals(aVar.f31102M) || !this.f31103N.equals(aVar.f31103N) || !j.a(this.f31098I, aVar.f31098I)) {
            return false;
        }
        return true;
    }

    public final T f(int i10, int i11) {
        if (this.f31105P) {
            return clone().f(i10, i11);
        }
        this.f31097H = i10;
        this.f31096G = i11;
        this.f31108f |= 512;
        i();
        return this;
    }

    public final T g(Drawable drawable) {
        if (this.f31105P) {
            return clone().g(drawable);
        }
        this.f31094E = drawable;
        this.f31108f = (this.f31108f | 64) & -129;
        i();
        return this;
    }

    public final C3492a h() {
        d dVar = d.f16876i;
        if (this.f31105P) {
            return clone().h();
        }
        this.f31110z = dVar;
        this.f31108f |= 8;
        i();
        return this;
    }

    public final int hashCode() {
        char[] cArr = j.f1390a;
        return j.f(j.f(j.f(j.f(j.f(j.f(j.f(j.e(0, j.e(0, j.e(this.f31100K ? 1 : 0, j.e(this.f31099J ? 1 : 0, j.e(this.f31097H, j.e(this.f31096G, j.e(this.f31095F ? 1 : 0, j.f(j.e(0, j.f(j.e(0, j.f(j.e(0, j.e(Float.floatToIntBits(1.0f), 17)), (Object) null)), this.f31094E)), (Object) null)))))))), this.f31109i), this.f31110z), this.f31101L), this.f31102M), this.f31103N), this.f31098I), (Object) null);
    }

    public final void i() {
        if (this.f31104O) {
            throw new IllegalStateException("You cannot modify locked T, consider clone()");
        }
    }

    public final C3492a j(f fVar, C2906g gVar) {
        if (this.f31105P) {
            return clone().j(fVar, gVar);
        }
        V6.b.e(fVar);
        V6.b.e(gVar);
        this.f31101L.f21256b.put(fVar, gVar);
        i();
        return this;
    }

    public final C3492a k(B5.b bVar) {
        if (this.f31105P) {
            return clone().k(bVar);
        }
        this.f31098I = bVar;
        this.f31108f |= 1024;
        i();
        return this;
    }

    public final C3492a l() {
        if (this.f31105P) {
            return clone().l();
        }
        this.f31095F = false;
        this.f31108f |= 256;
        i();
        return this;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [f5.k, f5.k<android.graphics.Bitmap>] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final T m(f5.k<android.graphics.Bitmap> r3, boolean r4) {
        /*
            r2 = this;
            boolean r0 = r2.f31105P
            if (r0 == 0) goto L_0x000d
            y5.a r0 = r2.clone()
            y5.a r3 = r0.m(r3, r4)
            return r3
        L_0x000d:
            p5.j r0 = new p5.j
            r0.<init>(r3, r4)
            java.lang.Class<android.graphics.Bitmap> r1 = android.graphics.Bitmap.class
            r2.n(r1, r3, r4)
            java.lang.Class<android.graphics.drawable.Drawable> r1 = android.graphics.drawable.Drawable.class
            r2.n(r1, r0, r4)
            java.lang.Class<android.graphics.drawable.BitmapDrawable> r1 = android.graphics.drawable.BitmapDrawable.class
            r2.n(r1, r0, r4)
            t5.e r0 = new t5.e
            r0.<init>(r3)
            java.lang.Class<t5.c> r3 = t5.C3184c.class
            r2.n(r3, r0, r4)
            r2.i()
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: y5.C3492a.m(f5.k, boolean):y5.a");
    }

    /* JADX WARNING: type inference failed for: r2v0, types: [java.lang.Class<Y>, java.lang.Object, java.lang.Class] */
    /* JADX WARNING: type inference failed for: r3v0, types: [f5.k, java.lang.Object, f5.k<Y>] */
    /* JADX WARNING: Unknown variable types count: 2 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final <Y> T n(java.lang.Class<Y> r2, f5.k<Y> r3, boolean r4) {
        /*
            r1 = this;
            boolean r0 = r1.f31105P
            if (r0 == 0) goto L_0x000d
            y5.a r0 = r1.clone()
            y5.a r2 = r0.n(r2, r3, r4)
            return r2
        L_0x000d:
            V6.b.e(r3)
            C5.b r0 = r1.f31102M
            r0.put(r2, r3)
            int r2 = r1.f31108f
            r3 = 1
            r1.f31100K = r3
            r0 = 67584(0x10800, float:9.4705E-41)
            r0 = r0 | r2
            r1.f31108f = r0
            r0 = 0
            r1.f31106Q = r0
            if (r4 == 0) goto L_0x002d
            r4 = 198656(0x30800, float:2.78376E-40)
            r2 = r2 | r4
            r1.f31108f = r2
            r1.f31099J = r3
        L_0x002d:
            r1.i()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: y5.C3492a.n(java.lang.Class, f5.k, boolean):y5.a");
    }

    public final C3492a p(C2906g.e eVar, C2911l lVar) {
        if (this.f31105P) {
            return clone().p(eVar, lVar);
        }
        f<C2906g> fVar = C2906g.f26657d;
        V6.b.f(eVar, "Argument must not be null");
        j(fVar, eVar);
        return m(lVar, true);
    }

    public final C3492a q() {
        if (this.f31105P) {
            return clone().q();
        }
        this.f31107R = true;
        this.f31108f |= ByteChannelKt.CHANNEL_MAX_SIZE;
        i();
        return this;
    }
}
