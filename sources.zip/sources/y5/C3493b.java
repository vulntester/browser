package y5;

/* renamed from: y5.b  reason: case insensitive filesystem */
public interface C3493b {
    boolean b();

    void c();

    void clear();

    boolean d();

    boolean isRunning();

    void pause();
}
