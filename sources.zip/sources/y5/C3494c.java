package y5;

/* renamed from: y5.c  reason: case insensitive filesystem */
public interface C3494c<R> {
    boolean b();

    boolean c();
}
