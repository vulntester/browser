package y5;

import A5.a;
import C5.e;
import C5.j;
import D2.B;
import D5.d;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import com.bumptech.glide.c;
import com.bumptech.glide.f;
import f5.C2282a;
import i5.m;
import i5.q;
import i5.u;
import java.util.ArrayList;
import java.util.Iterator;
import z5.C3565c;
import z5.C3566d;

/* renamed from: y5.e  reason: case insensitive filesystem */
public final class C3496e<R> implements C3493b, C3565c {

    /* renamed from: z  reason: collision with root package name */
    public static final boolean f31111z = Log.isLoggable("Request", 2);

    /* renamed from: a  reason: collision with root package name */
    public final String f31112a;

    /* renamed from: b  reason: collision with root package name */
    public final d.a f31113b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f31114c;

    /* renamed from: d  reason: collision with root package name */
    public final c f31115d;

    /* renamed from: e  reason: collision with root package name */
    public final Object f31116e;

    /* renamed from: f  reason: collision with root package name */
    public final Class<R> f31117f;

    /* renamed from: g  reason: collision with root package name */
    public final f f31118g;

    /* renamed from: h  reason: collision with root package name */
    public final int f31119h;

    /* renamed from: i  reason: collision with root package name */
    public final int f31120i;

    /* renamed from: j  reason: collision with root package name */
    public final com.bumptech.glide.d f31121j;

    /* renamed from: k  reason: collision with root package name */
    public final C3566d<R> f31122k;

    /* renamed from: l  reason: collision with root package name */
    public final ArrayList f31123l;

    /* renamed from: m  reason: collision with root package name */
    public final a.C0003a f31124m;

    /* renamed from: n  reason: collision with root package name */
    public final e.a f31125n;

    /* renamed from: o  reason: collision with root package name */
    public u<R> f31126o;

    /* renamed from: p  reason: collision with root package name */
    public m.d f31127p;

    /* renamed from: q  reason: collision with root package name */
    public long f31128q;

    /* renamed from: r  reason: collision with root package name */
    public volatile m f31129r;

    /* renamed from: s  reason: collision with root package name */
    public a f31130s;

    /* renamed from: t  reason: collision with root package name */
    public Drawable f31131t;

    /* renamed from: u  reason: collision with root package name */
    public Drawable f31132u;

    /* renamed from: v  reason: collision with root package name */
    public Drawable f31133v;

    /* renamed from: w  reason: collision with root package name */
    public int f31134w;

    /* renamed from: x  reason: collision with root package name */
    public int f31135x;

    /* renamed from: y  reason: collision with root package name */
    public boolean f31136y;

    /* renamed from: y5.e$a */
    public enum a {
        ;

        /* access modifiers changed from: public */
        a() {
            throw null;
        }
    }

    /* JADX WARNING: type inference failed for: r0v2, types: [java.lang.Object, D5.d$a] */
    public C3496e(Context context, c cVar, Object obj, Object obj2, Class cls, f fVar, int i10, int i11, com.bumptech.glide.d dVar, C3566d dVar2, ArrayList arrayList, m mVar, e.a aVar) {
        String str;
        a.C0003a aVar2 = A5.a.f325a;
        if (f31111z) {
            str = String.valueOf(hashCode());
        } else {
            str = null;
        }
        this.f31112a = str;
        this.f31113b = new Object();
        this.f31114c = obj;
        this.f31115d = cVar;
        this.f31116e = obj2;
        this.f31117f = cls;
        this.f31118g = fVar;
        this.f31119h = i10;
        this.f31120i = i11;
        this.f31121j = dVar;
        this.f31122k = dVar2;
        this.f31123l = arrayList;
        this.f31129r = mVar;
        this.f31124m = aVar2;
        this.f31125n = aVar;
        this.f31130s = a.f31141f;
        cVar.getClass();
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v0, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v1, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v2, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v0, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v3, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v4, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v5, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v6, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v7, resolved type: y5.e} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v8, resolved type: y5.e} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(int r23, int r24) {
        /*
            r22 = this;
            r1 = r22
            r0 = r23
            r2 = r24
            java.lang.String r3 = "finished onSizeReady in "
            java.lang.String r4 = "finished setup for calling load in "
            java.lang.String r5 = "Got onSizeReady in "
            D5.d$a r6 = r1.f31113b
            r6.a()
            java.lang.Object r6 = r1.f31114c
            monitor-enter(r6)
            boolean r20 = f31111z     // Catch:{ all -> 0x002e }
            if (r20 == 0) goto L_0x0033
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ all -> 0x002e }
            r7.<init>(r5)     // Catch:{ all -> 0x002e }
            long r8 = r1.f31128q     // Catch:{ all -> 0x002e }
            double r8 = C5.f.a(r8)     // Catch:{ all -> 0x002e }
            r7.append(r8)     // Catch:{ all -> 0x002e }
            java.lang.String r5 = r7.toString()     // Catch:{ all -> 0x002e }
            r1.h(r5)     // Catch:{ all -> 0x002e }
            goto L_0x0033
        L_0x002e:
            r0 = move-exception
            r3 = r1
            r1 = r6
            goto L_0x00ff
        L_0x0033:
            y5.e$a r5 = r1.f31130s     // Catch:{ all -> 0x002e }
            y5.e$a r7 = y5.C3496e.a.f31143z     // Catch:{ all -> 0x002e }
            if (r5 == r7) goto L_0x003b
            monitor-exit(r6)     // Catch:{ all -> 0x002e }
            return
        L_0x003b:
            y5.e$a r5 = y5.C3496e.a.f31142i     // Catch:{ all -> 0x002e }
            r1.f31130s = r5     // Catch:{ all -> 0x002e }
            com.bumptech.glide.f r7 = r1.f31118g     // Catch:{ all -> 0x002e }
            r7.getClass()     // Catch:{ all -> 0x002e }
            r7 = 1065353216(0x3f800000, float:1.0)
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 != r8) goto L_0x004b
            goto L_0x0051
        L_0x004b:
            float r0 = (float) r0     // Catch:{ all -> 0x002e }
            float r0 = r0 * r7
            int r0 = java.lang.Math.round(r0)     // Catch:{ all -> 0x002e }
        L_0x0051:
            r1.f31134w = r0     // Catch:{ all -> 0x002e }
            if (r2 != r8) goto L_0x0057
            r0 = r2
            goto L_0x005d
        L_0x0057:
            float r0 = (float) r2     // Catch:{ all -> 0x002e }
            float r7 = r7 * r0
            int r0 = java.lang.Math.round(r7)     // Catch:{ all -> 0x002e }
        L_0x005d:
            r1.f31135x = r0     // Catch:{ all -> 0x002e }
            if (r20 == 0) goto L_0x0076
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ all -> 0x002e }
            r0.<init>(r4)     // Catch:{ all -> 0x002e }
            long r7 = r1.f31128q     // Catch:{ all -> 0x002e }
            double r7 = C5.f.a(r7)     // Catch:{ all -> 0x002e }
            r0.append(r7)     // Catch:{ all -> 0x002e }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x002e }
            r1.h(r0)     // Catch:{ all -> 0x002e }
        L_0x0076:
            i5.m r2 = r1.f31129r     // Catch:{ all -> 0x002e }
            r0 = r3
            com.bumptech.glide.c r3 = r1.f31115d     // Catch:{ all -> 0x002e }
            java.lang.Object r4 = r1.f31116e     // Catch:{ all -> 0x002e }
            com.bumptech.glide.f r7 = r1.f31118g     // Catch:{ all -> 0x002e }
            r8 = r5
            f5.e r5 = r7.f31098I     // Catch:{ all -> 0x002e }
            r9 = r6
            int r6 = r1.f31134w     // Catch:{ all -> 0x00fc }
            int r10 = r1.f31135x     // Catch:{ all -> 0x00fc }
            r11 = r8
            java.lang.Class<?> r8 = r7.f31103N     // Catch:{ all -> 0x00fc }
            r12 = r9
            java.lang.Class<R> r9 = r1.f31117f     // Catch:{ all -> 0x00f8 }
            r13 = r10
            com.bumptech.glide.d r10 = r1.f31121j     // Catch:{ all -> 0x00f8 }
            r14 = r11
            i5.l r11 = r7.f31109i     // Catch:{ all -> 0x00f8 }
            r15 = r12
            C5.b r12 = r7.f31102M     // Catch:{ all -> 0x00f4 }
            r16 = r13
            boolean r13 = r7.f31099J     // Catch:{ all -> 0x00f4 }
            r17 = r14
            boolean r14 = r7.f31106Q     // Catch:{ all -> 0x00f4 }
            r18 = r15
            f5.g r15 = r7.f31101L     // Catch:{ all -> 0x00ef }
            r23 = r0
            boolean r0 = r7.f31095F     // Catch:{ all -> 0x00ef }
            boolean r7 = r7.f31107R     // Catch:{ all -> 0x00ef }
            r19 = r0
            C5.e$a r0 = r1.f31125n     // Catch:{ all -> 0x00ef }
            r21 = r19
            r19 = r0
            r0 = r17
            r17 = r7
            r7 = r16
            r16 = r21
            r21 = r18
            r18 = r1
            r1 = r21
            i5.m$d r2 = r2.a(r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19)     // Catch:{ all -> 0x00eb }
            r3 = r18
            r3.f31127p = r2     // Catch:{ all -> 0x00ce }
            y5.e$a r2 = r3.f31130s     // Catch:{ all -> 0x00ce }
            if (r2 == r0) goto L_0x00d0
            r0 = 0
            r3.f31127p = r0     // Catch:{ all -> 0x00ce }
            goto L_0x00d0
        L_0x00ce:
            r0 = move-exception
            goto L_0x00ff
        L_0x00d0:
            if (r20 == 0) goto L_0x00e9
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ all -> 0x00ce }
            r2 = r23
            r0.<init>(r2)     // Catch:{ all -> 0x00ce }
            long r4 = r3.f31128q     // Catch:{ all -> 0x00ce }
            double r4 = C5.f.a(r4)     // Catch:{ all -> 0x00ce }
            r0.append(r4)     // Catch:{ all -> 0x00ce }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x00ce }
            r3.h(r0)     // Catch:{ all -> 0x00ce }
        L_0x00e9:
            monitor-exit(r1)     // Catch:{ all -> 0x00ce }
            return
        L_0x00eb:
            r0 = move-exception
            r3 = r18
            goto L_0x00ff
        L_0x00ef:
            r0 = move-exception
            r3 = r1
            r1 = r18
            goto L_0x00ff
        L_0x00f4:
            r0 = move-exception
            r3 = r1
            r1 = r15
            goto L_0x00ff
        L_0x00f8:
            r0 = move-exception
            r3 = r1
            r1 = r12
            goto L_0x00ff
        L_0x00fc:
            r0 = move-exception
            r3 = r1
            r1 = r9
        L_0x00ff:
            monitor-exit(r1)     // Catch:{ all -> 0x00ce }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: y5.C3496e.a(int, int):void");
    }

    public final boolean b() {
        boolean z10;
        synchronized (this.f31114c) {
            if (this.f31130s == a.f31139G) {
                z10 = true;
            } else {
                z10 = false;
            }
        }
        return z10;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00a5, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void c() {
        /*
            r6 = this;
            java.lang.String r0 = "finished run method in "
            java.lang.Object r1 = r6.f31114c
            monitor-enter(r1)
            boolean r2 = r6.f31136y     // Catch:{ all -> 0x002d }
            if (r2 != 0) goto L_0x00ae
            D5.d$a r2 = r6.f31113b     // Catch:{ all -> 0x002d }
            r2.a()     // Catch:{ all -> 0x002d }
            int r2 = C5.f.f1382b     // Catch:{ all -> 0x002d }
            long r2 = android.os.SystemClock.elapsedRealtimeNanos()     // Catch:{ all -> 0x002d }
            r6.f31128q = r2     // Catch:{ all -> 0x002d }
            java.lang.Object r2 = r6.f31116e     // Catch:{ all -> 0x002d }
            if (r2 != 0) goto L_0x004f
            int r0 = r6.f31119h     // Catch:{ all -> 0x002d }
            int r2 = r6.f31120i     // Catch:{ all -> 0x002d }
            boolean r0 = C5.j.g(r0, r2)     // Catch:{ all -> 0x002d }
            if (r0 == 0) goto L_0x0030
            int r0 = r6.f31119h     // Catch:{ all -> 0x002d }
            r6.f31134w = r0     // Catch:{ all -> 0x002d }
            int r0 = r6.f31120i     // Catch:{ all -> 0x002d }
            r6.f31135x = r0     // Catch:{ all -> 0x002d }
            goto L_0x0030
        L_0x002d:
            r0 = move-exception
            goto L_0x00b6
        L_0x0030:
            android.graphics.drawable.Drawable r0 = r6.f31133v     // Catch:{ all -> 0x002d }
            if (r0 != 0) goto L_0x003c
            com.bumptech.glide.f r0 = r6.f31118g     // Catch:{ all -> 0x002d }
            r0.getClass()     // Catch:{ all -> 0x002d }
            r0 = 0
            r6.f31133v = r0     // Catch:{ all -> 0x002d }
        L_0x003c:
            android.graphics.drawable.Drawable r0 = r6.f31133v     // Catch:{ all -> 0x002d }
            if (r0 != 0) goto L_0x0042
            r0 = 5
            goto L_0x0043
        L_0x0042:
            r0 = 3
        L_0x0043:
            i5.q r2 = new i5.q     // Catch:{ all -> 0x002d }
            java.lang.String r3 = "Received null model"
            r2.<init>(r3)     // Catch:{ all -> 0x002d }
            r6.i(r2, r0)     // Catch:{ all -> 0x002d }
            monitor-exit(r1)     // Catch:{ all -> 0x002d }
            return
        L_0x004f:
            y5.e$a r2 = r6.f31130s     // Catch:{ all -> 0x002d }
            y5.e$a r3 = y5.C3496e.a.f31142i     // Catch:{ all -> 0x002d }
            if (r2 == r3) goto L_0x00a6
            y5.e$a r4 = y5.C3496e.a.f31137E     // Catch:{ all -> 0x002d }
            if (r2 != r4) goto L_0x0062
            i5.u<R> r0 = r6.f31126o     // Catch:{ all -> 0x002d }
            f5.a r2 = f5.C2282a.f21237F     // Catch:{ all -> 0x002d }
            r6.j(r0, r2)     // Catch:{ all -> 0x002d }
            monitor-exit(r1)     // Catch:{ all -> 0x002d }
            return
        L_0x0062:
            y5.e$a r2 = y5.C3496e.a.f31143z     // Catch:{ all -> 0x002d }
            r6.f31130s = r2     // Catch:{ all -> 0x002d }
            int r4 = r6.f31119h     // Catch:{ all -> 0x002d }
            int r5 = r6.f31120i     // Catch:{ all -> 0x002d }
            boolean r4 = C5.j.g(r4, r5)     // Catch:{ all -> 0x002d }
            if (r4 == 0) goto L_0x0078
            int r4 = r6.f31119h     // Catch:{ all -> 0x002d }
            int r5 = r6.f31120i     // Catch:{ all -> 0x002d }
            r6.a(r4, r5)     // Catch:{ all -> 0x002d }
            goto L_0x007d
        L_0x0078:
            z5.d<R> r4 = r6.f31122k     // Catch:{ all -> 0x002d }
            r4.f(r6)     // Catch:{ all -> 0x002d }
        L_0x007d:
            y5.e$a r4 = r6.f31130s     // Catch:{ all -> 0x002d }
            if (r4 == r3) goto L_0x0083
            if (r4 != r2) goto L_0x008b
        L_0x0083:
            z5.d<R> r2 = r6.f31122k     // Catch:{ all -> 0x002d }
            r6.f()     // Catch:{ all -> 0x002d }
            r2.getClass()     // Catch:{ all -> 0x002d }
        L_0x008b:
            boolean r2 = f31111z     // Catch:{ all -> 0x002d }
            if (r2 == 0) goto L_0x00a4
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x002d }
            r2.<init>(r0)     // Catch:{ all -> 0x002d }
            long r3 = r6.f31128q     // Catch:{ all -> 0x002d }
            double r3 = C5.f.a(r3)     // Catch:{ all -> 0x002d }
            r2.append(r3)     // Catch:{ all -> 0x002d }
            java.lang.String r0 = r2.toString()     // Catch:{ all -> 0x002d }
            r6.h(r0)     // Catch:{ all -> 0x002d }
        L_0x00a4:
            monitor-exit(r1)     // Catch:{ all -> 0x002d }
            return
        L_0x00a6:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x002d }
            java.lang.String r2 = "Cannot restart a running request"
            r0.<init>(r2)     // Catch:{ all -> 0x002d }
            throw r0     // Catch:{ all -> 0x002d }
        L_0x00ae:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x002d }
            java.lang.String r2 = "You can't start or clear loads in RequestListener or Target callbacks. If you're trying to start a fallback request when a load fails, use RequestBuilder#error(RequestBuilder). Otherwise consider posting your into() or clear() calls to the main thread using a Handler instead."
            r0.<init>(r2)     // Catch:{ all -> 0x002d }
            throw r0     // Catch:{ all -> 0x002d }
        L_0x00b6:
            monitor-exit(r1)     // Catch:{ all -> 0x002d }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: y5.C3496e.c():void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x002e, code lost:
        if (r1 == null) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0030, code lost:
        r5.f31129r.getClass();
        i5.m.g(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void clear() {
        /*
            r5 = this;
            java.lang.Object r0 = r5.f31114c
            monitor-enter(r0)
            boolean r1 = r5.f31136y     // Catch:{ all -> 0x0014 }
            if (r1 != 0) goto L_0x0039
            D5.d$a r1 = r5.f31113b     // Catch:{ all -> 0x0014 }
            r1.a()     // Catch:{ all -> 0x0014 }
            y5.e$a r1 = r5.f31130s     // Catch:{ all -> 0x0014 }
            y5.e$a r2 = y5.C3496e.a.f31139G     // Catch:{ all -> 0x0014 }
            if (r1 != r2) goto L_0x0016
            monitor-exit(r0)     // Catch:{ all -> 0x0014 }
            return
        L_0x0014:
            r1 = move-exception
            goto L_0x0041
        L_0x0016:
            r5.e()     // Catch:{ all -> 0x0014 }
            i5.u<R> r1 = r5.f31126o     // Catch:{ all -> 0x0014 }
            r3 = 0
            if (r1 == 0) goto L_0x0021
            r5.f31126o = r3     // Catch:{ all -> 0x0014 }
            goto L_0x0022
        L_0x0021:
            r1 = r3
        L_0x0022:
            z5.d<R> r3 = r5.f31122k     // Catch:{ all -> 0x0014 }
            android.graphics.drawable.Drawable r4 = r5.f()     // Catch:{ all -> 0x0014 }
            r3.g(r4)     // Catch:{ all -> 0x0014 }
            r5.f31130s = r2     // Catch:{ all -> 0x0014 }
            monitor-exit(r0)     // Catch:{ all -> 0x0014 }
            if (r1 == 0) goto L_0x0038
            i5.m r0 = r5.f31129r
            r0.getClass()
            i5.m.g(r1)
        L_0x0038:
            return
        L_0x0039:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException     // Catch:{ all -> 0x0014 }
            java.lang.String r2 = "You can't start or clear loads in RequestListener or Target callbacks. If you're trying to start a fallback request when a load fails, use RequestBuilder#error(RequestBuilder). Otherwise consider posting your into() or clear() calls to the main thread using a Handler instead."
            r1.<init>(r2)     // Catch:{ all -> 0x0014 }
            throw r1     // Catch:{ all -> 0x0014 }
        L_0x0041:
            monitor-exit(r0)     // Catch:{ all -> 0x0014 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: y5.C3496e.clear():void");
    }

    public final boolean d() {
        boolean z10;
        synchronized (this.f31114c) {
            if (this.f31130s == a.f31137E) {
                z10 = true;
            } else {
                z10 = false;
            }
        }
        return z10;
    }

    public final void e() {
        if (!this.f31136y) {
            this.f31113b.a();
            this.f31122k.h(this);
            m.d dVar = this.f31127p;
            if (dVar != null) {
                synchronized (m.this) {
                    dVar.f23178a.j(dVar.f23179b);
                }
                this.f31127p = null;
                return;
            }
            return;
        }
        throw new IllegalStateException("You can't start or clear loads in RequestListener or Target callbacks. If you're trying to start a fallback request when a load fails, use RequestBuilder#error(RequestBuilder). Otherwise consider posting your into() or clear() calls to the main thread using a Handler instead.");
    }

    public final Drawable f() {
        if (this.f31132u == null) {
            this.f31132u = this.f31118g.f31094E;
        }
        return this.f31132u;
    }

    public final boolean g(C3493b bVar) {
        int i10;
        int i11;
        Object obj;
        Class<R> cls;
        f fVar;
        com.bumptech.glide.d dVar;
        int i12;
        int i13;
        int i14;
        Object obj2;
        Class<R> cls2;
        f fVar2;
        com.bumptech.glide.d dVar2;
        int i15;
        boolean z10;
        C3493b bVar2 = bVar;
        if (!(bVar2 instanceof C3496e)) {
            return false;
        }
        synchronized (this.f31114c) {
            try {
                i10 = this.f31119h;
                i11 = this.f31120i;
                obj = this.f31116e;
                cls = this.f31117f;
                fVar = this.f31118g;
                dVar = this.f31121j;
                ArrayList arrayList = this.f31123l;
                if (arrayList != null) {
                    i12 = arrayList.size();
                } else {
                    i12 = 0;
                }
            } finally {
                while (true) {
                }
            }
        }
        C3496e eVar = (C3496e) bVar2;
        synchronized (eVar.f31114c) {
            try {
                i13 = eVar.f31119h;
                i14 = eVar.f31120i;
                obj2 = eVar.f31116e;
                cls2 = eVar.f31117f;
                fVar2 = eVar.f31118g;
                dVar2 = eVar.f31121j;
                ArrayList arrayList2 = eVar.f31123l;
                if (arrayList2 != null) {
                    i15 = arrayList2.size();
                } else {
                    i15 = 0;
                }
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        if (i10 != i13 || i11 != i14) {
            return false;
        }
        char[] cArr = j.f1390a;
        if (obj == null) {
            if (obj2 == null) {
                z10 = true;
            } else {
                z10 = false;
            }
        } else if (obj instanceof m5.m) {
            z10 = ((m5.m) obj).a();
        } else {
            z10 = obj.equals(obj2);
        }
        if (!z10 || !cls.equals(cls2) || !fVar.equals(fVar2) || dVar != dVar2 || i12 != i15) {
            return false;
        }
        return true;
    }

    public final void h(String str) {
        StringBuilder y10 = B.y(str, " this: ");
        y10.append(this.f31112a);
        Log.v("Request", y10.toString());
    }

    public final void i(q qVar, int i10) {
        boolean z10;
        Drawable drawable;
        this.f31113b.a();
        synchronized (this.f31114c) {
            try {
                qVar.getClass();
                int i11 = this.f31115d.f16873g;
                if (i11 <= i10) {
                    Log.w("Glide", "Load failed for " + this.f31116e + " with size [" + this.f31134w + "x" + this.f31135x + "]", qVar);
                    if (i11 <= 4) {
                        qVar.d();
                    }
                }
                this.f31127p = null;
                this.f31130s = a.f31138F;
                this.f31136y = true;
                ArrayList arrayList = this.f31123l;
                if (arrayList != null) {
                    Iterator it = arrayList.iterator();
                    z10 = false;
                    while (it.hasNext()) {
                        z10 |= ((C3494c) it.next()).b();
                    }
                } else {
                    z10 = false;
                }
                if (!z10) {
                    if (this.f31116e == null) {
                        if (this.f31133v == null) {
                            this.f31118g.getClass();
                            this.f31133v = null;
                        }
                        drawable = this.f31133v;
                    } else {
                        drawable = null;
                    }
                    if (drawable == null) {
                        if (this.f31131t == null) {
                            this.f31118g.getClass();
                            this.f31131t = null;
                        }
                        drawable = this.f31131t;
                    }
                    if (drawable == null) {
                        f();
                    }
                    this.f31122k.b();
                }
                this.f31136y = false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean isRunning() {
        boolean z10;
        synchronized (this.f31114c) {
            try {
                a aVar = this.f31130s;
                if (aVar != a.f31142i) {
                    if (aVar != a.f31143z) {
                        z10 = false;
                    }
                }
                z10 = true;
            } catch (Throwable th) {
                throw th;
            }
        }
        return z10;
    }

    public final void j(u<?> uVar, C2282a aVar) {
        Object obj;
        String str;
        this.f31113b.a();
        u<?> uVar2 = null;
        try {
            synchronized (this.f31114c) {
                try {
                    this.f31127p = null;
                    if (uVar == null) {
                        i(new q("Expected to receive a Resource<R> with an object of " + this.f31117f + " inside, but instead got null."), 5);
                        return;
                    }
                    Object obj2 = uVar.get();
                    if (obj2 != null) {
                        if (this.f31117f.isAssignableFrom(obj2.getClass())) {
                            k(uVar, obj2, aVar);
                            return;
                        }
                    }
                    try {
                        this.f31126o = null;
                        StringBuilder sb2 = new StringBuilder("Expected to receive an object of ");
                        sb2.append(this.f31117f);
                        sb2.append(" but instead got ");
                        if (obj2 != null) {
                            obj = obj2.getClass();
                        } else {
                            obj = "";
                        }
                        sb2.append(obj);
                        sb2.append("{");
                        sb2.append(obj2);
                        sb2.append("} inside Resource{");
                        sb2.append(uVar);
                        sb2.append("}.");
                        if (obj2 != null) {
                            str = "";
                        } else {
                            str = " To indicate failure return a null Resource object, rather than a Resource object containing null data.";
                        }
                        sb2.append(str);
                        i(new q(sb2.toString()), 5);
                        this.f31129r.getClass();
                        m.g(uVar);
                    } catch (Throwable th) {
                        uVar2 = uVar;
                        th = th;
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    throw th;
                }
            }
        } catch (Throwable th3) {
            if (uVar2 != null) {
                this.f31129r.getClass();
                m.g(uVar2);
            }
            throw th3;
        }
    }

    public final void k(u<R> uVar, R r10, C2282a aVar) {
        boolean z10;
        this.f31130s = a.f31137E;
        this.f31126o = uVar;
        if (this.f31115d.f16873g <= 3) {
            Log.d("Glide", "Finished loading " + r10.getClass().getSimpleName() + " from " + aVar + " for " + this.f31116e + " with size [" + this.f31134w + "x" + this.f31135x + "] in " + C5.f.a(this.f31128q) + " ms");
        }
        this.f31136y = true;
        try {
            ArrayList arrayList = this.f31123l;
            if (arrayList != null) {
                Iterator it = arrayList.iterator();
                z10 = false;
                while (it.hasNext()) {
                    z10 |= ((C3494c) it.next()).c();
                }
            } else {
                z10 = false;
            }
            if (!z10) {
                this.f31124m.getClass();
                this.f31122k.c(r10);
            }
            this.f31136y = false;
        } catch (Throwable th) {
            this.f31136y = false;
            throw th;
        }
    }

    public final void pause() {
        synchronized (this.f31114c) {
            try {
                if (isRunning()) {
                    clear();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
