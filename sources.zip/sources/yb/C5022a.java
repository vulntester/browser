package yb;

import Ta.e;
import Ta.f;
import java.io.DataInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import kotlin.jvm.internal.l;
import ya.C5004A;
import ya.n;
import ya.s;
import zb.C5033a;

/* renamed from: yb.a  reason: case insensitive filesystem */
public final class C5022a extends C5033a {

    /* renamed from: f  reason: collision with root package name */
    public static final C5022a f44693f = new C5022a(1, 0, 7);

    /* renamed from: yb.a$a  reason: collision with other inner class name */
    public static final class C0468a {
        public static C5022a a(InputStream inputStream) {
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            e eVar = new e(1, dataInputStream.readInt(), 1);
            ArrayList arrayList = new ArrayList(n.v(10, eVar));
            Iterator it = eVar.iterator();
            while (((f) it).f38037z) {
                ((C5004A) it).a();
                arrayList.add(Integer.valueOf(dataInputStream.readInt()));
            }
            int[] v02 = s.v0(arrayList);
            return new C5022a(Arrays.copyOf(v02, v02.length));
        }
    }

    static {
        new C5022a(new int[0]);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C5022a(int... iArr) {
        super(Arrays.copyOf(iArr, iArr.length));
        l.f(iArr, "numbers");
    }
}
