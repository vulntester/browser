package yb;

import Db.h;
import Db.x;
import java.util.List;
import xb.C4987a;
import xb.C4988b;
import xb.c;
import xb.f;
import xb.k;
import xb.m;
import xb.p;
import xb.r;
import xb.t;

/* renamed from: yb.b  reason: case insensitive filesystem */
public final class C5023b {

    /* renamed from: a  reason: collision with root package name */
    public static final h.e<k, Integer> f44694a = h.h(k.f44337L, 0, (h) null, 151, x.INT32, Integer.class);

    /* renamed from: b  reason: collision with root package name */
    public static final h.e<C4988b, List<C4987a>> f44695b;

    /* renamed from: c  reason: collision with root package name */
    public static final h.e<c, List<C4987a>> f44696c;

    /* renamed from: d  reason: collision with root package name */
    public static final h.e<xb.h, List<C4987a>> f44697d;

    /* renamed from: e  reason: collision with root package name */
    public static final h.e<m, List<C4987a>> f44698e;

    /* renamed from: f  reason: collision with root package name */
    public static final h.e<m, List<C4987a>> f44699f;

    /* renamed from: g  reason: collision with root package name */
    public static final h.e<m, List<C4987a>> f44700g;

    /* renamed from: h  reason: collision with root package name */
    public static final h.e<m, C4987a.b.c> f44701h;

    /* renamed from: i  reason: collision with root package name */
    public static final h.e<f, List<C4987a>> f44702i;

    /* renamed from: j  reason: collision with root package name */
    public static final h.e<t, List<C4987a>> f44703j;

    /* renamed from: k  reason: collision with root package name */
    public static final h.e<p, List<C4987a>> f44704k;

    /* renamed from: l  reason: collision with root package name */
    public static final h.e<r, List<C4987a>> f44705l;

    static {
        C4988b bVar = C4988b.f44149k0;
        C4987a aVar = C4987a.f44083H;
        x.c cVar = x.MESSAGE;
        Class<C4987a> cls = C4987a.class;
        f44695b = h.g(bVar, aVar, 150, cVar, cls);
        f44696c = h.g(c.f44216J, aVar, 150, cVar, cls);
        f44697d = h.g(xb.h.f44297V, aVar, 150, cVar, cls);
        m mVar = m.f44369V;
        f44698e = h.g(mVar, aVar, 150, cVar, cls);
        f44699f = h.g(mVar, aVar, 152, cVar, cls);
        f44700g = h.g(mVar, aVar, 153, cVar, cls);
        C4987a.b.c cVar2 = C4987a.b.c.f44102Q;
        f44701h = h.h(mVar, cVar2, cVar2, 151, cVar, C4987a.b.c.class);
        f44702i = h.g(f.f44262H, aVar, 150, cVar, cls);
        f44703j = h.g(t.f44554M, aVar, 150, cVar, cls);
        f44704k = h.g(p.f44439U, aVar, 150, cVar, cls);
        f44705l = h.g(r.f44518N, aVar, 150, cVar, cls);
    }

    public static void a(Db.f fVar) {
        fVar.a(f44694a);
        fVar.a(f44695b);
        fVar.a(f44696c);
        fVar.a(f44697d);
        fVar.a(f44698e);
        fVar.a(f44699f);
        fVar.a(f44700g);
        fVar.a(f44701h);
        fVar.a(f44702i);
        fVar.a(f44703j);
        fVar.a(f44704k);
        fVar.a(f44705l);
    }
}
