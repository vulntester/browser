package z2;

import android.net.Uri;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import q2.C2949f;
import q2.C2951h;
import q2.C2952i;
import q2.v;

/* renamed from: z2.a  reason: case insensitive filesystem */
public final class C3548a implements C2949f {

    /* renamed from: E  reason: collision with root package name */
    public CipherInputStream f31583E;

    /* renamed from: f  reason: collision with root package name */
    public final C2949f f31584f;

    /* renamed from: i  reason: collision with root package name */
    public final byte[] f31585i;

    /* renamed from: z  reason: collision with root package name */
    public final byte[] f31586z;

    public C3548a(C2949f fVar, byte[] bArr, byte[] bArr2) {
        this.f31584f = fVar;
        this.f31585i = bArr;
        this.f31586z = bArr2;
    }

    public final void close() {
        if (this.f31583E != null) {
            this.f31583E = null;
            this.f31584f.close();
        }
    }

    public final Uri getUri() {
        return this.f31584f.getUri();
    }

    public final long j(C2952i iVar) {
        try {
            Cipher instance = Cipher.getInstance("AES/CBC/PKCS7Padding");
            try {
                instance.init(2, new SecretKeySpec(this.f31585i, "AES"), new IvParameterSpec(this.f31586z));
                C2951h hVar = new C2951h(this.f31584f, iVar);
                this.f31583E = new CipherInputStream(hVar, instance);
                if (hVar.f26874E) {
                    return -1;
                }
                hVar.f26876f.j(hVar.f26877i);
                hVar.f26874E = true;
                return -1;
            } catch (InvalidAlgorithmParameterException | InvalidKeyException e10) {
                throw new RuntimeException(e10);
            }
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e11) {
            throw new RuntimeException(e11);
        }
    }

    public final Map<String, List<String>> q() {
        return this.f31584f.q();
    }

    public final int read(byte[] bArr, int i10, int i11) {
        this.f31583E.getClass();
        int read = this.f31583E.read(bArr, i10, i11);
        if (read < 0) {
            return -1;
        }
        return read;
    }

    public final void t(v vVar) {
        vVar.getClass();
        this.f31584f.t(vVar);
    }
}
