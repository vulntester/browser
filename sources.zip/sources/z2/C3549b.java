package z2;

import R2.B;
import R2.n;
import o2.y;
import o3.C2763e;

/* renamed from: z2.b  reason: case insensitive filesystem */
public final class C3549b implements h {

    /* renamed from: f  reason: collision with root package name */
    public static final B f31587f = new Object();

    /* renamed from: a  reason: collision with root package name */
    public final n f31588a;

    /* renamed from: b  reason: collision with root package name */
    public final l2.n f31589b;

    /* renamed from: c  reason: collision with root package name */
    public final y f31590c;

    /* renamed from: d  reason: collision with root package name */
    public final C2763e f31591d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f31592e;

    public C3549b(n nVar, l2.n nVar2, y yVar, C2763e eVar, boolean z10) {
        this.f31588a = nVar;
        this.f31589b = nVar2;
        this.f31590c = yVar;
        this.f31591d = eVar;
        this.f31592e = z10;
    }
}
