package z2;

import q2.C2949f;

/* renamed from: z2.c  reason: case insensitive filesystem */
public final class C3550c {

    /* renamed from: a  reason: collision with root package name */
    public final C2949f.a f31593a;

    public C3550c(C2949f.a aVar) {
        this.f31593a = aVar;
    }
}
