package z2;

import W7.b;
import io.ktor.sse.ServerSentEventKt;
import java.util.ArrayList;
import l2.n;
import l2.u;
import o3.C2763e;

/* renamed from: z2.d  reason: case insensitive filesystem */
public final class C3551d {

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f31594c = {8, 13, 11, 2, 0, 1, 7};

    /* renamed from: a  reason: collision with root package name */
    public C2763e f31595a;

    /* renamed from: b  reason: collision with root package name */
    public boolean f31596b;

    public static void a(int i10, ArrayList arrayList) {
        if (b.t0(f31594c, i10, 0, 7) != -1 && !arrayList.contains(Integer.valueOf(i10))) {
            arrayList.add(Integer.valueOf(i10));
        }
    }

    public final n b(n nVar) {
        String str;
        if (!this.f31596b || !this.f31595a.e(nVar)) {
            return nVar;
        }
        n.a a10 = nVar.a();
        a10.f24328m = u.p("application/x-media3-cues");
        a10.f24312I = this.f31595a.a(nVar);
        StringBuilder sb2 = new StringBuilder();
        sb2.append(nVar.f24291n);
        String str2 = nVar.f24288k;
        if (str2 != null) {
            str = ServerSentEventKt.SPACE.concat(str2);
        } else {
            str = "";
        }
        sb2.append(str);
        a10.f24325j = sb2.toString();
        a10.f24333r = Long.MAX_VALUE;
        return new n(a10);
    }
}
