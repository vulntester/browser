package z2;

import android.net.Uri;
import java.util.LinkedHashMap;
import java.util.Map;

/* renamed from: z2.e  reason: case insensitive filesystem */
public final class C3552e extends LinkedHashMap<Uri, byte[]> {
    public final boolean removeEldestEntry(Map.Entry<Uri, byte[]> entry) {
        if (size() > 4) {
            return true;
        }
        return false;
    }
}
