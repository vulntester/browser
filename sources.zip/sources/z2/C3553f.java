package z2;

import A2.e;
import Fc.C3984j;
import I2.C0787b;
import K2.k;
import K2.m;
import M2.r;
import Pb.C4126p;
import S7.C1150x;
import S7.O;
import android.net.Uri;
import android.os.SystemClock;
import android.util.Pair;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import l2.C2611C;
import l2.n;
import o2.C2756B;
import o2.z;
import q2.C2949f;
import q2.C2952i;
import q2.v;
import u2.j;

/* renamed from: z2.f  reason: case insensitive filesystem */
public final class C3553f {

    /* renamed from: a  reason: collision with root package name */
    public final C3551d f31597a;

    /* renamed from: b  reason: collision with root package name */
    public final C2949f f31598b;

    /* renamed from: c  reason: collision with root package name */
    public final C2949f f31599c;

    /* renamed from: d  reason: collision with root package name */
    public final C3984j f31600d;

    /* renamed from: e  reason: collision with root package name */
    public final Uri[] f31601e;

    /* renamed from: f  reason: collision with root package name */
    public final n[] f31602f;

    /* renamed from: g  reason: collision with root package name */
    public final A2.b f31603g;

    /* renamed from: h  reason: collision with root package name */
    public final C2611C f31604h;

    /* renamed from: i  reason: collision with root package name */
    public final List<n> f31605i;

    /* renamed from: j  reason: collision with root package name */
    public final C4126p f31606j = new C4126p(11);

    /* renamed from: k  reason: collision with root package name */
    public final j f31607k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f31608l;

    /* renamed from: m  reason: collision with root package name */
    public byte[] f31609m = C2756B.f25813c;

    /* renamed from: n  reason: collision with root package name */
    public C0787b f31610n;

    /* renamed from: o  reason: collision with root package name */
    public Uri f31611o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f31612p;

    /* renamed from: q  reason: collision with root package name */
    public r f31613q;

    /* renamed from: r  reason: collision with root package name */
    public long f31614r = -9223372036854775807L;

    /* renamed from: s  reason: collision with root package name */
    public boolean f31615s;

    /* renamed from: z2.f$a */
    public static final class a extends k {

        /* renamed from: l  reason: collision with root package name */
        public byte[] f31616l;
    }

    /* renamed from: z2.f$b */
    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        public K2.e f31617a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f31618b;

        /* renamed from: c  reason: collision with root package name */
        public Uri f31619c;
    }

    /* renamed from: z2.f$c */
    public static final class c extends K2.b {

        /* renamed from: e  reason: collision with root package name */
        public final List<e.f> f31620e;

        /* renamed from: f  reason: collision with root package name */
        public final long f31621f;

        public c(List list, long j10) {
            super(0, (long) (list.size() - 1));
            this.f31621f = j10;
            this.f31620e = list;
        }

        public final long a() {
            c();
            return this.f31621f + this.f31620e.get((int) this.f5286d).f133F;
        }

        public final long b() {
            c();
            e.f fVar = this.f31620e.get((int) this.f5286d);
            return this.f31621f + fVar.f133F + fVar.f142z;
        }
    }

    /* renamed from: z2.f$d */
    public static final class d extends M2.c {

        /* renamed from: g  reason: collision with root package name */
        public int f31622g;

        public final int f() {
            return this.f31622g;
        }

        public final void g(long j10, long j11, long j12, List<? extends m> list, K2.n[] nVarArr) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            if (e(this.f31622g, elapsedRealtime)) {
                for (int i10 = this.f5769b - 1; i10 >= 0; i10--) {
                    if (!e(i10, elapsedRealtime)) {
                        this.f31622g = i10;
                        return;
                    }
                }
                throw new IllegalStateException();
            }
        }

        public final int n() {
            return 0;
        }

        public final Object q() {
            return null;
        }
    }

    /* renamed from: z2.f$e */
    public static final class e {

        /* renamed from: a  reason: collision with root package name */
        public final e.f f31623a;

        /* renamed from: b  reason: collision with root package name */
        public final long f31624b;

        /* renamed from: c  reason: collision with root package name */
        public final int f31625c;

        /* renamed from: d  reason: collision with root package name */
        public final boolean f31626d;

        public e(e.f fVar, long j10, int i10) {
            boolean z10;
            this.f31623a = fVar;
            this.f31624b = j10;
            this.f31625c = i10;
            if (!(fVar instanceof e.c) || !((e.c) fVar).f126N) {
                z10 = false;
            } else {
                z10 = true;
            }
            this.f31626d = z10;
        }
    }

    /* JADX WARNING: type inference failed for: r3v1, types: [z2.f$d, M2.c, M2.r] */
    public C3553f(C3551d dVar, A2.b bVar, Uri[] uriArr, n[] nVarArr, C3550c cVar, v vVar, C3984j jVar, List list, j jVar2) {
        this.f31597a = dVar;
        this.f31603g = bVar;
        this.f31601e = uriArr;
        this.f31602f = nVarArr;
        this.f31600d = jVar;
        this.f31605i = list;
        this.f31607k = jVar2;
        C2949f a10 = cVar.f31593a.a();
        this.f31598b = a10;
        if (vVar != null) {
            a10.t(vVar);
        }
        this.f31599c = cVar.f31593a.a();
        this.f31604h = new C2611C("", nVarArr);
        ArrayList arrayList = new ArrayList();
        for (int i10 = 0; i10 < uriArr.length; i10++) {
            if ((nVarArr[i10].f24283f & 16384) == 0) {
                arrayList.add(Integer.valueOf(i10));
            }
        }
        C2611C c10 = this.f31604h;
        int[] v02 = W7.b.v0(arrayList);
        ? cVar2 = new M2.c(c10, v02);
        cVar2.f31622g = cVar2.b(c10.f24150d[v02[0]]);
        this.f31613q = cVar2;
    }

    public final K2.n[] a(g gVar, long j10) {
        int i10;
        int i11;
        boolean z10;
        List list;
        C3553f fVar = this;
        g gVar2 = gVar;
        if (gVar2 == null) {
            i10 = -1;
        } else {
            i10 = fVar.f31604h.a(gVar2.f5310d);
        }
        int length = fVar.f31613q.length();
        K2.n[] nVarArr = new K2.n[length];
        boolean z11 = false;
        int i12 = 0;
        while (i12 < length) {
            int j11 = fVar.f31613q.j(i12);
            Uri uri = fVar.f31601e[j11];
            A2.b bVar = fVar.f31603g;
            if (!bVar.d(uri)) {
                nVarArr[i12] = K2.n.f5361a;
                i11 = i12;
            } else {
                A2.e b10 = bVar.b(z11, uri);
                b10.getClass();
                long j12 = b10.f91h - bVar.f65O;
                if (j11 != i10) {
                    z10 = true;
                } else {
                    z10 = z11;
                }
                Pair<Long, Integer> c10 = fVar.c(gVar2, z10, b10, j12, j10);
                long longValue = ((Long) c10.first).longValue();
                int intValue = ((Integer) c10.second).intValue();
                i11 = i12;
                int i13 = (int) (longValue - b10.f94k);
                if (i13 >= 0) {
                    C1150x xVar = b10.f101r;
                    if (xVar.size() >= i13) {
                        ArrayList arrayList = new ArrayList();
                        if (i13 < xVar.size()) {
                            if (intValue != -1) {
                                e.C0001e eVar = (e.C0001e) xVar.get(i13);
                                if (intValue == 0) {
                                    arrayList.add(eVar);
                                } else if (intValue < eVar.f131N.size()) {
                                    C1150x xVar2 = eVar.f131N;
                                    arrayList.addAll(xVar2.subList(intValue, xVar2.size()));
                                }
                                i13++;
                            }
                            arrayList.addAll(xVar.subList(i13, xVar.size()));
                            intValue = 0;
                        }
                        if (b10.f97n != -9223372036854775807L) {
                            if (intValue == -1) {
                                intValue = 0;
                            }
                            C1150x xVar3 = b10.f102s;
                            if (intValue < xVar3.size()) {
                                arrayList.addAll(xVar3.subList(intValue, xVar3.size()));
                            }
                        }
                        list = Collections.unmodifiableList(arrayList);
                        nVarArr[i11] = new c(list, j12);
                    }
                }
                C1150x.b bVar2 = C1150x.f9860i;
                list = O.f9711F;
                nVarArr[i11] = new c(list, j12);
            }
            i12 = i11 + 1;
            fVar = this;
            gVar2 = gVar;
            z11 = false;
        }
        return nVarArr;
    }

    public final int b(g gVar) {
        C1150x xVar;
        if (gVar.f31643o == -1) {
            return 1;
        }
        A2.e b10 = this.f31603g.b(false, this.f31601e[this.f31604h.a(gVar.f5310d)]);
        b10.getClass();
        int i10 = (int) (gVar.f5360j - b10.f94k);
        if (i10 < 0) {
            return 1;
        }
        C1150x xVar2 = b10.f101r;
        if (i10 < xVar2.size()) {
            xVar = ((e.C0001e) xVar2.get(i10)).f131N;
        } else {
            xVar = b10.f102s;
        }
        int size = xVar.size();
        int i11 = gVar.f31643o;
        if (i11 >= size) {
            return 2;
        }
        e.c cVar = (e.c) xVar.get(i11);
        if (cVar.f126N) {
            return 0;
        }
        if (Objects.equals(Uri.parse(z.c(b10.f168a, cVar.f140f)), gVar.f5308b.f26879a)) {
            return 1;
        }
        return 2;
    }

    public final Pair<Long, Integer> c(g gVar, boolean z10, A2.e eVar, long j10, long j11) {
        C1150x xVar;
        long j12;
        boolean z11 = true;
        int i10 = -1;
        if (gVar == null || z10) {
            long j13 = eVar.f104u + j10;
            if (gVar != null && !this.f31612p) {
                j11 = gVar.f5313g;
            }
            boolean z12 = eVar.f98o;
            long j14 = eVar.f94k;
            C1150x xVar2 = eVar.f101r;
            if (!z12 && j11 >= j13) {
                return new Pair<>(Long.valueOf(j14 + ((long) xVar2.size())), -1);
            }
            long j15 = j11 - j10;
            Long valueOf = Long.valueOf(j15);
            int i11 = 0;
            if (this.f31603g.f64N && gVar != null) {
                z11 = false;
            }
            int b10 = C2756B.b(xVar2, valueOf, z11);
            long j16 = ((long) b10) + j14;
            if (b10 >= 0) {
                e.C0001e eVar2 = (e.C0001e) xVar2.get(b10);
                int i12 = (j15 > (eVar2.f133F + eVar2.f142z) ? 1 : (j15 == (eVar2.f133F + eVar2.f142z) ? 0 : -1));
                C1150x xVar3 = eVar.f102s;
                if (i12 < 0) {
                    xVar = eVar2.f131N;
                } else {
                    xVar = xVar3;
                }
                while (true) {
                    if (i11 >= xVar.size()) {
                        break;
                    }
                    e.c cVar = (e.c) xVar.get(i11);
                    if (j15 >= cVar.f133F + cVar.f142z) {
                        i11++;
                    } else if (cVar.f125M) {
                        if (xVar == xVar3) {
                            j12 = 1;
                        } else {
                            j12 = 0;
                        }
                        j16 += j12;
                        i10 = i11;
                    }
                }
            }
            return new Pair<>(Long.valueOf(j16), Integer.valueOf(i10));
        }
        boolean z13 = gVar.f31635H;
        long j17 = gVar.f5360j;
        int i13 = gVar.f31643o;
        if (!z13) {
            return new Pair<>(Long.valueOf(j17), Integer.valueOf(i13));
        }
        if (i13 == -1) {
            j17 = gVar.c();
        }
        Long valueOf2 = Long.valueOf(j17);
        if (i13 != -1) {
            i10 = i13 + 1;
        }
        return new Pair<>(valueOf2, Integer.valueOf(i10));
    }

    /* JADX WARNING: type inference failed for: r6v1, types: [K2.k, z2.f$a, K2.e] */
    public final a d(Uri uri, int i10, boolean z10) {
        Uri uri2 = uri;
        if (uri2 == null) {
            return null;
        }
        C4126p pVar = this.f31606j;
        byte[] bArr = (byte[]) ((C3552e) pVar.f37552f).remove(uri2);
        if (bArr != null) {
            byte[] bArr2 = (byte[]) ((C3552e) pVar.f37552f).put(uri2, bArr);
            return null;
        }
        C2952i iVar = new C2952i(uri2, 1, (byte[]) null, Collections.EMPTY_MAP, 0, -1, (String) null, 1);
        n nVar = this.f31602f[i10];
        int n10 = this.f31613q.n();
        Object q10 = this.f31613q.q();
        byte[] bArr3 = this.f31609m;
        ? eVar = new K2.e(this.f31599c, iVar, 3, nVar, n10, q10, -9223372036854775807L, -9223372036854775807L);
        if (bArr3 == null) {
            bArr3 = C2756B.f25813c;
        }
        eVar.f5354j = bArr3;
        return eVar;
    }
}
