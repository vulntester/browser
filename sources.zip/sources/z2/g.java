package z2;

import A1.a;
import K2.m;
import R2.C1013i;
import S7.C1150x;
import S7.O;
import android.net.Uri;
import f3.C2265g;
import f7.M;
import java.io.EOFException;
import java.math.BigInteger;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import k5.b;
import l2.C2625k;
import l2.n;
import l3.C2628c;
import o2.t;
import o2.y;
import q2.C2949f;
import q2.C2952i;
import u2.j;
import y3.E;

public final class g extends m {

    /* renamed from: L  reason: collision with root package name */
    public static final AtomicInteger f31627L = new AtomicInteger();

    /* renamed from: A  reason: collision with root package name */
    public final boolean f31628A;

    /* renamed from: B  reason: collision with root package name */
    public final boolean f31629B;

    /* renamed from: C  reason: collision with root package name */
    public h f31630C;

    /* renamed from: D  reason: collision with root package name */
    public k f31631D;

    /* renamed from: E  reason: collision with root package name */
    public int f31632E;

    /* renamed from: F  reason: collision with root package name */
    public boolean f31633F;

    /* renamed from: G  reason: collision with root package name */
    public volatile boolean f31634G;

    /* renamed from: H  reason: collision with root package name */
    public boolean f31635H;

    /* renamed from: I  reason: collision with root package name */
    public O f31636I;

    /* renamed from: J  reason: collision with root package name */
    public boolean f31637J;

    /* renamed from: K  reason: collision with root package name */
    public boolean f31638K;

    /* renamed from: k  reason: collision with root package name */
    public final int f31639k;

    /* renamed from: l  reason: collision with root package name */
    public final int f31640l;

    /* renamed from: m  reason: collision with root package name */
    public final Uri f31641m;

    /* renamed from: n  reason: collision with root package name */
    public final boolean f31642n;

    /* renamed from: o  reason: collision with root package name */
    public final int f31643o;

    /* renamed from: p  reason: collision with root package name */
    public final C2949f f31644p;

    /* renamed from: q  reason: collision with root package name */
    public final C2952i f31645q;

    /* renamed from: r  reason: collision with root package name */
    public final h f31646r;

    /* renamed from: s  reason: collision with root package name */
    public final boolean f31647s;

    /* renamed from: t  reason: collision with root package name */
    public final boolean f31648t;

    /* renamed from: u  reason: collision with root package name */
    public final y f31649u;

    /* renamed from: v  reason: collision with root package name */
    public final C3551d f31650v;

    /* renamed from: w  reason: collision with root package name */
    public final List<n> f31651w;

    /* renamed from: x  reason: collision with root package name */
    public final C2625k f31652x;

    /* renamed from: y  reason: collision with root package name */
    public final C2265g f31653y;

    /* renamed from: z  reason: collision with root package name */
    public final t f31654z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public g(C3551d dVar, C2949f fVar, C2952i iVar, n nVar, boolean z10, C2949f fVar2, C2952i iVar2, boolean z11, Uri uri, List list, int i10, Object obj, long j10, long j11, long j12, int i11, boolean z12, int i12, boolean z13, boolean z14, y yVar, C2625k kVar, h hVar, C2265g gVar, t tVar, boolean z15, j jVar) {
        super(fVar, iVar, nVar, i10, obj, j10, j11, j12);
        C2952i iVar3 = iVar2;
        this.f31628A = z10;
        this.f31643o = i11;
        this.f31638K = z12;
        this.f31640l = i12;
        this.f31645q = iVar3;
        this.f31644p = fVar2;
        this.f31633F = iVar3 != null;
        this.f31629B = z11;
        this.f31641m = uri;
        this.f31647s = z14;
        this.f31649u = yVar;
        this.f31648t = z13;
        this.f31650v = dVar;
        this.f31651w = list;
        this.f31652x = kVar;
        this.f31646r = hVar;
        this.f31653y = gVar;
        this.f31654z = tVar;
        this.f31642n = z15;
        C1150x.b bVar = C1150x.f9860i;
        this.f31636I = O.f9711F;
        this.f31639k = f31627L.getAndIncrement();
    }

    public static byte[] f(String str) {
        int i10;
        if (a.N(str).startsWith("0x")) {
            str = str.substring(2);
        }
        byte[] byteArray = new BigInteger(str, 16).toByteArray();
        byte[] bArr = new byte[16];
        if (byteArray.length > 16) {
            i10 = byteArray.length - 16;
        } else {
            i10 = 0;
        }
        System.arraycopy(byteArray, i10, bArr, (16 - byteArray.length) + i10, byteArray.length - i10);
        return bArr;
    }

    public final void a() {
        h hVar;
        this.f31631D.getClass();
        if (this.f31630C == null && (hVar = this.f31646r) != null) {
            R2.n c10 = ((C3549b) hVar).f31588a.c();
            if ((c10 instanceof E) || (c10 instanceof C2628c)) {
                this.f31630C = this.f31646r;
                this.f31633F = false;
            }
        }
        if (this.f31633F) {
            C2949f fVar = this.f31644p;
            fVar.getClass();
            C2952i iVar = this.f31645q;
            iVar.getClass();
            e(fVar, iVar, this.f31629B, false);
            this.f31632E = 0;
            this.f31633F = false;
        }
        if (!this.f31634G) {
            if (!this.f31648t) {
                e(this.f5315i, this.f5308b, this.f31628A, true);
            }
            this.f31635H = !this.f31634G;
        }
    }

    public final void b() {
        this.f31634G = true;
    }

    public final boolean d() {
        throw null;
    }

    public final void e(C2949f fVar, C2952i iVar, boolean z10, boolean z11) {
        C2952i iVar2;
        C1013i h10;
        long j10;
        long j11;
        boolean z12 = false;
        if (z10) {
            if (this.f31632E != 0) {
                z12 = true;
            }
            iVar2 = iVar;
        } else {
            iVar2 = iVar.b((long) this.f31632E);
        }
        try {
            h10 = h(fVar, iVar2, z11);
            if (z12) {
                h10.s(this.f31632E);
            }
            do {
                if (!this.f31634G) {
                }
                break;
            } while (((C3549b) this.f31630C).f31588a.i(h10, C3549b.f31587f) == 0);
            break;
            j10 = h10.f8167E;
            j11 = iVar.f26883e;
        } catch (EOFException e10) {
            if ((this.f5310d.f24283f & 16384) != 0) {
                ((C3549b) this.f31630C).f31588a.a(0, 0);
                j10 = h10.f8167E;
                j11 = iVar.f26883e;
            } else {
                throw e10;
            }
        } catch (Throwable th) {
            b.i(fVar);
            throw th;
        }
        this.f31632E = (int) (j10 - j11);
        b.i(fVar);
    }

    public final int g(int i10) {
        M.m(!this.f31642n);
        O o10 = this.f31636I;
        if (i10 >= o10.f9712E) {
            return 0;
        }
        return ((Integer) o10.get(i10)).intValue();
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x02a2  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x02a4  */
    /* JADX WARNING: Removed duplicated region for block: B:127:0x02a7  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x02ae  */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x02b5  */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x02b8  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final R2.C1013i h(q2.C2949f r34, q2.C2952i r35, boolean r36) {
        /*
            r33 = this;
            r1 = r33
            r0 = r35
            long r6 = r34.j(r35)
            long r8 = r1.f5313g
            o2.y r10 = r1.f31649u
            if (r36 == 0) goto L_0x0021
            boolean r2 = r1.f31647s     // Catch:{ InterruptedException -> 0x001b, TimeoutException -> 0x0014 }
            r10.h(r8, r2)     // Catch:{ InterruptedException -> 0x001b, TimeoutException -> 0x0014 }
            goto L_0x0021
        L_0x0014:
            r0 = move-exception
            java.io.IOException r2 = new java.io.IOException
            r2.<init>(r0)
            throw r2
        L_0x001b:
            java.io.InterruptedIOException r0 = new java.io.InterruptedIOException
            r0.<init>()
            throw r0
        L_0x0021:
            R2.i r2 = new R2.i
            long r4 = r0.f26883e
            r3 = r34
            r2.<init>(r3, r4, r6)
            z2.h r3 = r1.f31630C
            r4 = 0
            r5 = 1
            if (r3 != 0) goto L_0x03d5
            o2.t r3 = r1.f31654z
            r2.f8169G = r4
            r6 = 10
            r7 = 8
            r3.D(r6)     // Catch:{ EOFException -> 0x00b5 }
            byte[] r13 = r3.f25885a     // Catch:{ EOFException -> 0x00b5 }
            r2.l(r13, r4, r6, r4)     // Catch:{ EOFException -> 0x00b5 }
            int r13 = r3.x()
            r14 = 4801587(0x494433, float:6.728456E-39)
            if (r13 == r14) goto L_0x0054
            r11 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r16 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            goto L_0x00bb
        L_0x0054:
            r13 = 3
            r3.H(r13)
            int r13 = r3.t()
            int r14 = r13 + 10
            byte[] r15 = r3.f25885a
            r16 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r11 = r15.length
            if (r14 <= r11) goto L_0x0070
            r3.D(r14)
            byte[] r11 = r3.f25885a
            java.lang.System.arraycopy(r15, r4, r11, r4, r6)
        L_0x0070:
            byte[] r11 = r3.f25885a
            r2.l(r11, r6, r13, r4)
            byte[] r6 = r3.f25885a
            f3.g r11 = r1.f31653y
            l2.t r6 = r11.r0(r13, r6)
            if (r6 != 0) goto L_0x0082
        L_0x007f:
            r11 = r16
            goto L_0x00bb
        L_0x0082:
            l2.t$a[] r6 = r6.f24443a
            int r11 = r6.length
            r12 = r4
        L_0x0086:
            if (r12 >= r11) goto L_0x007f
            r13 = r6[r12]
            boolean r14 = r13 instanceof f3.C2270l
            if (r14 == 0) goto L_0x00b2
            f3.l r13 = (f3.C2270l) r13
            java.lang.String r14 = r13.f21065b
            java.lang.String r15 = "com.apple.streaming.transportStreamTimestamp"
            boolean r14 = r15.equals(r14)
            if (r14 == 0) goto L_0x00b2
            byte[] r6 = r3.f25885a
            byte[] r11 = r13.f21066c
            java.lang.System.arraycopy(r11, r4, r6, r4, r7)
            r3.G(r4)
            r3.F(r7)
            long r11 = r3.o()
            r13 = 8589934591(0x1ffffffff, double:4.2439915814E-314)
            long r11 = r11 & r13
            goto L_0x00bb
        L_0x00b2:
            int r12 = r12 + 1
            goto L_0x0086
        L_0x00b5:
            r16 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            goto L_0x007f
        L_0x00bb:
            r2.f8169G = r4
            z2.h r3 = r1.f31646r
            if (r3 == 0) goto L_0x0165
            z2.b r3 = (z2.C3549b) r3
            R2.n r0 = r3.f31588a
            R2.n r6 = r0.c()
            boolean r7 = r6 instanceof y3.E
            if (r7 != 0) goto L_0x00d4
            boolean r6 = r6 instanceof l3.C2628c
            if (r6 == 0) goto L_0x00d2
            goto L_0x00d4
        L_0x00d2:
            r6 = r4
            goto L_0x00d5
        L_0x00d4:
            r6 = r5
        L_0x00d5:
            r6 = r6 ^ r5
            f7.M.m(r6)
            R2.n r6 = r0.c()
            if (r6 != r0) goto L_0x00e1
            r6 = r5
            goto L_0x00e2
        L_0x00e1:
            r6 = r4
        L_0x00e2:
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            java.lang.String r15 = "Can't recreate wrapped extractors. Outer type: "
            r7.<init>(r15)
            java.lang.Class r15 = r0.getClass()
            r7.append(r15)
            java.lang.String r7 = r7.toString()
            f7.M.l(r7, r6)
            boolean r6 = r0 instanceof z2.n
            if (r6 == 0) goto L_0x010d
            z2.n r0 = new z2.n
            l2.n r6 = r3.f31589b
            java.lang.String r6 = r6.f24281d
            o2.y r7 = r3.f31590c
            o3.e r15 = r3.f31591d
            boolean r13 = r3.f31592e
            r0.<init>(r6, r7, r15, r13)
        L_0x010a:
            r19 = r0
            goto L_0x0135
        L_0x010d:
            boolean r6 = r0 instanceof y3.C3487e
            if (r6 == 0) goto L_0x0117
            y3.e r0 = new y3.e
            r0.<init>()
            goto L_0x010a
        L_0x0117:
            boolean r6 = r0 instanceof y3.C3483a
            if (r6 == 0) goto L_0x0121
            y3.a r0 = new y3.a
            r0.<init>()
            goto L_0x010a
        L_0x0121:
            boolean r6 = r0 instanceof y3.C3485c
            if (r6 == 0) goto L_0x012b
            y3.c r0 = new y3.c
            r0.<init>()
            goto L_0x010a
        L_0x012b:
            boolean r6 = r0 instanceof k3.C2584d
            if (r6 == 0) goto L_0x0151
            k3.d r0 = new k3.d
            r0.<init>()
            goto L_0x010a
        L_0x0135:
            z2.b r18 = new z2.b
            o3.e r0 = r3.f31591d
            boolean r6 = r3.f31592e
            l2.n r7 = r3.f31589b
            o2.y r3 = r3.f31590c
            r22 = r0
            r21 = r3
            r23 = r6
            r20 = r7
            r18.<init>(r19, r20, r21, r22, r23)
            r31 = r8
            r8 = r4
        L_0x014d:
            r0 = r18
            goto L_0x0357
        L_0x0151:
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException
            java.lang.Class r0 = r0.getClass()
            java.lang.String r0 = r0.getSimpleName()
            java.lang.String r3 = "Unexpected extractor type for recreation: "
            java.lang.String r0 = r3.concat(r0)
            r2.<init>(r0)
            throw r2
        L_0x0165:
            java.util.Map r3 = r34.q()
            z2.d r6 = r1.f31650v
            r6.getClass()
            l2.n r13 = r1.f5310d
            java.lang.String r14 = r13.f24291n
            int r14 = P8.b.E(r14)
            java.lang.String r15 = "Content-Type"
            java.lang.Object r3 = r3.get(r15)
            java.util.List r3 = (java.util.List) r3
            if (r3 == 0) goto L_0x018e
            boolean r18 = r3.isEmpty()
            if (r18 == 0) goto L_0x0187
            goto L_0x018e
        L_0x0187:
            java.lang.Object r3 = r3.get(r4)
            java.lang.String r3 = (java.lang.String) r3
            goto L_0x018f
        L_0x018e:
            r3 = 0
        L_0x018f:
            int r3 = P8.b.E(r3)
            android.net.Uri r0 = r0.f26879a
            int r0 = P8.b.F(r0)
            java.util.ArrayList r15 = new java.util.ArrayList
            r7 = 7
            r15.<init>(r7)
            z2.C3551d.a(r14, r15)
            z2.C3551d.a(r3, r15)
            z2.C3551d.a(r0, r15)
            int[] r18 = z2.C3551d.f31594c
            r5 = r4
        L_0x01ab:
            if (r5 >= r7) goto L_0x01b6
            r7 = r18[r5]
            z2.C3551d.a(r7, r15)
            int r5 = r5 + 1
            r7 = 7
            goto L_0x01ab
        L_0x01b6:
            r2.f8169G = r4
            r5 = r4
            r19 = 0
        L_0x01bb:
            int r7 = r15.size()
            o2.y r4 = r1.f31649u
            if (r5 >= r7) goto L_0x033b
            java.lang.Object r7 = r15.get(r5)
            java.lang.Integer r7 = (java.lang.Integer) r7
            int r7 = r7.intValue()
            r18 = r5
            if (r7 == 0) goto L_0x02ec
            r5 = 1
            if (r7 == r5) goto L_0x02e0
            r5 = 2
            if (r7 == r5) goto L_0x02d4
            r5 = 7
            if (r7 == r5) goto L_0x02c6
            o3.n$a$a r21 = o3.C2772n.a.f25925a
            java.util.List<l2.n> r5 = r1.f31651w
            r22 = r5
            r5 = 8
            if (r7 == r5) goto L_0x026e
            r5 = 11
            if (r7 == r5) goto L_0x0208
            r5 = 13
            if (r7 == r5) goto L_0x01f5
            r29 = r4
            r31 = r8
            r23 = r15
            r5 = 0
            goto L_0x02f7
        L_0x01f5:
            z2.n r5 = new z2.n
            r31 = r8
            o3.e r8 = r6.f31595a
            boolean r9 = r6.f31596b
            r23 = r15
            java.lang.String r15 = r13.f24281d
            r5.<init>(r15, r4, r8, r9)
            r29 = r4
            goto L_0x02f7
        L_0x0208:
            r31 = r8
            r23 = r15
            o3.e r5 = r6.f31595a
            boolean r8 = r6.f31596b
            if (r22 == 0) goto L_0x021a
            r9 = 48
            r15 = r9
            r9 = r22
        L_0x0217:
            r29 = r4
            goto L_0x0233
        L_0x021a:
            l2.n$a r9 = new l2.n$a
            r9.<init>()
            java.lang.String r15 = "application/cea-608"
            java.lang.String r15 = l2.u.p(r15)
            r9.f24328m = r15
            l2.n r15 = new l2.n
            r15.<init>(r9)
            java.util.List r9 = java.util.Collections.singletonList(r15)
            r15 = 16
            goto L_0x0217
        L_0x0233:
            java.lang.String r4 = r13.f24288k
            boolean r22 = android.text.TextUtils.isEmpty(r4)
            r25 = r5
            if (r22 != 0) goto L_0x0253
            java.lang.String r5 = "audio/mp4a-latm"
            java.lang.String r5 = l2.u.c(r4, r5)
            if (r5 == 0) goto L_0x0246
            goto L_0x0248
        L_0x0246:
            r15 = r15 | 2
        L_0x0248:
            java.lang.String r5 = "video/avc"
            java.lang.String r4 = l2.u.c(r4, r5)
            if (r4 == 0) goto L_0x0251
            goto L_0x0253
        L_0x0251:
            r15 = r15 | 4
        L_0x0253:
            if (r8 != 0) goto L_0x0258
            r28 = r21
            goto L_0x025a
        L_0x0258:
            r28 = r25
        L_0x025a:
            r27 = r8 ^ 1
            y3.E r25 = new y3.E
            y3.g r4 = new y3.g
            r4.<init>(r15, r9)
            r26 = 2
            r30 = r4
            r25.<init>(r26, r27, r28, r29, r30)
        L_0x026a:
            r5 = r25
            goto L_0x02f7
        L_0x026e:
            r29 = r4
            r31 = r8
            r23 = r15
            o3.e r4 = r6.f31595a
            boolean r5 = r6.f31596b
            l2.t r8 = r13.f24289l
            if (r8 != 0) goto L_0x0280
            r25 = r4
        L_0x027e:
            r4 = 0
            goto L_0x02a0
        L_0x0280:
            r9 = 0
        L_0x0281:
            l2.t$a[] r15 = r8.f24443a
            r25 = r4
            int r4 = r15.length
            if (r9 >= r4) goto L_0x027e
            r4 = r15[r9]
            boolean r15 = r4 instanceof z2.l
            if (r15 == 0) goto L_0x029b
            z2.l r4 = (z2.l) r4
            java.util.List<z2.l$a> r4 = r4.f31743c
            boolean r4 = r4.isEmpty()
            r24 = 1
            r4 = r4 ^ 1
            goto L_0x02a0
        L_0x029b:
            int r9 = r9 + 1
            r4 = r25
            goto L_0x0281
        L_0x02a0:
            if (r4 == 0) goto L_0x02a4
            r4 = 4
            goto L_0x02a5
        L_0x02a4:
            r4 = 0
        L_0x02a5:
            if (r5 != 0) goto L_0x02ae
            r4 = r4 | 32
            r26 = r21
        L_0x02ab:
            r27 = r4
            goto L_0x02b1
        L_0x02ae:
            r26 = r25
            goto L_0x02ab
        L_0x02b1:
            l3.c r25 = new l3.c
            if (r22 == 0) goto L_0x02b8
            r5 = r22
            goto L_0x02ba
        L_0x02b8:
            S7.O r5 = S7.O.f9711F
        L_0x02ba:
            r30 = 0
            r28 = r29
            r29 = r5
            r25.<init>(r26, r27, r28, r29, r30)
            r29 = r28
            goto L_0x026a
        L_0x02c6:
            r29 = r4
            r31 = r8
            r23 = r15
            k3.d r5 = new k3.d
            r8 = 0
            r5.<init>((long) r8)
            goto L_0x02f7
        L_0x02d4:
            r29 = r4
            r31 = r8
            r23 = r15
            y3.e r5 = new y3.e
            r5.<init>()
            goto L_0x02f7
        L_0x02e0:
            r29 = r4
            r31 = r8
            r23 = r15
            y3.c r5 = new y3.c
            r5.<init>()
            goto L_0x02f7
        L_0x02ec:
            r29 = r4
            r31 = r8
            r23 = r15
            y3.a r5 = new y3.a
            r5.<init>()
        L_0x02f7:
            r5.getClass()
            boolean r4 = r5.g(r2)     // Catch:{ EOFException -> 0x0307, all -> 0x0302 }
            r8 = 0
            r2.f8169G = r8
            goto L_0x030b
        L_0x0302:
            r0 = move-exception
            r8 = 0
            r2.f8169G = r8
            throw r0
        L_0x0307:
            r8 = 0
            r2.f8169G = r8
            r4 = r8
        L_0x030b:
            if (r4 == 0) goto L_0x0322
            z2.b r18 = new z2.b
            o3.e r0 = r6.f31595a
            boolean r3 = r6.f31596b
            r22 = r0
            r23 = r3
            r19 = r5
            r20 = r13
            r21 = r29
            r18.<init>(r19, r20, r21, r22, r23)
            goto L_0x014d
        L_0x0322:
            r4 = r13
            if (r19 != 0) goto L_0x0331
            if (r7 == r14) goto L_0x032f
            if (r7 == r3) goto L_0x032f
            if (r7 == r0) goto L_0x032f
            r9 = 11
            if (r7 != r9) goto L_0x0331
        L_0x032f:
            r19 = r5
        L_0x0331:
            int r5 = r18 + 1
            r13 = r4
            r4 = r8
            r15 = r23
            r8 = r31
            goto L_0x01bb
        L_0x033b:
            r29 = r4
            r31 = r8
            r4 = r13
            r8 = 0
            z2.b r18 = new z2.b
            r19.getClass()
            o3.e r0 = r6.f31595a
            boolean r3 = r6.f31596b
            r22 = r0
            r23 = r3
            r20 = r4
            r21 = r29
            r18.<init>(r19, r20, r21, r22, r23)
            goto L_0x014d
        L_0x0357:
            r1.f31630C = r0
            R2.n r0 = r0.f31588a
            R2.n r0 = r0.c()
            boolean r3 = r0 instanceof y3.C3487e
            if (r3 != 0) goto L_0x0372
            boolean r3 = r0 instanceof y3.C3483a
            if (r3 != 0) goto L_0x0372
            boolean r3 = r0 instanceof y3.C3485c
            if (r3 != 0) goto L_0x0372
            boolean r0 = r0 instanceof k3.C2584d
            if (r0 == 0) goto L_0x0370
            goto L_0x0372
        L_0x0370:
            r0 = r8
            goto L_0x0373
        L_0x0372:
            r0 = 1
        L_0x0373:
            if (r0 == 0) goto L_0x03a0
            z2.k r0 = r1.f31631D
            int r3 = (r11 > r16 ? 1 : (r11 == r16 ? 0 : -1))
            if (r3 == 0) goto L_0x0380
            long r3 = r10.b(r11)
            goto L_0x0382
        L_0x0380:
            r3 = r31
        L_0x0382:
            long r5 = r0.f31728w0
            int r5 = (r5 > r3 ? 1 : (r5 == r3 ? 0 : -1))
            if (r5 == 0) goto L_0x03c2
            r0.f31728w0 = r3
            z2.k$b[] r0 = r0.f31701W
            int r5 = r0.length
            r6 = r8
        L_0x038e:
            if (r6 >= r5) goto L_0x03c2
            r7 = r0[r6]
            long r9 = r7.f4304F
            int r9 = (r9 > r3 ? 1 : (r9 == r3 ? 0 : -1))
            if (r9 == 0) goto L_0x039d
            r7.f4304F = r3
            r9 = 1
            r7.f4331z = r9
        L_0x039d:
            int r6 = r6 + 1
            goto L_0x038e
        L_0x03a0:
            z2.k r0 = r1.f31631D
            long r3 = r0.f31728w0
            r5 = 0
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 == 0) goto L_0x03c2
            r0.f31728w0 = r5
            z2.k$b[] r0 = r0.f31701W
            int r3 = r0.length
            r4 = r8
        L_0x03b0:
            if (r4 >= r3) goto L_0x03c2
            r7 = r0[r4]
            long r9 = r7.f4304F
            int r9 = (r9 > r5 ? 1 : (r9 == r5 ? 0 : -1))
            if (r9 == 0) goto L_0x03bf
            r7.f4304F = r5
            r9 = 1
            r7.f4331z = r9
        L_0x03bf:
            int r4 = r4 + 1
            goto L_0x03b0
        L_0x03c2:
            z2.k r0 = r1.f31631D
            java.util.HashSet r0 = r0.f31703Y
            r0.clear()
            z2.h r0 = r1.f31630C
            z2.k r3 = r1.f31631D
            z2.b r0 = (z2.C3549b) r0
            R2.n r0 = r0.f31588a
            r0.d(r3)
            goto L_0x03d6
        L_0x03d5:
            r8 = r4
        L_0x03d6:
            z2.k r0 = r1.f31631D
            l2.k r3 = r0.f31729x0
            l2.k r4 = r1.f31652x
            boolean r3 = j$.util.Objects.equals(r3, r4)
            if (r3 != 0) goto L_0x03fb
            r0.f31729x0 = r4
        L_0x03e4:
            z2.k$b[] r3 = r0.f31701W
            int r5 = r3.length
            if (r8 >= r5) goto L_0x03fb
            boolean[] r5 = r0.f31721p0
            boolean r5 = r5[r8]
            if (r5 == 0) goto L_0x03f7
            r3 = r3[r8]
            r3.f31740I = r4
            r9 = 1
            r3.f4331z = r9
            goto L_0x03f8
        L_0x03f7:
            r9 = 1
        L_0x03f8:
            int r8 = r8 + 1
            goto L_0x03e4
        L_0x03fb:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: z2.g.h(q2.f, q2.i, boolean):R2.i");
    }
}
