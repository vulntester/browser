package z2;

public interface h {
}
