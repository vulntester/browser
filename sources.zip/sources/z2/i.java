package z2;

import A2.b;
import A2.e;
import A2.j;
import Fc.C3984j;
import I2.C;
import I2.C0793h;
import I2.C0806v;
import I2.G;
import I2.N;
import I2.O;
import I2.V;
import N2.g;
import S7.C1150x;
import android.net.Uri;
import android.util.SparseArray;
import androidx.media3.exoplayer.g;
import com.google.android.gms.internal.measurement.C1684y2;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import l2.C2611C;
import l2.C2625k;
import l2.n;
import l2.t;
import l2.u;
import o2.C2756B;
import q2.v;
import y2.d;
import y2.e;

public final class i implements C0806v, j {

    /* renamed from: E  reason: collision with root package name */
    public final v f31655E;

    /* renamed from: F  reason: collision with root package name */
    public final e f31656F;

    /* renamed from: G  reason: collision with root package name */
    public final d.a f31657G;

    /* renamed from: H  reason: collision with root package name */
    public final g f31658H;

    /* renamed from: I  reason: collision with root package name */
    public final C.a f31659I;

    /* renamed from: J  reason: collision with root package name */
    public final N2.d f31660J;

    /* renamed from: K  reason: collision with root package name */
    public final IdentityHashMap<N, Integer> f31661K;

    /* renamed from: L  reason: collision with root package name */
    public final C3984j f31662L;

    /* renamed from: M  reason: collision with root package name */
    public final C1684y2 f31663M;

    /* renamed from: N  reason: collision with root package name */
    public final boolean f31664N;

    /* renamed from: O  reason: collision with root package name */
    public final int f31665O;

    /* renamed from: P  reason: collision with root package name */
    public final u2.j f31666P;

    /* renamed from: Q  reason: collision with root package name */
    public final a f31667Q = new a();

    /* renamed from: R  reason: collision with root package name */
    public C0806v.a f31668R;

    /* renamed from: S  reason: collision with root package name */
    public int f31669S;

    /* renamed from: T  reason: collision with root package name */
    public V f31670T;

    /* renamed from: U  reason: collision with root package name */
    public k[] f31671U;

    /* renamed from: V  reason: collision with root package name */
    public k[] f31672V;

    /* renamed from: W  reason: collision with root package name */
    public int f31673W;

    /* renamed from: X  reason: collision with root package name */
    public C0793h f31674X;

    /* renamed from: f  reason: collision with root package name */
    public final C3551d f31675f;

    /* renamed from: i  reason: collision with root package name */
    public final b f31676i;

    /* renamed from: z  reason: collision with root package name */
    public final C3550c f31677z;

    public class a implements O.a {
        public a() {
        }

        public final void b(O o10) {
            k kVar = (k) o10;
            i iVar = i.this;
            iVar.f31668R.b(iVar);
        }

        public final void c() {
            i iVar = i.this;
            int i10 = iVar.f31669S - 1;
            iVar.f31669S = i10;
            if (i10 <= 0) {
                int i11 = 0;
                for (k kVar : iVar.f31671U) {
                    kVar.w();
                    i11 += kVar.f31715j0.f4364a;
                }
                C2611C[] cArr = new C2611C[i11];
                int i12 = 0;
                for (k kVar2 : iVar.f31671U) {
                    kVar2.w();
                    int i13 = kVar2.f31715j0.f4364a;
                    int i14 = 0;
                    while (i14 < i13) {
                        kVar2.w();
                        cArr[i12] = kVar2.f31715j0.a(i14);
                        i14++;
                        i12++;
                    }
                }
                iVar.f31670T = new V(cArr);
                iVar.f31668R.a(iVar);
            }
        }
    }

    public i(C3551d dVar, b bVar, C3550c cVar, v vVar, e eVar, d.a aVar, g gVar, C.a aVar2, N2.d dVar2, C1684y2 y2Var, boolean z10, int i10, u2.j jVar) {
        this.f31675f = dVar;
        this.f31676i = bVar;
        this.f31677z = cVar;
        this.f31655E = vVar;
        this.f31656F = eVar;
        this.f31657G = aVar;
        this.f31658H = gVar;
        this.f31659I = aVar2;
        this.f31660J = dVar2;
        this.f31663M = y2Var;
        this.f31664N = z10;
        this.f31665O = i10;
        this.f31666P = jVar;
        y2Var.getClass();
        C1150x.b bVar2 = C1150x.f9860i;
        S7.O o10 = S7.O.f9711F;
        this.f31674X = new C0793h(o10, o10);
        this.f31661K = new IdentityHashMap<>();
        this.f31662L = new C3984j(10, false);
        this.f31671U = new k[0];
        this.f31672V = new k[0];
    }

    public static n h(n nVar, n nVar2, boolean z10) {
        C1150x xVar;
        String str;
        String str2;
        int i10;
        int i11;
        int i12;
        t tVar;
        String str3;
        int i13;
        C1150x.b bVar = C1150x.f9860i;
        S7.O o10 = S7.O.f9711F;
        int i14 = -1;
        if (nVar2 != null) {
            str3 = nVar2.f24288k;
            tVar = nVar2.f24289l;
            i12 = nVar2.f24267D;
            i11 = nVar2.f24282e;
            i10 = nVar2.f24283f;
            str2 = nVar2.f24281d;
            str = nVar2.f24279b;
            xVar = nVar2.f24280c;
        } else {
            String v10 = C2756B.v(1, nVar.f24288k);
            tVar = nVar.f24289l;
            if (z10) {
                i12 = nVar.f24267D;
                i11 = nVar.f24282e;
                i10 = nVar.f24283f;
                str2 = nVar.f24281d;
                str = nVar.f24279b;
                str3 = v10;
                xVar = nVar.f24280c;
            } else {
                i11 = 0;
                str2 = null;
                S7.O o11 = o10;
                str3 = v10;
                xVar = o11;
                i12 = -1;
                i10 = 0;
                str = null;
            }
        }
        String e10 = u.e(str3);
        if (z10) {
            i13 = nVar.f24285h;
        } else {
            i13 = -1;
        }
        if (z10) {
            i14 = nVar.f24286i;
        }
        n.a aVar = new n.a();
        aVar.f24316a = nVar.f24278a;
        aVar.f24317b = str;
        aVar.f24318c = C1150x.o(xVar);
        aVar.f24327l = u.p(nVar.f24290m);
        aVar.f24328m = u.p(e10);
        aVar.f24325j = str3;
        aVar.f24326k = tVar;
        aVar.f24323h = i13;
        aVar.f24324i = i14;
        aVar.f24306C = i12;
        aVar.f24320e = i11;
        aVar.f24321f = i10;
        aVar.f24319d = str2;
        return new n(aVar);
    }

    public final void a() {
        for (k kVar : this.f31671U) {
            ArrayList<g> arrayList = kVar.f31693O;
            if (!arrayList.isEmpty()) {
                g gVar = (g) A1.a.x(arrayList);
                int b10 = kVar.f31683E.b(gVar);
                if (b10 == 1) {
                    gVar.f31638K = true;
                } else if (b10 == 0) {
                    kVar.f31697S.post(new G(6, kVar, gVar));
                } else if (b10 == 2 && !kVar.f31726u0) {
                    N2.i iVar = kVar.f31689K;
                    if (iVar.d()) {
                        iVar.b();
                    }
                }
            }
        }
        this.f31668R.b(this);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x008f, code lost:
        if (r8 != false) goto L_0x0091;
     */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x004c  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x0095  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0058 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(android.net.Uri r19, N2.h.c r20, boolean r21) {
        /*
            r18 = this;
            r0 = r18
            r1 = r19
            z2.k[] r2 = r0.f31671U
            int r3 = r2.length
            r6 = 0
            r7 = 1
        L_0x0009:
            if (r6 >= r3) goto L_0x009d
            r8 = r2[r6]
            z2.f r9 = r8.f31683E
            android.net.Uri[] r10 = r9.f31601e
            boolean r11 = o2.C2756B.l(r1, r10)
            if (r11 != 0) goto L_0x001d
            r14 = r20
            r4 = 1
            r13 = 1
            goto L_0x0098
        L_0x001d:
            if (r21 != 0) goto L_0x003a
            M2.r r13 = r9.f31613q
            N2.h$a r13 = M2.v.a(r13)
            N2.g r8 = r8.f31688J
            r14 = r20
            N2.h$b r8 = r8.a(r13, r14)
            if (r8 == 0) goto L_0x0038
            int r13 = r8.f6355a
            r15 = 2
            if (r13 != r15) goto L_0x0038
            r13 = 1
            long r4 = r8.f6356b
            goto L_0x0042
        L_0x0038:
            r13 = 1
            goto L_0x003d
        L_0x003a:
            r14 = r20
            goto L_0x0038
        L_0x003d:
            r4 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
        L_0x0042:
            r8 = 0
            r16 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
        L_0x0048:
            int r11 = r10.length
            r12 = -1
            if (r8 >= r11) goto L_0x0058
            r11 = r10[r8]
            boolean r11 = r11.equals(r1)
            if (r11 == 0) goto L_0x0055
            goto L_0x0059
        L_0x0055:
            int r8 = r8 + 1
            goto L_0x0048
        L_0x0058:
            r8 = r12
        L_0x0059:
            if (r8 != r12) goto L_0x005c
            goto L_0x0091
        L_0x005c:
            M2.r r10 = r9.f31613q
            int r8 = r10.u(r8)
            if (r8 != r12) goto L_0x0065
            goto L_0x0091
        L_0x0065:
            boolean r10 = r9.f31615s
            android.net.Uri r11 = r9.f31611o
            boolean r11 = r1.equals(r11)
            r10 = r10 | r11
            r9.f31615s = r10
            int r10 = (r4 > r16 ? 1 : (r4 == r16 ? 0 : -1))
            if (r10 == 0) goto L_0x0091
            M2.r r10 = r9.f31613q
            boolean r8 = r10.o(r8, r4)
            if (r8 == 0) goto L_0x0097
            A2.b r8 = r9.f31603g
            java.util.HashMap<android.net.Uri, A2.b$b> r8 = r8.f55E
            java.lang.Object r8 = r8.get(r1)
            A2.b$b r8 = (A2.b.C0000b) r8
            if (r8 == 0) goto L_0x008e
            boolean r8 = A2.b.C0000b.a(r8, r4)
            r8 = r8 ^ r13
            goto L_0x008f
        L_0x008e:
            r8 = 0
        L_0x008f:
            if (r8 == 0) goto L_0x0097
        L_0x0091:
            int r4 = (r4 > r16 ? 1 : (r4 == r16 ? 0 : -1))
            if (r4 == 0) goto L_0x0097
            r4 = r13
            goto L_0x0098
        L_0x0097:
            r4 = 0
        L_0x0098:
            r7 = r7 & r4
            int r6 = r6 + 1
            goto L_0x0009
        L_0x009d:
            I2.v$a r1 = r0.f31668R
            r1.b(r0)
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: z2.i.b(android.net.Uri, N2.h$c, boolean):boolean");
    }

    public final long c(long j10, t2.V v10) {
        A2.e eVar;
        long j11;
        k[] kVarArr = this.f31672V;
        int length = kVarArr.length;
        int i10 = 0;
        while (true) {
            if (i10 >= length) {
                break;
            }
            k kVar = kVarArr[i10];
            if (kVar.f31706b0 == 2) {
                C3553f fVar = kVar.f31683E;
                int f10 = fVar.f31613q.f();
                Uri[] uriArr = fVar.f31601e;
                int length2 = uriArr.length;
                b bVar = fVar.f31603g;
                if (f10 >= length2 || f10 == -1) {
                    eVar = null;
                } else {
                    eVar = bVar.b(true, uriArr[fVar.f31613q.k()]);
                }
                if (eVar != null) {
                    C1150x xVar = eVar.f101r;
                    if (!xVar.isEmpty()) {
                        long j12 = eVar.f91h - bVar.f65O;
                        long j13 = j10 - j12;
                        int b10 = C2756B.b(xVar, Long.valueOf(j13), true);
                        long j14 = ((e.C0001e) xVar.get(b10)).f133F;
                        if (!eVar.f170c || b10 == xVar.size() - 1) {
                            j11 = j14;
                        } else {
                            j11 = ((e.C0001e) xVar.get(b10 + 1)).f133F;
                        }
                        return v10.a(j13, j14, j11) + j12;
                    }
                }
            } else {
                i10++;
            }
        }
        return j10;
    }

    public final k d(String str, int i10, Uri[] uriArr, n[] nVarArr, n nVar, List<n> list, Map<String, C2625k> map, long j10) {
        Uri[] uriArr2 = uriArr;
        n[] nVarArr2 = nVarArr;
        C3553f fVar = new C3553f(this.f31675f, this.f31676i, uriArr2, nVarArr2, this.f31677z, this.f31655E, this.f31662L, list, this.f31666P);
        a aVar = this.f31667Q;
        C.a aVar2 = this.f31659I;
        return new k(str, i10, aVar, fVar, map, this.f31660J, j10, nVar, this.f31656F, this.f31657G, this.f31658H, aVar2, this.f31665O);
    }

    public final boolean e(androidx.media3.exoplayer.g gVar) {
        if (this.f31670T != null) {
            return this.f31674X.e(gVar);
        }
        for (k kVar : this.f31671U) {
            if (!kVar.e0) {
                g.a aVar = new g.a();
                aVar.f15281a = kVar.f31722q0;
                kVar.e(new androidx.media3.exoplayer.g(aVar));
            }
        }
        return false;
    }

    public final long f() {
        return this.f31674X.f();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x00aa, code lost:
        if (r5[r0] != 1) goto L_0x00b1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void g(I2.C0806v.a r25, long r26) {
        /*
            r24 = this;
            r0 = r24
            r10 = 0
            r1 = r25
            r0.f31668R = r1
            A2.b r1 = r0.f31676i
            java.util.concurrent.CopyOnWriteArrayList<A2.j> r2 = r1.f56F
            r2.add(r0)
            A2.f r12 = r1.f61K
            r12.getClass()
            java.util.Map r7 = java.util.Collections.EMPTY_MAP
            java.util.List<A2.f$b> r1 = r12.f150e
            boolean r2 = r1.isEmpty()
            r0.f31669S = r10
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
            java.util.ArrayList r14 = new java.util.ArrayList
            r14.<init>()
            z2.d r15 = r0.f31675f
            boolean r3 = r0.f31664N
            java.util.List<A2.f$a> r4 = r12.f152g
            if (r2 != 0) goto L_0x023e
            int r2 = r1.size()
            int[] r5 = new int[r2]
            r6 = r10
            r8 = r6
            r9 = r8
            r16 = r9
        L_0x003a:
            int r10 = r1.size()
            if (r6 >= r10) goto L_0x006e
            java.lang.Object r10 = r1.get(r6)
            A2.f$b r10 = (A2.f.b) r10
            l2.n r10 = r10.f163b
            int r11 = r10.f24299v
            if (r11 > 0) goto L_0x0067
            java.lang.String r10 = r10.f24288k
            r11 = 2
            java.lang.String r18 = o2.C2756B.v(r11, r10)
            if (r18 == 0) goto L_0x0058
            r10 = 2
            r11 = 1
            goto L_0x0069
        L_0x0058:
            r11 = 1
            java.lang.String r10 = o2.C2756B.v(r11, r10)
            if (r10 == 0) goto L_0x0063
            r5[r6] = r11
            int r9 = r9 + r11
            goto L_0x006c
        L_0x0063:
            r10 = -1
            r5[r6] = r10
            goto L_0x006c
        L_0x0067:
            r11 = 1
            r10 = 2
        L_0x0069:
            r5[r6] = r10
            int r8 = r8 + r11
        L_0x006c:
            int r6 = r6 + r11
            goto L_0x003a
        L_0x006e:
            if (r8 <= 0) goto L_0x0076
            r10 = r8
            r6 = r16
            r2 = 1
            r8 = r3
            goto L_0x0084
        L_0x0076:
            if (r9 >= r2) goto L_0x007f
            int r2 = r2 - r9
            r10 = r2
            r8 = r3
            r2 = r16
            r6 = 1
            goto L_0x0084
        L_0x007f:
            r10 = r2
            r8 = r3
            r2 = r16
            r6 = r2
        L_0x0084:
            android.net.Uri[] r3 = new android.net.Uri[r10]
            r9 = r4
            l2.n[] r4 = new l2.n[r10]
            int[] r11 = new int[r10]
            r19 = r2
            r0 = r16
            r18 = r0
        L_0x0091:
            int r2 = r1.size()
            if (r0 >= r2) goto L_0x00cc
            if (r19 == 0) goto L_0x00a3
            r2 = r5[r0]
            r20 = r3
            r3 = 2
            if (r2 != r3) goto L_0x00a1
            goto L_0x00a5
        L_0x00a1:
            r3 = 1
            goto L_0x00ad
        L_0x00a3:
            r20 = r3
        L_0x00a5:
            if (r6 == 0) goto L_0x00b0
            r2 = r5[r0]
            r3 = 1
            if (r2 == r3) goto L_0x00ad
            goto L_0x00b1
        L_0x00ad:
            r17 = r3
            goto L_0x00c7
        L_0x00b0:
            r3 = 1
        L_0x00b1:
            java.lang.Object r2 = r1.get(r0)
            A2.f$b r2 = (A2.f.b) r2
            r17 = r3
            android.net.Uri r3 = r2.f162a
            r20[r18] = r3
            l2.n r2 = r2.f163b
            r4[r18] = r2
            int r2 = r18 + 1
            r11[r18] = r0
            r18 = r2
        L_0x00c7:
            int r0 = r0 + 1
            r3 = r20
            goto L_0x0091
        L_0x00cc:
            r20 = r3
            r17 = 1
            r0 = r4[r16]
            java.lang.String r0 = r0.f24288k
            r3 = 2
            int r1 = o2.C2756B.u(r3, r0)
            r3 = r17
            int r0 = o2.C2756B.u(r3, r0)
            if (r0 == r3) goto L_0x00e9
            if (r0 != 0) goto L_0x00f2
            boolean r2 = r9.isEmpty()
            if (r2 == 0) goto L_0x00f2
        L_0x00e9:
            if (r1 > r3) goto L_0x00f2
            int r2 = r0 + r1
            if (r2 <= 0) goto L_0x00f2
            r18 = 1
            goto L_0x00f4
        L_0x00f2:
            r18 = r16
        L_0x00f4:
            if (r19 != 0) goto L_0x00fb
            if (r0 <= 0) goto L_0x00fb
            r2 = 1
        L_0x00f9:
            r3 = r1
            goto L_0x00fe
        L_0x00fb:
            r2 = r16
            goto L_0x00f9
        L_0x00fe:
            java.lang.String r1 = "main"
            l2.n r5 = r12.f155j
            java.util.List<l2.n> r6 = r12.f156k
            r22 = r0
            r21 = r3
            r19 = r8
            r3 = r20
            r0 = r24
            r20 = r9
            r8 = r26
            z2.k r2 = r0.d(r1, r2, r3, r4, r5, r6, r7, r8)
            r13.add(r2)
            r14.add(r11)
            if (r19 == 0) goto L_0x0242
            if (r18 == 0) goto L_0x0242
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            l2.n r3 = r12.f155j
            if (r21 <= 0) goto L_0x01ea
            l2.n[] r5 = new l2.n[r10]
            r6 = r16
        L_0x012d:
            if (r6 >= r10) goto L_0x0191
            r8 = r4[r6]
            java.lang.String r9 = r8.f24288k
            r11 = 2
            java.lang.String r9 = o2.C2756B.v(r11, r9)
            java.lang.String r18 = l2.u.e(r9)
            l2.n$a r11 = new l2.n$a
            r11.<init>()
            r21 = r4
            java.lang.String r4 = r8.f24278a
            r11.f24316a = r4
            java.lang.String r4 = r8.f24279b
            r11.f24317b = r4
            S7.x r4 = r8.f24280c
            S7.x r4 = S7.C1150x.o(r4)
            r11.f24318c = r4
            java.lang.String r4 = r8.f24290m
            java.lang.String r4 = l2.u.p(r4)
            r11.f24327l = r4
            java.lang.String r4 = l2.u.p(r18)
            r11.f24328m = r4
            r11.f24325j = r9
            l2.t r4 = r8.f24289l
            r11.f24326k = r4
            int r4 = r8.f24285h
            r11.f24323h = r4
            int r4 = r8.f24286i
            r11.f24324i = r4
            int r4 = r8.f24298u
            r11.f24335t = r4
            int r4 = r8.f24299v
            r11.f24336u = r4
            float r4 = r8.f24300w
            r11.f24337v = r4
            int r4 = r8.f24282e
            r11.f24320e = r4
            int r4 = r8.f24283f
            r11.f24321f = r4
            l2.n r4 = new l2.n
            r4.<init>(r11)
            r5[r6] = r4
            r17 = 1
            int r6 = r6 + 1
            r4 = r21
            goto L_0x012d
        L_0x0191:
            r21 = r4
            l2.C r4 = new l2.C
            r4.<init>(r1, r5)
            r0.add(r4)
            if (r22 <= 0) goto L_0x01bc
            if (r3 != 0) goto L_0x01a5
            boolean r1 = r20.isEmpty()
            if (r1 == 0) goto L_0x01bc
        L_0x01a5:
            l2.C r1 = new l2.C
            r4 = r21[r16]
            r5 = r16
            l2.n r3 = h(r4, r3, r5)
            r11 = 1
            l2.n[] r4 = new l2.n[r11]
            r4[r5] = r3
            java.lang.String r3 = "main:audio"
            r1.<init>(r3, r4)
            r0.add(r1)
        L_0x01bc:
            java.util.List<l2.n> r1 = r12.f156k
            if (r1 == 0) goto L_0x01e8
            r3 = 0
        L_0x01c1:
            int r4 = r1.size()
            if (r3 >= r4) goto L_0x01e8
            java.lang.String r4 = "main:cc:"
            java.lang.String r4 = D1.b.j(r3, r4)
            l2.C r5 = new l2.C
            java.lang.Object r6 = r1.get(r3)
            l2.n r6 = (l2.n) r6
            l2.n r6 = r15.b(r6)
            r11 = 1
            l2.n[] r8 = new l2.n[r11]
            r16 = 0
            r8[r16] = r6
            r5.<init>(r4, r8)
            r0.add(r5)
            int r3 = r3 + r11
            goto L_0x01c1
        L_0x01e8:
            r11 = 1
            goto L_0x0204
        L_0x01ea:
            r21 = r4
            r11 = 1
            l2.n[] r4 = new l2.n[r10]
            r5 = 0
        L_0x01f0:
            if (r5 >= r10) goto L_0x01fc
            r6 = r21[r5]
            l2.n r6 = h(r6, r3, r11)
            r4[r5] = r6
            int r5 = r5 + r11
            goto L_0x01f0
        L_0x01fc:
            l2.C r3 = new l2.C
            r3.<init>(r1, r4)
            r0.add(r3)
        L_0x0204:
            l2.C r1 = new l2.C
            l2.n$a r3 = new l2.n$a
            r3.<init>()
            java.lang.String r4 = "ID3"
            r3.f24316a = r4
            java.lang.String r4 = "application/id3"
            java.lang.String r4 = l2.u.p(r4)
            r3.f24328m = r4
            l2.n r4 = new l2.n
            r4.<init>(r3)
            r11 = 1
            l2.n[] r3 = new l2.n[r11]
            r5 = 0
            r3[r5] = r4
            java.lang.String r4 = "main:id3"
            r1.<init>(r4, r3)
            r0.add(r1)
            l2.C[] r3 = new l2.C2611C[r5]
            java.lang.Object[] r3 = r0.toArray(r3)
            l2.C[] r3 = (l2.C2611C[]) r3
            int r0 = r0.indexOf(r1)
            int[] r0 = new int[]{r0}
            r2.G(r3, r0)
            goto L_0x0242
        L_0x023e:
            r19 = r3
            r20 = r4
        L_0x0242:
            java.util.ArrayList r10 = new java.util.ArrayList
            int r0 = r20.size()
            r10.<init>(r0)
            java.util.ArrayList r11 = new java.util.ArrayList
            int r0 = r20.size()
            r11.<init>(r0)
            java.util.ArrayList r0 = new java.util.ArrayList
            int r1 = r20.size()
            r0.<init>(r1)
            java.util.HashSet r1 = new java.util.HashSet
            r1.<init>()
            r2 = 0
        L_0x0263:
            int r3 = r20.size()
            if (r2 >= r3) goto L_0x0333
            r3 = r20
            java.lang.Object r4 = r3.get(r2)
            A2.f$a r4 = (A2.f.a) r4
            java.lang.String r4 = r4.f161c
            boolean r5 = r1.add(r4)
            if (r5 != 0) goto L_0x0286
            r21 = r0
            r22 = r1
            r23 = r2
            r20 = r3
            r3 = 1
            r0 = r24
            goto L_0x032b
        L_0x0286:
            r10.clear()
            r11.clear()
            r0.clear()
            r5 = 0
            r18 = 1
        L_0x0292:
            int r6 = r3.size()
            if (r5 >= r6) goto L_0x02d1
            java.lang.Object r6 = r3.get(r5)
            A2.f$a r6 = (A2.f.a) r6
            java.lang.String r6 = r6.f161c
            boolean r6 = r4.equals(r6)
            if (r6 == 0) goto L_0x02ce
            java.lang.Object r6 = r3.get(r5)
            A2.f$a r6 = (A2.f.a) r6
            java.lang.Integer r8 = java.lang.Integer.valueOf(r5)
            r0.add(r8)
            android.net.Uri r8 = r6.f159a
            r10.add(r8)
            l2.n r6 = r6.f160b
            r11.add(r6)
            java.lang.String r6 = r6.f24288k
            r8 = 1
            int r6 = o2.C2756B.u(r8, r6)
            if (r6 != r8) goto L_0x02c8
            r6 = r8
            goto L_0x02c9
        L_0x02c8:
            r6 = 0
        L_0x02c9:
            r6 = r18 & r6
            r18 = r6
            goto L_0x02cf
        L_0x02ce:
            r8 = 1
        L_0x02cf:
            int r5 = r5 + r8
            goto L_0x0292
        L_0x02d1:
            java.lang.String r5 = "audio:"
            java.lang.String r4 = r5.concat(r4)
            r5 = 0
            android.net.Uri[] r6 = new android.net.Uri[r5]
            int r8 = o2.C2756B.f25811a
            java.lang.Object[] r6 = r10.toArray(r6)
            android.net.Uri[] r6 = (android.net.Uri[]) r6
            l2.n[] r8 = new l2.n[r5]
            java.lang.Object[] r5 = r11.toArray(r8)
            l2.n[] r5 = (l2.n[]) r5
            r20 = r3
            r3 = r6
            java.util.List r6 = java.util.Collections.EMPTY_LIST
            r8 = r2
            r2 = 1
            r9 = r1
            r1 = r4
            r4 = r5
            r5 = 0
            r21 = r0
            r23 = r8
            r22 = r9
            r0 = r24
            r8 = r26
            z2.k r2 = r0.d(r1, r2, r3, r4, r5, r6, r7, r8)
            int[] r3 = W7.b.v0(r21)
            r14.add(r3)
            r13.add(r2)
            if (r19 == 0) goto L_0x032a
            if (r18 == 0) goto L_0x032a
            r5 = 0
            l2.n[] r3 = new l2.n[r5]
            java.lang.Object[] r3 = r11.toArray(r3)
            l2.n[] r3 = (l2.n[]) r3
            l2.C r4 = new l2.C
            r4.<init>(r1, r3)
            r3 = 1
            l2.C[] r1 = new l2.C2611C[r3]
            r1[r5] = r4
            int[] r4 = new int[r5]
            r2.G(r1, r4)
            goto L_0x032b
        L_0x032a:
            r3 = 1
        L_0x032b:
            int r2 = r23 + 1
            r0 = r21
            r1 = r22
            goto L_0x0263
        L_0x0333:
            r0 = r24
            int r1 = r13.size()
            r0.f31673W = r1
            r10 = 0
        L_0x033c:
            java.util.List<A2.f$a> r1 = r12.f153h
            int r2 = r1.size()
            if (r10 >= r2) goto L_0x03a3
            java.lang.Object r1 = r1.get(r10)
            A2.f$a r1 = (A2.f.a) r1
            java.lang.String r2 = "subtitle:"
            java.lang.String r3 = ":"
            java.lang.StringBuilder r2 = D1.b.m(r10, r2, r3)
            java.lang.String r3 = r1.f161c
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            android.net.Uri r3 = r1.f159a
            r4 = r3
            r11 = 1
            android.net.Uri[] r3 = new android.net.Uri[r11]
            r16 = 0
            r3[r16] = r4
            l2.n r1 = r1.f160b
            l2.n[] r4 = new l2.n[r11]
            r4[r16] = r1
            java.util.List r6 = java.util.Collections.EMPTY_LIST
            r5 = r1
            r1 = r2
            r2 = 3
            r8 = r5
            r5 = 0
            r9 = r16
            r16 = r10
            r10 = r9
            r11 = r8
            r8 = r26
            z2.k r2 = r0.d(r1, r2, r3, r4, r5, r6, r7, r8)
            int[] r3 = new int[]{r16}
            r14.add(r3)
            r13.add(r2)
            l2.C r3 = new l2.C
            l2.n r4 = r15.b(r11)
            r11 = 1
            l2.n[] r5 = new l2.n[r11]
            r5[r10] = r4
            r3.<init>(r1, r5)
            l2.C[] r1 = new l2.C2611C[r11]
            r1[r10] = r3
            int[] r3 = new int[r10]
            r2.G(r1, r3)
            int r1 = r16 + 1
            r10 = r1
            goto L_0x033c
        L_0x03a3:
            r10 = 0
            z2.k[] r1 = new z2.k[r10]
            java.lang.Object[] r1 = r13.toArray(r1)
            z2.k[] r1 = (z2.k[]) r1
            r0.f31671U = r1
            int[][] r1 = new int[r10][]
            java.lang.Object[] r1 = r14.toArray(r1)
            int[][] r1 = (int[][]) r1
            z2.k[] r1 = r0.f31671U
            int r1 = r1.length
            r0.f31669S = r1
            r5 = r10
        L_0x03bc:
            int r1 = r0.f31673W
            if (r5 >= r1) goto L_0x03cb
            z2.k[] r1 = r0.f31671U
            r1 = r1[r5]
            z2.f r1 = r1.f31683E
            r11 = 1
            r1.f31608l = r11
            int r5 = r5 + r11
            goto L_0x03bc
        L_0x03cb:
            z2.k[] r1 = r0.f31671U
            int r2 = r1.length
        L_0x03ce:
            if (r10 >= r2) goto L_0x03ec
            r3 = r1[r10]
            boolean r4 = r3.e0
            if (r4 != 0) goto L_0x03e7
            androidx.media3.exoplayer.g$a r4 = new androidx.media3.exoplayer.g$a
            r4.<init>()
            long r5 = r3.f31722q0
            r4.f15281a = r5
            androidx.media3.exoplayer.g r5 = new androidx.media3.exoplayer.g
            r5.<init>(r4)
            r3.e(r5)
        L_0x03e7:
            r17 = 1
            int r10 = r10 + 1
            goto L_0x03ce
        L_0x03ec:
            z2.k[] r1 = r0.f31671U
            r0.f31672V = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: z2.i.g(I2.v$a, long):void");
    }

    public final void i() {
        k[] kVarArr = this.f31671U;
        int length = kVarArr.length;
        int i10 = 0;
        while (i10 < length) {
            k kVar = kVarArr[i10];
            kVar.F();
            if (!kVar.f31726u0 || kVar.e0) {
                i10++;
            } else {
                throw l2.v.a((RuntimeException) null, "Loading finished before preparation is complete.");
            }
        }
    }

    public final long j(long j10) {
        k[] kVarArr = this.f31672V;
        if (kVarArr.length > 0) {
            boolean I10 = kVarArr[0].I(j10, false);
            int i10 = 1;
            while (true) {
                k[] kVarArr2 = this.f31672V;
                if (i10 >= kVarArr2.length) {
                    break;
                }
                kVarArr2[i10].I(j10, I10);
                i10++;
            }
            if (I10) {
                ((SparseArray) this.f31662L.f35181f).clear();
            }
        }
        return j10;
    }

    public final boolean l() {
        return this.f31674X.l();
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v15, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v24, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v33, resolved type: java.lang.Object[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x0264  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x0277  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final long o(M2.r[] r39, boolean[] r40, I2.N[] r41, boolean[] r42, long r43) {
        /*
            r38 = this;
            r0 = r38
            r1 = r39
            r2 = r41
            r4 = r43
            int r3 = r1.length
            int[] r12 = new int[r3]
            int r3 = r1.length
            int[] r13 = new int[r3]
            r3 = 0
        L_0x000f:
            int r6 = r1.length
            java.util.IdentityHashMap<I2.N, java.lang.Integer> r15 = r0.f31661K
            r7 = -1
            if (r3 >= r6) goto L_0x004d
            r6 = r2[r3]
            if (r6 != 0) goto L_0x001b
            r6 = r7
            goto L_0x0025
        L_0x001b:
            java.lang.Object r6 = r15.get(r6)
            java.lang.Integer r6 = (java.lang.Integer) r6
            int r6 = r6.intValue()
        L_0x0025:
            r12[r3] = r6
            r13[r3] = r7
            r6 = r1[r3]
            if (r6 == 0) goto L_0x004a
            l2.C r6 = r6.a()
            r8 = 0
        L_0x0032:
            z2.k[] r9 = r0.f31671U
            int r10 = r9.length
            if (r8 >= r10) goto L_0x004a
            r9 = r9[r8]
            r9.w()
            I2.V r9 = r9.f31715j0
            int r9 = r9.b(r6)
            if (r9 == r7) goto L_0x0047
            r13[r3] = r8
            goto L_0x004a
        L_0x0047:
            int r8 = r8 + 1
            goto L_0x0032
        L_0x004a:
            int r3 = r3 + 1
            goto L_0x000f
        L_0x004d:
            r15.clear()
            int r3 = r1.length
            I2.N[] r6 = new I2.N[r3]
            int r8 = r1.length
            I2.N[] r9 = new I2.N[r8]
            int r10 = r1.length
            M2.r[] r11 = new M2.r[r10]
            r16 = 0
            z2.k[] r14 = r0.f31671U
            int r14 = r14.length
            z2.k[] r14 = new z2.k[r14]
            r17 = r8
            r8 = r16
            r18 = r8
            r19 = r18
        L_0x0068:
            z2.k[] r7 = r0.f31671U
            int r7 = r7.length
            if (r8 >= r7) goto L_0x030f
            r21 = r3
            r7 = r16
        L_0x0071:
            int r3 = r1.length
            r22 = r6
            if (r7 >= r3) goto L_0x008f
            r3 = r12[r7]
            if (r3 != r8) goto L_0x007d
            r3 = r2[r7]
            goto L_0x007e
        L_0x007d:
            r3 = 0
        L_0x007e:
            r9[r7] = r3
            r3 = r13[r7]
            if (r3 != r8) goto L_0x0087
            r6 = r1[r7]
            goto L_0x0088
        L_0x0087:
            r6 = 0
        L_0x0088:
            r11[r7] = r6
            int r7 = r7 + 1
            r6 = r22
            goto L_0x0071
        L_0x008f:
            z2.k[] r3 = r0.f31671U
            r3 = r3[r8]
            r3.w()
            int r7 = r3.f31710f0
            r24 = r8
            r6 = r16
            r23 = 0
        L_0x009e:
            if (r6 >= r10) goto L_0x00f1
            r25 = r9[r6]
            r26 = 1
            r8 = r25
            z2.j r8 = (z2.j) r8
            if (r8 == 0) goto L_0x00b5
            r25 = r11[r6]
            if (r25 == 0) goto L_0x00b2
            boolean r25 = r40[r6]
            if (r25 != 0) goto L_0x00b5
        L_0x00b2:
            r25 = r6
            goto L_0x00bb
        L_0x00b5:
            r25 = r6
            r27 = r7
            r7 = -1
            goto L_0x00ec
        L_0x00bb:
            int r6 = r3.f31710f0
            int r6 = r6 + -1
            r3.f31710f0 = r6
            int r6 = r8.f31681z
            r27 = r7
            r7 = -1
            if (r6 == r7) goto L_0x00ea
            z2.k r6 = r8.f31680i
            r6.w()
            int[] r7 = r6.f31717l0
            r7.getClass()
            int[] r7 = r6.f31717l0
            r26 = r7
            int r7 = r8.f31679f
            r7 = r26[r7]
            r26 = r7
            boolean[] r7 = r6.f31720o0
            boolean r7 = r7[r26]
            f7.M.m(r7)
            boolean[] r6 = r6.f31720o0
            r6[r26] = r16
            r7 = -1
            r8.f31681z = r7
        L_0x00ea:
            r9[r25] = r23
        L_0x00ec:
            int r6 = r25 + 1
            r7 = r27
            goto L_0x009e
        L_0x00f1:
            r27 = r7
            r7 = -1
            r26 = 1
            if (r19 != 0) goto L_0x0109
            boolean r6 = r3.f31725t0
            if (r6 == 0) goto L_0x00ff
            if (r27 != 0) goto L_0x0106
            goto L_0x0109
        L_0x00ff:
            long r7 = r3.f31722q0
            int r6 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r6 == 0) goto L_0x0106
            goto L_0x0109
        L_0x0106:
            r6 = r16
            goto L_0x010b
        L_0x0109:
            r6 = r26
        L_0x010b:
            z2.f r7 = r3.f31683E
            M2.r r8 = r7.f31613q
            r25 = r6
            r27 = r9
            r28 = r11
            r6 = r16
            r9 = r8
        L_0x0118:
            A2.b r11 = r7.f31603g
            r29 = r12
            android.net.Uri[] r12 = r7.f31601e
            if (r6 >= r10) goto L_0x018a
            r30 = r6
            r6 = r28[r30]
            if (r6 != 0) goto L_0x0129
            r31 = r10
            goto L_0x0181
        L_0x0129:
            r31 = r10
            I2.V r10 = r3.f31715j0
            r32 = r12
            l2.C r12 = r6.a()
            int r10 = r10.b(r12)
            int r12 = r3.f31718m0
            if (r10 != r12) goto L_0x0149
            M2.r r9 = r7.f31613q
            int r9 = r9.k()
            r9 = r32[r9]
            r11.a(r9)
            r7.f31613q = r6
            r9 = r6
        L_0x0149:
            r6 = r27[r30]
            if (r6 != 0) goto L_0x0181
            int r6 = r3.f31710f0
            int r6 = r6 + 1
            r3.f31710f0 = r6
            z2.j r6 = new z2.j
            r6.<init>(r3, r10)
            r27[r30] = r6
            r42[r30] = r26
            int[] r11 = r3.f31717l0
            if (r11 == 0) goto L_0x0181
            r6.c()
            if (r25 != 0) goto L_0x0181
            z2.k$b[] r6 = r3.f31701W
            int[] r11 = r3.f31717l0
            r10 = r11[r10]
            r6 = r6[r10]
            int r10 = r6.t()
            if (r10 == 0) goto L_0x017d
            r10 = r26
            boolean r6 = r6.H(r4, r10)
            if (r6 != 0) goto L_0x017d
            r10 = 1
            goto L_0x017f
        L_0x017d:
            r10 = r16
        L_0x017f:
            r25 = r10
        L_0x0181:
            int r6 = r30 + 1
            r12 = r29
            r10 = r31
            r26 = 1
            goto L_0x0118
        L_0x018a:
            r31 = r10
            r32 = r12
            int r6 = r3.f31710f0
            java.util.ArrayList<z2.g> r10 = r3.f31693O
            if (r6 != 0) goto L_0x01e1
            M2.r r6 = r7.f31613q
            int r6 = r6.k()
            r6 = r32[r6]
            r11.a(r6)
            r6 = r23
            r7.f31610n = r6
            r3.f31712h0 = r6
            r6 = 1
            r3.f31724s0 = r6
            r10.clear()
            N2.i r8 = r3.f31689K
            boolean r9 = r8.d()
            if (r9 == 0) goto L_0x01ca
            boolean r9 = r3.f31708d0
            if (r9 == 0) goto L_0x01c6
            z2.k$b[] r9 = r3.f31701W
            int r10 = r9.length
            r11 = r16
        L_0x01bc:
            if (r11 >= r10) goto L_0x01c6
            r12 = r9[r11]
            r12.k()
            int r11 = r11 + 1
            goto L_0x01bc
        L_0x01c6:
            r8.b()
            goto L_0x01cd
        L_0x01ca:
            r3.H()
        L_0x01cd:
            r20 = r14
            r14 = r3
            r3 = r17
            r17 = r20
            r26 = r13
            r34 = r21
            r35 = r22
            r37 = r24
            r20 = -1
            r13 = r7
            goto L_0x027b
        L_0x01e1:
            r6 = 1
            boolean r10 = r10.isEmpty()
            if (r10 != 0) goto L_0x024d
            boolean r8 = j$.util.Objects.equals(r9, r8)
            if (r8 != 0) goto L_0x024d
            boolean r8 = r3.f31725t0
            if (r8 != 0) goto L_0x0237
            r10 = 0
            int r8 = (r4 > r10 ? 1 : (r4 == r10 ? 0 : -1))
            if (r8 >= 0) goto L_0x01f9
            long r10 = -r4
        L_0x01f9:
            z2.g r12 = r3.B()
            r32 = r10
            K2.n[] r11 = r7.a(r12, r4)
            r10 = r9
            r8 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r23 = r10
            java.util.List<z2.g> r10 = r3.f31694P
            r26 = r13
            r36 = r17
            r34 = r21
            r35 = r22
            r37 = r24
            r20 = -1
            r13 = r7
            r17 = r14
            r6 = r32
            r14 = r3
            r3 = r23
            r3.g(r4, r6, r8, r10, r11)
            r10 = r3
            l2.n r3 = r12.f5310d
            l2.C r6 = r13.f31604h
            int r3 = r6.a(r3)
            int r6 = r10.k()
            if (r6 == r3) goto L_0x0235
            r10 = 1
            goto L_0x0248
        L_0x0235:
            r10 = 1
            goto L_0x025e
        L_0x0237:
            r26 = r13
            r36 = r17
            r34 = r21
            r35 = r22
            r37 = r24
            r20 = -1
            r13 = r7
            r17 = r14
            r14 = r3
            r10 = r6
        L_0x0248:
            r14.f31724s0 = r10
            r3 = r10
            r8 = r3
            goto L_0x0262
        L_0x024d:
            r10 = r6
            r26 = r13
            r36 = r17
            r34 = r21
            r35 = r22
            r37 = r24
            r20 = -1
            r13 = r7
            r17 = r14
            r14 = r3
        L_0x025e:
            r3 = r19
            r8 = r25
        L_0x0262:
            if (r8 == 0) goto L_0x0277
            r14.I(r4, r3)
            r6 = r16
            r3 = r36
        L_0x026b:
            if (r6 >= r3) goto L_0x0279
            r7 = r27[r6]
            if (r7 == 0) goto L_0x0273
            r42[r6] = r10
        L_0x0273:
            int r6 = r6 + 1
            r10 = 1
            goto L_0x026b
        L_0x0277:
            r3 = r36
        L_0x0279:
            r25 = r8
        L_0x027b:
            java.util.ArrayList<z2.j> r6 = r14.f31698T
            r6.clear()
            r7 = r16
        L_0x0282:
            if (r7 >= r3) goto L_0x0290
            r8 = r27[r7]
            if (r8 == 0) goto L_0x028d
            z2.j r8 = (z2.j) r8
            r6.add(r8)
        L_0x028d:
            int r7 = r7 + 1
            goto L_0x0282
        L_0x0290:
            r10 = 1
            r14.f31725t0 = r10
            r6 = r16
            r8 = r6
        L_0x0296:
            int r7 = r1.length
            if (r6 >= r7) goto L_0x02c7
            r7 = r27[r6]
            r9 = r26[r6]
            r10 = r37
            if (r9 != r10) goto L_0x02b1
            r7.getClass()
            r9 = r35
            r9[r6] = r7
            java.lang.Integer r8 = java.lang.Integer.valueOf(r10)
            r15.put(r7, r8)
            r8 = 1
            goto L_0x02c0
        L_0x02b1:
            r9 = r35
            r11 = r29[r6]
            if (r11 != r10) goto L_0x02c0
            if (r7 != 0) goto L_0x02bb
            r7 = 1
            goto L_0x02bd
        L_0x02bb:
            r7 = r16
        L_0x02bd:
            f7.M.m(r7)
        L_0x02c0:
            int r6 = r6 + 1
            r35 = r9
            r37 = r10
            goto L_0x0296
        L_0x02c7:
            r9 = r35
            r10 = r37
            r6 = r18
            if (r8 == 0) goto L_0x02fa
            r17[r6] = r14
            int r18 = r6 + 1
            if (r6 != 0) goto L_0x02ef
            r6 = 1
            r13.f31608l = r6
            if (r25 != 0) goto L_0x02e3
            z2.k[] r7 = r0.f31672V
            int r8 = r7.length
            if (r8 == 0) goto L_0x02e3
            r7 = r7[r16]
            if (r14 == r7) goto L_0x02fa
        L_0x02e3:
            Fc.j r7 = r0.f31662L
            java.lang.Object r7 = r7.f35181f
            android.util.SparseArray r7 = (android.util.SparseArray) r7
            r7.clear()
            r19 = r6
            goto L_0x02fa
        L_0x02ef:
            r6 = 1
            int r7 = r0.f31673W
            if (r10 >= r7) goto L_0x02f6
            r8 = r6
            goto L_0x02f8
        L_0x02f6:
            r8 = r16
        L_0x02f8:
            r13.f31608l = r8
        L_0x02fa:
            int r8 = r10 + 1
            r6 = r9
            r14 = r17
            r13 = r26
            r9 = r27
            r11 = r28
            r12 = r29
            r10 = r31
            r17 = r3
            r3 = r34
            goto L_0x0068
        L_0x030f:
            r8 = r3
            r9 = r6
            r17 = r14
            r7 = r16
            r6 = r18
            java.lang.System.arraycopy(r9, r7, r2, r7, r8)
            r1 = r17
            java.lang.Object[] r1 = o2.C2756B.Q(r6, r1)
            z2.k[] r1 = (z2.k[]) r1
            r0.f31672V = r1
            S7.O r1 = S7.C1150x.q(r1)
            F0.y r2 = new F0.y
            r3 = 14
            r2.<init>(r3)
            java.util.AbstractList r2 = S7.F.b(r1, r2)
            com.google.android.gms.internal.measurement.y2 r3 = r0.f31663M
            r3.getClass()
            I2.h r3 = new I2.h
            r3.<init>(r1, r2)
            r0.f31674X = r3
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: z2.i.o(M2.r[], boolean[], I2.N[], boolean[], long):long");
    }

    public final long q() {
        return -9223372036854775807L;
    }

    public final V s() {
        V v10 = this.f31670T;
        v10.getClass();
        return v10;
    }

    public final long t() {
        return this.f31674X.t();
    }

    public final void u(long j10, boolean z10) {
        for (k kVar : this.f31672V) {
            if (kVar.f31708d0 && !kVar.D()) {
                int length = kVar.f31701W.length;
                for (int i10 = 0; i10 < length; i10++) {
                    kVar.f31701W[i10].j(j10, z10, kVar.f31720o0[i10]);
                }
            }
        }
    }

    public final void v(long j10) {
        this.f31674X.v(j10);
    }
}
