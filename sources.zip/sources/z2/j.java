package z2;

import A6.u;
import D1.d;
import I2.N;
import O3.h;
import W7.b;
import f7.M;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import l2.n;
import o2.C2756B;
import s2.f;
import z2.k;

public final class j implements N {

    /* renamed from: f  reason: collision with root package name */
    public final int f31679f;

    /* renamed from: i  reason: collision with root package name */
    public final k f31680i;

    /* renamed from: z  reason: collision with root package name */
    public int f31681z = -1;

    public j(k kVar, int i10) {
        this.f31680i = kVar;
        this.f31679f = i10;
    }

    public final void a() {
        int i10 = this.f31681z;
        k kVar = this.f31680i;
        if (i10 == -2) {
            kVar.w();
            throw new IOException(d.i("Unable to bind a sample queue to TrackGroup with MIME type ", kVar.f31715j0.a(this.f31679f).f24150d[0].f24291n, "."));
        } else if (i10 == -1) {
            kVar.F();
        } else if (i10 != -3) {
            kVar.F();
            kVar.f31701W[i10].z();
        }
    }

    public final boolean b() {
        if (this.f31681z == -3) {
            return true;
        }
        if (!d()) {
            return false;
        }
        int i10 = this.f31681z;
        k kVar = this.f31680i;
        if (kVar.D() || !kVar.f31701W[i10].x(kVar.f31726u0)) {
            return false;
        }
        return true;
    }

    public final void c() {
        boolean z10;
        if (this.f31681z == -1) {
            z10 = true;
        } else {
            z10 = false;
        }
        M.h(z10);
        k kVar = this.f31680i;
        kVar.w();
        kVar.f31717l0.getClass();
        int[] iArr = kVar.f31717l0;
        int i10 = this.f31679f;
        int i11 = iArr[i10];
        if (i11 != -1) {
            boolean[] zArr = kVar.f31720o0;
            if (!zArr[i11]) {
                zArr[i11] = true;
                this.f31681z = i11;
            }
        } else if (kVar.f31716k0.contains(kVar.f31715j0.a(i10))) {
            i11 = -3;
            this.f31681z = i11;
        }
        i11 = -2;
        this.f31681z = i11;
    }

    public final boolean d() {
        int i10 = this.f31681z;
        if (i10 == -1 || i10 == -3 || i10 == -2) {
            return false;
        }
        return true;
    }

    public final int k(long j10) {
        Object obj;
        g gVar;
        g next;
        if (!d()) {
            return 0;
        }
        int i10 = this.f31681z;
        k kVar = this.f31680i;
        if (kVar.D()) {
            return 0;
        }
        k.b bVar = kVar.f31701W[i10];
        int v10 = bVar.v(j10, kVar.f31726u0);
        ArrayList<g> arrayList = kVar.f31693O;
        if (arrayList == null) {
            Iterator<g> it = arrayList.iterator();
            if (it.hasNext()) {
                do {
                    next = it.next();
                } while (it.hasNext());
                obj = next;
                gVar = (g) obj;
                v10 = Math.min(v10, gVar.g(i10) - bVar.t());
                bVar.I(v10);
                return v10;
            }
        } else if (!arrayList.isEmpty()) {
            obj = u.m(1, arrayList);
            gVar = (g) obj;
            if (gVar != null && !gVar.f31638K) {
                v10 = Math.min(v10, gVar.g(i10) - bVar.t());
            }
            bVar.I(v10);
            return v10;
        }
        obj = null;
        gVar = (g) obj;
        v10 = Math.min(v10, gVar.g(i10) - bVar.t());
        bVar.I(v10);
        return v10;
    }

    public final int m(h hVar, f fVar, int i10) {
        n nVar;
        h hVar2 = hVar;
        f fVar2 = fVar;
        if (this.f31681z == -3) {
            fVar2.g(4);
            return -4;
        }
        if (d()) {
            int i11 = this.f31681z;
            k kVar = this.f31680i;
            if (!kVar.D()) {
                ArrayList<g> arrayList = kVar.f31693O;
                int i12 = 0;
                if (!arrayList.isEmpty()) {
                    int i13 = 0;
                    loop0:
                    while (i13 < arrayList.size() - 1) {
                        int i14 = arrayList.get(i13).f31639k;
                        int length = kVar.f31701W.length;
                        for (int i15 = 0; i15 < length; i15++) {
                            if (kVar.f31720o0[i15] && kVar.f31701W[i15].B() == ((long) i14)) {
                                break loop0;
                            }
                        }
                        i13++;
                    }
                    C2756B.T(arrayList, 0, i13);
                    g gVar = arrayList.get(0);
                    n nVar2 = gVar.f5310d;
                    if (!nVar2.equals(kVar.f31712h0)) {
                        kVar.f31690L.b(kVar.f31713i, nVar2, gVar.f5311e, gVar.f5312f, gVar.f5313g);
                    }
                    kVar.f31712h0 = nVar2;
                }
                if (arrayList.isEmpty() || arrayList.get(0).f31638K) {
                    int C10 = kVar.f31701W[i11].C(hVar2, fVar2, i10, kVar.f31726u0);
                    if (C10 == -5) {
                        n nVar3 = (n) hVar2.f6772i;
                        nVar3.getClass();
                        if (i11 == kVar.f31707c0) {
                            int s02 = b.s0(kVar.f31701W[i11].B());
                            while (i12 < arrayList.size() && arrayList.get(i12).f31639k != s02) {
                                i12++;
                            }
                            if (i12 < arrayList.size()) {
                                nVar = arrayList.get(i12).f5310d;
                            } else {
                                nVar = kVar.f31711g0;
                                nVar.getClass();
                            }
                            nVar3 = nVar3.d(nVar);
                        }
                        hVar2.f6772i = nVar3;
                    }
                    return C10;
                }
            }
        }
        return -3;
    }
}
