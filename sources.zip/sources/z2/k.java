package z2;

import B2.c;
import D2.B;
import D2.C0557h;
import I2.C;
import I2.C0787b;
import I2.M;
import I2.O;
import I2.V;
import I2.r;
import K2.e;
import L.C0866g;
import M2.v;
import N2.d;
import N2.g;
import N2.h;
import N2.i;
import Pb.C4126p;
import R2.C1015k;
import R2.H;
import R2.p;
import S7.C1150x;
import android.net.Uri;
import android.os.Handler;
import android.util.SparseIntArray;
import androidx.media3.exoplayer.g;
import c3.C1395a;
import c3.C1396b;
import f3.C2270l;
import j$.util.Objects;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import l2.C2611C;
import l2.C2623i;
import l2.C2625k;
import l2.n;
import l2.t;
import l2.u;
import o2.C2756B;
import o2.t;
import y2.d;
import z2.C3553f;
import z2.i;

public final class k implements i.a<e>, i.e, O, p, M.c {

    /* renamed from: z0  reason: collision with root package name */
    public static final Set<Integer> f31682z0 = Collections.unmodifiableSet(new HashSet(Arrays.asList(new Integer[]{1, 2, 5})));

    /* renamed from: E  reason: collision with root package name */
    public final C3553f f31683E;

    /* renamed from: F  reason: collision with root package name */
    public final d f31684F;

    /* renamed from: G  reason: collision with root package name */
    public final n f31685G;

    /* renamed from: H  reason: collision with root package name */
    public final y2.e f31686H;

    /* renamed from: I  reason: collision with root package name */
    public final d.a f31687I;

    /* renamed from: J  reason: collision with root package name */
    public final g f31688J;

    /* renamed from: K  reason: collision with root package name */
    public final i f31689K = new i("Loader:HlsSampleStreamWrapper");

    /* renamed from: L  reason: collision with root package name */
    public final C.a f31690L;

    /* renamed from: M  reason: collision with root package name */
    public final int f31691M;

    /* renamed from: N  reason: collision with root package name */
    public final C3553f.b f31692N;

    /* renamed from: O  reason: collision with root package name */
    public final ArrayList<g> f31693O;

    /* renamed from: P  reason: collision with root package name */
    public final List<g> f31694P;

    /* renamed from: Q  reason: collision with root package name */
    public final C0557h f31695Q;

    /* renamed from: R  reason: collision with root package name */
    public final B2.b f31696R;

    /* renamed from: S  reason: collision with root package name */
    public final Handler f31697S;

    /* renamed from: T  reason: collision with root package name */
    public final ArrayList<j> f31698T;

    /* renamed from: U  reason: collision with root package name */
    public final Map<String, C2625k> f31699U;

    /* renamed from: V  reason: collision with root package name */
    public e f31700V;

    /* renamed from: W  reason: collision with root package name */
    public b[] f31701W;

    /* renamed from: X  reason: collision with root package name */
    public int[] f31702X;

    /* renamed from: Y  reason: collision with root package name */
    public final HashSet f31703Y;

    /* renamed from: Z  reason: collision with root package name */
    public final SparseIntArray f31704Z;

    /* renamed from: a0  reason: collision with root package name */
    public a f31705a0;

    /* renamed from: b0  reason: collision with root package name */
    public int f31706b0;

    /* renamed from: c0  reason: collision with root package name */
    public int f31707c0;

    /* renamed from: d0  reason: collision with root package name */
    public boolean f31708d0;
    public boolean e0;

    /* renamed from: f  reason: collision with root package name */
    public final String f31709f;

    /* renamed from: f0  reason: collision with root package name */
    public int f31710f0;

    /* renamed from: g0  reason: collision with root package name */
    public n f31711g0;

    /* renamed from: h0  reason: collision with root package name */
    public n f31712h0;

    /* renamed from: i  reason: collision with root package name */
    public final int f31713i;

    /* renamed from: i0  reason: collision with root package name */
    public boolean f31714i0;

    /* renamed from: j0  reason: collision with root package name */
    public V f31715j0;

    /* renamed from: k0  reason: collision with root package name */
    public Set<C2611C> f31716k0;

    /* renamed from: l0  reason: collision with root package name */
    public int[] f31717l0;

    /* renamed from: m0  reason: collision with root package name */
    public int f31718m0;

    /* renamed from: n0  reason: collision with root package name */
    public boolean f31719n0;

    /* renamed from: o0  reason: collision with root package name */
    public boolean[] f31720o0;

    /* renamed from: p0  reason: collision with root package name */
    public boolean[] f31721p0;

    /* renamed from: q0  reason: collision with root package name */
    public long f31722q0;

    /* renamed from: r0  reason: collision with root package name */
    public long f31723r0;

    /* renamed from: s0  reason: collision with root package name */
    public boolean f31724s0;

    /* renamed from: t0  reason: collision with root package name */
    public boolean f31725t0;

    /* renamed from: u0  reason: collision with root package name */
    public boolean f31726u0;

    /* renamed from: v0  reason: collision with root package name */
    public boolean f31727v0;

    /* renamed from: w0  reason: collision with root package name */
    public long f31728w0;

    /* renamed from: x0  reason: collision with root package name */
    public C2625k f31729x0;

    /* renamed from: y0  reason: collision with root package name */
    public g f31730y0;

    /* renamed from: z  reason: collision with root package name */
    public final i.a f31731z;

    public static class a implements H {

        /* renamed from: f  reason: collision with root package name */
        public static final n f31732f;

        /* renamed from: g  reason: collision with root package name */
        public static final n f31733g;

        /* renamed from: a  reason: collision with root package name */
        public final H f31734a;

        /* renamed from: b  reason: collision with root package name */
        public final n f31735b;

        /* renamed from: c  reason: collision with root package name */
        public n f31736c;

        /* renamed from: d  reason: collision with root package name */
        public byte[] f31737d;

        /* renamed from: e  reason: collision with root package name */
        public int f31738e;

        static {
            n.a aVar = new n.a();
            aVar.f24328m = u.p("application/id3");
            f31732f = new n(aVar);
            n.a aVar2 = new n.a();
            aVar2.f24328m = u.p("application/x-emsg");
            f31733g = new n(aVar2);
        }

        public a(H h10, int i10) {
            this.f31734a = h10;
            if (i10 == 1) {
                this.f31735b = f31732f;
            } else if (i10 == 3) {
                this.f31735b = f31733g;
            } else {
                throw new IllegalArgumentException(D1.b.j(i10, "Unknown metadataType: "));
            }
            this.f31737d = new byte[0];
            this.f31738e = 0;
        }

        public final void a(t tVar, int i10, int i11) {
            int i12 = this.f31738e + i10;
            byte[] bArr = this.f31737d;
            if (bArr.length < i12) {
                this.f31737d = Arrays.copyOf(bArr, (i12 / 2) + i12);
            }
            tVar.f(this.f31738e, this.f31737d, i10);
            this.f31738e += i10;
        }

        public final void b(long j10, int i10, int i11, int i12, H.a aVar) {
            this.f31736c.getClass();
            int i13 = this.f31738e - i12;
            t tVar = new t(Arrays.copyOfRange(this.f31737d, i13 - i11, i13));
            byte[] bArr = this.f31737d;
            System.arraycopy(bArr, i13, bArr, 0, i12);
            this.f31738e = i12;
            String str = this.f31736c.f24291n;
            n nVar = this.f31735b;
            if (!Objects.equals(str, nVar.f24291n)) {
                if ("application/x-emsg".equals(this.f31736c.f24291n)) {
                    C1395a r02 = C1396b.r0(tVar);
                    n a10 = r02.a();
                    String str2 = nVar.f24291n;
                    if (a10 == null || !Objects.equals(str2, a10.f24291n)) {
                        n a11 = r02.a();
                        o2.n.f("HlsSampleStreamWrapper", "Ignoring EMSG. Expected it to contain wrapped " + str2 + " but actual wrapped format: " + a11);
                        return;
                    }
                    byte[] c10 = r02.c();
                    c10.getClass();
                    tVar = new t(c10);
                } else {
                    o2.n.f("HlsSampleStreamWrapper", "Ignoring sample for unsupported format: " + this.f31736c.f24291n);
                    return;
                }
            }
            int a12 = tVar.a();
            H h10 = this.f31734a;
            h10.e(a12, tVar);
            h10.b(j10, i10, a12, 0, aVar);
        }

        public final int c(C2623i iVar, int i10, boolean z10) {
            return f(iVar, i10, z10);
        }

        public final void d(n nVar) {
            this.f31736c = nVar;
            this.f31734a.d(this.f31735b);
        }

        public final /* synthetic */ void e(int i10, t tVar) {
            C0866g.d(this, tVar, i10);
        }

        public final int f(C2623i iVar, int i10, boolean z10) {
            int i11 = this.f31738e + i10;
            byte[] bArr = this.f31737d;
            if (bArr.length < i11) {
                this.f31737d = Arrays.copyOf(bArr, (i11 / 2) + i11);
            }
            int read = iVar.read(this.f31737d, this.f31738e, i10);
            if (read != -1) {
                this.f31738e += read;
                return read;
            } else if (z10) {
                return -1;
            } else {
                throw new EOFException();
            }
        }
    }

    public static final class b extends M {

        /* renamed from: H  reason: collision with root package name */
        public final Map<String, C2625k> f31739H;

        /* renamed from: I  reason: collision with root package name */
        public C2625k f31740I;

        public b() {
            throw null;
        }

        public b(N2.d dVar, y2.e eVar, d.a aVar, Map map) {
            super(dVar, eVar, aVar);
            this.f31739H = map;
        }

        public final n p(n nVar) {
            int i10;
            C2625k kVar;
            C2625k kVar2 = this.f31740I;
            if (kVar2 == null) {
                kVar2 = nVar.f24295r;
            }
            if (!(kVar2 == null || (kVar = this.f31739H.get(kVar2.f24255z)) == null)) {
                kVar2 = kVar;
            }
            l2.t tVar = nVar.f24289l;
            l2.t tVar2 = null;
            if (tVar != null) {
                t.a[] aVarArr = tVar.f24443a;
                int length = aVarArr.length;
                int i11 = 0;
                while (true) {
                    if (i11 >= length) {
                        i11 = -1;
                        break;
                    }
                    t.a aVar = aVarArr[i11];
                    if ((aVar instanceof C2270l) && "com.apple.streaming.transportStreamTimestamp".equals(((C2270l) aVar).f21065b)) {
                        break;
                    }
                    i11++;
                }
                if (i11 != -1) {
                    if (length != 1) {
                        t.a[] aVarArr2 = new t.a[(length - 1)];
                        for (int i12 = 0; i12 < length; i12++) {
                            if (i12 != i11) {
                                if (i12 < i11) {
                                    i10 = i12;
                                } else {
                                    i10 = i12 - 1;
                                }
                                aVarArr2[i10] = aVarArr[i12];
                            }
                        }
                        tVar2 = new l2.t(aVarArr2);
                    }
                }
                if (!(kVar2 == nVar.f24295r && tVar == nVar.f24289l)) {
                    n.a a10 = nVar.a();
                    a10.f24332q = kVar2;
                    a10.f24326k = tVar;
                    nVar = new n(a10);
                }
                return super.p(nVar);
            }
            tVar = tVar2;
            n.a a102 = nVar.a();
            a102.f24332q = kVar2;
            a102.f24326k = tVar;
            nVar = new n(a102);
            return super.p(nVar);
        }
    }

    /* JADX WARNING: type inference failed for: r1v2, types: [z2.f$b, java.lang.Object] */
    public k(String str, int i10, i.a aVar, C3553f fVar, Map map, N2.d dVar, long j10, n nVar, y2.e eVar, d.a aVar2, g gVar, C.a aVar3, int i11) {
        this.f31709f = str;
        this.f31713i = i10;
        this.f31731z = aVar;
        this.f31683E = fVar;
        this.f31699U = map;
        this.f31684F = dVar;
        this.f31685G = nVar;
        this.f31686H = eVar;
        this.f31687I = aVar2;
        this.f31688J = gVar;
        this.f31690L = aVar3;
        this.f31691M = i11;
        ? obj = new Object();
        obj.f31617a = null;
        obj.f31618b = false;
        obj.f31619c = null;
        this.f31692N = obj;
        this.f31702X = new int[0];
        Set<Integer> set = f31682z0;
        this.f31703Y = new HashSet(set.size());
        this.f31704Z = new SparseIntArray(set.size());
        this.f31701W = new b[0];
        this.f31721p0 = new boolean[0];
        this.f31720o0 = new boolean[0];
        ArrayList<g> arrayList = new ArrayList<>();
        this.f31693O = arrayList;
        this.f31694P = Collections.unmodifiableList(arrayList);
        this.f31698T = new ArrayList<>();
        this.f31695Q = new C0557h(this, 8);
        this.f31696R = new B2.b(this, 9);
        this.f31697S = C2756B.n((Handler.Callback) null);
        this.f31722q0 = j10;
        this.f31723r0 = j10;
    }

    public static int C(int i10) {
        if (i10 == 1) {
            return 2;
        }
        if (i10 == 2) {
            return 3;
        }
        if (i10 != 3) {
            return 0;
        }
        return 1;
    }

    public static C1015k x(int i10, int i11) {
        o2.n.f("HlsSampleStreamWrapper", "Unmapped track with id " + i10 + " of type " + i11);
        return new C1015k();
    }

    public static n z(n nVar, n nVar2, boolean z10) {
        String str;
        String str2;
        int i10;
        int i11;
        if (nVar == null) {
            return nVar2;
        }
        String str3 = nVar2.f24291n;
        int i12 = u.i(str3);
        String str4 = nVar.f24288k;
        if (C2756B.u(i12, str4) == 1) {
            str2 = C2756B.v(i12, str4);
            str = u.e(str2);
        } else {
            String c10 = u.c(str4, str3);
            str = str3;
            str2 = c10;
        }
        n.a a10 = nVar2.a();
        a10.f24316a = nVar.f24278a;
        a10.f24317b = nVar.f24279b;
        a10.f24318c = C1150x.o(nVar.f24280c);
        a10.f24319d = nVar.f24281d;
        a10.f24320e = nVar.f24282e;
        a10.f24321f = nVar.f24283f;
        if (z10) {
            i10 = nVar.f24285h;
        } else {
            i10 = -1;
        }
        a10.f24323h = i10;
        if (z10) {
            i11 = nVar.f24286i;
        } else {
            i11 = -1;
        }
        a10.f24324i = i11;
        a10.f24325j = str2;
        if (i12 == 2) {
            a10.f24335t = nVar.f24298u;
            a10.f24336u = nVar.f24299v;
            a10.f24337v = nVar.f24300w;
        }
        if (str != null) {
            a10.f24328m = u.p(str);
        }
        int i13 = nVar.f24267D;
        if (i13 != -1 && i12 == 1) {
            a10.f24306C = i13;
        }
        l2.t tVar = nVar.f24289l;
        if (tVar != null) {
            l2.t tVar2 = nVar2.f24289l;
            if (tVar2 != null) {
                tVar = tVar2.b(tVar);
            }
            a10.f24326k = tVar;
        }
        return new n(a10);
    }

    public final void A(int i10) {
        ArrayList<g> arrayList;
        f7.M.m(!this.f31689K.d());
        loop0:
        while (true) {
            arrayList = this.f31693O;
            if (i10 >= arrayList.size()) {
                i10 = -1;
                break;
            }
            int i11 = i10;
            while (true) {
                if (i11 >= arrayList.size()) {
                    g gVar = arrayList.get(i10);
                    int i12 = 0;
                    while (i12 < this.f31701W.length) {
                        if (this.f31701W[i12].t() <= gVar.g(i12)) {
                            i12++;
                        }
                    }
                    break loop0;
                } else if (arrayList.get(i11).f31642n) {
                    break;
                } else {
                    i11++;
                }
            }
            i10++;
        }
        if (i10 != -1) {
            long j10 = B().f5314h;
            g gVar2 = arrayList.get(i10);
            C2756B.T(arrayList, i10, arrayList.size());
            for (int i13 = 0; i13 < this.f31701W.length; i13++) {
                this.f31701W[i13].n(gVar2.g(i13));
            }
            if (arrayList.isEmpty()) {
                this.f31723r0 = this.f31722q0;
            } else {
                ((g) A1.a.x(arrayList)).f31637J = true;
            }
            this.f31726u0 = false;
            this.f31690L.h(gVar2.f5313g, j10, this.f31706b0);
        }
    }

    public final g B() {
        return (g) A6.u.m(1, this.f31693O);
    }

    public final boolean D() {
        if (this.f31723r0 != -9223372036854775807L) {
            return true;
        }
        return false;
    }

    public final void E() {
        boolean z10;
        boolean z11;
        int i10;
        n nVar;
        boolean z12 = false;
        if (!this.f31714i0 && this.f31717l0 == null && this.f31708d0) {
            b[] bVarArr = this.f31701W;
            int length = bVarArr.length;
            int i11 = 0;
            while (i11 < length) {
                if (bVarArr[i11].w() != null) {
                    i11++;
                } else {
                    return;
                }
            }
            V v10 = this.f31715j0;
            if (v10 != null) {
                int i12 = v10.f4364a;
                int[] iArr = new int[i12];
                this.f31717l0 = iArr;
                Arrays.fill(iArr, -1);
                for (int i13 = 0; i13 < i12; i13++) {
                    int i14 = 0;
                    while (true) {
                        b[] bVarArr2 = this.f31701W;
                        if (i14 >= bVarArr2.length) {
                            break;
                        }
                        n w10 = bVarArr2[i14].w();
                        f7.M.n(w10);
                        n nVar2 = this.f31715j0.a(i13).f24150d[0];
                        String str = nVar2.f24291n;
                        String str2 = w10.f24291n;
                        int i15 = u.i(str2);
                        if (i15 == 3) {
                            if (Objects.equals(str2, str)) {
                                if ((!"application/cea-608".equals(str2) && !"application/cea-708".equals(str2)) || w10.f24272I == nVar2.f24272I) {
                                    break;
                                }
                            } else {
                                continue;
                            }
                            i14++;
                        } else if (i15 == u.i(str)) {
                            break;
                        } else {
                            i14++;
                        }
                    }
                    this.f31717l0[i13] = i14;
                }
                Iterator<j> it = this.f31698T.iterator();
                while (it.hasNext()) {
                    it.next().c();
                }
                return;
            }
            int length2 = this.f31701W.length;
            int i16 = 0;
            int i17 = -1;
            int i18 = -2;
            while (true) {
                int i19 = 2;
                if (i16 >= length2) {
                    break;
                }
                n w11 = this.f31701W[i16].w();
                f7.M.n(w11);
                String str3 = w11.f24291n;
                if (!u.o(str3)) {
                    if (u.k(str3)) {
                        i19 = 1;
                    } else if (u.n(str3)) {
                        i19 = 3;
                    } else {
                        i19 = -2;
                    }
                }
                if (C(i19) > C(i18)) {
                    i17 = i16;
                    i18 = i19;
                } else if (i19 == i18 && i17 != -1) {
                    i17 = -1;
                }
                i16++;
            }
            C2611C c10 = this.f31683E.f31604h;
            int i20 = c10.f24147a;
            this.f31718m0 = -1;
            this.f31717l0 = new int[length2];
            for (int i21 = 0; i21 < length2; i21++) {
                this.f31717l0[i21] = i21;
            }
            C2611C[] cArr = new C2611C[length2];
            int i22 = 0;
            while (i22 < length2) {
                n w12 = this.f31701W[i22].w();
                f7.M.n(w12);
                String str4 = this.f31709f;
                n nVar3 = this.f31685G;
                if (i22 == i17) {
                    n[] nVarArr = new n[i20];
                    for (int i23 = z12; i23 < i20; i23++) {
                        n nVar4 = c10.f24150d[i23];
                        if (i18 == 1 && nVar3 != null) {
                            nVar4 = nVar4.d(nVar3);
                        }
                        if (i20 == 1) {
                            nVar = w12.d(nVar4);
                        } else {
                            nVar = z(nVar4, w12, true);
                        }
                        nVarArr[i23] = nVar;
                    }
                    cArr[i22] = new C2611C(str4, nVarArr);
                    this.f31718m0 = i22;
                    z11 = false;
                } else {
                    if (i18 != 2 || !u.k(w12.f24291n)) {
                        nVar3 = null;
                    }
                    StringBuilder y10 = B.y(str4, ":muxed:");
                    if (i22 < i17) {
                        i10 = i22;
                    } else {
                        i10 = i22 - 1;
                    }
                    y10.append(i10);
                    z11 = false;
                    cArr[i22] = new C2611C(y10.toString(), z(nVar3, w12, false));
                }
                i22++;
                z12 = z11;
            }
            boolean z13 = z12;
            this.f31715j0 = y(cArr);
            if (this.f31716k0 == null) {
                z10 = true;
            } else {
                z10 = z13;
            }
            f7.M.m(z10);
            this.f31716k0 = Collections.EMPTY_SET;
            this.e0 = true;
            this.f31731z.c();
        }
    }

    public final void F() {
        this.f31689K.a();
        C3553f fVar = this.f31683E;
        C0787b bVar = fVar.f31610n;
        if (bVar == null) {
            Uri uri = fVar.f31611o;
            if (uri != null && fVar.f31615s) {
                fVar.f31603g.e(uri);
                return;
            }
            return;
        }
        throw bVar;
    }

    public final void G(C2611C[] cArr, int... iArr) {
        this.f31715j0 = y(cArr);
        this.f31716k0 = new HashSet();
        for (int a10 : iArr) {
            this.f31716k0.add(this.f31715j0.a(a10));
        }
        this.f31718m0 = 0;
        this.f31697S.post(new c(this.f31731z, 7));
        this.e0 = true;
    }

    public final void H() {
        for (b E10 : this.f31701W) {
            E10.E(this.f31724s0);
        }
        this.f31724s0 = false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0059, code lost:
        r11 = false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean I(long r9, boolean r11) {
        /*
            r8 = this;
            r8.f31722q0 = r9
            boolean r0 = r8.D()
            r1 = 1
            if (r0 == 0) goto L_0x000c
            r8.f31723r0 = r9
            return r1
        L_0x000c:
            z2.f r0 = r8.f31683E
            boolean r0 = r0.f31612p
            java.util.ArrayList<z2.g> r2 = r8.f31693O
            r3 = 0
            r4 = 0
            if (r0 == 0) goto L_0x002d
            r0 = r4
        L_0x0017:
            int r5 = r2.size()
            if (r0 >= r5) goto L_0x002d
            java.lang.Object r5 = r2.get(r0)
            z2.g r5 = (z2.g) r5
            long r6 = r5.f5313g
            int r6 = (r6 > r9 ? 1 : (r6 == r9 ? 0 : -1))
            if (r6 != 0) goto L_0x002a
            goto L_0x002e
        L_0x002a:
            int r0 = r0 + 1
            goto L_0x0017
        L_0x002d:
            r5 = r3
        L_0x002e:
            boolean r0 = r8.f31708d0
            if (r0 == 0) goto L_0x0062
            if (r11 != 0) goto L_0x0062
            z2.k$b[] r11 = r8.f31701W
            int r11 = r11.length
            r0 = r4
        L_0x0038:
            if (r0 >= r11) goto L_0x005e
            z2.k$b[] r6 = r8.f31701W
            r6 = r6[r0]
            if (r5 == 0) goto L_0x0049
            int r7 = r5.g(r0)
            boolean r6 = r6.G(r7)
            goto L_0x004d
        L_0x0049:
            boolean r6 = r6.H(r9, r4)
        L_0x004d:
            if (r6 != 0) goto L_0x005b
            boolean[] r6 = r8.f31721p0
            boolean r6 = r6[r0]
            if (r6 != 0) goto L_0x0059
            boolean r6 = r8.f31719n0
            if (r6 != 0) goto L_0x005b
        L_0x0059:
            r11 = r4
            goto L_0x005f
        L_0x005b:
            int r0 = r0 + 1
            goto L_0x0038
        L_0x005e:
            r11 = r1
        L_0x005f:
            if (r11 == 0) goto L_0x0062
            return r4
        L_0x0062:
            r8.f31723r0 = r9
            r8.f31726u0 = r4
            r2.clear()
            N2.i r9 = r8.f31689K
            boolean r10 = r9.d()
            if (r10 == 0) goto L_0x0086
            boolean r10 = r8.f31708d0
            if (r10 == 0) goto L_0x0082
            z2.k$b[] r10 = r8.f31701W
            int r11 = r10.length
        L_0x0078:
            if (r4 >= r11) goto L_0x0082
            r0 = r10[r4]
            r0.k()
            int r4 = r4 + 1
            goto L_0x0078
        L_0x0082:
            r9.b()
            return r1
        L_0x0086:
            r9.f6364c = r3
            r8.H()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: z2.k.I(long, boolean):boolean");
    }

    public final void b() {
        this.f31727v0 = true;
        this.f31697S.post(this.f31696R);
    }

    public final void d() {
        for (b D10 : this.f31701W) {
            D10.D();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r30v2, resolved type: z2.a} */
    /* JADX WARNING: type inference failed for: r2v26, types: [java.io.IOException, I2.b] */
    /* JADX WARNING: Code restructure failed: missing block: B:140:0x02d6, code lost:
        if (r15 < r5.f5314h) goto L_0x02db;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x026c  */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x0272  */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x027e  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x02fb  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x0302  */
    /* JADX WARNING: Removed duplicated region for block: B:151:0x0310  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x0312  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x0328  */
    /* JADX WARNING: Removed duplicated region for block: B:156:0x032d  */
    /* JADX WARNING: Removed duplicated region for block: B:159:0x034f  */
    /* JADX WARNING: Removed duplicated region for block: B:160:0x0352  */
    /* JADX WARNING: Removed duplicated region for block: B:162:0x0356  */
    /* JADX WARNING: Removed duplicated region for block: B:163:0x0360  */
    /* JADX WARNING: Removed duplicated region for block: B:166:0x0365  */
    /* JADX WARNING: Removed duplicated region for block: B:167:0x0372  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x037a  */
    /* JADX WARNING: Removed duplicated region for block: B:181:0x03c0  */
    /* JADX WARNING: Removed duplicated region for block: B:184:0x03d3  */
    /* JADX WARNING: Removed duplicated region for block: B:210:0x041b  */
    /* JADX WARNING: Removed duplicated region for block: B:213:0x0441  */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x021e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean e(androidx.media3.exoplayer.g r62) {
        /*
            r61 = this;
            r0 = r61
            r1 = 1
            boolean r2 = r0.f31726u0
            r3 = 0
            if (r2 != 0) goto L_0x0016
            N2.i r2 = r0.f31689K
            boolean r4 = r2.d()
            if (r4 != 0) goto L_0x0016
            boolean r4 = r2.c()
            if (r4 == 0) goto L_0x001a
        L_0x0016:
            r25 = r3
            goto L_0x0517
        L_0x001a:
            boolean r4 = r0.D()
            if (r4 == 0) goto L_0x0034
            java.util.List r4 = java.util.Collections.EMPTY_LIST
            long r5 = r0.f31723r0
            z2.k$b[] r7 = r0.f31701W
            int r8 = r7.length
            r9 = r3
        L_0x0028:
            if (r9 >= r8) goto L_0x0032
            r10 = r7[r9]
            long r11 = r0.f31723r0
            r10.f4325t = r11
            int r9 = r9 + r1
            goto L_0x0028
        L_0x0032:
            r14 = r4
            goto L_0x004c
        L_0x0034:
            z2.g r4 = r0.B()
            boolean r5 = r4.f31635H
            if (r5 == 0) goto L_0x0040
            long r4 = r4.f5314h
        L_0x003e:
            r5 = r4
            goto L_0x0049
        L_0x0040:
            long r5 = r0.f31722q0
            long r7 = r4.f5313g
            long r4 = java.lang.Math.max(r5, r7)
            goto L_0x003e
        L_0x0049:
            java.util.List<z2.g> r4 = r0.f31694P
            goto L_0x0032
        L_0x004c:
            z2.f$b r4 = r0.f31692N
            r7 = 0
            r4.f31617a = r7
            r4.f31618b = r3
            r4.f31619c = r7
            boolean r8 = r0.e0
            if (r8 != 0) goto L_0x0063
            boolean r8 = r14.isEmpty()
            if (r8 != 0) goto L_0x0060
            goto L_0x0063
        L_0x0060:
            r16 = r3
            goto L_0x0065
        L_0x0063:
            r16 = r1
        L_0x0065:
            z2.f r8 = r0.f31683E
            boolean r9 = r14.isEmpty()
            if (r9 == 0) goto L_0x006f
            r9 = r7
            goto L_0x0075
        L_0x006f:
            java.lang.Object r9 = A1.a.x(r14)
            z2.g r9 = (z2.g) r9
        L_0x0075:
            if (r9 != 0) goto L_0x007b
            r11 = -1
        L_0x0078:
            r12 = r62
            goto L_0x0084
        L_0x007b:
            l2.C r11 = r8.f31604h
            l2.n r12 = r9.f5310d
            int r11 = r11.a(r12)
            goto L_0x0078
        L_0x0084:
            long r12 = r12.f15278a
            long r17 = r5 - r12
            r19 = r11
            long r10 = r8.f31614r
            r21 = r2
            r1 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            int r22 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r22 == 0) goto L_0x0099
            long r10 = r10 - r12
            goto L_0x009a
        L_0x0099:
            r10 = r1
        L_0x009a:
            if (r9 == 0) goto L_0x00bf
            boolean r7 = r8.f31612p
            if (r7 != 0) goto L_0x00bf
            r23 = r1
            long r1 = r9.f5314h
            r26 = r4
            long r3 = r9.f5313g
            long r1 = r1 - r3
            long r3 = r17 - r1
            r27 = r1
            r1 = 0
            long r17 = java.lang.Math.max(r1, r3)
            int r3 = (r10 > r23 ? 1 : (r10 == r23 ? 0 : -1))
            if (r3 == 0) goto L_0x00bd
            long r10 = r10 - r27
            long r10 = java.lang.Math.max(r1, r10)
        L_0x00bd:
            r1 = -1
            goto L_0x00c4
        L_0x00bf:
            r23 = r1
            r26 = r4
            goto L_0x00bd
        L_0x00c4:
            K2.n[] r15 = r8.a(r9, r5)
            M2.r r7 = r8.f31613q
            r3 = r1
            r4 = r8
            r2 = r19
            r1 = 0
            r59 = r5
            r5 = r9
            r8 = r12
            r12 = r10
            r10 = r17
            r17 = r59
            r7.g(r8, r10, r12, r14, r15)
            M2.r r6 = r4.f31613q
            int r12 = r6.k()
            if (r2 == r12) goto L_0x00e5
            r6 = 1
            goto L_0x00e6
        L_0x00e5:
            r6 = 0
        L_0x00e6:
            android.net.Uri[] r13 = r4.f31601e
            r14 = r13[r12]
            A2.b r15 = r4.f31603g
            boolean r7 = r15.d(r14)
            if (r7 != 0) goto L_0x0106
            r7 = r26
            r7.f31619c = r14
            boolean r1 = r4.f31615s
            android.net.Uri r2 = r4.f31611o
            boolean r2 = r14.equals(r2)
            r1 = r1 & r2
            r4.f31615s = r1
            r4.f31611o = r14
            r1 = r7
            goto L_0x047c
        L_0x0106:
            r8 = 1
            A2.e r7 = r15.b(r8, r14)
            r7.getClass()
            boolean r8 = r7.f170c
            r4.f31612p = r8
            boolean r8 = r7.f98o
            long r9 = r7.f91h
            if (r8 == 0) goto L_0x011d
            r19 = r2
            r1 = r23
            goto L_0x0127
        L_0x011d:
            r19 = r2
            long r1 = r7.f104u
            long r1 = r1 + r9
            r8 = r4
            long r3 = r15.f65O
            long r1 = r1 - r3
            r4 = r8
        L_0x0127:
            r4.f31614r = r1
            long r1 = r15.f65O
            long r9 = r9 - r1
            r8 = r9
            r10 = r17
            r1 = r26
            android.util.Pair r2 = r4.c(r5, r6, r7, r8, r10)
            java.lang.Object r3 = r2.first
            java.lang.Long r3 = (java.lang.Long) r3
            long r17 = r3.longValue()
            java.lang.Object r2 = r2.second
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            r62 = r2
            long r2 = r7.f94k
            int r2 = (r17 > r2 ? 1 : (r17 == r2 ? 0 : -1))
            if (r2 >= 0) goto L_0x017d
            if (r5 == 0) goto L_0x017d
            if (r6 == 0) goto L_0x017d
            r14 = r13[r19]
            r8 = 1
            A2.e r7 = r15.b(r8, r14)
            r7.getClass()
            long r2 = r15.f65O
            long r8 = r7.f91h
            long r8 = r8 - r2
            r6 = 0
            android.util.Pair r2 = r4.c(r5, r6, r7, r8, r10)
            java.lang.Object r3 = r2.first
            java.lang.Long r3 = (java.lang.Long) r3
            long r17 = r3.longValue()
            java.lang.Object r2 = r2.second
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            r6 = r2
            r9 = r8
            r8 = r19
            r11 = r8
        L_0x017a:
            r2 = r17
            goto L_0x0184
        L_0x017d:
            r6 = r62
            r9 = r8
            r11 = r12
            r8 = r19
            goto L_0x017a
        L_0x0184:
            if (r11 == r8) goto L_0x018e
            r12 = -1
            if (r8 == r12) goto L_0x018e
            r8 = r13[r8]
            r15.a(r8)
        L_0x018e:
            long r12 = r7.f94k
            int r8 = (r2 > r12 ? 1 : (r2 == r12 ? 0 : -1))
            if (r8 >= 0) goto L_0x019d
            I2.b r2 = new I2.b
            r2.<init>()
            r4.f31610n = r2
            goto L_0x047c
        L_0x019d:
            r17 = r9
            long r8 = r2 - r12
            int r8 = (int) r8
            S7.x r9 = r7.f101r
            int r10 = r9.size()
            r28 = 1
            S7.x r15 = r7.f102s
            if (r8 != r10) goto L_0x01c6
            r10 = -1
            if (r6 == r10) goto L_0x01b2
            goto L_0x01b3
        L_0x01b2:
            r6 = 0
        L_0x01b3:
            int r8 = r15.size()
            if (r6 >= r8) goto L_0x021b
            z2.f$e r8 = new z2.f$e
            java.lang.Object r10 = r15.get(r6)
            A2.e$f r10 = (A2.e.f) r10
            r8.<init>(r10, r2, r6)
        L_0x01c4:
            r6 = r8
            goto L_0x021c
        L_0x01c6:
            java.lang.Object r10 = r9.get(r8)
            A2.e$e r10 = (A2.e.C0001e) r10
            r19 = r8
            r8 = -1
            if (r6 != r8) goto L_0x01d7
            z2.f$e r6 = new z2.f$e
            r6.<init>(r10, r2, r8)
            goto L_0x021c
        L_0x01d7:
            S7.x r8 = r10.f131N
            int r8 = r8.size()
            if (r6 >= r8) goto L_0x01ed
            z2.f$e r8 = new z2.f$e
            S7.x r10 = r10.f131N
            java.lang.Object r10 = r10.get(r6)
            A2.e$f r10 = (A2.e.f) r10
            r8.<init>(r10, r2, r6)
            goto L_0x01c4
        L_0x01ed:
            r20 = 1
            int r8 = r19 + 1
            int r6 = r9.size()
            if (r8 >= r6) goto L_0x0206
            z2.f$e r6 = new z2.f$e
            java.lang.Object r8 = r9.get(r8)
            A2.e$f r8 = (A2.e.f) r8
            long r2 = r2 + r28
            r15 = -1
            r6.<init>(r8, r2, r15)
            goto L_0x021c
        L_0x0206:
            boolean r6 = r15.isEmpty()
            if (r6 != 0) goto L_0x021b
            z2.f$e r6 = new z2.f$e
            r8 = 0
            java.lang.Object r10 = r15.get(r8)
            A2.e$f r10 = (A2.e.f) r10
            long r2 = r2 + r28
            r6.<init>(r10, r2, r8)
            goto L_0x021c
        L_0x021b:
            r6 = 0
        L_0x021c:
            if (r6 != 0) goto L_0x0251
            boolean r2 = r7.f98o
            if (r2 != 0) goto L_0x0233
            r1.f31619c = r14
            boolean r2 = r4.f31615s
            android.net.Uri r3 = r4.f31611o
            boolean r3 = r14.equals(r3)
            r2 = r2 & r3
            r4.f31615s = r2
            r4.f31611o = r14
            goto L_0x047c
        L_0x0233:
            if (r16 != 0) goto L_0x023b
            boolean r2 = r9.isEmpty()
            if (r2 == 0) goto L_0x023d
        L_0x023b:
            r8 = 1
            goto L_0x0253
        L_0x023d:
            z2.f$e r6 = new z2.f$e
            java.lang.Object r2 = A1.a.x(r9)
            A2.e$f r2 = (A2.e.f) r2
            int r3 = r9.size()
            long r8 = (long) r3
            long r12 = r12 + r8
            long r12 = r12 - r28
            r15 = -1
            r6.<init>(r2, r12, r15)
        L_0x0251:
            r8 = 0
            goto L_0x0257
        L_0x0253:
            r1.f31618b = r8
            goto L_0x047c
        L_0x0257:
            r4.f31615s = r8
            r2 = 0
            r4.f31611o = r2
            android.os.SystemClock.elapsedRealtime()
            A2.e$f r2 = r6.f31623a
            A2.e$e r3 = r2.f141i
            java.lang.String r8 = r7.f168a
            if (r3 == 0) goto L_0x0272
            java.lang.String r3 = r3.f135H
            if (r3 != 0) goto L_0x026c
            goto L_0x0272
        L_0x026c:
            android.net.Uri r3 = o2.z.d(r8, r3)
        L_0x0270:
            r9 = 1
            goto L_0x0274
        L_0x0272:
            r3 = 0
            goto L_0x0270
        L_0x0274:
            z2.f$a r10 = r4.d(r3, r11, r9)
            r1.f31617a = r10
            if (r10 == 0) goto L_0x027e
            goto L_0x047c
        L_0x027e:
            java.lang.String r9 = r2.f135H
            if (r9 != 0) goto L_0x0285
            r9 = 0
        L_0x0283:
            r10 = 0
            goto L_0x028a
        L_0x0285:
            android.net.Uri r9 = o2.z.d(r8, r9)
            goto L_0x0283
        L_0x028a:
            z2.f$a r12 = r4.d(r9, r11, r10)
            r1.f31617a = r12
            if (r12 == 0) goto L_0x0294
            goto L_0x047c
        L_0x0294:
            long r12 = r2.f133F
            if (r5 != 0) goto L_0x029f
            java.util.concurrent.atomic.AtomicInteger r10 = z2.g.f31627L
        L_0x029a:
            r19 = r11
        L_0x029c:
            r57 = 0
            goto L_0x02dd
        L_0x029f:
            android.net.Uri r10 = r5.f31641m
            boolean r10 = r14.equals(r10)
            if (r10 == 0) goto L_0x02ac
            boolean r10 = r5.f31635H
            if (r10 == 0) goto L_0x02ac
            goto L_0x029a
        L_0x02ac:
            long r15 = r17 + r12
            boolean r10 = r2 instanceof A2.e.c
            r19 = r10
            boolean r10 = r7.f170c
            if (r19 == 0) goto L_0x02cc
            r19 = r10
            r10 = r2
            A2.e$c r10 = (A2.e.c) r10
            boolean r10 = r10.f125M
            if (r10 != 0) goto L_0x02c9
            int r10 = r6.f31625c
            if (r10 != 0) goto L_0x02c6
            if (r19 == 0) goto L_0x02c6
            goto L_0x02c9
        L_0x02c6:
            r19 = 0
            goto L_0x02ce
        L_0x02c9:
            r19 = 1
            goto L_0x02ce
        L_0x02cc:
            r19 = r10
        L_0x02ce:
            if (r19 == 0) goto L_0x02d9
            r19 = r11
            long r10 = r5.f5314h
            int r10 = (r15 > r10 ? 1 : (r15 == r10 ? 0 : -1))
            if (r10 >= 0) goto L_0x029c
            goto L_0x02db
        L_0x02d9:
            r19 = r11
        L_0x02db:
            r57 = 1
        L_0x02dd:
            boolean r10 = r6.f31626d
            if (r57 == 0) goto L_0x02e5
            if (r10 == 0) goto L_0x02e5
            goto L_0x047c
        L_0x02e5:
            l2.n[] r11 = r4.f31602f
            r32 = r11[r19]
            M2.r r11 = r4.f31613q
            int r39 = r11.n()
            M2.r r11 = r4.f31613q
            java.lang.Object r40 = r11.q()
            boolean r11 = r4.f31608l
            Pb.p r15 = r4.f31606j
            if (r9 != 0) goto L_0x0302
            r15.getClass()
            r16 = r10
            r9 = 0
            goto L_0x030e
        L_0x0302:
            r16 = r10
            java.lang.Object r10 = r15.f37552f
            z2.e r10 = (z2.C3552e) r10
            java.lang.Object r9 = r10.get(r9)
            byte[] r9 = (byte[]) r9
        L_0x030e:
            if (r3 != 0) goto L_0x0312
            r3 = 0
            goto L_0x031c
        L_0x0312:
            java.lang.Object r10 = r15.f37552f
            z2.e r10 = (z2.C3552e) r10
            java.lang.Object r3 = r10.get(r3)
            byte[] r3 = (byte[]) r3
        L_0x031c:
            java.util.concurrent.atomic.AtomicInteger r10 = z2.g.f31627L
            java.util.Map r45 = java.util.Collections.EMPTY_MAP
            java.lang.String r10 = r2.f140f
            android.net.Uri r10 = o2.z.d(r8, r10)
            if (r16 == 0) goto L_0x032d
            r15 = 8
            r51 = r15
            goto L_0x032f
        L_0x032d:
            r51 = 0
        L_0x032f:
            java.lang.String r15 = "The uri must be set."
            f7.M.o(r10, r15)
            q2.i r31 = new q2.i
            r44 = 0
            r50 = 0
            r43 = 1
            r42 = r10
            r19 = r11
            long r10 = r2.f137J
            r46 = r10
            long r10 = r2.f138K
            r48 = r10
            r41 = r31
            r41.<init>(r42, r43, r44, r45, r46, r48, r50, r51)
            if (r9 == 0) goto L_0x0352
            r33 = 1
            goto L_0x0354
        L_0x0352:
            r33 = 0
        L_0x0354:
            if (r33 == 0) goto L_0x0360
            java.lang.String r10 = r2.f136I
            r10.getClass()
            byte[] r10 = z2.g.f(r10)
            goto L_0x0361
        L_0x0360:
            r10 = 0
        L_0x0361:
            q2.f r11 = r4.f31598b
            if (r9 == 0) goto L_0x0372
            r10.getClass()
            r26 = r12
            z2.a r12 = new z2.a
            r12.<init>(r11, r9, r10)
            r30 = r12
            goto L_0x0376
        L_0x0372:
            r26 = r12
            r30 = r11
        L_0x0376:
            A2.e$e r9 = r2.f141i
            if (r9 == 0) goto L_0x03c0
            if (r3 == 0) goto L_0x037e
            r10 = 1
            goto L_0x037f
        L_0x037e:
            r10 = 0
        L_0x037f:
            if (r10 == 0) goto L_0x038b
            java.lang.String r12 = r9.f136I
            r12.getClass()
            byte[] r12 = z2.g.f(r12)
            goto L_0x038c
        L_0x038b:
            r12 = 0
        L_0x038c:
            java.lang.String r13 = r9.f140f
            android.net.Uri r8 = o2.z.d(r8, r13)
            f7.M.o(r8, r15)
            q2.i r41 = new q2.i
            r13 = r1
            long r0 = r9.f137J
            r51 = 0
            r43 = 1
            r44 = 0
            r46 = r0
            long r0 = r9.f138K
            r50 = 0
            r48 = r0
            r42 = r8
            r41.<init>(r42, r43, r44, r45, r46, r48, r50, r51)
            if (r3 == 0) goto L_0x03b8
            r12.getClass()
            z2.a r0 = new z2.a
            r0.<init>(r11, r3, r12)
            goto L_0x03b9
        L_0x03b8:
            r0 = r11
        L_0x03b9:
            r34 = r0
            r36 = r10
            r0 = r41
            goto L_0x03c6
        L_0x03c0:
            r13 = r1
            r0 = 0
            r34 = 0
            r36 = 0
        L_0x03c6:
            long r41 = r17 + r26
            long r8 = r2.f142z
            long r43 = r41 + r8
            int r1 = r7.f93j
            int r3 = r2.f132E
            int r1 = r1 + r3
            if (r5 == 0) goto L_0x041b
            q2.i r3 = r5.f31645q
            if (r0 == r3) goto L_0x03f0
            if (r0 == 0) goto L_0x03ee
            if (r3 == 0) goto L_0x03ee
            android.net.Uri r7 = r0.f26879a
            android.net.Uri r8 = r3.f26879a
            boolean r7 = r7.equals(r8)
            if (r7 == 0) goto L_0x03ee
            long r7 = r0.f26883e
            long r9 = r3.f26883e
            int r3 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r3 != 0) goto L_0x03ee
            goto L_0x03f0
        L_0x03ee:
            r3 = 0
            goto L_0x03f1
        L_0x03f0:
            r3 = 1
        L_0x03f1:
            android.net.Uri r7 = r5.f31641m
            boolean r7 = r14.equals(r7)
            if (r7 == 0) goto L_0x03ff
            boolean r7 = r5.f31635H
            if (r7 == 0) goto L_0x03ff
            r7 = 1
            goto L_0x0400
        L_0x03ff:
            r7 = 0
        L_0x0400:
            if (r3 == 0) goto L_0x040f
            if (r7 == 0) goto L_0x040f
            boolean r3 = r5.f31637J
            if (r3 != 0) goto L_0x040f
            int r3 = r5.f31640l
            if (r3 != r1) goto L_0x040f
            z2.h r7 = r5.f31630C
            goto L_0x0410
        L_0x040f:
            r7 = 0
        L_0x0410:
            f3.g r3 = r5.f31653y
            o2.t r5 = r5.f31654z
            r56 = r5
            r54 = r7
        L_0x0418:
            r55 = r3
            goto L_0x042d
        L_0x041b:
            f3.g r3 = new f3.g
            r5 = 0
            r3.<init>(r5)
            o2.t r7 = new o2.t
            r8 = 10
            r7.<init>((int) r8)
            r54 = r5
            r56 = r7
            goto L_0x0418
        L_0x042d:
            z2.g r28 = new z2.g
            r20 = 1
            r48 = r16 ^ 1
            Fc.j r3 = r4.f31600d
            java.lang.Object r3 = r3.f35181f
            android.util.SparseArray r3 = (android.util.SparseArray) r3
            java.lang.Object r5 = r3.get(r1)
            o2.y r5 = (o2.y) r5
            if (r5 != 0) goto L_0x044e
            o2.y r5 = new o2.y
            r7 = 9223372036854775806(0x7ffffffffffffffe, double:NaN)
            r5.<init>(r7)
            r3.put(r1, r5)
        L_0x044e:
            r52 = r5
            int r3 = r6.f31625c
            boolean r5 = r2.f139L
            z2.d r7 = r4.f31597a
            java.util.List<l2.n> r8 = r4.f31605i
            long r9 = r6.f31624b
            l2.k r2 = r2.f134G
            u2.j r4 = r4.f31607k
            r35 = r0
            r49 = r1
            r53 = r2
            r47 = r3
            r58 = r4
            r50 = r5
            r29 = r7
            r38 = r8
            r45 = r9
            r37 = r14
            r51 = r19
            r28.<init>(r29, r30, r31, r32, r33, r34, r35, r36, r37, r38, r39, r40, r41, r43, r45, r47, r48, r49, r50, r51, r52, r53, r54, r55, r56, r57, r58)
            r0 = r28
            r1 = r13
            r1.f31617a = r0
        L_0x047c:
            boolean r0 = r1.f31618b
            K2.e r2 = r1.f31617a
            android.net.Uri r1 = r1.f31619c
            if (r0 == 0) goto L_0x048e
            r0 = r61
            r3 = r23
            r0.f31723r0 = r3
            r8 = 1
            r0.f31726u0 = r8
            return r8
        L_0x048e:
            r0 = r61
            r8 = 1
            if (r2 != 0) goto L_0x04ac
            if (r1 == 0) goto L_0x04a9
            z2.i$a r2 = r0.f31731z
            z2.i r2 = z2.i.this
            A2.b r2 = r2.f31676i
            java.util.HashMap<android.net.Uri, A2.b$b> r2 = r2.f55E
            java.lang.Object r1 = r2.get(r1)
            A2.b$b r1 = (A2.b.C0000b) r1
            r1.c(r8)
            r25 = 0
            return r25
        L_0x04a9:
            r25 = 0
            goto L_0x0517
        L_0x04ac:
            boolean r1 = r2 instanceof z2.g
            if (r1 == 0) goto L_0x0506
            r1 = r2
            z2.g r1 = (z2.g) r1
            r0.f31730y0 = r1
            l2.n r3 = r1.f5310d
            r0.f31711g0 = r3
            r3 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            r0.f31723r0 = r3
            java.util.ArrayList<z2.g> r3 = r0.f31693O
            r3.add(r1)
            S7.x$b r3 = S7.C1150x.f9860i
            S7.x$a r3 = new S7.x$a
            r3.<init>()
            z2.k$b[] r4 = r0.f31701W
            int r5 = r4.length
            r8 = 0
        L_0x04d0:
            if (r8 >= r5) goto L_0x04e5
            r6 = r4[r8]
            int r7 = r6.f4322q
            int r6 = r6.f4321p
            int r7 = r7 + r6
            java.lang.Integer r6 = java.lang.Integer.valueOf(r7)
            r3.c(r6)
            r20 = 1
            int r8 = r8 + 1
            goto L_0x04d0
        L_0x04e5:
            S7.O r3 = r3.g()
            r1.f31631D = r0
            r1.f31636I = r3
            z2.k$b[] r3 = r0.f31701W
            int r4 = r3.length
            r5 = 0
        L_0x04f1:
            if (r5 >= r4) goto L_0x0506
            r6 = r3[r5]
            r6.getClass()
            int r7 = r1.f31639k
            long r7 = (long) r7
            r6.f4301C = r7
            boolean r7 = r1.f31642n
            r8 = 1
            if (r7 == 0) goto L_0x0504
            r6.f4305G = r8
        L_0x0504:
            int r5 = r5 + r8
            goto L_0x04f1
        L_0x0506:
            r8 = 1
            r0.f31700V = r2
            N2.g r1 = r0.f31688J
            int r3 = r2.f5309c
            int r1 = r1.c(r3)
            r3 = r21
            r3.f(r2, r0, r1)
            return r8
        L_0x0517:
            return r25
        */
        throw new UnsupportedOperationException("Method not decompiled: z2.k.e(androidx.media3.exoplayer.g):boolean");
    }

    public final long f() {
        if (D()) {
            return this.f31723r0;
        }
        if (this.f31726u0) {
            return Long.MIN_VALUE;
        }
        return B().f5314h;
    }

    public final void h(i.d dVar, long j10, long j11, boolean z10) {
        e eVar = (e) dVar;
        this.f31700V = null;
        long j12 = eVar.f5307a;
        q2.u uVar = eVar.f5315i;
        Uri uri = uVar.f26937z;
        r rVar = new r(uVar.f26934E, j11);
        this.f31688J.getClass();
        this.f31690L.c(rVar, eVar.f5309c, this.f31713i, eVar.f5310d, eVar.f5311e, eVar.f5312f, eVar.f5313g, eVar.f5314h);
        if (!z10) {
            if (D() || this.f31710f0 == 0) {
                H();
            }
            if (this.f31710f0 > 0) {
                this.f31731z.b(this);
            }
        }
    }

    /* JADX WARNING: Failed to insert additional move for type inference */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final R2.H k(int r12, int r13) {
        /*
            r11 = this;
            r0 = 1
            java.lang.Integer r1 = java.lang.Integer.valueOf(r13)
            java.util.Set<java.lang.Integer> r2 = f31682z0
            boolean r1 = r2.contains(r1)
            java.util.HashSet r3 = r11.f31703Y
            android.util.SparseIntArray r4 = r11.f31704Z
            r5 = 0
            r6 = 0
            if (r1 == 0) goto L_0x0044
            java.lang.Integer r1 = java.lang.Integer.valueOf(r13)
            boolean r1 = r2.contains(r1)
            f7.M.h(r1)
            r1 = -1
            int r2 = r4.get(r13, r1)
            if (r2 != r1) goto L_0x0026
            goto L_0x0055
        L_0x0026:
            java.lang.Integer r1 = java.lang.Integer.valueOf(r13)
            boolean r1 = r3.add(r1)
            if (r1 == 0) goto L_0x0034
            int[] r1 = r11.f31702X
            r1[r2] = r12
        L_0x0034:
            int[] r1 = r11.f31702X
            r1 = r1[r2]
            if (r1 != r12) goto L_0x003f
            z2.k$b[] r1 = r11.f31701W
            r6 = r1[r2]
            goto L_0x0055
        L_0x003f:
            R2.k r6 = x(r12, r13)
            goto L_0x0055
        L_0x0044:
            r1 = r5
        L_0x0045:
            z2.k$b[] r2 = r11.f31701W
            int r7 = r2.length
            if (r1 >= r7) goto L_0x0055
            int[] r7 = r11.f31702X
            r7 = r7[r1]
            if (r7 != r12) goto L_0x0053
            r6 = r2[r1]
            goto L_0x0055
        L_0x0053:
            int r1 = r1 + r0
            goto L_0x0045
        L_0x0055:
            if (r6 != 0) goto L_0x00e7
            boolean r1 = r11.f31727v0
            if (r1 == 0) goto L_0x0060
            R2.k r12 = x(r12, r13)
            return r12
        L_0x0060:
            z2.k$b[] r1 = r11.f31701W
            int r1 = r1.length
            if (r13 == r0) goto L_0x0068
            r2 = 2
            if (r13 != r2) goto L_0x0069
        L_0x0068:
            r5 = r0
        L_0x0069:
            z2.k$b r6 = new z2.k$b
            y2.d$a r2 = r11.f31687I
            N2.d r7 = r11.f31684F
            java.util.Map<java.lang.String, l2.k> r8 = r11.f31699U
            y2.e r9 = r11.f31686H
            r6.<init>(r7, r9, r2, r8)
            long r7 = r11.f31722q0
            r6.f4325t = r7
            if (r5 == 0) goto L_0x0082
            l2.k r2 = r11.f31729x0
            r6.f31740I = r2
            r6.f4331z = r0
        L_0x0082:
            long r7 = r11.f31728w0
            long r9 = r6.f4304F
            int r2 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r2 == 0) goto L_0x008e
            r6.f4304F = r7
            r6.f4331z = r0
        L_0x008e:
            z2.g r2 = r11.f31730y0
            if (r2 == 0) goto L_0x0097
            int r2 = r2.f31639k
            long r7 = (long) r2
            r6.f4301C = r7
        L_0x0097:
            r6.f4311f = r11
            int[] r2 = r11.f31702X
            int r7 = r1 + 1
            int[] r2 = java.util.Arrays.copyOf(r2, r7)
            r11.f31702X = r2
            r2[r1] = r12
            z2.k$b[] r12 = r11.f31701W
            int r2 = o2.C2756B.f25811a
            int r2 = r12.length
            int r2 = r2 + r0
            java.lang.Object[] r0 = java.util.Arrays.copyOf(r12, r2)
            int r12 = r12.length
            r0[r12] = r6
            z2.k$b[] r0 = (z2.k.b[]) r0
            r11.f31701W = r0
            boolean[] r12 = r11.f31721p0
            boolean[] r12 = java.util.Arrays.copyOf(r12, r7)
            r11.f31721p0 = r12
            r12[r1] = r5
            boolean r12 = r11.f31719n0
            r12 = r12 | r5
            r11.f31719n0 = r12
            java.lang.Integer r12 = java.lang.Integer.valueOf(r13)
            r3.add(r12)
            r4.append(r13, r1)
            int r12 = C(r13)
            int r0 = r11.f31706b0
            int r0 = C(r0)
            if (r12 <= r0) goto L_0x00df
            r11.f31707c0 = r1
            r11.f31706b0 = r13
        L_0x00df:
            boolean[] r12 = r11.f31720o0
            boolean[] r12 = java.util.Arrays.copyOf(r12, r7)
            r11.f31720o0 = r12
        L_0x00e7:
            r12 = 5
            if (r13 != r12) goto L_0x00fa
            z2.k$a r12 = r11.f31705a0
            if (r12 != 0) goto L_0x00f7
            z2.k$a r12 = new z2.k$a
            int r13 = r11.f31691M
            r12.<init>(r6, r13)
            r11.f31705a0 = r12
        L_0x00f7:
            z2.k$a r12 = r11.f31705a0
            return r12
        L_0x00fa:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: z2.k.k(int, int):R2.H");
    }

    public final boolean l() {
        return this.f31689K.d();
    }

    public final void m() {
        this.f31697S.post(this.f31695Q);
    }

    public final void n(i.d dVar, long j10, long j11, int i10) {
        r rVar;
        e eVar = (e) dVar;
        if (i10 == 0) {
            long j12 = eVar.f5307a;
            rVar = new r(eVar.f5308b);
        } else {
            long j13 = eVar.f5307a;
            q2.u uVar = eVar.f5315i;
            Uri uri = uVar.f26937z;
            rVar = new r(uVar.f26934E, j11);
        }
        r rVar2 = rVar;
        int i11 = eVar.f5309c;
        this.f31690L.g(rVar2, i11, this.f31713i, eVar.f5310d, eVar.f5311e, eVar.f5312f, eVar.f5313g, eVar.f5314h, i10);
    }

    public final i.b p(i.d dVar, long j10, long j11, IOException iOException, int i10) {
        boolean z10;
        i.b bVar;
        int i11;
        IOException iOException2 = iOException;
        e eVar = (e) dVar;
        boolean z11 = eVar instanceof g;
        if (z11 && !((g) eVar).f31638K && (iOException2 instanceof q2.r) && ((i11 = ((q2.r) iOException2).f26922E) == 410 || i11 == 404)) {
            return N2.i.f6359d;
        }
        long j12 = eVar.f5315i.f26936i;
        boolean z12 = z11;
        q2.u uVar = eVar.f5315i;
        Uri uri = uVar.f26937z;
        r rVar = new r(uVar.f26934E, j11);
        C2756B.b0(eVar.f5313g);
        C2756B.b0(eVar.f5314h);
        h.c cVar = new h.c(iOException2, i10);
        C3553f fVar = this.f31683E;
        h.a a10 = v.a(fVar.f31613q);
        g gVar = this.f31688J;
        h.b a11 = gVar.a(a10, cVar);
        boolean z13 = false;
        if (a11 == null || a11.f6355a != 2) {
            z10 = false;
        } else {
            M2.r rVar2 = fVar.f31613q;
            z10 = rVar2.o(rVar2.u(fVar.f31604h.a(eVar.f5310d)), a11.f6356b);
        }
        if (z10) {
            if (z12 && j12 == 0) {
                ArrayList<g> arrayList = this.f31693O;
                if (arrayList.remove(arrayList.size() - 1) == eVar) {
                    z13 = true;
                }
                f7.M.m(z13);
                if (arrayList.isEmpty()) {
                    this.f31723r0 = this.f31722q0;
                } else {
                    ((g) A1.a.x(arrayList)).f31637J = true;
                }
            }
            bVar = N2.i.f6360e;
        } else {
            long b10 = gVar.b(cVar);
            if (b10 != -9223372036854775807L) {
                bVar = new i.b(0, b10);
            } else {
                bVar = N2.i.f6361f;
            }
        }
        i.b bVar2 = bVar;
        boolean a12 = bVar2.a();
        C.a aVar = this.f31690L;
        long j13 = eVar.f5313g;
        long j14 = eVar.f5314h;
        C.a aVar2 = aVar;
        C.a aVar3 = aVar2;
        C.a aVar4 = aVar3;
        C.a aVar5 = aVar4;
        C.a aVar6 = aVar5;
        aVar6.e(rVar, eVar.f5309c, this.f31713i, eVar.f5310d, eVar.f5311e, eVar.f5312f, j13, j14, iOException2, !a12);
        if (!a12) {
            this.f31700V = null;
        }
        if (z10) {
            if (!this.e0) {
                g.a aVar7 = new g.a();
                aVar7.f15281a = this.f31722q0;
                e(new androidx.media3.exoplayer.g(aVar7));
                return bVar2;
            }
            this.f31731z.b(this);
        }
        return bVar2;
    }

    public final void r(i.d dVar, long j10, long j11) {
        e eVar = (e) dVar;
        this.f31700V = null;
        C3553f fVar = this.f31683E;
        if (eVar instanceof C3553f.a) {
            C3553f.a aVar = (C3553f.a) eVar;
            fVar.f31609m = aVar.f5354j;
            Uri uri = aVar.f5308b.f26879a;
            byte[] bArr = aVar.f31616l;
            bArr.getClass();
            C4126p pVar = fVar.f31606j;
            pVar.getClass();
            uri.getClass();
            byte[] bArr2 = (byte[]) ((C3552e) pVar.f37552f).put(uri, bArr);
        }
        long j12 = eVar.f5307a;
        q2.u uVar = eVar.f5315i;
        Uri uri2 = uVar.f26937z;
        r rVar = new r(uVar.f26934E, j11);
        this.f31688J.getClass();
        this.f31690L.d(rVar, eVar.f5309c, this.f31713i, eVar.f5310d, eVar.f5311e, eVar.f5312f, eVar.f5313g, eVar.f5314h);
        if (!this.e0) {
            g.a aVar2 = new g.a();
            aVar2.f15281a = this.f31722q0;
            e(new androidx.media3.exoplayer.g(aVar2));
            return;
        }
        this.f31731z.b(this);
    }

    public final long t() {
        if (this.f31726u0) {
            return Long.MIN_VALUE;
        }
        if (D()) {
            return this.f31723r0;
        }
        long j10 = this.f31722q0;
        g B7 = B();
        if (!B7.f31635H) {
            ArrayList<g> arrayList = this.f31693O;
            if (arrayList.size() > 1) {
                B7 = (g) A6.u.m(2, arrayList);
            } else {
                B7 = null;
            }
        }
        if (B7 != null) {
            j10 = Math.max(j10, B7.f5314h);
        }
        if (this.f31708d0) {
            for (b q10 : this.f31701W) {
                j10 = Math.max(j10, q10.q());
            }
        }
        return j10;
    }

    public final void v(long j10) {
        int i10;
        boolean z10;
        N2.i iVar = this.f31689K;
        if (!iVar.c() && !D()) {
            boolean d10 = iVar.d();
            C3553f fVar = this.f31683E;
            List<g> list = this.f31694P;
            if (d10) {
                this.f31700V.getClass();
                e eVar = this.f31700V;
                if (fVar.f31610n != null) {
                    z10 = false;
                } else {
                    z10 = fVar.f31613q.l(j10, eVar, list);
                }
                if (z10) {
                    iVar.b();
                    return;
                }
                return;
            }
            int size = list.size();
            while (size > 0 && fVar.b(list.get(size - 1)) == 2) {
                size--;
            }
            if (size < list.size()) {
                A(size);
            }
            if (fVar.f31610n != null || fVar.f31613q.length() < 2) {
                i10 = list.size();
            } else {
                i10 = fVar.f31613q.t(list, j10);
            }
            if (i10 < this.f31693O.size()) {
                A(i10);
            }
        }
    }

    public final void w() {
        f7.M.m(this.e0);
        this.f31715j0.getClass();
        this.f31716k0.getClass();
    }

    public final V y(C2611C[] cArr) {
        for (int i10 = 0; i10 < cArr.length; i10++) {
            C2611C c10 = cArr[i10];
            n[] nVarArr = new n[c10.f24147a];
            for (int i11 = 0; i11 < c10.f24147a; i11++) {
                n nVar = c10.f24150d[i11];
                int b10 = this.f31686H.b(nVar);
                n.a a10 = nVar.a();
                a10.f24315L = b10;
                nVarArr[i11] = new n(a10);
            }
            cArr[i10] = new C2611C(c10.f24148b, nVarArr);
        }
        return new V(cArr);
    }

    public final void a(R2.C c10) {
    }
}
