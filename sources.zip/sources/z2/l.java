package z2;

import M.k;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import l2.n;
import l2.s;
import l2.t;
import x.i0;

public final class l implements t.a {

    /* renamed from: a  reason: collision with root package name */
    public final String f31741a;

    /* renamed from: b  reason: collision with root package name */
    public final String f31742b;

    /* renamed from: c  reason: collision with root package name */
    public final List<a> f31743c;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f31744a;

        /* renamed from: b  reason: collision with root package name */
        public final int f31745b;

        /* renamed from: c  reason: collision with root package name */
        public final String f31746c;

        /* renamed from: d  reason: collision with root package name */
        public final String f31747d;

        /* renamed from: e  reason: collision with root package name */
        public final String f31748e;

        /* renamed from: f  reason: collision with root package name */
        public final String f31749f;

        public a(int i10, String str, String str2, String str3, String str4, int i11) {
            this.f31744a = i10;
            this.f31745b = i11;
            this.f31746c = str;
            this.f31747d = str2;
            this.f31748e = str3;
            this.f31749f = str4;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj != null && a.class == obj.getClass()) {
                a aVar = (a) obj;
                if (this.f31744a != aVar.f31744a || this.f31745b != aVar.f31745b || !TextUtils.equals(this.f31746c, aVar.f31746c) || !TextUtils.equals(this.f31747d, aVar.f31747d) || !TextUtils.equals(this.f31748e, aVar.f31748e) || !TextUtils.equals(this.f31749f, aVar.f31749f)) {
                    return false;
                }
                return true;
            }
            return false;
        }

        public final int hashCode() {
            int i10;
            int i11;
            int i12;
            int i13 = ((this.f31744a * 31) + this.f31745b) * 31;
            int i14 = 0;
            String str = this.f31746c;
            if (str != null) {
                i10 = str.hashCode();
            } else {
                i10 = 0;
            }
            int i15 = (i13 + i10) * 31;
            String str2 = this.f31747d;
            if (str2 != null) {
                i11 = str2.hashCode();
            } else {
                i11 = 0;
            }
            int i16 = (i15 + i11) * 31;
            String str3 = this.f31748e;
            if (str3 != null) {
                i12 = str3.hashCode();
            } else {
                i12 = 0;
            }
            int i17 = (i16 + i12) * 31;
            String str4 = this.f31749f;
            if (str4 != null) {
                i14 = str4.hashCode();
            }
            return i17 + i14;
        }
    }

    public l(String str, String str2, List<a> list) {
        this.f31741a = str;
        this.f31742b = str2;
        this.f31743c = Collections.unmodifiableList(new ArrayList(list));
    }

    public final /* synthetic */ n a() {
        return null;
    }

    public final /* synthetic */ void b(s.a aVar) {
    }

    public final /* synthetic */ byte[] c() {
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && l.class == obj.getClass()) {
            l lVar = (l) obj;
            if (!TextUtils.equals(this.f31741a, lVar.f31741a) || !TextUtils.equals(this.f31742b, lVar.f31742b) || !this.f31743c.equals(lVar.f31743c)) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i10;
        int i11 = 0;
        String str = this.f31741a;
        if (str != null) {
            i10 = str.hashCode();
        } else {
            i10 = 0;
        }
        int i12 = i10 * 31;
        String str2 = this.f31742b;
        if (str2 != null) {
            i11 = str2.hashCode();
        }
        return this.f31743c.hashCode() + ((i12 + i11) * 31);
    }

    public final String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder("HlsTrackMetadataEntry");
        String str2 = this.f31741a;
        if (str2 != null) {
            str = i0.c(k.o(" [", str2, ", "), this.f31742b, "]");
        } else {
            str = "";
        }
        sb2.append(str);
        return sb2.toString();
    }
}
