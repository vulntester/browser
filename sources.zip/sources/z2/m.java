package z2;

import java.io.IOException;

public final class m extends IOException {
}
