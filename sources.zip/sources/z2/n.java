package z2;

import D2.E;
import R2.B;
import R2.C;
import R2.C1013i;
import R2.H;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import android.text.TextUtils;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import l2.n;
import l2.u;
import l2.v;
import o2.C2756B;
import o2.t;
import o2.y;
import o3.C2763e;
import o3.C2773o;
import x3.e;
import x3.g;

public final class n implements R2.n {

    /* renamed from: i  reason: collision with root package name */
    public static final Pattern f31750i = Pattern.compile("LOCAL:([^,]+)");

    /* renamed from: j  reason: collision with root package name */
    public static final Pattern f31751j = Pattern.compile("MPEGTS:(-?\\d+)");

    /* renamed from: a  reason: collision with root package name */
    public final String f31752a;

    /* renamed from: b  reason: collision with root package name */
    public final y f31753b;

    /* renamed from: c  reason: collision with root package name */
    public final t f31754c = new t();

    /* renamed from: d  reason: collision with root package name */
    public final C2763e f31755d;

    /* renamed from: e  reason: collision with root package name */
    public final boolean f31756e;

    /* renamed from: f  reason: collision with root package name */
    public p f31757f;

    /* renamed from: g  reason: collision with root package name */
    public byte[] f31758g = new byte[1024];

    /* renamed from: h  reason: collision with root package name */
    public int f31759h;

    public n(String str, y yVar, C2763e eVar, boolean z10) {
        this.f31752a = str;
        this.f31753b = yVar;
        this.f31755d = eVar;
        this.f31756e = z10;
    }

    public final void a(long j10, long j11) {
        throw new IllegalStateException();
    }

    public final H b(long j10) {
        H k10 = this.f31757f.k(0, 3);
        n.a aVar = new n.a();
        aVar.f24328m = u.p("text/vtt");
        aVar.f24319d = this.f31752a;
        aVar.f24333r = j10;
        E.r(aVar, k10);
        this.f31757f.b();
        return k10;
    }

    public final R2.n c() {
        return this;
    }

    public final void d(p pVar) {
        if (this.f31756e) {
            pVar = new C2773o(pVar, this.f31755d);
        }
        this.f31757f = pVar;
        pVar.a(new C.b(-9223372036854775807L));
    }

    public final boolean g(o oVar) {
        C1013i iVar = (C1013i) oVar;
        iVar.l(this.f31758g, 0, 6, false);
        byte[] bArr = this.f31758g;
        t tVar = this.f31754c;
        tVar.E(6, bArr);
        if (g.a(tVar)) {
            return true;
        }
        iVar.l(this.f31758g, 6, 3, false);
        tVar.E(9, this.f31758g);
        return g.a(tVar);
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    public final int i(o oVar, B b10) {
        String i10;
        int i11;
        this.f31757f.getClass();
        int i12 = (int) ((C1013i) oVar).f8173z;
        int i13 = this.f31759h;
        byte[] bArr = this.f31758g;
        if (i13 == bArr.length) {
            if (i12 != -1) {
                i11 = i12;
            } else {
                i11 = bArr.length;
            }
            this.f31758g = Arrays.copyOf(bArr, (i11 * 3) / 2);
        }
        byte[] bArr2 = this.f31758g;
        int i14 = this.f31759h;
        int read = ((C1013i) oVar).read(bArr2, i14, bArr2.length - i14);
        if (read != -1) {
            int i15 = this.f31759h + read;
            this.f31759h = i15;
            if (i12 == -1 || i15 != i12) {
                return 0;
            }
        }
        t tVar = new t(this.f31758g);
        g.d(tVar);
        String i16 = tVar.i(StandardCharsets.UTF_8);
        long j10 = 0;
        long j11 = 0;
        while (true) {
            Matcher matcher = null;
            if (!TextUtils.isEmpty(i16)) {
                if (i16.startsWith("X-TIMESTAMP-MAP")) {
                    Matcher matcher2 = f31750i.matcher(i16);
                    if (matcher2.find()) {
                        Matcher matcher3 = f31751j.matcher(i16);
                        if (matcher3.find()) {
                            String group = matcher2.group(1);
                            group.getClass();
                            j11 = g.c(group);
                            String group2 = matcher3.group(1);
                            group2.getClass();
                            long parseLong = Long.parseLong(group2);
                            int i17 = C2756B.f25811a;
                            j10 = C2756B.W(parseLong, 1000000, 90000, RoundingMode.DOWN);
                        } else {
                            throw v.a((RuntimeException) null, "X-TIMESTAMP-MAP doesn't contain media timestamp: ".concat(i16));
                        }
                    } else {
                        throw v.a((RuntimeException) null, "X-TIMESTAMP-MAP doesn't contain local timestamp: ".concat(i16));
                    }
                }
                i16 = tVar.i(StandardCharsets.UTF_8);
            } else {
                while (true) {
                    String i18 = tVar.i(StandardCharsets.UTF_8);
                    if (i18 == null) {
                        break;
                    } else if (g.f30583a.matcher(i18).matches()) {
                        do {
                            i10 = tVar.i(StandardCharsets.UTF_8);
                            if (i10 == null) {
                                break;
                            }
                        } while (i10.isEmpty());
                    } else {
                        Matcher matcher4 = e.f30557a.matcher(i18);
                        if (matcher4.matches()) {
                            matcher = matcher4;
                            break;
                        }
                    }
                }
                if (matcher == null) {
                    b(0);
                    return -1;
                }
                String group3 = matcher.group(1);
                group3.getClass();
                long c10 = g.c(group3);
                int i19 = C2756B.f25811a;
                long b11 = this.f31753b.b(C2756B.W((j10 + c10) - j11, 90000, 1000000, RoundingMode.DOWN) % 8589934592L);
                H b12 = b(b11 - c10);
                byte[] bArr3 = this.f31758g;
                int i20 = this.f31759h;
                t tVar2 = this.f31754c;
                tVar2.E(i20, bArr3);
                b12.e(this.f31759h, tVar2);
                b12.b(b11, 1, this.f31759h, 0, (H.a) null);
                return -1;
            }
        }
    }

    public final void release() {
    }
}
