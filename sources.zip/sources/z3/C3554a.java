package z3;

import R2.C1013i;
import R2.H;
import R2.n;
import R2.o;
import R2.p;
import S7.C1150x;
import S7.O;
import java.math.RoundingMode;
import java.util.List;
import l2.n;
import l2.u;
import l2.v;
import o2.C2756B;
import o2.t;

/* renamed from: z3.a  reason: case insensitive filesystem */
public final class C3554a implements n {

    /* renamed from: a  reason: collision with root package name */
    public p f31760a;

    /* renamed from: b  reason: collision with root package name */
    public H f31761b;

    /* renamed from: c  reason: collision with root package name */
    public int f31762c;

    /* renamed from: d  reason: collision with root package name */
    public long f31763d;

    /* renamed from: e  reason: collision with root package name */
    public b f31764e;

    /* renamed from: f  reason: collision with root package name */
    public int f31765f;

    /* renamed from: g  reason: collision with root package name */
    public long f31766g;

    /* renamed from: z3.a$a  reason: collision with other inner class name */
    public static final class C0310a implements b {

        /* renamed from: m  reason: collision with root package name */
        public static final int[] f31767m = {-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8};

        /* renamed from: n  reason: collision with root package name */
        public static final int[] f31768n = {7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767};

        /* renamed from: a  reason: collision with root package name */
        public final p f31769a;

        /* renamed from: b  reason: collision with root package name */
        public final H f31770b;

        /* renamed from: c  reason: collision with root package name */
        public final C3555b f31771c;

        /* renamed from: d  reason: collision with root package name */
        public final int f31772d;

        /* renamed from: e  reason: collision with root package name */
        public final byte[] f31773e;

        /* renamed from: f  reason: collision with root package name */
        public final t f31774f;

        /* renamed from: g  reason: collision with root package name */
        public final int f31775g;

        /* renamed from: h  reason: collision with root package name */
        public final l2.n f31776h;

        /* renamed from: i  reason: collision with root package name */
        public int f31777i;

        /* renamed from: j  reason: collision with root package name */
        public long f31778j;

        /* renamed from: k  reason: collision with root package name */
        public int f31779k;

        /* renamed from: l  reason: collision with root package name */
        public long f31780l;

        public C0310a(p pVar, H h10, C3555b bVar) {
            this.f31769a = pVar;
            this.f31770b = h10;
            this.f31771c = bVar;
            int i10 = bVar.f31790b;
            int max = Math.max(1, i10 / 10);
            this.f31775g = max;
            t tVar = new t(bVar.f31793e);
            tVar.n();
            int n10 = tVar.n();
            this.f31772d = n10;
            int i11 = bVar.f31789a;
            int i12 = bVar.f31791c;
            int i13 = (((i12 - (i11 * 4)) * 8) / (bVar.f31792d * i11)) + 1;
            if (n10 == i13) {
                int f10 = C2756B.f(max, n10);
                this.f31773e = new byte[(f10 * i12)];
                this.f31774f = new t(n10 * 2 * i11 * f10);
                int i14 = ((i12 * i10) * 8) / n10;
                n.a aVar = new n.a();
                aVar.f24328m = u.p("audio/raw");
                aVar.f24323h = i14;
                aVar.f24324i = i14;
                aVar.f24329n = max * 2 * i11;
                aVar.f24306C = i11;
                aVar.f24307D = i10;
                aVar.f24308E = 2;
                this.f31776h = new l2.n(aVar);
                return;
            }
            throw v.a((RuntimeException) null, "Expected frames per block: " + i13 + "; got: " + n10);
        }

        public final void a(long j10) {
            this.f31777i = 0;
            this.f31778j = j10;
            this.f31779k = 0;
            this.f31780l = 0;
        }

        public final void b(int i10, long j10) {
            this.f31769a.a(new C3557d(this.f31771c, this.f31772d, (long) i10, j10));
            this.f31770b.d(this.f31776h);
        }

        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
            	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
            */
        /* JADX WARNING: Removed duplicated region for block: B:11:0x0045 A[EDGE_INSN: B:40:0x0045->B:11:0x0045 ?: BREAK  
        EDGE_INSN: B:41:0x0045->B:11:0x0045 ?: BREAK  ] */
        /* JADX WARNING: Removed duplicated region for block: B:8:0x002b  */
        public final boolean c(R2.C1013i r25, long r26) {
            /*
                r24 = this;
                r0 = r24
                r1 = r26
                int r3 = r0.f31779k
                z3.b r4 = r0.f31771c
                int r5 = r4.f31789a
                int r5 = r5 * 2
                int r3 = r3 / r5
                int r5 = r0.f31775g
                int r3 = r5 - r3
                int r6 = r0.f31772d
                int r3 = o2.C2756B.f(r3, r6)
                int r7 = r4.f31791c
                int r3 = r3 * r7
                r8 = 0
                int r8 = (r1 > r8 ? 1 : (r1 == r8 ? 0 : -1))
                if (r8 != 0) goto L_0x0022
            L_0x0020:
                r8 = 1
                goto L_0x0023
            L_0x0022:
                r8 = 0
            L_0x0023:
                byte[] r11 = r0.f31773e
                if (r8 != 0) goto L_0x0045
                int r12 = r0.f31777i
                if (r12 >= r3) goto L_0x0045
                int r12 = r3 - r12
                long r12 = (long) r12
                long r12 = java.lang.Math.min(r12, r1)
                int r12 = (int) r12
                int r13 = r0.f31777i
                r14 = r25
                int r11 = r14.read(r11, r13, r12)
                r12 = -1
                if (r11 != r12) goto L_0x003f
                goto L_0x0020
            L_0x003f:
                int r12 = r0.f31777i
                int r12 = r12 + r11
                r0.f31777i = r12
                goto L_0x0023
            L_0x0045:
                int r1 = r0.f31777i
                int r1 = r1 / r7
                if (r1 <= 0) goto L_0x0138
                r2 = 0
            L_0x004b:
                o2.t r3 = r0.f31774f
                if (r2 >= r1) goto L_0x010b
                r12 = 0
            L_0x0050:
                int r13 = r4.f31789a
                if (r12 >= r13) goto L_0x0101
                byte[] r14 = r3.f25885a
                int r15 = r2 * r7
                int r16 = r12 * 4
                int r16 = r16 + r15
                int r15 = r13 * 4
                int r15 = r15 + r16
                int r17 = r7 / r13
                int r17 = r17 + -4
                int r18 = r16 + 1
                r19 = 1
                byte r9 = r11[r18]
                r9 = r9 & 255(0xff, float:3.57E-43)
                int r9 = r9 << 8
                byte r10 = r11[r16]
                r10 = r10 & 255(0xff, float:3.57E-43)
                r9 = r9 | r10
                short r9 = (short) r9
                int r16 = r16 + 2
                byte r10 = r11[r16]
                r10 = r10 & 255(0xff, float:3.57E-43)
                r25 = r1
                r1 = 88
                int r10 = java.lang.Math.min(r10, r1)
                int[] r16 = f31768n
                r20 = r16[r10]
                int r21 = r2 * r6
                int r21 = r21 * r13
                int r21 = r21 + r12
                int r21 = r21 * 2
                r1 = r9 & 255(0xff, float:3.57E-43)
                byte r1 = (byte) r1
                r14[r21] = r1
                int r1 = r21 + 1
                r27 = r1
                int r1 = r9 >> 8
                byte r1 = (byte) r1
                r14[r27] = r1
                r27 = r2
                r1 = 0
            L_0x009f:
                int r2 = r17 * 2
                if (r1 >= r2) goto L_0x00f9
                int r2 = r1 / 8
                int r22 = r1 / 2
                int r22 = r22 % 4
                int r2 = r2 * r13
                int r2 = r2 * 4
                int r2 = r2 + r15
                int r2 = r2 + r22
                byte r2 = r11[r2]
                r22 = r1
                r1 = r2 & 255(0xff, float:3.57E-43)
                int r23 = r22 % 2
                if (r23 != 0) goto L_0x00bc
                r1 = r2 & 15
                goto L_0x00be
            L_0x00bc:
                int r1 = r1 >> 4
            L_0x00be:
                r2 = r1 & 7
                int r2 = r2 * 2
                int r2 = r2 + 1
                int r2 = r2 * r20
                int r2 = r2 >> 3
                r20 = r1 & 8
                if (r20 == 0) goto L_0x00cd
                int r2 = -r2
            L_0x00cd:
                int r9 = r9 + r2
                r2 = -32768(0xffffffffffff8000, float:NaN)
                r20 = r1
                r1 = 32767(0x7fff, float:4.5916E-41)
                int r9 = o2.C2756B.i(r9, r2, r1)
                int r1 = r13 * 2
                int r21 = r1 + r21
                r1 = r9 & 255(0xff, float:3.57E-43)
                byte r1 = (byte) r1
                r14[r21] = r1
                int r1 = r21 + 1
                int r2 = r9 >> 8
                byte r2 = (byte) r2
                r14[r1] = r2
                int[] r1 = f31767m
                r1 = r1[r20]
                int r10 = r10 + r1
                r1 = 0
                r2 = 88
                int r10 = o2.C2756B.i(r10, r1, r2)
                r20 = r16[r10]
                int r1 = r22 + 1
                goto L_0x009f
            L_0x00f9:
                int r12 = r12 + 1
                r1 = r25
                r2 = r27
                goto L_0x0050
            L_0x0101:
                r25 = r1
                r27 = r2
                r19 = 1
                int r2 = r27 + 1
                goto L_0x004b
            L_0x010b:
                r25 = r1
                int r6 = r6 * r25
                int r6 = r6 * 2
                int r1 = r4.f31789a
                int r6 = r6 * r1
                r1 = 0
                r3.G(r1)
                r3.F(r6)
                int r1 = r0.f31777i
                int r2 = r25 * r7
                int r1 = r1 - r2
                r0.f31777i = r1
                int r1 = r3.f25887c
                R2.H r2 = r0.f31770b
                r2.e(r1, r3)
                int r2 = r0.f31779k
                int r2 = r2 + r1
                r0.f31779k = r2
                int r1 = r4.f31789a
                int r1 = r1 * 2
                int r2 = r2 / r1
                if (r2 < r5) goto L_0x0138
                r0.d(r5)
            L_0x0138:
                if (r8 == 0) goto L_0x0146
                int r1 = r0.f31779k
                int r2 = r4.f31789a
                int r2 = r2 * 2
                int r1 = r1 / r2
                if (r1 <= 0) goto L_0x0146
                r0.d(r1)
            L_0x0146:
                return r8
            */
            throw new UnsupportedOperationException("Method not decompiled: z3.C3554a.C0310a.c(R2.i, long):boolean");
        }

        public final void d(int i10) {
            int i11 = i10;
            long j10 = this.f31778j;
            long j11 = this.f31780l;
            C3555b bVar = this.f31771c;
            long j12 = (long) bVar.f31790b;
            int i12 = C2756B.f25811a;
            long W10 = j10 + C2756B.W(j11, 1000000, j12, RoundingMode.DOWN);
            int i13 = i11 * 2 * bVar.f31789a;
            this.f31770b.b(W10, 1, i13, this.f31779k - i13, (H.a) null);
            this.f31780l += (long) i11;
            this.f31779k -= i13;
        }
    }

    /* renamed from: z3.a$b */
    public interface b {
        void a(long j10);

        void b(int i10, long j10);

        boolean c(C1013i iVar, long j10);
    }

    /* renamed from: z3.a$c */
    public static final class c implements b {

        /* renamed from: a  reason: collision with root package name */
        public final p f31781a;

        /* renamed from: b  reason: collision with root package name */
        public final H f31782b;

        /* renamed from: c  reason: collision with root package name */
        public final C3555b f31783c;

        /* renamed from: d  reason: collision with root package name */
        public final l2.n f31784d;

        /* renamed from: e  reason: collision with root package name */
        public final int f31785e;

        /* renamed from: f  reason: collision with root package name */
        public long f31786f;

        /* renamed from: g  reason: collision with root package name */
        public int f31787g;

        /* renamed from: h  reason: collision with root package name */
        public long f31788h;

        public c(p pVar, H h10, C3555b bVar, String str, int i10) {
            this.f31781a = pVar;
            this.f31782b = h10;
            this.f31783c = bVar;
            int i11 = bVar.f31792d;
            int i12 = bVar.f31789a;
            int i13 = (i11 * i12) / 8;
            int i14 = bVar.f31791c;
            if (i14 == i13) {
                int i15 = bVar.f31790b;
                int i16 = i15 * i13;
                int i17 = i16 * 8;
                int max = Math.max(i13, i16 / 10);
                this.f31785e = max;
                n.a aVar = new n.a();
                aVar.f24327l = u.p("audio/wav");
                aVar.f24328m = u.p(str);
                aVar.f24323h = i17;
                aVar.f24324i = i17;
                aVar.f24329n = max;
                aVar.f24306C = i12;
                aVar.f24307D = i15;
                aVar.f24308E = i10;
                this.f31784d = new l2.n(aVar);
                return;
            }
            throw v.a((RuntimeException) null, "Expected block size: " + i13 + "; got: " + i14);
        }

        public final void a(long j10) {
            this.f31786f = j10;
            this.f31787g = 0;
            this.f31788h = 0;
        }

        public final void b(int i10, long j10) {
            this.f31781a.a(new C3557d(this.f31783c, 1, (long) i10, j10));
            this.f31782b.d(this.f31784d);
        }

        public final boolean c(C1013i iVar, long j10) {
            int i10;
            int i11;
            int i12;
            long j11 = j10;
            while (true) {
                i10 = (j11 > 0 ? 1 : (j11 == 0 ? 0 : -1));
                if (i10 <= 0 || (i11 = this.f31787g) >= (i12 = this.f31785e)) {
                    C3555b bVar = this.f31783c;
                    int i13 = this.f31787g;
                    int i14 = bVar.f31791c;
                    int i15 = i13 / i14;
                } else {
                    int c10 = this.f31782b.c(iVar, (int) Math.min((long) (i12 - i11), j11), true);
                    if (c10 == -1) {
                        j11 = 0;
                    } else {
                        this.f31787g += c10;
                        j11 -= (long) c10;
                    }
                }
            }
            C3555b bVar2 = this.f31783c;
            int i132 = this.f31787g;
            int i142 = bVar2.f31791c;
            int i152 = i132 / i142;
            if (i152 > 0) {
                long j12 = this.f31786f;
                long j13 = this.f31788h;
                long j14 = (long) bVar2.f31790b;
                int i16 = C2756B.f25811a;
                int i17 = i152 * i142;
                int i18 = this.f31787g - i17;
                this.f31782b.b(j12 + C2756B.W(j13, 1000000, j14, RoundingMode.DOWN), 1, i17, i18, (H.a) null);
                this.f31788h += (long) i152;
                this.f31787g = i18;
            }
            if (i10 <= 0) {
                return true;
            }
            return false;
        }
    }

    public final void a(long j10, long j11) {
        int i10;
        if (j10 == 0) {
            i10 = 0;
        } else {
            i10 = 4;
        }
        this.f31762c = i10;
        b bVar = this.f31764e;
        if (bVar != null) {
            bVar.a(j11);
        }
    }

    public final R2.n c() {
        return this;
    }

    public final void d(p pVar) {
        this.f31760a = pVar;
        this.f31761b = pVar.k(0, 1);
        pVar.b();
    }

    public final boolean g(o oVar) {
        return C3556c.a((C1013i) oVar);
    }

    public final List h() {
        C1150x.b bVar = C1150x.f9860i;
        return O.f9711F;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:50:0x018a, code lost:
        if (r12 != 65534) goto L_0x018c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0191, code lost:
        if (r1 == 32) goto L_0x0193;
     */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x019d  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x01b3  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int i(R2.o r25, R2.B r26) {
        /*
            r24 = this;
            r0 = r24
            R2.H r1 = r0.f31761b
            f7.M.n(r1)
            int r1 = o2.C2756B.f25811a
            int r1 = r0.f31762c
            r2 = 0
            r3 = -1
            r4 = 4
            r5 = 1
            if (r1 == 0) goto L_0x01fc
            r6 = 8
            r7 = 2
            r8 = -1
            if (r1 == r5) goto L_0x01c6
            r10 = 3
            if (r1 == r7) goto L_0x00d3
            if (r1 == r10) goto L_0x004a
            if (r1 != r4) goto L_0x0044
            long r6 = r0.f31766g
            int r1 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r1 == 0) goto L_0x0026
            goto L_0x0027
        L_0x0026:
            r5 = r2
        L_0x0027:
            f7.M.m(r5)
            long r4 = r0.f31766g
            r1 = r25
            R2.i r1 = (R2.C1013i) r1
            long r6 = r1.f8167E
            long r4 = r4 - r6
            z3.a$b r1 = r0.f31764e
            r1.getClass()
            r6 = r25
            R2.i r6 = (R2.C1013i) r6
            boolean r1 = r1.c(r6, r4)
            if (r1 == 0) goto L_0x0043
            return r3
        L_0x0043:
            return r2
        L_0x0044:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            r1.<init>()
            throw r1
        L_0x004a:
            r1 = r25
            R2.i r1 = (R2.C1013i) r1
            r1.f8169G = r2
            o2.t r1 = new o2.t
            r1.<init>((int) r6)
            r3 = r25
            R2.i r3 = (R2.C1013i) r3
            r5 = 1684108385(0x64617461, float:1.6635614E22)
            z3.c$a r1 = z3.C3556c.b(r5, r3, r1)
            r3.s(r6)
            long r5 = r3.f8167E
            java.lang.Long r5 = java.lang.Long.valueOf(r5)
            long r6 = r1.f31795b
            java.lang.Long r1 = java.lang.Long.valueOf(r6)
            android.util.Pair r1 = android.util.Pair.create(r5, r1)
            java.lang.Object r5 = r1.first
            java.lang.Long r5 = (java.lang.Long) r5
            int r5 = r5.intValue()
            r0.f31765f = r5
            java.lang.Object r1 = r1.second
            java.lang.Long r1 = (java.lang.Long) r1
            long r5 = r1.longValue()
            long r10 = r0.f31763d
            int r1 = (r10 > r8 ? 1 : (r10 == r8 ? 0 : -1))
            if (r1 == 0) goto L_0x0095
            r12 = 4294967295(0xffffffff, double:2.1219957905E-314)
            int r1 = (r5 > r12 ? 1 : (r5 == r12 ? 0 : -1))
            if (r1 != 0) goto L_0x0095
            r5 = r10
        L_0x0095:
            int r1 = r0.f31765f
            long r10 = (long) r1
            long r10 = r10 + r5
            r0.f31766g = r10
            long r5 = r3.f8173z
            int r1 = (r5 > r8 ? 1 : (r5 == r8 ? 0 : -1))
            if (r1 == 0) goto L_0x00c4
            int r1 = (r10 > r5 ? 1 : (r10 == r5 ? 0 : -1))
            if (r1 <= 0) goto L_0x00c4
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r3 = "Data exceeds input length: "
            r1.<init>(r3)
            long r7 = r0.f31766g
            r1.append(r7)
            java.lang.String r3 = ", "
            r1.append(r3)
            r1.append(r5)
            java.lang.String r1 = r1.toString()
            java.lang.String r3 = "WavExtractor"
            o2.n.f(r3, r1)
            r0.f31766g = r5
        L_0x00c4:
            z3.a$b r1 = r0.f31764e
            r1.getClass()
            int r3 = r0.f31765f
            long r5 = r0.f31766g
            r1.b(r3, r5)
            r0.f31762c = r4
            return r2
        L_0x00d3:
            o2.t r1 = new o2.t
            r3 = 16
            r1.<init>((int) r3)
            r6 = r25
            R2.i r6 = (R2.C1013i) r6
            r7 = 1718449184(0x666d7420, float:2.8033575E23)
            z3.c$a r7 = z3.C3556c.b(r7, r6, r1)
            long r7 = r7.f31795b
            r11 = 16
            int r9 = (r7 > r11 ? 1 : (r7 == r11 ? 0 : -1))
            if (r9 < 0) goto L_0x00ef
            r9 = r5
            goto L_0x00f0
        L_0x00ef:
            r9 = r2
        L_0x00f0:
            f7.M.m(r9)
            byte[] r9 = r1.f25885a
            r6.l(r9, r2, r3, r2)
            r1.G(r2)
            int r12 = r1.n()
            int r13 = r1.n()
            int r14 = r1.m()
            r1.m()
            int r16 = r1.n()
            int r17 = r1.n()
            int r1 = (int) r7
            int r1 = r1 - r3
            if (r1 <= 0) goto L_0x0121
            byte[] r3 = new byte[r1]
            r6 = r25
            R2.i r6 = (R2.C1013i) r6
            r6.l(r3, r2, r1, r2)
        L_0x011f:
            r15 = r3
            goto L_0x0124
        L_0x0121:
            byte[] r3 = o2.C2756B.f25813c
            goto L_0x011f
        L_0x0124:
            r1 = r25
            R2.i r1 = (R2.C1013i) r1
            long r6 = r1.m()
            long r8 = r1.f8167E
            long r6 = r6 - r8
            int r3 = (int) r6
            r1.s(r3)
            z3.b r21 = new z3.b
            r11 = r21
            r11.<init>(r12, r13, r14, r15, r16, r17)
            r1 = r17
            r3 = 17
            if (r12 != r3) goto L_0x014d
            z3.a$a r1 = new z3.a$a
            R2.p r3 = r0.f31760a
            R2.H r4 = r0.f31761b
            r1.<init>(r3, r4, r11)
            r0.f31764e = r1
            goto L_0x01b0
        L_0x014d:
            r3 = 6
            if (r12 != r3) goto L_0x0168
            z3.a$c r18 = new z3.a$c
            R2.p r1 = r0.f31760a
            R2.H r3 = r0.f31761b
            java.lang.String r22 = "audio/g711-alaw"
            r23 = -1
            r19 = r1
            r20 = r3
            r21 = r11
            r18.<init>(r19, r20, r21, r22, r23)
            r1 = r18
            r0.f31764e = r1
            goto L_0x01b0
        L_0x0168:
            r21 = r11
            r3 = 7
            if (r12 != r3) goto L_0x0183
            z3.a$c r18 = new z3.a$c
            R2.p r1 = r0.f31760a
            R2.H r3 = r0.f31761b
            java.lang.String r22 = "audio/g711-mlaw"
            r23 = -1
            r19 = r1
            r20 = r3
            r18.<init>(r19, r20, r21, r22, r23)
            r1 = r18
            r0.f31764e = r1
            goto L_0x01b0
        L_0x0183:
            if (r12 == r5) goto L_0x0196
            if (r12 == r10) goto L_0x018f
            r3 = 65534(0xfffe, float:9.1833E-41)
            if (r12 == r3) goto L_0x0196
        L_0x018c:
            r23 = r2
            goto L_0x019b
        L_0x018f:
            r3 = 32
            if (r1 != r3) goto L_0x018c
        L_0x0193:
            r23 = r4
            goto L_0x019b
        L_0x0196:
            int r4 = o2.C2756B.A(r1)
            goto L_0x0193
        L_0x019b:
            if (r23 == 0) goto L_0x01b3
            z3.a$c r18 = new z3.a$c
            R2.p r1 = r0.f31760a
            R2.H r3 = r0.f31761b
            java.lang.String r22 = "audio/raw"
            r19 = r1
            r20 = r3
            r18.<init>(r19, r20, r21, r22, r23)
            r1 = r18
            r0.f31764e = r1
        L_0x01b0:
            r0.f31762c = r10
            return r2
        L_0x01b3:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Unsupported WAV format type: "
            r1.<init>(r2)
            r1.append(r12)
            java.lang.String r1 = r1.toString()
            l2.v r1 = l2.v.c(r1)
            throw r1
        L_0x01c6:
            o2.t r1 = new o2.t
            r1.<init>((int) r6)
            r3 = r25
            R2.i r3 = (R2.C1013i) r3
            z3.c$a r4 = z3.C3556c.a.a(r3, r1)
            int r5 = r4.f31794a
            r10 = 1685272116(0x64733634, float:1.7945858E22)
            if (r5 == r10) goto L_0x01dd
            r3.f8169G = r2
            goto L_0x01f7
        L_0x01dd:
            r3.b(r6, r2)
            r1.G(r2)
            byte[] r3 = r1.f25885a
            r5 = r25
            R2.i r5 = (R2.C1013i) r5
            r5.l(r3, r2, r6, r2)
            long r8 = r1.k()
            long r3 = r4.f31795b
            int r1 = (int) r3
            int r1 = r1 + r6
            r5.s(r1)
        L_0x01f7:
            r0.f31763d = r8
            r0.f31762c = r7
            return r2
        L_0x01fc:
            r1 = r25
            R2.i r1 = (R2.C1013i) r1
            long r6 = r1.f8167E
            r8 = 0
            int r1 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r1 != 0) goto L_0x020a
            r1 = r5
            goto L_0x020b
        L_0x020a:
            r1 = r2
        L_0x020b:
            f7.M.m(r1)
            int r1 = r0.f31765f
            if (r1 == r3) goto L_0x021c
            r3 = r25
            R2.i r3 = (R2.C1013i) r3
            r3.s(r1)
            r0.f31762c = r4
            return r2
        L_0x021c:
            r1 = r25
            R2.i r1 = (R2.C1013i) r1
            boolean r3 = z3.C3556c.a(r1)
            if (r3 == 0) goto L_0x0234
            long r3 = r1.m()
            long r6 = r1.f8167E
            long r3 = r3 - r6
            int r3 = (int) r3
            r1.s(r3)
            r0.f31762c = r5
            return r2
        L_0x0234:
            java.lang.String r1 = "Unsupported or unrecognized wav file type."
            r2 = 0
            l2.v r1 = l2.v.a(r2, r1)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: z3.C3554a.i(R2.o, R2.B):int");
    }

    public final void release() {
    }
}
