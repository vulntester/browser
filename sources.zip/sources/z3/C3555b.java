package z3;

/* renamed from: z3.b  reason: case insensitive filesystem */
public final class C3555b {

    /* renamed from: a  reason: collision with root package name */
    public final int f31789a;

    /* renamed from: b  reason: collision with root package name */
    public final int f31790b;

    /* renamed from: c  reason: collision with root package name */
    public final int f31791c;

    /* renamed from: d  reason: collision with root package name */
    public final int f31792d;

    /* renamed from: e  reason: collision with root package name */
    public final byte[] f31793e;

    public C3555b(int i10, int i11, int i12, byte[] bArr, int i13, int i14) {
        this.f31789a = i11;
        this.f31790b = i12;
        this.f31791c = i13;
        this.f31792d = i14;
        this.f31793e = bArr;
    }
}
