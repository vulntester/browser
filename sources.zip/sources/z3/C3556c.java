package z3;

import A6.u;
import R2.C1013i;
import l2.v;
import o2.n;
import o2.t;

/* renamed from: z3.c  reason: case insensitive filesystem */
public final class C3556c {

    /* renamed from: z3.c$a */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f31794a;

        /* renamed from: b  reason: collision with root package name */
        public final long f31795b;

        public a(int i10, long j10) {
            this.f31794a = i10;
            this.f31795b = j10;
        }

        public static a a(C1013i iVar, t tVar) {
            iVar.l(tVar.f25885a, 0, 8, false);
            tVar.G(0);
            return new a(tVar.h(), tVar.l());
        }
    }

    public static boolean a(C1013i iVar) {
        t tVar = new t(8);
        int i10 = a.a(iVar, tVar).f31794a;
        if (i10 != 1380533830 && i10 != 1380333108) {
            return false;
        }
        iVar.l(tVar.f25885a, 0, 4, false);
        tVar.G(0);
        int h10 = tVar.h();
        if (h10 == 1463899717) {
            return true;
        }
        n.c("WavHeaderReader", "Unsupported form type: " + h10);
        return false;
    }

    public static a b(int i10, C1013i iVar, t tVar) {
        a a10 = a.a(iVar, tVar);
        while (true) {
            int i11 = a10.f31794a;
            if (i11 == i10) {
                return a10;
            }
            u.r(i11, "Ignoring unknown WAV chunk: ", "WavHeaderReader");
            long j10 = a10.f31795b;
            long j11 = 8 + j10;
            if (j10 % 2 != 0) {
                j11 = 9 + j10;
            }
            if (j11 <= 2147483647L) {
                iVar.s((int) j11);
                a10 = a.a(iVar, tVar);
            } else {
                throw v.c("Chunk is too large (~2GB+) to skip; id: " + i11);
            }
        }
    }
}
