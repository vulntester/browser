package z3;

import R2.C;
import R2.D;
import java.math.RoundingMode;
import o2.C2756B;

/* renamed from: z3.d  reason: case insensitive filesystem */
public final class C3557d implements C {

    /* renamed from: a  reason: collision with root package name */
    public final C3555b f31796a;

    /* renamed from: b  reason: collision with root package name */
    public final int f31797b;

    /* renamed from: c  reason: collision with root package name */
    public final long f31798c;

    /* renamed from: d  reason: collision with root package name */
    public final long f31799d;

    /* renamed from: e  reason: collision with root package name */
    public final long f31800e;

    public C3557d(C3555b bVar, int i10, long j10, long j11) {
        this.f31796a = bVar;
        this.f31797b = i10;
        this.f31798c = j10;
        long j12 = (j11 - j10) / ((long) bVar.f31791c);
        this.f31799d = j12;
        this.f31800e = a(j12);
    }

    public final long a(long j10) {
        long j11 = j10 * ((long) this.f31797b);
        long j12 = (long) this.f31796a.f31790b;
        int i10 = C2756B.f25811a;
        return C2756B.W(j11, 1000000, j12, RoundingMode.DOWN);
    }

    public final boolean f() {
        return true;
    }

    public final C.a j(long j10) {
        C3555b bVar = this.f31796a;
        long j11 = (((long) bVar.f31790b) * j10) / (((long) this.f31797b) * 1000000);
        long j12 = this.f31799d;
        long j13 = C2756B.j(j11, 0, j12 - 1);
        long j14 = this.f31798c;
        long a10 = a(j13);
        D d10 = new D(a10, (((long) bVar.f31791c) * j13) + j14);
        if (a10 >= j10 || j13 == j12 - 1) {
            return new C.a(d10, d10);
        }
        long j15 = j13 + 1;
        return new C.a(d10, new D(a(j15), (((long) bVar.f31791c) * j15) + j14));
    }

    public final long l() {
        return this.f31800e;
    }
}
