package z4;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import kotlin.jvm.internal.l;

/* renamed from: z4.a  reason: case insensitive filesystem */
public final class C3558a implements g {

    /* renamed from: a  reason: collision with root package name */
    public final Bitmap f31801a;

    public C3558a(Bitmap bitmap) {
        this.f31801a = bitmap;
    }

    public final long a() {
        int i10;
        int i11;
        Bitmap bitmap = this.f31801a;
        if (!bitmap.isRecycled()) {
            try {
                i10 = bitmap.getAllocationByteCount();
            } catch (Exception unused) {
                int height = bitmap.getHeight() * bitmap.getWidth();
                Bitmap.Config config = bitmap.getConfig();
                if (config == Bitmap.Config.ALPHA_8) {
                    i11 = 1;
                } else if (config == Bitmap.Config.RGB_565 || config == Bitmap.Config.ARGB_4444) {
                    i11 = 2;
                } else if (Build.VERSION.SDK_INT < 26 || config != Bitmap.Config.RGBA_F16) {
                    i11 = 4;
                } else {
                    i11 = 8;
                }
                i10 = i11 * height;
            }
            return (long) i10;
        }
        throw new IllegalStateException(("Cannot obtain size for recycled bitmap: " + bitmap + " [" + bitmap.getWidth() + " x " + bitmap.getHeight() + "] + " + bitmap.getConfig()).toString());
    }

    public final boolean b() {
        return true;
    }

    public final void c(Canvas canvas) {
        canvas.drawBitmap(this.f31801a, 0.0f, 0.0f, (Paint) null);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3558a)) {
            return false;
        }
        if (!l.a(this.f31801a, ((C3558a) obj).f31801a)) {
            return false;
        }
        return true;
    }

    public final int getHeight() {
        return this.f31801a.getHeight();
    }

    public final int getWidth() {
        return this.f31801a.getWidth();
    }

    public final int hashCode() {
        return (this.f31801a.hashCode() * 31) + 1231;
    }

    public final String toString() {
        return "BitmapImage(bitmap=" + this.f31801a + ", shareable=true)";
    }
}
