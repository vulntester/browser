package z4;

import A9.x;
import B9.G;
import B9.f1;
import C3.h;
import C4.C0548j;
import D9.S0;
import E4.j;
import H4.j;
import J4.c;
import Ua.d;
import java.util.ArrayList;
import java.util.List;
import xa.C4969i;
import xa.C4973m;
import xa.C4978r;
import ya.s;

/* renamed from: z4.b  reason: case insensitive filesystem */
public final class C3559b {

    /* renamed from: a  reason: collision with root package name */
    public final List<j> f31802a;

    /* renamed from: b  reason: collision with root package name */
    public final List<C4973m<c<? extends Object, ? extends Object>, d<? extends Object>>> f31803b;

    /* renamed from: c  reason: collision with root package name */
    public final List<C4973m<I4.c<? extends Object>, d<? extends Object>>> f31804c;

    /* renamed from: d  reason: collision with root package name */
    public List<? extends Na.a<? extends List<? extends C4973m<? extends j.a<? extends Object>, ? extends d<? extends Object>>>>> f31805d;

    /* renamed from: e  reason: collision with root package name */
    public List<? extends Na.a<? extends List<? extends C0548j.a>>> f31806e;

    /* renamed from: f  reason: collision with root package name */
    public final C4978r f31807f;

    /* renamed from: g  reason: collision with root package name */
    public final C4978r f31808g;

    public C3559b(List<? extends H4.j> list, List<? extends C4973m<? extends c<? extends Object, ? extends Object>, ? extends d<? extends Object>>> list2, List<? extends C4973m<? extends I4.c<? extends Object>, ? extends d<? extends Object>>> list3, List<? extends Na.a<? extends List<? extends C4973m<? extends j.a<? extends Object>, ? extends d<? extends Object>>>>> list4, List<? extends Na.a<? extends List<? extends C0548j.a>>> list5) {
        this.f31802a = list;
        this.f31803b = list2;
        this.f31804c = list3;
        this.f31805d = list4;
        this.f31806e = list5;
        this.f31807f = C4969i.e(new f1(this, 15));
        this.f31808g = C4969i.e(new x(this, 13));
    }

    /* renamed from: z4.b$a */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final ArrayList f31809a;

        /* renamed from: b  reason: collision with root package name */
        public final ArrayList f31810b;

        /* renamed from: c  reason: collision with root package name */
        public final ArrayList f31811c;

        /* renamed from: d  reason: collision with root package name */
        public final ArrayList f31812d;

        /* renamed from: e  reason: collision with root package name */
        public final ArrayList f31813e;

        public a() {
            this.f31809a = new ArrayList();
            this.f31810b = new ArrayList();
            this.f31811c = new ArrayList();
            this.f31812d = new ArrayList();
            this.f31813e = new ArrayList();
        }

        public final void a(j.a aVar, d dVar) {
            this.f31812d.add(new S0(5, aVar, dVar));
        }

        public final void b(c cVar, d dVar) {
            this.f31810b.add(new C4973m(cVar, dVar));
        }

        public final C3559b c() {
            return new C3559b(U4.c.a(this.f31809a), U4.c.a(this.f31810b), U4.c.a(this.f31811c), U4.c.a(this.f31812d), U4.c.a(this.f31813e));
        }

        public a(C3559b bVar) {
            this.f31809a = s.x0(bVar.f31802a);
            this.f31810b = s.x0(bVar.f31803b);
            this.f31811c = s.x0(bVar.f31804c);
            ArrayList arrayList = new ArrayList();
            for (C4973m hVar : (List) bVar.f31807f.getValue()) {
                arrayList.add(new h(hVar, 11));
            }
            this.f31812d = arrayList;
            ArrayList arrayList2 = new ArrayList();
            for (C0548j.a g6 : (List) bVar.f31808g.getValue()) {
                arrayList2.add(new G(g6, 11));
            }
            this.f31813e = arrayList2;
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C3559b() {
        /*
            r6 = this;
            ya.u r1 = ya.u.f44685f
            r2 = r1
            r3 = r1
            r4 = r1
            r5 = r1
            r0 = r6
            r0.<init>(r1, r2, r3, r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: z4.C3559b.<init>():void");
    }
}
