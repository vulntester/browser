package z4;

import U4.t;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import kotlin.jvm.internal.l;

/* renamed from: z4.c  reason: case insensitive filesystem */
public final class C3560c implements g {

    /* renamed from: a  reason: collision with root package name */
    public final Drawable f31814a;

    /* renamed from: z4.c$a */
    public interface a {
        long a();
    }

    public C3560c(Drawable drawable) {
        this.f31814a = drawable;
    }

    public final long a() {
        long j10;
        Drawable drawable = this.f31814a;
        if (drawable instanceof a) {
            j10 = ((a) drawable).a();
        } else {
            j10 = ((long) t.b(drawable)) * 4 * ((long) t.a(drawable));
        }
        if (j10 < 0) {
            return 0;
        }
        return j10;
    }

    public final boolean b() {
        return false;
    }

    public final void c(Canvas canvas) {
        this.f31814a.draw(canvas);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C3560c)) {
            return false;
        }
        if (!l.a(this.f31814a, ((C3560c) obj).f31814a)) {
            return false;
        }
        return true;
    }

    public final int getHeight() {
        return t.a(this.f31814a);
    }

    public final int getWidth() {
        return t.b(this.f31814a);
    }

    public final int hashCode() {
        return (this.f31814a.hashCode() * 31) + 1237;
    }

    public final String toString() {
        return "DrawableImage(drawable=" + this.f31814a + ", shareable=false)";
    }
}
