package z4;

/* renamed from: z4.d  reason: case insensitive filesystem */
public abstract class C3561d {

    /* renamed from: a  reason: collision with root package name */
    public static final a f31815a = new C3561d();

    /* renamed from: z4.d$a */
    public static final class a extends C3561d {
    }

    /* renamed from: z4.d$b */
    public interface b {

        /* renamed from: D  reason: collision with root package name */
        public static final L8.b f31816D = new L8.b(9);
    }
}
