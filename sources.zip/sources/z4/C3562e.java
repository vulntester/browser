package z4;

import U4.c;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.l;
import ya.C5007D;

/* renamed from: z4.e  reason: case insensitive filesystem */
public final class C3562e {

    /* renamed from: b  reason: collision with root package name */
    public static final C3562e f31817b = new C3562e(c.b(new a().f31819a));

    /* renamed from: a  reason: collision with root package name */
    public final Map<b<?>, Object> f31818a;

    /* renamed from: z4.e$b */
    public static final class b<T> {

        /* renamed from: a  reason: collision with root package name */
        public final T f31820a;

        public b(T t10) {
            this.f31820a = t10;
        }
    }

    public C3562e() {
        throw null;
    }

    public C3562e(Map map) {
        this.f31818a = map;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof C3562e) && l.a(this.f31818a, ((C3562e) obj).f31818a)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.f31818a.hashCode();
    }

    public final String toString() {
        return "Extras(data=" + this.f31818a + ')';
    }

    /* renamed from: z4.e$a */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final LinkedHashMap f31819a;

        public a() {
            this.f31819a = new LinkedHashMap();
        }

        public a(C3562e eVar) {
            this.f31819a = C5007D.F(eVar.f31818a);
        }
    }
}
