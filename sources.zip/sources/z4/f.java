package z4;

import P4.m;
import z4.C3562e;

public final class f {
    public static final <T> T a(P4.f fVar, C3562e.b<T> bVar) {
        T t10 = fVar.f7356s.f31818a.get(bVar);
        if (t10 != null) {
            return t10;
        }
        T t11 = fVar.f7358u.f7391n.f31818a.get(bVar);
        if (t11 == null) {
            return bVar.f31820a;
        }
        return t11;
    }

    public static final <T> T b(m mVar, C3562e.b<T> bVar) {
        T t10 = mVar.f7425j.f31818a.get(bVar);
        if (t10 == null) {
            return bVar.f31820a;
        }
        return t10;
    }
}
