package z4;

import android.graphics.Canvas;

public interface g {
    long a();

    boolean b();

    void c(Canvas canvas);

    int getHeight();

    int getWidth();
}
