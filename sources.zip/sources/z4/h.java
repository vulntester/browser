package z4;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import xa.C4961a;

public final class h extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    public final g f31821a;

    public h(g gVar) {
        this.f31821a = gVar;
    }

    public final void draw(Canvas canvas) {
        this.f31821a.c(canvas);
    }

    @C4961a
    public final int getOpacity() {
        return 0;
    }

    public final void setAlpha(int i10) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
