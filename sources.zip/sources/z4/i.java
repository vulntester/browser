package z4;

import A9.r;
import P4.f;
import U4.c;
import android.content.Context;
import xa.C4969i;
import xa.C4978r;
import z4.C3562e;
import z4.m;

public interface i {

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final Context f31822a;

        /* renamed from: b  reason: collision with root package name */
        public final f.b f31823b = f.b.f7377o;

        /* renamed from: c  reason: collision with root package name */
        public C3559b f31824c = null;

        /* renamed from: d  reason: collision with root package name */
        public final C3562e.a f31825d = new C3562e.a();

        public a(Context context) {
            this.f31822a = context.getApplicationContext();
        }

        public final m a() {
            C3562e.a aVar = this.f31825d;
            aVar.getClass();
            C3562e eVar = new C3562e(c.b(aVar.f31819a));
            f.b bVar = this.f31823b;
            f.b bVar2 = new f.b(bVar.f7378a, bVar.f7379b, bVar.f7380c, bVar.f7381d, bVar.f7382e, bVar.f7383f, bVar.f7384g, bVar.f7385h, bVar.f7386i, bVar.f7387j, bVar.f7388k, bVar.f7389l, bVar.f7390m, eVar);
            C4978r e10 = C4969i.e(new r(this, 15));
            C4978r e11 = C4969i.e(new L9.c(7));
            C3559b bVar3 = this.f31824c;
            if (bVar3 == null) {
                bVar3 = new C3559b();
            }
            return new m(new m.a(this.f31822a, bVar2, e10, e11, bVar3));
        }
    }

    Object a(f fVar, Da.c cVar);
}
