package z4;

import z4.C3562e;

public final class j {

    /* renamed from: a  reason: collision with root package name */
    public static final C3562e.b<Boolean> f31826a = new C3562e.b<>(Boolean.TRUE);
}
