package z4;

import C4.n;
import z4.C3562e;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    public static final C3562e.b<Integer> f31827a = new C3562e.b<>(4);

    /* renamed from: b  reason: collision with root package name */
    public static final C3562e.b<n> f31828b = new C3562e.b<>(n.f1350a);

    /* renamed from: c  reason: collision with root package name */
    public static final C3562e.b<Boolean> f31829c = new C3562e.b<>(Boolean.TRUE);
}
