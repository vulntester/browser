package z4;

import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

public final class l {
    public static final Drawable a(g gVar, Resources resources) {
        if (gVar instanceof C3560c) {
            return ((C3560c) gVar).f31814a;
        }
        if (gVar instanceof C3558a) {
            return new BitmapDrawable(resources, ((C3558a) gVar).f31801a);
        }
        return new h(gVar);
    }

    public static final g b(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return new C3558a(((BitmapDrawable) drawable).getBitmap());
        }
        return new C3560c(drawable);
    }
}
