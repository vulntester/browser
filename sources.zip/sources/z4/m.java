package z4;

import A9.y;
import Ba.e;
import Ba.h;
import C4.B;
import C4.C0542d;
import C4.n;
import Da.c;
import L8.b;
import P4.f;
import T4.d;
import Uc.C;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import androidx.lifecycle.C1333k;
import ic.C4488D;
import ic.C4529z;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.jvm.internal.E;
import kotlin.jvm.internal.F;
import kotlin.jvm.internal.l;
import nc.C4732d;
import sc.C4833f;
import sc.i;
import xa.C4973m;
import xa.C4978r;
import z4.C3559b;
import z4.C3561d;
import z4.C3562e;

public final class m implements i {

    /* renamed from: f  reason: collision with root package name */
    public static final /* synthetic */ int f31830f = 0;

    /* renamed from: a  reason: collision with root package name */
    public final a f31831a;

    /* renamed from: b  reason: collision with root package name */
    public final C4732d f31832b = C4488D.a(h.a.a(A1.a.f(), new Ba.a(C4529z.a.f41227f)));

    /* renamed from: c  reason: collision with root package name */
    public final P4.a f31833c;

    /* renamed from: d  reason: collision with root package name */
    public final C3559b f31834d;

    /* renamed from: e  reason: collision with root package name */
    public volatile /* synthetic */ int f31835e;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public final Context f31836a;

        /* renamed from: b  reason: collision with root package name */
        public final f.b f31837b;

        /* renamed from: c  reason: collision with root package name */
        public final C4978r f31838c;

        /* renamed from: d  reason: collision with root package name */
        public final C4978r f31839d;

        /* renamed from: e  reason: collision with root package name */
        public final C3559b f31840e;

        public a(Context context, f.b bVar, C4978r rVar, C4978r rVar2, C3559b bVar2) {
            this.f31836a = context;
            this.f31837b = bVar;
            this.f31838c = rVar;
            this.f31839d = rVar2;
            this.f31840e = bVar2;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            if (!l.a(this.f31836a, aVar.f31836a) || !this.f31837b.equals(aVar.f31837b) || !this.f31838c.equals(aVar.f31838c) || !this.f31839d.equals(aVar.f31839d)) {
                return false;
            }
            b bVar = C3561d.b.f31816D;
            if (bVar.equals(bVar) && this.f31840e.equals(aVar.f31840e)) {
                return true;
            }
            return false;
        }

        public final int hashCode() {
            int hashCode = this.f31837b.hashCode();
            int hashCode2 = this.f31838c.hashCode();
            int hashCode3 = this.f31839d.hashCode();
            int hashCode4 = C3561d.b.f31816D.hashCode();
            return (this.f31840e.hashCode() + ((hashCode4 + ((hashCode3 + ((hashCode2 + ((hashCode + (this.f31836a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31;
        }

        public final String toString() {
            return "Options(application=" + this.f31836a + ", defaults=" + this.f31837b + ", memoryCacheLazy=" + this.f31838c + ", diskCacheLazy=" + this.f31839d + ", eventListenerFactory=" + C3561d.b.f31816D + ", componentRegistry=" + this.f31840e + ", logger=null)";
        }
    }

    static {
        AtomicIntegerFieldUpdater.newUpdater(m.class, "e");
    }

    /* JADX WARNING: type inference failed for: r4v7, types: [java.lang.Object, J4.c] */
    /* JADX WARNING: type inference failed for: r4v8, types: [java.lang.Object, J4.c] */
    /* JADX WARNING: type inference failed for: r9v1, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r9v2, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r9v3, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r9v4, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r9v5, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r9v12, types: [sc.f, sc.h] */
    /* JADX WARNING: type inference failed for: r13v6, types: [java.lang.Object, J4.c] */
    /* JADX WARNING: type inference failed for: r13v7, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r13v8, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r13v9, types: [java.lang.Object, J4.c] */
    /* JADX WARNING: type inference failed for: r13v10, types: [java.lang.Object, J4.c] */
    /* JADX WARNING: type inference failed for: r13v13, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r13v14, types: [E4.j$a, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r13v15, types: [E4.j$a, java.lang.Object] */
    public m(a aVar) {
        this.f31831a = aVar;
        U4.a aVar2 = new U4.a(this);
        P4.a aVar3 = new P4.a(this, aVar2);
        this.f31833c = aVar3;
        C3559b.a aVar4 = new C3559b.a(aVar.f31840e);
        f.b bVar = aVar.f31837b;
        Object obj = bVar.f7391n.f31818a.get(j.f31826a);
        boolean booleanValue = ((Boolean) (obj == null ? Boolean.TRUE : obj)).booleanValue();
        ArrayList arrayList = aVar4.f31813e;
        if (booleanValue) {
            aVar4.f31812d.add(new E5.b(6));
            arrayList.add(new io.ktor.client.plugins.cache.storage.a(4));
        }
        ? obj2 = new Object();
        F f10 = E.f41744a;
        aVar4.b(obj2, f10.b(Uri.class));
        aVar4.b(new Object(), f10.b(Integer.class));
        Class<w> cls = w.class;
        C4973m mVar = new C4973m(new Object(), f10.b(cls));
        ArrayList arrayList2 = aVar4.f31811c;
        arrayList2.add(mVar);
        aVar4.a(new Object(), f10.b(cls));
        aVar4.a(new Object(), f10.b(cls));
        aVar4.a(new Object(), f10.b(cls));
        aVar4.a(new Object(), f10.b(Drawable.class));
        aVar4.a(new Object(), f10.b(Bitmap.class));
        C3562e.b<Integer> bVar2 = k.f31827a;
        int i10 = bVar.f7391n.f31818a.get(k.f31827a);
        int intValue = ((Number) (i10 == null ? 4 : i10)).intValue();
        int i11 = i.f43482a;
        ? fVar = new C4833f(intValue, 0);
        int i12 = Build.VERSION.SDK_INT;
        Object obj3 = n.f1350a;
        if (i12 >= 29) {
            Object obj4 = bVar.f7391n.f31818a.get(k.f31829c);
            if (((Boolean) (obj4 == null ? Boolean.TRUE : obj4)).booleanValue()) {
                Object obj5 = bVar.f7391n.f31818a.get(k.f31828b);
                if (((n) (obj5 == null ? obj3 : obj5)).equals(obj3)) {
                    arrayList.add(new y(new B.a(fVar), 17));
                }
            }
        }
        Object obj6 = bVar.f7391n.f31818a.get(k.f31828b);
        arrayList.add(new y(new C0542d.b(fVar, (n) (obj6 != null ? obj6 : obj3)), 17));
        aVar4.b(new Object(), f10.b(File.class));
        aVar4.a(new Object(), f10.b(cls));
        aVar4.a(new Object(), f10.b(ByteBuffer.class));
        aVar4.b(new Object(), f10.b(String.class));
        aVar4.b(new Object(), f10.b(C.class));
        arrayList2.add(new C4973m(new Object(), f10.b(cls)));
        arrayList2.add(new C4973m(new Object(), f10.b(cls)));
        aVar4.a(new Object(), f10.b(cls));
        aVar4.a(new Object(), f10.b(byte[].class));
        aVar4.a(new Object(), f10.b(cls));
        aVar4.f31809a.add(new H4.a(this, aVar2, aVar3));
        this.f31834d = aVar4.c();
    }

    public final Object a(f fVar, c cVar) {
        if ((fVar.f7340c instanceof R4.a) || (fVar.f7353p instanceof Q4.l) || ((C1333k) f.a(fVar, P4.h.f7410e)) != null) {
            return C4488D.c(new o((e) null, fVar, this), cVar);
        }
        return b(fVar, 1, cVar);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v4, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v5, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v2, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v7, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v9, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v11, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v11, resolved type: P4.q} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v12, resolved type: P4.n} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v29, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v29, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v30, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v32, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v33, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v38, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v39, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v20, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v40, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v36, resolved type: P4.f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v21, resolved type: P4.n} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v41, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v42, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v43, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v44, resolved type: z4.d$a} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v45, resolved type: z4.d} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v46, resolved type: z4.d} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v25, resolved type: P4.n} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v26, resolved type: P4.n} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v48, resolved type: z4.d} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v49, resolved type: z4.d} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v28, resolved type: P4.n} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v29, resolved type: P4.n} */
    /* JADX WARNING: Code restructure failed: missing block: B:152:0x0260, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:153:0x0261, code lost:
        r3 = r1;
        r1 = r4;
        r4 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x003b, code lost:
        r0 = th;
        r4 = r4;
        r1 = r1;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [B:13:0x0036, B:128:0x01f5] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x01ae A[Catch:{ all -> 0x0260, all -> 0x003b }] */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x01f0  */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x0214  */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x021d A[Catch:{ all -> 0x0260, all -> 0x003b }] */
    /* JADX WARNING: Removed duplicated region for block: B:144:0x024a A[Catch:{ all -> 0x0260, all -> 0x003b }] */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0068  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x002a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object b(P4.f r16, int r17, Da.c r18) {
        /*
            r15 = this;
            r5 = r16
            r0 = r18
            boolean r1 = r0 instanceof z4.p
            if (r1 == 0) goto L_0x0018
            r1 = r0
            z4.p r1 = (z4.p) r1
            int r3 = r1.f31854H
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r6 = r3 & r4
            if (r6 == 0) goto L_0x0018
            int r3 = r3 - r4
            r1.f31854H = r3
        L_0x0016:
            r9 = r1
            goto L_0x001e
        L_0x0018:
            z4.p r1 = new z4.p
            r1.<init>(r15, r0)
            goto L_0x0016
        L_0x001e:
            java.lang.Object r0 = r9.f31852F
            Ca.a r10 = Ca.a.f33640f
            int r1 = r9.f31854H
            r11 = 0
            r12 = 3
            r13 = 2
            r14 = 1
            if (r1 == 0) goto L_0x0068
            if (r1 == r14) goto L_0x005d
            if (r1 == r13) goto L_0x0046
            if (r1 != r12) goto L_0x003e
            z4.d r1 = r9.f31857z
            P4.f r3 = r9.f31856i
            P4.n r4 = r9.f31855f
            xa.C4976p.b(r0)     // Catch:{ all -> 0x003b }
            goto L_0x0217
        L_0x003b:
            r0 = move-exception
            goto L_0x026d
        L_0x003e:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r1)
            throw r0
        L_0x0046:
            z4.g r1 = r9.f31851E
            z4.d r3 = r9.f31857z
            P4.f r4 = r9.f31856i
            P4.n r5 = r9.f31855f
            xa.C4976p.b(r0)     // Catch:{ all -> 0x0057 }
            r7 = r5
            r5 = r1
            r1 = r4
            r4 = r3
            goto L_0x01f4
        L_0x0057:
            r0 = move-exception
            r1 = r3
            r3 = r4
            r4 = r5
            goto L_0x026d
        L_0x005d:
            z4.d r1 = r9.f31857z
            P4.f r3 = r9.f31856i
            P4.n r4 = r9.f31855f
            xa.C4976p.b(r0)     // Catch:{ all -> 0x003b }
            goto L_0x01a7
        L_0x0068:
            xa.C4976p.b(r0)
            Ba.h r0 = r9.getContext()
            ic.m0 r8 = f7.J.r(r0)
            if (r17 != 0) goto L_0x0077
            r0 = r14
            goto L_0x0078
        L_0x0077:
            r0 = 0
        L_0x0078:
            P4.a r1 = r15.f31833c
            r1.getClass()
            A4.f r3 = r5.f7340c
            boolean r4 = r3 instanceof R4.a
            if (r4 == 0) goto L_0x009f
            z4.e$b<androidx.lifecycle.k> r0 = P4.h.f7410e
            java.lang.Object r0 = z4.f.a(r5, r0)
            androidx.lifecycle.k r0 = (androidx.lifecycle.C1333k) r0
            if (r0 != 0) goto L_0x0091
            androidx.lifecycle.k r0 = P4.a.a(r5)
        L_0x0091:
            r7 = r0
            r0 = r3
            P4.q r3 = new P4.q
            z4.m r4 = r1.f7328a
            r6 = r0
            R4.a r6 = (R4.a) r6
            r3.<init>(r4, r5, r6, r7, r8)
            r4 = r3
            goto L_0x00c0
        L_0x009f:
            z4.e$b<androidx.lifecycle.k> r3 = P4.h.f7410e
            java.lang.Object r3 = z4.f.a(r5, r3)
            androidx.lifecycle.k r3 = (androidx.lifecycle.C1333k) r3
            if (r3 != 0) goto L_0x00b1
            if (r0 == 0) goto L_0x00b0
            androidx.lifecycle.k r3 = P4.a.a(r5)
            goto L_0x00b1
        L_0x00b0:
            r3 = r11
        L_0x00b1:
            if (r3 == 0) goto L_0x00ba
            P4.j r0 = new P4.j
            r0.<init>(r3, r8)
        L_0x00b8:
            r4 = r0
            goto L_0x00c0
        L_0x00ba:
            P4.b r0 = new P4.b
            r0.<init>(r8)
            goto L_0x00b8
        L_0x00c0:
            r4.c()
            r1.getClass()
            P4.f$a r0 = P4.f.a(r5)
            z4.m r1 = r1.f7328a
            z4.m$a r1 = r1.f31831a
            P4.f$b r1 = r1.f31837b
            r0.f7360b = r1
            P4.f$c r1 = r5.f7357t
            Q4.i r3 = r1.f7399h
            A4.f r6 = r5.f7340c
            if (r3 != 0) goto L_0x0106
            boolean r3 = r6 instanceof R4.a
            if (r3 == 0) goto L_0x0102
            r3 = r6
            R4.a r3 = (R4.a) r3
            android.view.View r3 = r3.getView()
            boolean r7 = r3 instanceof android.widget.ImageView
            if (r7 == 0) goto L_0x00fb
            r7 = r3
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            android.widget.ImageView$ScaleType r7 = r7.getScaleType()
            android.widget.ImageView$ScaleType r8 = android.widget.ImageView.ScaleType.CENTER
            if (r7 == r8) goto L_0x00f8
            android.widget.ImageView$ScaleType r8 = android.widget.ImageView.ScaleType.MATRIX
            if (r7 != r8) goto L_0x00fb
        L_0x00f8:
            Q4.d r3 = Q4.i.f7760g
            goto L_0x0104
        L_0x00fb:
            Q4.e r7 = new Q4.e
            r7.<init>(r3)
            r3 = r7
            goto L_0x0104
        L_0x0102:
            Q4.d r3 = Q4.i.f7760g
        L_0x0104:
            r0.f7373o = r3
        L_0x0106:
            Q4.f r7 = r1.f7400i
            if (r7 != 0) goto L_0x014a
            boolean r7 = r6 instanceof R4.a
            if (r7 == 0) goto L_0x0112
            r7 = r6
            R4.a r7 = (R4.a) r7
            goto L_0x0113
        L_0x0112:
            r7 = r11
        L_0x0113:
            if (r7 == 0) goto L_0x011a
            android.view.View r7 = r7.getView()
            goto L_0x011b
        L_0x011a:
            r7 = r11
        L_0x011b:
            boolean r8 = r7 instanceof android.widget.ImageView
            if (r8 == 0) goto L_0x0122
            android.widget.ImageView r7 = (android.widget.ImageView) r7
            goto L_0x0123
        L_0x0122:
            r7 = r11
        L_0x0123:
            if (r7 == 0) goto L_0x0146
            android.graphics.Bitmap$Config[] r5 = U4.t.f10494a
            android.widget.ImageView$ScaleType r5 = r7.getScaleType()
            if (r5 != 0) goto L_0x012f
            r5 = -1
            goto L_0x0137
        L_0x012f:
            int[] r7 = U4.t.a.f10496a
            int r5 = r5.ordinal()
            r5 = r7[r5]
        L_0x0137:
            if (r5 == r14) goto L_0x0143
            if (r5 == r13) goto L_0x0143
            if (r5 == r12) goto L_0x0143
            r7 = 4
            if (r5 == r7) goto L_0x0143
            Q4.f r5 = Q4.f.f7749f
            goto L_0x0148
        L_0x0143:
            Q4.f r5 = Q4.f.f7750i
            goto L_0x0148
        L_0x0146:
            Q4.f r5 = r5.f7354q
        L_0x0148:
            r0.f7374p = r5
        L_0x014a:
            Q4.c r5 = r1.f7401j
            if (r5 != 0) goto L_0x0182
            Q4.i r1 = r1.f7399h
            if (r1 != 0) goto L_0x015d
            Q4.d r1 = Q4.i.f7760g
            boolean r1 = kotlin.jvm.internal.l.a(r3, r1)
            if (r1 == 0) goto L_0x015d
            Q4.c r1 = Q4.c.f7745i
            goto L_0x0180
        L_0x015d:
            boolean r1 = r6 instanceof R4.a
            if (r1 == 0) goto L_0x017e
            boolean r1 = r3 instanceof Q4.l
            if (r1 == 0) goto L_0x017e
            R4.a r6 = (R4.a) r6
            android.view.View r1 = r6.getView()
            boolean r1 = r1 instanceof android.widget.ImageView
            if (r1 == 0) goto L_0x017e
            android.view.View r1 = r6.getView()
            Q4.l r3 = (Q4.l) r3
            android.view.View r3 = r3.getView()
            if (r1 != r3) goto L_0x017e
            Q4.c r1 = Q4.c.f7745i
            goto L_0x0180
        L_0x017e:
            Q4.c r1 = Q4.c.f7744f
        L_0x0180:
            r0.f7375q = r1
        L_0x0182:
            P4.f r3 = r0.a()
            z4.d$a r1 = z4.C3561d.f31815a
            java.lang.Object r0 = r3.f7339b     // Catch:{ all -> 0x003b }
            P4.k r5 = P4.k.f7415a     // Catch:{ all -> 0x003b }
            boolean r0 = kotlin.jvm.internal.l.a(r0, r5)     // Catch:{ all -> 0x003b }
            if (r0 != 0) goto L_0x0265
            r4.start()     // Catch:{ all -> 0x003b }
            if (r17 != 0) goto L_0x01a7
            r9.f31855f = r4     // Catch:{ all -> 0x003b }
            r9.f31856i = r3     // Catch:{ all -> 0x003b }
            r9.f31857z = r1     // Catch:{ all -> 0x003b }
            r9.f31854H = r14     // Catch:{ all -> 0x003b }
            java.lang.Object r0 = r4.g(r9)     // Catch:{ all -> 0x003b }
            if (r0 != r10) goto L_0x01a7
            goto L_0x0213
        L_0x01a7:
            r3.getClass()     // Catch:{ all -> 0x003b }
            A4.f r0 = r3.f7340c     // Catch:{ all -> 0x003b }
            if (r0 == 0) goto L_0x01da
            Na.l<P4.f, z4.g> r5 = r3.f7350m     // Catch:{ all -> 0x003b }
            java.lang.Object r5 = r5.invoke(r3)     // Catch:{ all -> 0x003b }
            z4.g r5 = (z4.g) r5     // Catch:{ all -> 0x003b }
            if (r5 != 0) goto L_0x01c2
            P4.f$b r5 = r3.f7358u     // Catch:{ all -> 0x003b }
            Na.l<P4.f, z4.g> r5 = r5.f7385h     // Catch:{ all -> 0x003b }
            java.lang.Object r5 = r5.invoke(r3)     // Catch:{ all -> 0x003b }
            z4.g r5 = (z4.g) r5     // Catch:{ all -> 0x003b }
        L_0x01c2:
            A4.e r6 = r0.f293b     // Catch:{ all -> 0x003b }
            if (r5 == 0) goto L_0x01d1
            P4.f r0 = r0.f292a     // Catch:{ all -> 0x003b }
            android.content.Context r0 = r0.f7338a     // Catch:{ all -> 0x003b }
            int r7 = r6.f273R     // Catch:{ all -> 0x003b }
            u0.c r0 = A4.o.i(r5, r0, r7)     // Catch:{ all -> 0x003b }
            goto L_0x01d2
        L_0x01d1:
            r0 = r11
        L_0x01d2:
            A4.e$b$c r5 = new A4.e$b$c     // Catch:{ all -> 0x003b }
            r5.<init>(r0)     // Catch:{ all -> 0x003b }
            A4.e.k(r6, r5)     // Catch:{ all -> 0x003b }
        L_0x01da:
            r1.getClass()     // Catch:{ all -> 0x003b }
            Q4.i r0 = r3.f7353p     // Catch:{ all -> 0x003b }
            r9.f31855f = r4     // Catch:{ all -> 0x003b }
            r9.f31856i = r3     // Catch:{ all -> 0x003b }
            r9.f31857z = r1     // Catch:{ all -> 0x003b }
            r9.f31851E = r11     // Catch:{ all -> 0x003b }
            r9.f31854H = r13     // Catch:{ all -> 0x003b }
            java.lang.Object r0 = r0.e(r9)     // Catch:{ all -> 0x003b }
            if (r0 != r10) goto L_0x01f0
            goto L_0x0213
        L_0x01f0:
            r7 = r4
            r5 = r11
            r4 = r1
            r1 = r3
        L_0x01f4:
            r3 = r0
            Q4.h r3 = (Q4.h) r3     // Catch:{ all -> 0x0260 }
            r4.getClass()     // Catch:{ all -> 0x0260 }
            Ba.h r8 = r1.f7344g     // Catch:{ all -> 0x0260 }
            z4.q r0 = new z4.q     // Catch:{ all -> 0x0260 }
            r6 = 0
            r2 = r15
            r0.<init>(r1, r2, r3, r4, r5, r6)     // Catch:{ all -> 0x0260 }
            r9.f31855f = r7     // Catch:{ all -> 0x0260 }
            r9.f31856i = r1     // Catch:{ all -> 0x0260 }
            r9.f31857z = r4     // Catch:{ all -> 0x0260 }
            r9.f31851E = r11     // Catch:{ all -> 0x0260 }
            r9.f31854H = r12     // Catch:{ all -> 0x0260 }
            java.lang.Object r0 = ic.G.M(r8, r0, r9)     // Catch:{ all -> 0x0260 }
            if (r0 != r10) goto L_0x0214
        L_0x0213:
            return r10
        L_0x0214:
            r3 = r1
            r1 = r4
            r4 = r7
        L_0x0217:
            P4.i r0 = (P4.i) r0     // Catch:{ all -> 0x003b }
            boolean r5 = r0 instanceof P4.o     // Catch:{ all -> 0x003b }
            if (r5 == 0) goto L_0x024a
            r5 = r0
            P4.o r5 = (P4.o) r5     // Catch:{ all -> 0x003b }
            A4.f r6 = r3.f7340c     // Catch:{ all -> 0x003b }
            P4.f r7 = r5.f7427b     // Catch:{ all -> 0x003b }
            boolean r8 = r6 instanceof T4.e     // Catch:{ all -> 0x003b }
            if (r8 != 0) goto L_0x0229
            goto L_0x0246
        L_0x0229:
            z4.e$b<T4.d$a> r8 = P4.h.f7406a     // Catch:{ all -> 0x003b }
            java.lang.Object r7 = z4.f.a(r7, r8)     // Catch:{ all -> 0x003b }
            T4.d$a r7 = (T4.d.a) r7     // Catch:{ all -> 0x003b }
            r8 = r6
            T4.e r8 = (T4.e) r8     // Catch:{ all -> 0x003b }
            T4.d r5 = r7.a(r8, r5)     // Catch:{ all -> 0x003b }
            boolean r7 = r5 instanceof T4.c     // Catch:{ all -> 0x003b }
            if (r7 == 0) goto L_0x0240
            r6.getClass()     // Catch:{ all -> 0x003b }
            goto L_0x0246
        L_0x0240:
            r1.getClass()     // Catch:{ all -> 0x003b }
            r5.a()     // Catch:{ all -> 0x003b }
        L_0x0246:
            r1.getClass()     // Catch:{ all -> 0x003b }
            goto L_0x0256
        L_0x024a:
            boolean r5 = r0 instanceof P4.e     // Catch:{ all -> 0x003b }
            if (r5 == 0) goto L_0x025a
            r5 = r0
            P4.e r5 = (P4.e) r5     // Catch:{ all -> 0x003b }
            A4.f r6 = r3.f7340c     // Catch:{ all -> 0x003b }
            r15.d(r5, r6, r1)     // Catch:{ all -> 0x003b }
        L_0x0256:
            r4.b()
            return r0
        L_0x025a:
            xa.k r0 = new xa.k     // Catch:{ all -> 0x003b }
            r0.<init>()     // Catch:{ all -> 0x003b }
            throw r0     // Catch:{ all -> 0x003b }
        L_0x0260:
            r0 = move-exception
            r3 = r1
            r1 = r4
            r4 = r7
            goto L_0x026d
        L_0x0265:
            P4.l r0 = new P4.l     // Catch:{ all -> 0x003b }
            java.lang.String r5 = "The request's data is null."
            r0.<init>(r5)     // Catch:{ all -> 0x003b }
            throw r0     // Catch:{ all -> 0x003b }
        L_0x026d:
            boolean r5 = r0 instanceof java.util.concurrent.CancellationException     // Catch:{ all -> 0x027e }
            if (r5 != 0) goto L_0x0280
            P4.e r0 = U4.s.a(r3, r0)     // Catch:{ all -> 0x027e }
            A4.f r3 = r3.f7340c     // Catch:{ all -> 0x027e }
            r15.d(r0, r3, r1)     // Catch:{ all -> 0x027e }
            r4.b()
            return r0
        L_0x027e:
            r0 = move-exception
            goto L_0x0287
        L_0x0280:
            r1.getClass()     // Catch:{ all -> 0x027e }
            r3.getClass()     // Catch:{ all -> 0x027e }
            throw r0     // Catch:{ all -> 0x027e }
        L_0x0287:
            r4.b()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: z4.m.b(P4.f, int, Da.c):java.lang.Object");
    }

    public final K4.c c() {
        return (K4.c) this.f31831a.f31838c.getValue();
    }

    public final void d(P4.e eVar, A4.f fVar, C3561d dVar) {
        f fVar2 = eVar.f7336b;
        if (fVar instanceof T4.e) {
            d a10 = ((d.a) f.a(fVar2, P4.h.f7406a)).a((T4.e) fVar, eVar);
            if (a10 instanceof T4.c) {
                fVar.getClass();
            } else {
                dVar.getClass();
                a10.a();
            }
        }
        dVar.getClass();
        fVar2.getClass();
    }
}
