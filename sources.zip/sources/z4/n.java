package z4;

import Ca.a;
import Da.e;
import Da.i;
import Na.p;
import P4.f;
import ic.C4487C;
import xa.C4959D;
import xa.C4976p;

@e(c = "coil3.RealImageLoader$enqueue$job$1", f = "RealImageLoader.kt", l = {67}, m = "invokeSuspend")
public final class n extends i implements p<C4487C, Ba.e<? super P4.i>, Object> {

    /* renamed from: f  reason: collision with root package name */
    public int f31841f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ m f31842i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ f f31843z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public n(Ba.e eVar, f fVar, m mVar) {
        super(2, eVar);
        this.f31842i = mVar;
        this.f31843z = fVar;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new n(eVar, this.f31843z, this.f31842i);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((n) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        a aVar = a.f33640f;
        int i10 = this.f31841f;
        if (i10 == 0) {
            C4976p.b(obj);
            this.f31841f = 1;
            int i11 = m.f31830f;
            Object b10 = this.f31842i.b(this.f31843z, 0, this);
            if (b10 == aVar) {
                return aVar;
            }
            return b10;
        } else if (i10 == 1) {
            C4976p.b(obj);
            return obj;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
