package z4;

import Da.e;
import Da.i;
import Na.p;
import P4.f;
import ic.C4487C;
import ic.G;
import ic.J;
import ic.U;
import jc.C4577e;
import xa.C4959D;
import xa.C4976p;

@e(c = "coil3.RealImageLoader$execute$2", f = "RealImageLoader.kt", l = {87}, m = "invokeSuspend")
public final class o extends i implements p<C4487C, Ba.e<? super P4.i>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ m f31844E;

    /* renamed from: f  reason: collision with root package name */
    public int f31845f;

    /* renamed from: i  reason: collision with root package name */
    public /* synthetic */ Object f31846i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ f f31847z;

    @e(c = "coil3.RealImageLoader$execute$2$job$1", f = "RealImageLoader.kt", l = {83}, m = "invokeSuspend")
    public static final class a extends i implements p<C4487C, Ba.e<? super P4.i>, Object> {

        /* renamed from: f  reason: collision with root package name */
        public int f31848f;

        /* renamed from: i  reason: collision with root package name */
        public final /* synthetic */ m f31849i;

        /* renamed from: z  reason: collision with root package name */
        public final /* synthetic */ f f31850z;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(Ba.e eVar, f fVar, m mVar) {
            super(2, eVar);
            this.f31849i = mVar;
            this.f31850z = fVar;
        }

        public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
            return new a(eVar, this.f31850z, this.f31849i);
        }

        public final Object invoke(Object obj, Object obj2) {
            return ((a) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
        }

        public final Object invokeSuspend(Object obj) {
            Ca.a aVar = Ca.a.f33640f;
            int i10 = this.f31848f;
            if (i10 == 0) {
                C4976p.b(obj);
                this.f31848f = 1;
                int i11 = m.f31830f;
                Object b10 = this.f31849i.b(this.f31850z, 1, this);
                if (b10 == aVar) {
                    return aVar;
                }
                return b10;
            } else if (i10 == 1) {
                C4976p.b(obj);
                return obj;
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public o(Ba.e eVar, f fVar, m mVar) {
        super(2, eVar);
        this.f31847z = fVar;
        this.f31844E = mVar;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        o oVar = new o(eVar, this.f31847z, this.f31844E);
        oVar.f31846i = obj;
        return oVar;
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((o) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        Ca.a aVar = Ca.a.f33640f;
        int i10 = this.f31845f;
        if (i10 == 0) {
            C4976p.b(obj);
            U u7 = U.f41134a;
            C4577e C02 = nc.p.f42446a.C0();
            m mVar = this.f31844E;
            f fVar = this.f31847z;
            J<P4.i> job = s.a(fVar, G.d((C4487C) this.f31846i, C02, new a((Ba.e) null, fVar, mVar), 2)).getJob();
            this.f31845f = 1;
            Object j10 = job.j(this);
            if (j10 == aVar) {
                return aVar;
            }
            return j10;
        } else if (i10 == 1) {
            C4976p.b(obj);
            return obj;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
