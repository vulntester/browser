package z4;

import Da.c;
import Da.e;
import P4.f;
import P4.n;

@e(c = "coil3.RealImageLoader", f = "RealImageLoader.kt", l = {117, 129, 133}, m = "execute")
public final class p extends c {

    /* renamed from: E  reason: collision with root package name */
    public g f31851E;

    /* renamed from: F  reason: collision with root package name */
    public /* synthetic */ Object f31852F;

    /* renamed from: G  reason: collision with root package name */
    public final /* synthetic */ m f31853G;

    /* renamed from: H  reason: collision with root package name */
    public int f31854H;

    /* renamed from: f  reason: collision with root package name */
    public n f31855f;

    /* renamed from: i  reason: collision with root package name */
    public f f31856i;

    /* renamed from: z  reason: collision with root package name */
    public C3561d f31857z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public p(m mVar, c cVar) {
        super(cVar);
        this.f31853G = mVar;
    }

    public final Object invokeSuspend(Object obj) {
        this.f31852F = obj;
        this.f31854H |= Integer.MIN_VALUE;
        int i10 = m.f31830f;
        return this.f31853G.b((f) null, 0, this);
    }
}
