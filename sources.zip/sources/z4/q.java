package z4;

import Ca.a;
import Da.e;
import Da.i;
import H4.j;
import H4.l;
import Na.p;
import P4.f;
import Q4.h;
import ic.C4487C;
import java.util.List;
import xa.C4959D;
import xa.C4976p;

@e(c = "coil3.RealImageLoader$execute$result$1", f = "RealImageLoader.kt", l = {142}, m = "invokeSuspend")
public final class q extends i implements p<C4487C, Ba.e<? super P4.i>, Object> {

    /* renamed from: E  reason: collision with root package name */
    public final /* synthetic */ h f31858E;

    /* renamed from: F  reason: collision with root package name */
    public final /* synthetic */ C3561d f31859F;

    /* renamed from: G  reason: collision with root package name */
    public final /* synthetic */ g f31860G;

    /* renamed from: f  reason: collision with root package name */
    public int f31861f;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ f f31862i;

    /* renamed from: z  reason: collision with root package name */
    public final /* synthetic */ m f31863z;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public q(f fVar, m mVar, h hVar, C3561d dVar, g gVar, Ba.e<? super q> eVar) {
        super(2, eVar);
        this.f31862i = fVar;
        this.f31863z = mVar;
        this.f31858E = hVar;
        this.f31859F = dVar;
        this.f31860G = gVar;
    }

    public final Ba.e<C4959D> create(Object obj, Ba.e<?> eVar) {
        return new q(this.f31862i, this.f31863z, this.f31858E, this.f31859F, this.f31860G, eVar);
    }

    public final Object invoke(Object obj, Object obj2) {
        return ((q) create((C4487C) obj, (Ba.e) obj2)).invokeSuspend(C4959D.f44058a);
    }

    public final Object invokeSuspend(Object obj) {
        boolean z10;
        a aVar = a.f33640f;
        int i10 = this.f31861f;
        if (i10 == 0) {
            C4976p.b(obj);
            List<j> list = this.f31863z.f31834d.f31802a;
            if (this.f31860G != null) {
                z10 = true;
            } else {
                z10 = false;
            }
            f fVar = this.f31862i;
            l lVar = new l(fVar, list, 0, fVar, this.f31858E, this.f31859F, z10);
            this.f31861f = 1;
            Object a10 = lVar.a(this);
            if (a10 == aVar) {
                return aVar;
            }
            return a10;
        } else if (i10 == 1) {
            C4976p.b(obj);
            return obj;
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
