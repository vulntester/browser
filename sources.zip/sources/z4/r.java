package z4;

import Ba.a;
import Ba.h;
import ic.C4529z;

public final class r extends a implements C4529z {
    public final void handleException(h hVar, Throwable th) {
    }
}
