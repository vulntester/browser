package z4;

import Fc.C3984j;
import P4.d;
import P4.f;
import P4.p;
import P4.t;
import R4.a;
import android.graphics.Bitmap;
import android.os.Looper;
import ic.A0;
import ic.K;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.l;

public final class s {
    public static final d a(f fVar, K k10) {
        A4.f fVar2 = fVar.f7340c;
        if (!(fVar2 instanceof a)) {
            return new C3984j((Object) k10);
        }
        P4.s a10 = t.a(((a) fVar2).getView());
        synchronized (a10) {
            p pVar = a10.f7444i;
            if (pVar != null) {
                Bitmap.Config[] configArr = U4.t.f10494a;
                if (l.a(Looper.myLooper(), Looper.getMainLooper()) && a10.f7442F) {
                    a10.f7442F = false;
                    pVar.f7434i = k10;
                    return pVar;
                }
            }
            A0 a02 = a10.f7445z;
            if (a02 != null) {
                a02.e((CancellationException) null);
            }
            a10.f7445z = null;
            p pVar2 = new p(a10.f7443f, k10);
            a10.f7444i = pVar2;
            return pVar2;
        }
    }
}
