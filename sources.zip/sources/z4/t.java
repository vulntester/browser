package z4;

import android.content.Context;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.jvm.internal.l;

public final class t {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ AtomicReference f31864a = new AtomicReference((Object) null);

    public interface a {
        m a(Context context);
    }

    public static final i a(Context context) {
        i iVar;
        i iVar2;
        i iVar3;
        a aVar;
        a aVar2;
        AtomicReference atomicReference = f31864a;
        Object obj = atomicReference.get();
        if (obj instanceof i) {
            iVar = (i) obj;
        } else {
            iVar = null;
        }
        if (iVar != null) {
            return iVar;
        }
        i iVar4 = null;
        while (true) {
            Object obj2 = atomicReference.get();
            if (obj2 instanceof i) {
                iVar3 = (i) obj2;
                iVar2 = iVar4;
            } else {
                if (iVar4 == null) {
                    if (obj2 instanceof a) {
                        aVar = (a) obj2;
                    } else {
                        aVar = null;
                    }
                    if (aVar != null) {
                        iVar4 = aVar.a(context);
                    } else {
                        Context applicationContext = context.getApplicationContext();
                        if (applicationContext instanceof a) {
                            aVar2 = (a) applicationContext;
                        } else {
                            aVar2 = null;
                        }
                        if (aVar2 != null) {
                            iVar4 = aVar2.a(context);
                        } else {
                            iVar4 = v.f31865a.a(context);
                        }
                    }
                }
                iVar3 = iVar4;
                iVar2 = iVar3;
            }
            while (!atomicReference.compareAndSet(obj2, iVar3)) {
                if (atomicReference.get() != obj2) {
                    iVar4 = iVar2;
                }
            }
            l.d(iVar3, "null cannot be cast to non-null type coil3.ImageLoader");
            return iVar3;
        }
    }
}
