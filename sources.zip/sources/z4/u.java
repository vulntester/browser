package z4;

import android.content.Context;
import java.util.LinkedHashMap;
import xa.C4959D;
import z4.C3562e;
import z4.i;
import z4.t;

public final /* synthetic */ class u implements t.a {
    public final m a(Context context) {
        i.a aVar = new i.a(context);
        C4959D d10 = C4959D.f44058a;
        C3562e.b<C4959D> bVar = v.f31866b;
        LinkedHashMap linkedHashMap = aVar.f31825d.f31819a;
        if (d10 != null) {
            linkedHashMap.put(bVar, d10);
        } else {
            linkedHashMap.remove(bVar);
        }
        return aVar.a();
    }
}
