package z4;

import xa.C4959D;
import z4.C3562e;

public final class v {

    /* renamed from: a  reason: collision with root package name */
    public static final u f31865a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public static final C3562e.b<C4959D> f31866b = new C3562e.b<>(C4959D.f44058a);
}
