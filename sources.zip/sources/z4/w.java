package z4;

import kotlin.jvm.internal.l;

public final class w {

    /* renamed from: a  reason: collision with root package name */
    public final String f31867a;

    /* renamed from: b  reason: collision with root package name */
    public final String f31868b;

    /* renamed from: c  reason: collision with root package name */
    public final String f31869c;

    /* renamed from: d  reason: collision with root package name */
    public final String f31870d;

    /* renamed from: e  reason: collision with root package name */
    public final String f31871e;

    public w(String str, String str2, String str3, String str4, String str5) {
        this.f31867a = str;
        this.f31868b = str2;
        this.f31869c = str3;
        this.f31870d = str4;
        this.f31871e = str5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof w) || !l.a(((w) obj).f31867a, this.f31867a)) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.f31867a.hashCode();
    }

    public final String toString() {
        return this.f31867a;
    }
}
