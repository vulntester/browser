package z5;

import C5.j;
import y5.C3493b;
import y5.C3496e;

/* renamed from: z5.a  reason: case insensitive filesystem */
public abstract class C3563a<T> implements C3566d<T> {

    /* renamed from: f  reason: collision with root package name */
    public final int f31872f;

    /* renamed from: i  reason: collision with root package name */
    public final int f31873i;

    /* renamed from: z  reason: collision with root package name */
    public C3496e f31874z;

    public C3563a() {
        if (j.g(Integer.MIN_VALUE, Integer.MIN_VALUE)) {
            this.f31872f = Integer.MIN_VALUE;
            this.f31873i = Integer.MIN_VALUE;
            return;
        }
        throw new IllegalArgumentException("Width and height must both be > 0 or Target#SIZE_ORIGINAL, but given width: -2147483648 and height: -2147483648");
    }

    public final void d(C3496e eVar) {
        this.f31874z = eVar;
    }

    public final void f(C3496e eVar) {
        eVar.a(this.f31872f, this.f31873i);
    }

    public final C3493b getRequest() {
        return this.f31874z;
    }

    public final void a() {
    }

    public final void b() {
    }

    public final void e() {
    }

    public final void i() {
    }

    public final void h(C3496e eVar) {
    }
}
