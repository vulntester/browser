package z5;

import Q7.e;
import V6.b;
import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.ImageView;
import com.internet.tvbrowser.R;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import y5.C3493b;
import y5.C3496e;

/* renamed from: z5.b  reason: case insensitive filesystem */
public abstract class C3564b<T extends View, Z> implements C3566d<Z> {

    /* renamed from: f  reason: collision with root package name */
    public final a f31875f;

    /* renamed from: i  reason: collision with root package name */
    public final ImageView f31876i;

    /* renamed from: z5.b$a */
    public static final class a {

        /* renamed from: d  reason: collision with root package name */
        public static Integer f31877d;

        /* renamed from: a  reason: collision with root package name */
        public final ImageView f31878a;

        /* renamed from: b  reason: collision with root package name */
        public final ArrayList f31879b = new ArrayList();

        /* renamed from: c  reason: collision with root package name */
        public C0311a f31880c;

        /* renamed from: z5.b$a$a  reason: collision with other inner class name */
        public static final class C0311a implements ViewTreeObserver.OnPreDrawListener {

            /* renamed from: f  reason: collision with root package name */
            public final WeakReference<a> f31881f;

            public C0311a(a aVar) {
                this.f31881f = new WeakReference<>(aVar);
            }

            public final boolean onPreDraw() {
                int i10;
                if (Log.isLoggable("CustomViewTarget", 2)) {
                    Log.v("CustomViewTarget", "OnGlobalLayoutListener called attachStateListener=" + this);
                }
                a aVar = this.f31881f.get();
                if (aVar == null) {
                    return true;
                }
                ArrayList arrayList = aVar.f31879b;
                if (arrayList.isEmpty()) {
                    return true;
                }
                ImageView imageView = aVar.f31878a;
                int paddingRight = imageView.getPaddingRight() + imageView.getPaddingLeft();
                ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
                int i11 = 0;
                if (layoutParams != null) {
                    i10 = layoutParams.width;
                } else {
                    i10 = 0;
                }
                int a10 = aVar.a(imageView.getWidth(), i10, paddingRight);
                int paddingBottom = imageView.getPaddingBottom() + imageView.getPaddingTop();
                ViewGroup.LayoutParams layoutParams2 = imageView.getLayoutParams();
                if (layoutParams2 != null) {
                    i11 = layoutParams2.height;
                }
                int a11 = aVar.a(imageView.getHeight(), i11, paddingBottom);
                if (a10 <= 0 && a10 != Integer.MIN_VALUE) {
                    return true;
                }
                if (a11 <= 0 && a11 != Integer.MIN_VALUE) {
                    return true;
                }
                Iterator it = new ArrayList(arrayList).iterator();
                while (it.hasNext()) {
                    ((C3565c) it.next()).a(a10, a11);
                }
                ViewTreeObserver viewTreeObserver = imageView.getViewTreeObserver();
                if (viewTreeObserver.isAlive()) {
                    viewTreeObserver.removeOnPreDrawListener(aVar.f31880c);
                }
                aVar.f31880c = null;
                arrayList.clear();
                return true;
            }
        }

        public a(ImageView imageView) {
            this.f31878a = imageView;
        }

        public final int a(int i10, int i11, int i12) {
            int i13 = i11 - i12;
            if (i13 > 0) {
                return i13;
            }
            int i14 = i10 - i12;
            if (i14 > 0) {
                return i14;
            }
            ImageView imageView = this.f31878a;
            if (imageView.isLayoutRequested() || i11 != -2) {
                return 0;
            }
            if (Log.isLoggable("CustomViewTarget", 4)) {
                Log.i("CustomViewTarget", "Glide treats LayoutParams.WRAP_CONTENT as a request for an image the size of this device's screen dimensions. If you want to load the original image and are ok with the corresponding memory cost and OOMs (depending on the input size), use .override(Target.SIZE_ORIGINAL). Otherwise, use LayoutParams.MATCH_PARENT, set layout_width and layout_height to fixed dimension, or use .override() with fixed dimensions.");
            }
            Context context = imageView.getContext();
            if (f31877d == null) {
                WindowManager windowManager = (WindowManager) context.getSystemService("window");
                b.f(windowManager, "Argument must not be null");
                Display defaultDisplay = windowManager.getDefaultDisplay();
                Point point = new Point();
                defaultDisplay.getSize(point);
                f31877d = Integer.valueOf(Math.max(point.x, point.y));
            }
            return f31877d.intValue();
        }
    }

    public C3564b(ImageView imageView) {
        b.f(imageView, "Argument must not be null");
        this.f31876i = imageView;
        this.f31875f = new a(imageView);
    }

    public final void d(C3496e eVar) {
        this.f31876i.setTag(R.id.glide_custom_view_target_tag, eVar);
    }

    public final void f(C3496e eVar) {
        int i10;
        a aVar = this.f31875f;
        ImageView imageView = aVar.f31878a;
        int paddingRight = imageView.getPaddingRight() + imageView.getPaddingLeft();
        ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
        int i11 = 0;
        if (layoutParams != null) {
            i10 = layoutParams.width;
        } else {
            i10 = 0;
        }
        int a10 = aVar.a(imageView.getWidth(), i10, paddingRight);
        ImageView imageView2 = aVar.f31878a;
        int paddingBottom = imageView2.getPaddingBottom() + imageView2.getPaddingTop();
        ViewGroup.LayoutParams layoutParams2 = imageView2.getLayoutParams();
        if (layoutParams2 != null) {
            i11 = layoutParams2.height;
        }
        int a11 = aVar.a(imageView2.getHeight(), i11, paddingBottom);
        if ((a10 > 0 || a10 == Integer.MIN_VALUE) && (a11 > 0 || a11 == Integer.MIN_VALUE)) {
            eVar.a(a10, a11);
            return;
        }
        ArrayList arrayList = aVar.f31879b;
        if (!arrayList.contains(eVar)) {
            arrayList.add(eVar);
        }
        if (aVar.f31880c == null) {
            ViewTreeObserver viewTreeObserver = imageView2.getViewTreeObserver();
            a.C0311a aVar2 = new a.C0311a(aVar);
            aVar.f31880c = aVar2;
            viewTreeObserver.addOnPreDrawListener(aVar2);
        }
    }

    public final void g(Drawable drawable) {
        a aVar = this.f31875f;
        ViewTreeObserver viewTreeObserver = aVar.f31878a.getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeOnPreDrawListener(aVar.f31880c);
        }
        aVar.f31880c = null;
        aVar.f31879b.clear();
        ((e) this).f7943z.f20052z0.setImageDrawable(drawable);
    }

    public final C3493b getRequest() {
        Object tag = this.f31876i.getTag(R.id.glide_custom_view_target_tag);
        if (tag == null) {
            return null;
        }
        if (tag instanceof C3493b) {
            return (C3493b) tag;
        }
        throw new IllegalArgumentException("You must not pass non-R.id ids to setTag(id)");
    }

    public final void h(C3496e eVar) {
        this.f31875f.f31879b.remove(eVar);
    }

    public final String toString() {
        return "Target for: " + this.f31876i;
    }

    public final void a() {
    }

    public final void e() {
    }

    public final void i() {
    }
}
