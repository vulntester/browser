package z5;

/* renamed from: z5.c  reason: case insensitive filesystem */
public interface C3565c {
    void a(int i10, int i11);
}
