package z5;

import android.graphics.drawable.Drawable;
import v5.e;
import y5.C3493b;
import y5.C3496e;

/* renamed from: z5.d  reason: case insensitive filesystem */
public interface C3566d<R> extends e {
    void b();

    void c(Object obj);

    void d(C3496e eVar);

    void f(C3496e eVar);

    void g(Drawable drawable);

    C3493b getRequest();

    void h(C3496e eVar);
}
