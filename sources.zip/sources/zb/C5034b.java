package zb;

import Db.i;
import xb.C4988b;
import xb.j;
import xb.w;

/* renamed from: zb.b  reason: case insensitive filesystem */
public final class C5034b {

    /* renamed from: A  reason: collision with root package name */
    public static final a f44765A;

    /* renamed from: B  reason: collision with root package name */
    public static final a f44766B;

    /* renamed from: C  reason: collision with root package name */
    public static final a f44767C;

    /* renamed from: D  reason: collision with root package name */
    public static final a f44768D;

    /* renamed from: E  reason: collision with root package name */
    public static final a f44769E;

    /* renamed from: F  reason: collision with root package name */
    public static final a f44770F;

    /* renamed from: G  reason: collision with root package name */
    public static final a f44771G;

    /* renamed from: H  reason: collision with root package name */
    public static final a f44772H;

    /* renamed from: I  reason: collision with root package name */
    public static final a f44773I;

    /* renamed from: J  reason: collision with root package name */
    public static final a f44774J;

    /* renamed from: K  reason: collision with root package name */
    public static final a f44775K;

    /* renamed from: L  reason: collision with root package name */
    public static final a f44776L;

    /* renamed from: M  reason: collision with root package name */
    public static final a f44777M;

    /* renamed from: N  reason: collision with root package name */
    public static final a f44778N = c.b();

    /* renamed from: a  reason: collision with root package name */
    public static final a f44779a;

    /* renamed from: b  reason: collision with root package name */
    public static final a f44780b;

    /* renamed from: c  reason: collision with root package name */
    public static final a f44781c;

    /* renamed from: d  reason: collision with root package name */
    public static final C0473b f44782d;

    /* renamed from: e  reason: collision with root package name */
    public static final C0473b f44783e;

    /* renamed from: f  reason: collision with root package name */
    public static final C0473b f44784f;

    /* renamed from: g  reason: collision with root package name */
    public static final a f44785g;

    /* renamed from: h  reason: collision with root package name */
    public static final a f44786h;

    /* renamed from: i  reason: collision with root package name */
    public static final a f44787i;

    /* renamed from: j  reason: collision with root package name */
    public static final a f44788j;

    /* renamed from: k  reason: collision with root package name */
    public static final a f44789k;

    /* renamed from: l  reason: collision with root package name */
    public static final a f44790l;

    /* renamed from: m  reason: collision with root package name */
    public static final a f44791m;

    /* renamed from: n  reason: collision with root package name */
    public static final a f44792n;

    /* renamed from: o  reason: collision with root package name */
    public static final a f44793o;

    /* renamed from: p  reason: collision with root package name */
    public static final C0473b f44794p;

    /* renamed from: q  reason: collision with root package name */
    public static final a f44795q;

    /* renamed from: r  reason: collision with root package name */
    public static final a f44796r;

    /* renamed from: s  reason: collision with root package name */
    public static final a f44797s;

    /* renamed from: t  reason: collision with root package name */
    public static final a f44798t;

    /* renamed from: u  reason: collision with root package name */
    public static final a f44799u;

    /* renamed from: v  reason: collision with root package name */
    public static final a f44800v;

    /* renamed from: w  reason: collision with root package name */
    public static final a f44801w;

    /* renamed from: x  reason: collision with root package name */
    public static final a f44802x;

    /* renamed from: y  reason: collision with root package name */
    public static final a f44803y;

    /* renamed from: z  reason: collision with root package name */
    public static final a f44804z;

    /* renamed from: zb.b$a */
    public static class a extends c<Boolean> {
        public final Boolean c(int i10) {
            boolean z10 = true;
            if ((i10 & (1 << this.f44806a)) == 0) {
                z10 = false;
            }
            return Boolean.valueOf(z10);
        }
    }

    /* renamed from: zb.b$b  reason: collision with other inner class name */
    public static class C0473b<E extends i.a> extends c<E> {

        /* renamed from: c  reason: collision with root package name */
        public final E[] f44805c;

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public C0473b(int r5, E[] r6) {
            /*
                r4 = this;
                if (r6 == 0) goto L_0x0033
                int r0 = r6.length
                r1 = 1
                int r0 = r0 - r1
                if (r0 != 0) goto L_0x0008
                goto L_0x0012
            L_0x0008:
                r2 = 31
            L_0x000a:
                if (r2 < 0) goto L_0x001b
                int r3 = r1 << r2
                r3 = r3 & r0
                if (r3 == 0) goto L_0x0018
                int r1 = r1 + r2
            L_0x0012:
                r4.<init>(r5, r1)
                r4.f44805c = r6
                return
            L_0x0018:
                int r2 = r2 + -1
                goto L_0x000a
            L_0x001b:
                java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "Empty enum: "
                r0.<init>(r1)
                java.lang.Class r6 = r6.getClass()
                r0.append(r6)
                java.lang.String r6 = r0.toString()
                r5.<init>(r6)
                throw r5
            L_0x0033:
                java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
                java.lang.String r6 = "Argument for @NotNull parameter 'enumEntries' of kotlin/reflect/jvm/internal/impl/metadata/deserialization/Flags$EnumLiteFlagField.bitWidth must not be null"
                r5.<init>(r6)
                throw r5
            */
            throw new UnsupportedOperationException("Method not decompiled: zb.C5034b.C0473b.<init>(int, Db.i$a[]):void");
        }

        public final Object c(int i10) {
            int i11 = this.f44806a;
            int i12 = (i10 & (((1 << this.f44807b) - 1) << i11)) >> i11;
            for (E e10 : this.f44805c) {
                if (e10.a() == i12) {
                    return e10;
                }
            }
            return null;
        }
    }

    /* renamed from: zb.b$c */
    public static abstract class c<E> {

        /* renamed from: a  reason: collision with root package name */
        public final int f44806a;

        /* renamed from: b  reason: collision with root package name */
        public final int f44807b;

        public c(int i10, int i11) {
            this.f44806a = i10;
            this.f44807b = i11;
        }

        /* JADX WARNING: type inference failed for: r2v2, types: [zb.b$c, zb.b$a] */
        public static a a(c<?> cVar) {
            return new c(cVar.f44806a + cVar.f44807b, 1);
        }

        /* JADX WARNING: type inference failed for: r0v0, types: [zb.b$c, zb.b$a] */
        public static a b() {
            return new c(0, 1);
        }
    }

    static {
        a b10 = c.b();
        f44779a = b10;
        f44780b = c.a(b10);
        a b11 = c.b();
        f44781c = b11;
        w[] values = w.values();
        int i10 = b11.f44806a + b11.f44807b;
        C0473b bVar = new C0473b(i10, values);
        f44782d = bVar;
        j[] values2 = j.values();
        int i11 = i10 + bVar.f44807b;
        C0473b bVar2 = new C0473b(i11, values2);
        f44783e = bVar2;
        C4988b.c[] values3 = C4988b.c.values();
        int i12 = bVar2.f44807b;
        C0473b bVar3 = new C0473b(i11 + i12, values3);
        f44784f = bVar3;
        a a10 = c.a(bVar3);
        f44785g = a10;
        a a11 = c.a(a10);
        f44786h = a11;
        a a12 = c.a(a11);
        f44787i = a12;
        a a13 = c.a(a12);
        f44788j = a13;
        a a14 = c.a(a13);
        f44789k = a14;
        a a15 = c.a(a14);
        f44790l = a15;
        f44791m = c.a(a15);
        a a16 = c.a(bVar);
        f44792n = a16;
        f44793o = c.a(a16);
        C0473b bVar4 = new C0473b(i11 + i12, xb.i.values());
        f44794p = bVar4;
        a a17 = c.a(bVar4);
        f44795q = a17;
        a a18 = c.a(a17);
        f44796r = a18;
        a a19 = c.a(a18);
        f44797s = a19;
        a a20 = c.a(a19);
        f44798t = a20;
        a a21 = c.a(a20);
        f44799u = a21;
        a a22 = c.a(a21);
        f44800v = a22;
        a a23 = c.a(a22);
        f44801w = a23;
        f44802x = c.a(a23);
        a a24 = c.a(bVar4);
        f44803y = a24;
        a a25 = c.a(a24);
        f44804z = a25;
        a a26 = c.a(a25);
        f44765A = a26;
        a a27 = c.a(a26);
        f44766B = a27;
        a a28 = c.a(a27);
        f44767C = a28;
        a a29 = c.a(a28);
        f44768D = a29;
        a a30 = c.a(a29);
        f44769E = a30;
        a a31 = c.a(a30);
        f44770F = a31;
        f44771G = c.a(a31);
        a a32 = c.a(b11);
        f44772H = a32;
        a a33 = c.a(a32);
        f44773I = a33;
        f44774J = c.a(a33);
        a a34 = c.a(bVar2);
        f44775K = a34;
        a a35 = c.a(a34);
        f44776L = a35;
        f44777M = c.a(a35);
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0036  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x003b  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0040  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x004a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static /* synthetic */ void a(int r5) {
        /*
            r0 = 3
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r1 = 1
            r2 = 0
            r3 = 2
            if (r5 == r1) goto L_0x002b
            if (r5 == r3) goto L_0x0026
            r4 = 5
            if (r5 == r4) goto L_0x002b
            r4 = 6
            if (r5 == r4) goto L_0x0021
            r4 = 8
            if (r5 == r4) goto L_0x002b
            r4 = 9
            if (r5 == r4) goto L_0x0021
            r4 = 11
            if (r5 == r4) goto L_0x002b
            java.lang.String r4 = "visibility"
            r0[r2] = r4
            goto L_0x002f
        L_0x0021:
            java.lang.String r4 = "memberKind"
            r0[r2] = r4
            goto L_0x002f
        L_0x0026:
            java.lang.String r4 = "kind"
            r0[r2] = r4
            goto L_0x002f
        L_0x002b:
            java.lang.String r4 = "modality"
            r0[r2] = r4
        L_0x002f:
            java.lang.String r2 = "kotlin/reflect/jvm/internal/impl/metadata/deserialization/Flags"
            r0[r1] = r2
            switch(r5) {
                case 3: goto L_0x004a;
                case 4: goto L_0x0045;
                case 5: goto L_0x0045;
                case 6: goto L_0x0045;
                case 7: goto L_0x0040;
                case 8: goto L_0x0040;
                case 9: goto L_0x0040;
                case 10: goto L_0x003b;
                case 11: goto L_0x003b;
                default: goto L_0x0036;
            }
        L_0x0036:
            java.lang.String r5 = "getClassFlags"
            r0[r3] = r5
            goto L_0x004e
        L_0x003b:
            java.lang.String r5 = "getAccessorFlags"
            r0[r3] = r5
            goto L_0x004e
        L_0x0040:
            java.lang.String r5 = "getPropertyFlags"
            r0[r3] = r5
            goto L_0x004e
        L_0x0045:
            java.lang.String r5 = "getFunctionFlags"
            r0[r3] = r5
            goto L_0x004e
        L_0x004a:
            java.lang.String r5 = "getConstructorFlags"
            r0[r3] = r5
        L_0x004e:
            java.lang.String r5 = "Argument for @NotNull parameter '%s' of %s.%s must not be null"
            java.lang.String r5 = java.lang.String.format(r5, r0)
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            r0.<init>(r5)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: zb.C5034b.a(int):void");
    }
}
