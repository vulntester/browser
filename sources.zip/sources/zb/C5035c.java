package zb;

/* renamed from: zb.c  reason: case insensitive filesystem */
public interface C5035c {
    String a(int i10);

    String b(int i10);

    boolean c(int i10);
}
