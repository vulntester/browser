package zb;

import java.util.LinkedList;
import java.util.List;
import kotlin.jvm.internal.l;
import xa.C4979s;
import xb.n;
import xb.o;
import ya.s;

/* renamed from: zb.d  reason: case insensitive filesystem */
public final class C5036d implements C5035c {

    /* renamed from: a  reason: collision with root package name */
    public final o f44808a;

    /* renamed from: b  reason: collision with root package name */
    public final n f44809b;

    public C5036d(o oVar, n nVar) {
        l.f(oVar, "strings");
        l.f(nVar, "qualifiedNames");
        this.f44808a = oVar;
        this.f44809b = nVar;
    }

    public final String a(int i10) {
        C4979s<List<String>, List<String>, Boolean> d10 = d(i10);
        List list = (List) d10.f44080f;
        String a02 = s.a0((List) d10.f44081i, ".", (String) null, (String) null, (Na.l) null, 62);
        if (list.isEmpty()) {
            return a02;
        }
        return s.a0(list, "/", (String) null, (String) null, (Na.l) null, 62) + '/' + a02;
    }

    public final String b(int i10) {
        String str = (String) this.f44808a.f44435i.get(i10);
        l.e(str, "getString(...)");
        return str;
    }

    public final boolean c(int i10) {
        return ((Boolean) d(i10).f44082z).booleanValue();
    }

    public final C4979s<List<String>, List<String>, Boolean> d(int i10) {
        LinkedList linkedList = new LinkedList();
        LinkedList linkedList2 = new LinkedList();
        boolean z10 = false;
        while (i10 != -1) {
            n.c cVar = this.f44809b.f44409i.get(i10);
            String str = (String) this.f44808a.f44435i.get(cVar.f44415E);
            n.c.C0463c cVar2 = cVar.f44416F;
            l.c(cVar2);
            int ordinal = cVar2.ordinal();
            if (ordinal == 0) {
                linkedList2.addFirst(str);
            } else if (ordinal == 1) {
                linkedList.addFirst(str);
            } else if (ordinal == 2) {
                linkedList2.addFirst(str);
                z10 = true;
            } else {
                throw new RuntimeException();
            }
            i10 = cVar.f44421z;
        }
        return new C4979s<>(linkedList, linkedList2, Boolean.valueOf(z10));
    }
}
