package zb;

import Db.g;
import Db.h;
import java.util.List;
import kotlin.jvm.internal.l;

/* renamed from: zb.e  reason: case insensitive filesystem */
public final class C5037e {
    public static final <M extends h.c<M>, T> T a(h.c<M> cVar, h.e<M, T> eVar) {
        l.f(cVar, "<this>");
        l.f(eVar, "extension");
        if (cVar.l(eVar)) {
            return cVar.k(eVar);
        }
        return null;
    }

    public static final <M extends h.c<M>, T> T b(h.c<M> cVar, h.e<M, List<T>> eVar, int i10) {
        int i11;
        l.f(cVar, "<this>");
        l.f(eVar, "extension");
        cVar.o(eVar);
        g<h.d> gVar = cVar.f34290f;
        gVar.getClass();
        h.d dVar = eVar.f34299d;
        if (dVar.f34295z) {
            Object e10 = gVar.e(dVar);
            if (e10 == null) {
                i11 = 0;
            } else {
                i11 = ((List) e10).size();
            }
            if (i10 >= i11) {
                return null;
            }
            cVar.o(eVar);
            if (dVar.f34295z) {
                Object e11 = gVar.e(dVar);
                if (e11 != null) {
                    return eVar.a(((List) e11).get(i10));
                }
                throw new IndexOutOfBoundsException();
            }
            throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
        }
        throw new IllegalArgumentException("getRepeatedField() can only be called on repeated fields.");
    }
}
