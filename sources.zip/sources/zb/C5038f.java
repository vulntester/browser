package zb;

import kotlin.jvm.internal.l;
import xb.h;
import xb.m;
import xb.p;
import xb.t;

/* renamed from: zb.f  reason: case insensitive filesystem */
public final class C5038f {
    public static final p a(p pVar, C5039g gVar) {
        l.f(pVar, "<this>");
        int i10 = pVar.f44458z;
        if ((i10 & 256) == 256) {
            return pVar.f44450N;
        }
        if ((i10 & 512) == 512) {
            return gVar.a(pVar.f44451O);
        }
        return null;
    }

    public static final p b(h hVar, C5039g gVar) {
        l.f(hVar, "<this>");
        l.f(gVar, "typeTable");
        int i10 = hVar.f44317z;
        if ((i10 & 32) == 32) {
            return hVar.f44305K;
        }
        if ((i10 & 64) == 64) {
            return gVar.a(hVar.f44306L);
        }
        return null;
    }

    public static final p c(h hVar, C5039g gVar) {
        l.f(hVar, "<this>");
        l.f(gVar, "typeTable");
        int i10 = hVar.f44317z;
        if ((i10 & 8) == 8) {
            p pVar = hVar.f44302H;
            l.e(pVar, "getReturnType(...)");
            return pVar;
        } else if ((i10 & 16) == 16) {
            return gVar.a(hVar.f44303I);
        } else {
            throw new IllegalStateException("No returnType in ProtoBuf.Function");
        }
    }

    public static final p d(m mVar, C5039g gVar) {
        l.f(mVar, "<this>");
        l.f(gVar, "typeTable");
        int i10 = mVar.f44389z;
        if ((i10 & 8) == 8) {
            p pVar = mVar.f44374H;
            l.e(pVar, "getReturnType(...)");
            return pVar;
        } else if ((i10 & 16) == 16) {
            return gVar.a(mVar.f44375I);
        } else {
            throw new IllegalStateException("No returnType in ProtoBuf.Property");
        }
    }

    public static final p e(t tVar, C5039g gVar) {
        l.f(gVar, "typeTable");
        int i10 = tVar.f44565z;
        if ((i10 & 4) == 4) {
            p pVar = tVar.f44558G;
            l.e(pVar, "getType(...)");
            return pVar;
        } else if ((i10 & 8) == 8) {
            return gVar.a(tVar.f44559H);
        } else {
            throw new IllegalStateException("No type in ProtoBuf.ValueParameter");
        }
    }
}
