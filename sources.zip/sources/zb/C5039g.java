package zb;

import Db.v;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.l;
import xb.p;
import xb.s;
import ya.n;

/* renamed from: zb.g  reason: case insensitive filesystem */
public final class C5039g {

    /* renamed from: a  reason: collision with root package name */
    public final List<p> f44810a;

    public C5039g(s sVar) {
        l.f(sVar, "typeTable");
        List<p> list = sVar.f44550z;
        if ((sVar.f44549i & 1) == 1) {
            int i10 = sVar.f44545E;
            l.e(list, "getTypeList(...)");
            ArrayList arrayList = new ArrayList(n.v(10, list));
            int i11 = 0;
            for (T next : list) {
                int i12 = i11 + 1;
                if (i11 >= 0) {
                    p pVar = (p) next;
                    if (i11 >= i10) {
                        pVar.getClass();
                        p.c q10 = p.q(pVar);
                        q10.f44478E |= 2;
                        q10.f44480G = true;
                        pVar = q10.k();
                        if (!pVar.c()) {
                            throw new v();
                        }
                    }
                    arrayList.add(pVar);
                    i11 = i12;
                } else {
                    n.C();
                    throw null;
                }
            }
            list = arrayList;
        }
        l.e(list, "run(...)");
        this.f44810a = list;
    }

    public final p a(int i10) {
        return this.f44810a.get(i10);
    }
}
